---
name: tests-domain-ddd-dotnet
description: "Use SEMPRE que o usuário pedir testes unitários para código de domínio C# / .NET escrito seguindo o padrão da skill domain-codegen-ddd-dotnet (Aggregate Root, Entity, ValueObject, Enumeration, Domain Event, Domain Service, factory de erros). Cobre três cenários: (1) gerar testes do zero para Aggregate completo, (2) adicionar testes para comportamento ou invariante novos, (3) revisar/expandir suíte existente identificando lacunas. Dispare em: 'cria os testes desse Aggregate', 'gera testes unitários pra Bill', 'preciso de testes pro método Approve', 'cobre essa invariante com teste', 'testa esse Value Object', 'testa esse Domain Service'. Stack: xUnit + assertions nativas (Assert.Equal etc.) + Object Mother manual. Cobre: Aggregate Root, Value Objects, Smart Enums, Entities internas via Root, Domain Services (sem mocks), factories de erros. NÃO use para testes de integração, Repository, Application Service, EF, ou frameworks que não xUnit."
---

# DDD .NET Domain Tests

Skill especializada em **escrever testes unitários para código de domínio C# / .NET** que segue o padrão da skill irmã `domain-codegen-ddd-dotnet`.

Cobre três cenários:

1. **Aggregate completo do zero**: usuário traz o código do domínio, skill gera suíte completa.
2. **Comportamento novo**: usuário adicionou método/invariante, skill gera só os testes faltantes.
3. **Revisar suíte**: skill identifica lacunas (transições não cobertas, eventos não verificados, invariantes não testadas).

## Stack obrigatória

- **Framework**: xUnit (não NUnit, não MSTest).
- **Assertions**: `Xunit.Assert` nativas (não FluentAssertions, não Shouldly).
- **Geração de dados**: **Object Mother / Test Builders manuais**. Sem Bogus, sem AutoFixture.
- **Mocks**: não use mocks no domínio. Domínio puro testa-se sem dependências externas.

## Escopo do que a skill testa

✅ **Aggregate Root**: factory `Create`, cada método de mutação, cada invariante, cada transição de status, emissão de eventos com payload correto, atualização de `UpdatedAt`.

✅ **Entity interna**: comportamento através da Root (nunca testar `internal` direto), mudanças de estado, validações no construtor.

✅ **Value Object**: criação válida, rejeição de valores inválidos (cada regra de validação), igualdade por valor, imutabilidade, métodos de comportamento (`Add`, `Subtract`, `Combine`, etc.).

✅ **Smart Enum (Enumeration)**: cada transição válida em `CanTransitionTo`, cada transição inválida (matriz completa), `FromValue`/`FromDisplayName`, `GetAll`.

✅ **Domain Event**: emissão pelo Aggregate, **payload exato** dos dados, contagem (não emite duplicado, não emite quando não deveria).

✅ **Domain Service**: cada regra de negócio coordenada, validação de inputs, side effects nos Aggregates passados (se houver), eventos emitidos pelos Aggregates como consequência. Aggregates reais via Mother — **sem mocks**. Detalhes em `references/domain-services-tests.md`.

✅ **Factory de erros**: cada método retorna `DomainException` com `Id` correto, `MessageTemplate` não-vazia, `Parameters` consistente, `SourcePath` preenchido. Vale para factories de Aggregate (`<Aggregate>Errors.cs`) e de Domain Service (`<Service>Errors.cs`).

❌ **Fora de escopo** (não gere a menos que pedido explicitamente): testes de Repository, EF Core, Application Services, Specifications, integração, performance, snapshot.

## Workflow por cenário

### Cenário A — Aggregate completo do zero
1. Leia o código do Aggregate Root + Entities internas + VOs + Eventos + Smart Enums + factory de erros.
2. Identifique:
   - Comportamentos públicos do Aggregate Root (cada método = 1 grupo de testes).
   - Invariantes (cada uma = 1 teste de violação).
   - Transições de status (cada par válido/inválido = 1 teste).
   - VOs com regras de validação (cada regra = 1 teste).
   - Eventos emitidos (cada um = 1 teste de emissão + payload).
3. **Gere primeiro o Object Mother** do Aggregate (e dos VOs onde fizer sentido).
4. Gere os arquivos de teste por classe, na ordem: VOs → Smart Enums → Entities internas → Aggregate Root → Eventos → factory de erros.
5. Liste lacunas reconhecidas no fim.

### Cenário B — Comportamento novo
1. Leia o código atual + diff/descrição da mudança.
2. Identifique novos casos a cobrir (novo método, nova invariante, novo evento).
3. **Reuse o Mother existente** (se houver) ou crie um cenário novo (`BillMother.ReadyForApproval()`).
4. Gere apenas os arquivos novos ou os métodos a serem adicionados em arquivos existentes.

### Cenário C — Revisar suíte
1. Compare código de domínio vs. testes existentes.
2. Liste lacunas:
   - Transição de status sem teste.
   - Invariante sem teste de violação.
   - Evento sem verificação de payload.
   - VO sem teste de igualdade.
3. Gere apenas os testes faltantes; não duplique o que já existe.

## Convenções obrigatórias

→ Detalhes em `references/test-conventions.md` e `references/object-mother-pattern.md`. Resumo não-negociável:

- **Idioma**: tudo em inglês (nomes de classes, métodos, variáveis), incluindo nomes de testes. Mensagens de `DomainException` continuam em PT (mas o teste compara o `Id`, não a mensagem).
- **Nome do método de teste**: padrão `MethodName_StateUnderTest_ExpectedBehavior` (ex.: `Approve_WhenBillIsAwaitingApproval_ShouldChangeStatusToApproved`).
- **Estrutura AAA**: Arrange / Act / Assert separados visualmente por linha em branco. Sem comentários `// Arrange`, `// Act`, `// Assert` (o espaço já delimita).
- **Um arquivo por classe testada**, dentro de uma pasta por Aggregate (ver estrutura abaixo).
- **`[Fact]` para casos únicos**, **`[Theory]` + `[InlineData]`** quando o teste verifica múltiplos inputs com mesma estrutura (ex.: matriz de transições, valores inválidos de VO).
- **Object Mother** para construir Aggregates/Entities. Nunca instanciar direto nos testes — a duplicação e o ruído de setup escondem a intenção.
- **Cuidado com viciamento em valores fixos**: ver `references/object-mother-pattern.md` para o anti-padrão e como evitá-lo.
- **Asserções de evento**: usar `PullDomainEvents()` e validar tipo, contagem, e **cada campo do payload** individualmente.
- **Asserções de erro**: capturar `DomainException` via `Assert.Throws<DomainException>`, validar `Id` (não a mensagem em PT).
- **`DateTime.UtcNow` proibido em testes** — use uma constante fixa (`new DateTime(2024, 1, 15, 10, 30, 0, DateTimeKind.Utc)`) ou parâmetro do Mother. Tempos aleatórios geram testes flaky.

## Estrutura de arquivos

Cada Bounded Context é seu próprio projeto. O projeto de testes do domínio segue o nome do projeto de domínio com sufixo `.Tests`. A estrutura interna espelha a do projeto de domínio, **sem camada de BoundedContext** (o projeto inteiro já é o BC).

```
<BoundedContext>.Domain.Tests/
├── Services/                                ← Testes de Domain Services (se houver)
│   ├── <Service>Tests.cs
│   └── <Service>ErrorsTests.cs
└── <Aggregate>/
    ├── Mothers/
    │   ├── <Aggregate>Mother.cs            ← Object Mother do Aggregate Root
    │   └── <ValueObject>Mother.cs          ← Mothers de VOs complexos (opcional)
    ├── <Aggregate>Tests.cs                 ← Aggregate Root: comportamentos, invariantes, transições, eventos
    ├── <InternalEntity>Tests.cs            ← Comportamento via Root (Entity interna não tem teste direto)
    ├── <ValueObject>Tests.cs               ← Cada VO em arquivo próprio
    ├── <SmartEnum>Tests.cs                 ← Smart Enum: transições, FromValue, etc.
    └── <Aggregate>ErrorsTests.cs           ← Factory: existência de cada erro com Id correto
```

Erros transversais do BC (aqueles em `<BoundedContext>Errors.cs`, sem nome de Aggregate) ficam em `<BoundedContext>ErrorsTests.cs` na raiz do projeto de testes.

A pasta `Services/` é **opcional** — só existe se o projeto de domínio tiver Domain Services. Testes de Service consomem Mothers dos respectivos Aggregates (não duplique).

Exemplo concreto:

```
AccountsPayable.Domain.Tests/
├── AccountsPayableErrorsTests.cs           ← se houver erros transversais do BC
├── Services/                                ← se houver Domain Services
│   ├── BillClassificationServiceTests.cs
│   └── BillClassificationErrorsTests.cs
└── Bills/
    ├── Mothers/
    │   ├── BillMother.cs
    │   └── MoneyMother.cs
    ├── BillTests.cs
    ├── BillItemTests.cs
    ├── MoneyTests.cs
    ├── DueDateTests.cs
    ├── BillStatusTests.cs
    └── BillErrorsTests.cs
```

→ Templates prontos por categoria em `references/test-templates.md`.
→ Padrão específico de testes de Domain Service em `references/domain-services-tests.md`.

## Estilo da resposta

- **Comece curto**: resumo de 3-5 linhas do que vai gerar (quais arquivos).
- **Um arquivo por bloco** com caminho como comentário no topo.
- **Object Mother primeiro**, depois testes que dependem dele.
- **Não comente cada teste** — nomes auto-descritivos bastam.
- **Liste lacunas reconhecidas no fim** (testes que dependem de regras ainda ambíguas, ou cenários que precisam de confirmação).

## O que NÃO fazer

- Não instanciar Aggregate/Entity direto no teste — sempre via Mother.
- Não usar `DateTime.UtcNow`, `DateTime.Now`, `Guid.NewGuid()` ou `<Type>Id.New()` solto em arrange — fixar valores ou parametrizar via Mother. Ids strongly-typed devem ser construídos com `<Type>Id.From(new Guid("..."))` quando o teste depende de igualdade entre instâncias.
- Não testar getters/setters triviais.
- Não testar comportamento de Entity interna **diretamente** (construtor `internal`/`private`) — sempre via Root.
- Não asseguir tudo via reflexão para "evitar verificar campo a campo" — assert explícito por campo no payload de evento é mais útil que comparar objeto inteiro.
- Não comparar mensagens de `DomainException` em PT — comparar `Id` (constante, não muda com tradução).
- Não usar mocks para o domínio — domínio é puro, sem dependência externa.
- Não criar suite "completa" demais — cubra invariantes, transições, validações, eventos. Deixe casos óbvios de fora (ex.: getter de propriedade simples não precisa de teste).
- Não inventar invariante ou comportamento não presente no código — se faltar info, **pergunte**.
