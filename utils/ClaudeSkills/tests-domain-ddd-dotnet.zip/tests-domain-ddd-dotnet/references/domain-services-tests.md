# Testes de Domain Service

> Use quando o usuário pedir testes para um **Domain Service** (classe stateless em `Services/` que coordena múltiplos Aggregates). Carregue este arquivo junto com `test-templates.md`.

## Princípio

Domain Service é **stateless** e recebe Aggregates como parâmetros. Não tem dependência de infra. Por isso testes de Domain Service:

- ✅ **Não usam mocks.** Aggregates reais são construídos via Mother.
- ✅ **Não precisam de DI / setup complexo.** Service é instanciado direto: `new BillClassificationService()`.
- ✅ **São rápidos e determinísticos** — puro cálculo/coordenação em memória.

## O que testar num Domain Service

1. **Caminho feliz** para cada combinação relevante de estado dos Aggregates de entrada.
2. **Cada regra de negócio** que o Service implementa (geralmente várias condições combinadas).
3. **Erros lançados** (parâmetros nulos, Aggregates em estado inválido, regras de negócio violadas).
4. **Side effects nos Aggregates passados** (se o Service muta os Aggregates via métodos deles, verifique o estado pós-operação).
5. **Eventos emitidos pelos Aggregates como consequência** (drene `PullDomainEvents` dos Aggregates passados, valide tipo e payload).

## O que NÃO testar num Domain Service

- ❌ Estado interno do Service (não tem — é stateless).
- ❌ Comportamento dos Aggregates passados (isso é coberto nos testes do próprio Aggregate).
- ❌ Integração com Repository, banco, HTTP (Domain Service não tem dependências externas — se tiver, é Application Service e não cabe nesta skill).

## Estrutura de pastas

Testes de Domain Service ficam em **`Services/`** dentro do projeto de testes, espelhando a estrutura do projeto de domínio:

```
<BoundedContext>.Domain.Tests/
├── Services/
│   ├── <Service>Tests.cs
│   └── <Service>ErrorsTests.cs
├── Mothers/                            ← Mothers compartilhadas (se houver)
└── <Aggregate>/
    ├── Mothers/
    └── <Aggregate>Tests.cs
```

Exemplo concreto:

```
AccountsPayable.Domain.Tests/
├── Services/
│   ├── BillClassificationServiceTests.cs
│   └── BillClassificationErrorsTests.cs
└── Bills/
    ├── Mothers/
    │   └── BillMother.cs
    └── BillTests.cs
```

Mothers usados nos testes do Service são **as mesmas** dos testes dos Aggregates — não duplique. Um teste de `BillClassificationService` consome `BillMother` e `SupplierMother` dos respectivos Aggregates.

## Template — Service que avalia/calcula (sem mutação)

Este é o caso mais comum: Service recebe Aggregates, retorna um valor (VO, Smart Enum, bool, etc.). Não muta os Aggregates.

```csharp
// AccountsPayable.Domain.Tests/Services/BillClassificationServiceTests.cs
namespace AccountsPayable.Domain.Tests.Services;

using AccountsPayable.Domain.Bills;
using AccountsPayable.Domain.Bills.Enumerations;
using AccountsPayable.Domain.Bills.ValueObjects;
using AccountsPayable.Domain.SeedWork;
using AccountsPayable.Domain.Services;
using AccountsPayable.Domain.Suppliers;
using AccountsPayable.Domain.Tests.Bills.Mothers;
using AccountsPayable.Domain.Tests.Suppliers.Mothers;

public class BillClassificationServiceTests
{
    private static readonly DateTime FIXED_NOW = new(2024, 1, 15, 10, 0, 0, DateTimeKind.Utc);

    public class WhenClassifying
    {
        [Fact]
        public void Classify_OperationalSupplierWithSmallTrustedAmount_ShouldReturnAutoApprove()
        {
            var bill = BillMother.DraftWithItems(itemCount: 1, itemAmount: 100m);
            var supplier = SupplierMother.OperationalAndTrusted();
            var service = new BillClassificationService();

            var result = service.Classify(bill, supplier, FIXED_NOW);

            Assert.Equal(BillClassification.AutoApprove, result);
        }

        [Fact]
        public void Classify_OperationalSupplierAboveThreshold_ShouldRequireHumanReview()
        {
            var bill = BillMother.DraftWithItems(itemCount: 1, itemAmount: 1500m);
            var supplier = SupplierMother.OperationalAndTrusted();
            var service = new BillClassificationService();

            var result = service.Classify(bill, supplier, FIXED_NOW);

            Assert.Equal(BillClassification.RequiresHumanReview, result);
        }

        [Fact]
        public void Classify_AmountAboveTenTimesThreshold_ShouldRequireSeniorApproval()
        {
            var bill = BillMother.DraftWithItems(itemCount: 1, itemAmount: 10_000m);
            var supplier = SupplierMother.OperationalAndTrusted();
            var service = new BillClassificationService();

            var result = service.Classify(bill, supplier, FIXED_NOW);

            Assert.Equal(BillClassification.RequiresSeniorApproval, result);
        }

        [Fact]
        public void Classify_NonOperationalSupplier_ShouldRequireHumanReview()
        {
            var bill = BillMother.DraftWithItems(itemCount: 1, itemAmount: 100m);
            var supplier = SupplierMother.StrategicCategory();
            var service = new BillClassificationService();

            var result = service.Classify(bill, supplier, FIXED_NOW);

            Assert.Equal(BillClassification.RequiresHumanReview, result);
        }

        [Fact]
        public void Classify_LowTrustSupplier_ShouldRequireHumanReview()
        {
            var bill = BillMother.DraftWithItems(itemCount: 1, itemAmount: 100m);
            var supplier = SupplierMother.OperationalLowTrust();
            var service = new BillClassificationService();

            var result = service.Classify(bill, supplier, FIXED_NOW);

            Assert.Equal(BillClassification.RequiresHumanReview, result);
        }
    }

    public class WhenInputIsInvalid
    {
        [Fact]
        public void Classify_WithNullBill_ShouldThrowDomainException()
        {
            var supplier = SupplierMother.OperationalAndTrusted();
            var service = new BillClassificationService();

            var ex = Assert.Throws<DomainException>(
                () => service.Classify(null!, supplier, FIXED_NOW));

            Assert.Equal("APD.BCS01", ex.Id);
        }

        [Fact]
        public void Classify_WithNullSupplier_ShouldThrowDomainException()
        {
            var bill = BillMother.DraftWithItems();
            var service = new BillClassificationService();

            var ex = Assert.Throws<DomainException>(
                () => service.Classify(bill, null!, FIXED_NOW));

            Assert.Equal("APD.BCS02", ex.Id);
        }
    }
}
```

## Template — Service que coordena mutação (com side effects nos Aggregates)

Quando o Service modifica Aggregates passados (via métodos deles), verifique:

1. Estado dos Aggregates após a operação.
2. Eventos emitidos pelos Aggregates como consequência.

```csharp
// Banking.Domain.Tests/Services/FundsTransferServiceTests.cs
namespace Banking.Domain.Tests.Services;

using Banking.Domain.Accounts;
using Banking.Domain.Accounts.Events;
using Banking.Domain.Accounts.ValueObjects;
using Banking.Domain.SeedWork;
using Banking.Domain.Services;
using Banking.Domain.Tests.Accounts.Mothers;

public class FundsTransferServiceTests
{
    private static readonly DateTime FIXED_NOW = new(2024, 1, 15, 10, 0, 0, DateTimeKind.Utc);

    public class WhenTransferring
    {
        [Fact]
        public void Transfer_WithSufficientBalance_ShouldDebitSourceAndCreditTarget()
        {
            var source = AccountMother.WithBalance(1000m);
            var target = AccountMother.WithBalance(500m);
            var amount = new Money(300m, "BRL");
            var service = new FundsTransferService();

            service.Transfer(source, target, amount, FIXED_NOW);

            Assert.Equal(700m, source.Balance.Amount);
            Assert.Equal(800m, target.Balance.Amount);
        }

        [Fact]
        public void Transfer_ShouldEmitDebitedEventOnSource()
        {
            var source = AccountMother.WithBalance(1000m);
            var target = AccountMother.WithBalance(500m);
            var amount = new Money(300m, "BRL");
            var service = new FundsTransferService();
            source.PullDomainEvents();
            target.PullDomainEvents();

            service.Transfer(source, target, amount, FIXED_NOW);

            var sourceEvents = source.PullDomainEvents();
            var debited = Assert.Single(sourceEvents);
            var debitedEvent = Assert.IsType<AccountDebited>(debited);
            Assert.Equal(source.Id, debitedEvent.AccountId);
            Assert.Equal(300m, debitedEvent.Amount);
            Assert.Equal(FIXED_NOW, debitedEvent.OccurredAt);
        }

        [Fact]
        public void Transfer_ShouldEmitCreditedEventOnTarget()
        {
            var source = AccountMother.WithBalance(1000m);
            var target = AccountMother.WithBalance(500m);
            var amount = new Money(300m, "BRL");
            var service = new FundsTransferService();
            source.PullDomainEvents();
            target.PullDomainEvents();

            service.Transfer(source, target, amount, FIXED_NOW);

            var targetEvents = target.PullDomainEvents();
            var credited = Assert.Single(targetEvents);
            var creditedEvent = Assert.IsType<AccountCredited>(credited);
            Assert.Equal(target.Id, creditedEvent.AccountId);
            Assert.Equal(300m, creditedEvent.Amount);
        }
    }

    public class WhenValidating
    {
        [Fact]
        public void Transfer_WithInsufficientBalance_ShouldThrowDomainException()
        {
            var source = AccountMother.WithBalance(100m);
            var target = AccountMother.WithBalance(500m);
            var amount = new Money(300m, "BRL");
            var service = new FundsTransferService();

            var ex = Assert.Throws<DomainException>(
                () => service.Transfer(source, target, amount, FIXED_NOW));

            Assert.Equal("BNK.FTS01", ex.Id);
        }

        [Fact]
        public void Transfer_WithBlockedTarget_ShouldThrowDomainException()
        {
            var source = AccountMother.WithBalance(1000m);
            var target = AccountMother.Blocked();
            var amount = new Money(300m, "BRL");
            var service = new FundsTransferService();

            var ex = Assert.Throws<DomainException>(
                () => service.Transfer(source, target, amount, FIXED_NOW));

            Assert.Equal("BNK.FTS02", ex.Id);
        }

        [Fact]
        public void Transfer_WhenValidationFails_ShouldNotMutateAggregates()
        {
            var source = AccountMother.WithBalance(100m);
            var target = AccountMother.WithBalance(500m);
            var amount = new Money(300m, "BRL");
            var service = new FundsTransferService();

            try { service.Transfer(source, target, amount, FIXED_NOW); }
            catch (DomainException) { /* expected */ }

            Assert.Equal(100m, source.Balance.Amount);
            Assert.Equal(500m, target.Balance.Amount);
        }
    }
}
```

## Factory de erros do Service

Mesmo padrão dos testes de `<Aggregate>ErrorsTests.cs`:

```csharp
// AccountsPayable.Domain.Tests/Services/BillClassificationErrorsTests.cs
namespace AccountsPayable.Domain.Tests.Services;

using AccountsPayable.Domain.Services;

public class BillClassificationErrorsTests
{
    [Fact]
    public void BillRequired_ShouldHaveCorrectIdAndNoParameters()
    {
        var error = BillClassificationErrors.BillRequired();

        Assert.Equal("APD.BCS01", error.Id);
        Assert.NotEmpty(error.MessageTemplate);
        Assert.Empty(error.Parameters);
        Assert.NotEmpty(error.SourcePath);
    }

    [Fact]
    public void SupplierRequired_ShouldHaveCorrectIdAndNoParameters()
    {
        var error = BillClassificationErrors.SupplierRequired();

        Assert.Equal("APD.BCS02", error.Id);
        Assert.Empty(error.Parameters);
    }

    [Fact]
    public void AllErrors_ShouldHaveUniqueIds()
    {
        var errors = new[]
        {
            BillClassificationErrors.BillRequired().Id,
            BillClassificationErrors.SupplierRequired().Id,
        };

        Assert.Equal(errors.Length, errors.Distinct().Count());
    }
}
```

## Mothers para cenários multi-Aggregate

Se o Service combina Aggregates em situações específicas que se repetem em vários testes, considere uma **Mother de cenário** que produz a tupla:

```csharp
// AccountsPayable.Domain.Tests/Services/Mothers/ClassificationScenarioMother.cs
namespace AccountsPayable.Domain.Tests.Services.Mothers;

public static class ClassificationScenarioMother
{
    public static (Bill bill, Supplier supplier) AutoApprovable()
        => (BillMother.DraftWithItems(itemCount: 1, itemAmount: 100m),
            SupplierMother.OperationalAndTrusted());

    public static (Bill bill, Supplier supplier) RequiresSeniorApproval()
        => (BillMother.DraftWithItems(itemCount: 1, itemAmount: 10_000m),
            SupplierMother.OperationalAndTrusted());
}
```

Use só quando há repetição real — não invente Mother pra um único teste.

## Checklist ao gerar testes de Domain Service

- [ ] Cada regra de negócio do Service tem um teste dedicado?
- [ ] Cada erro lançado pelo Service tem um teste de violação?
- [ ] Aggregates são instanciados via **Mother** (não direto)?
- [ ] Service é instanciado direto: `new <Service>Service()` (sem mocks, sem DI)?
- [ ] Se o Service muta Aggregates, há teste de **side effects** nos Aggregates?
- [ ] Se a mutação dispara eventos nos Aggregates, há teste do **payload do evento**?
- [ ] Se a validação falha, há teste verificando que **nenhum estado foi alterado**?
- [ ] Erros do Service comparam `Id` (não a mensagem em PT)?
