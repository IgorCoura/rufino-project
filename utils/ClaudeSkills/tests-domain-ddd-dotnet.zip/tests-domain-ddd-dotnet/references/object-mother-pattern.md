# Padrão Object Mother / Test Builders

> Como construir Aggregates, Entities e VOs em testes de forma legível, reutilizável, e que **respeite as invariantes do domínio**. Este é o ponto de maior impacto na qualidade da suíte de testes.

## Princípio

**Mothers são código de teste**, não de produção. Vivem em `<Aggregate>/Mothers/<Aggregate>Mother.cs`. Cada método retorna um cenário de negócio nomeado.

Padrão:
- Classe `static` com nome `<Type>Mother`
- Métodos `static` com nome em **inglês** descrevendo o cenário (`Draft`, `AwaitingApproval`, `ApprovedWithItems`, `Paid`, `Overdue`)
- Cada método tem **parâmetros opcionais com defaults** que permitem customização sem quebrar o caso default
- Constrói via factory `Create` do Aggregate / construtor do VO — **respeitando as invariantes**

## Exemplo: BillMother

```csharp
// AccountsPayable.Domain.Tests/Bills/Mothers/BillMother.cs
namespace AccountsPayable.Domain.Tests.Bills.Mothers;

using AccountsPayable.Domain.Bills;
using AccountsPayable.Domain.Bills.Enumerations;
using AccountsPayable.Domain.Bills.ValueObjects;

public static class BillMother
{
    private static readonly DateTime DEFAULT_OCCURRED_AT = new(2024, 1, 15, 10, 0, 0, DateTimeKind.Utc);
    private static readonly SupplierId DEFAULT_SUPPLIER_ID = SupplierId.From(new Guid("22222222-2222-2222-2222-222222222222"));

    public static Bill Draft(
        BillId? id = null,
        SupplierId? supplierId = null,
        DateTime? dueDate = null,
        DateTime? occurredAt = null)
    {
        return Bill.Create(
            id: id ?? BillId.New(),
            supplierId: supplierId ?? DEFAULT_SUPPLIER_ID,
            dueDate: new DueDate(dueDate ?? DEFAULT_OCCURRED_AT.AddDays(30)),
            occurredAt: occurredAt ?? DEFAULT_OCCURRED_AT);
    }

    public static Bill DraftWithItems(int itemCount = 3, decimal itemAmount = 100m)
    {
        var bill = Draft();
        for (var i = 0; i < itemCount; i++)
            bill.AddItem(
                description: $"Item {i + 1}",
                amount: new Money(itemAmount, "BRL"),
                categoryCode: "OPEX",
                occurredAt: DEFAULT_OCCURRED_AT);
        return bill;
    }

    public static Bill AwaitingApproval(int itemCount = 3, decimal itemAmount = 100m)
    {
        var bill = DraftWithItems(itemCount, itemAmount);
        bill.SubmitForApproval(DEFAULT_OCCURRED_AT.AddMinutes(5));
        return bill;
    }

    public static Bill Approved(int itemCount = 3, decimal itemAmount = 100m, UserId? approver = null)
    {
        var bill = AwaitingApproval(itemCount, itemAmount);
        bill.Approve(
            approver: approver ?? UserId.New(),
            occurredAt: DEFAULT_OCCURRED_AT.AddMinutes(10));
        return bill;
    }

    public static Bill Paid()
    {
        var bill = Approved();
        // Schedule e Pay são chamados aqui...
        return bill;
    }
}
```

## Uso em teste

```csharp
[Fact]
public void Approve_WhenBillIsAwaitingApproval_ShouldChangeStatusToApproved()
{
    var bill = BillMother.AwaitingApproval();
    var approver = UserId.New();
    var occurredAt = new DateTime(2024, 2, 1, 12, 0, 0, DateTimeKind.Utc);

    bill.Approve(approver, occurredAt);

    Assert.Equal(BillStatus.Approved, bill.Status);
}

[Fact]
public void Approve_WhenBillIsDraft_ShouldThrowDomainException()
{
    var bill = BillMother.Draft();

    var ex = Assert.Throws<DomainException>(
        () => bill.Approve(UserId.New(), DateTime.UnixEpoch));

    Assert.Equal("APD.BIL01", ex.Id);
}
```

A intenção do teste fica óbvia em uma linha. Quem lê não precisa decifrar setup de 15 linhas.

## Mothers de Value Object

VOs simples (`Money`, `EmailAddress`) **não precisam de Mother** — instanciar direto é claro o bastante:

```csharp
var money = new Money(100m, "BRL");
```

Mothers fazem sentido para VOs com:
- Múltiplos atributos (>3 campos)
- Construção complexa (validações múltiplas, cálculos)
- Cenários nomeados que se repetem (ex.: `AddressMother.BrazilianValid()`, `AddressMother.International()`)

## ⚠️ Anti-padrão crítico: viciamento em valores fixos

**O grande risco do Object Mother**: você fixa `100m`, `"BRL"`, `"Item 1"` em toda Mother — e seus testes **só validam esses casos específicos**. Bugs em valores limítrofes, especiais, ou edge cases **passam despercebidos**.

### Sintomas
- Toda Mother retorna a mesma quantia, mesma moeda, mesma descrição, mesma quantidade de itens.
- Testes do tipo "validei que 100 + 100 = 200" e nada mais.
- Bugs descobertos em produção com valores quebrados (`-0.01`, `999999999.99`, strings com apóstrofo, etc.).

### Como evitar — três técnicas

#### 1. Parametrize a Mother com defaults

Mother **aceita parâmetros opcionais** com valores razoáveis como default. Quem precisar de variação, passa o argumento.

```csharp
public static Bill DraftWithItems(int itemCount = 3, decimal itemAmount = 100m, string currency = "BRL")
{
    // ... usa itemCount, itemAmount, currency
}
```

Isso permite:
```csharp
var billCheap = BillMother.DraftWithItems(itemAmount: 0.01m);
var billExpensive = BillMother.DraftWithItems(itemAmount: 999999.99m);
var billUSD = BillMother.DraftWithItems(currency: "USD");
```

#### 2. Use `[Theory]` + `[InlineData]` para variações de valor

Quando o teste verifica algo que depende do valor, parametrize com **múltiplos casos representativos**:

```csharp
[Theory]
[InlineData(0.01)]      // mínimo positivo
[InlineData(100)]       // valor "normal"
[InlineData(999999.99)] // grande
public void Constructor_WithValidAmount_ShouldCreateMoney(decimal amount)
{
    var money = new Money(amount, "BRL");

    Assert.Equal(amount, money.Amount);
}

[Theory]
[InlineData(-0.01)]
[InlineData(-100)]
public void Constructor_WithNegativeAmount_ShouldThrowDomainException(decimal amount)
{
    var ex = Assert.Throws<DomainException>(
        () => new Money(amount, "BRL"));

    Assert.Equal("APD.MNY02", ex.Id);
}
```

#### 3. Crie Mothers para cenários de borda explicitamente

Em vez de só `Draft()` e `Approved()`, crie Mothers que **expõem casos extremos**:

```csharp
public static Bill DraftWithSingleItemOfMinimumAmount() =>
    DraftWithItems(itemCount: 1, itemAmount: 0.01m);

public static Bill DraftWithMaximumItems() =>
    DraftWithItems(itemCount: 200, itemAmount: 1m);

public static Bill DraftWithLongDescriptionItems()
{
    var bill = Draft();
    bill.AddItem(
        description: new string('A', 500),
        amount: new Money(100m, "BRL"),
        categoryCode: "OPEX",
        occurredAt: DEFAULT_OCCURRED_AT);
    return bill;
}
```

Casos extremos viram cenários nomeados. Quem lê o teste vê: "ah, o teste cobre isso explicitamente".

### Heurística rápida

Quando criar/atualizar Mother, pergunte:

1. **Há inputs aceitos** (limites superior/inferior, formatos especiais, vazio, máximo)? Parametrize ou crie cenário extremo.
2. **Há inputs rejeitados** (negativo, vazio, muito longo, formato inválido)? Use `[Theory]` + `[InlineData]` no teste, não na Mother.
3. **Há valor "padrão" usado em quase todos os testes**? OK manter como default da Mother — só não esqueça de criar **pelo menos um teste** com variação.

## Mothers de transição de estado

Para Aggregates com máquina de estados, prefira Mothers que **representem cada estado válido**:

```csharp
BillMother.Draft()                 // estado inicial
BillMother.AwaitingApproval()      // após submit
BillMother.Approved()              // após approve
BillMother.Scheduled()             // após schedule
BillMother.Paid()                  // após pay
BillMother.Cancelled()             // após cancel
BillMother.Rejected()              // após reject
```

Cada Mother chama os métodos do Aggregate na sequência correta — **respeita a máquina de estados**, garantindo que o teste sempre opera num cenário válido.

## Tempo nas Mothers

Mothers têm uma constante `DEFAULT_OCCURRED_AT` no topo. Métodos que avançam estado adicionam minutos/dias relativos:

```csharp
private static readonly DateTime DEFAULT_OCCURRED_AT = new(2024, 1, 15, 10, 0, 0, DateTimeKind.Utc);

// Submit: 5 min depois da criação
// Approve: 10 min depois da criação
// Pay: 1 dia depois da criação
```

Isso garante que `bill.UpdatedAt` reflete a última ação, e os testes podem comparar diferenças temporais sem flakiness.

## Quando NÃO criar Mother

- VO simples com 1-2 campos: instanciar direto é mais claro (`new Money(100m, "BRL")`).
- Teste que valida **exatamente** o estado de criação inicial: instanciar direto deixa explícito o que está sendo testado.
- Caso único usado em um único teste: criar Mother é over-engineering.

## Localização e namespace

```
AccountsPayable.Domain.Tests/
└── Bills/
    └── Mothers/
        ├── BillMother.cs
        └── MoneyMother.cs   ← se houver
```

Namespace: `AccountsPayable.Domain.Tests.Bills.Mothers`

Mothers são `public static` para que possam ser usadas por outros testes do mesmo Bounded Context (não vazam para Application.Tests, etc.).
