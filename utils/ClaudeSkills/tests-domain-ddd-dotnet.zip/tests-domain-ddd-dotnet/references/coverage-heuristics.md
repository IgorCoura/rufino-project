# Heurística de cobertura

> Como decidir o que testar e o que não testar. Cobertura 100% é raramente o objetivo certo — o que importa é cobrir invariantes, comportamentos e transições reais do domínio.

## O que SEMPRE testar

### Aggregate Root
- ✅ Cada método público de mutação (caminho feliz + cada invariante violada)
- ✅ Cada transição de status válida (que o método transita corretamente)
- ✅ Cada transição de status inválida (que o método rejeita)
- ✅ Cada Domain Event emitido (existência + payload completo, campo a campo)
- ✅ Factory `Create` (estado inicial correto + evento de criação emitido)
- ✅ `UpdatedAt` é atualizado em cada mutação
- ✅ Recálculos automáticos (totais, agregações) após mutação

### Value Object
- ✅ Construção válida (props populadas)
- ✅ **Cada** validação no construtor (com `[Theory]` para múltiplos inputs ruins)
- ✅ Igualdade entre instâncias com mesmo valor
- ✅ Desigualdade quando algum atributo difere
- ✅ Hash code consistente com igualdade
- ✅ Métodos de comportamento (com cenários positivos e edge cases)
- ✅ Imutabilidade — métodos retornam novo VO sem mutar original (quando aplicável)

### Smart Enum (Enumeration)
- ✅ Matriz **completa** de transições válidas (uma `[InlineData]` por par)
- ✅ Conjunto representativo de transições inválidas (não precisa cobrir TODOS os pares N×N — escolher casos suspeitos: estados terminais, saltos, reversões)
- ✅ `FromValue` / `FromDisplayName` com inputs válidos e inválidos
- ✅ `GetAll` retorna a quantidade esperada

### Entity interna (via Root)
- ✅ Criação **através** do método da Root (`AddItem`, etc.)
- ✅ Validações no construtor da Entity (lançadas via Root)
- ✅ Mutação **através** da Root
- ✅ Estado pós-mutação verificado consultando coleção da Root

### Factory de erros
- ✅ Cada método retorna `DomainException` com `Id` esperado
- ✅ Parâmetros corretamente preenchidos
- ✅ Todos os IDs são únicos no arquivo

## O que NÃO testar

- ❌ **Getters/setters triviais** — se a propriedade só guarda o valor passado no construtor, o teste do construtor já cobre.
- ❌ **Construtores privados via reflexão** — Aggregate/Entity tem ctor `private` para EF; não teste.
- ❌ **Comportamento da base SeedWork** — `Entity.Equals`, `ValueObject.GetHashCode`, etc. são testados na própria base, não em cada concreto.
- ❌ **Métodos `internal` de Entity interna** — sempre via Root.
- ❌ **Frameworks** — não teste se EF, xUnit, ou C# funcionam.
- ❌ **Casos óbvios sem regra de negócio** — `Money.Currency` retorna a string passada; testar isso é ruído.
- ❌ **Comparação de mensagens em PT** — frágil; compare apenas `Id` da `DomainException`.

## Heurística de "o suficiente"

Para um Aggregate típico, espere:

| Tipo de teste | Quantidade típica |
|---|---|
| Aggregate Root tests | 15-30 testes (5-8 métodos × 2-4 cenários cada) |
| Value Object tests (por VO) | 5-15 testes |
| Smart Enum tests | 10-20 testes (matriz de transições + lookups) |
| Entity interna (via Root) | 3-8 testes |
| Factory de erros | 1 teste por erro + 1 teste de unicidade |

**Quando parar**: quando você consegue olhar pro Aggregate, identificar cada invariante e cada transição na cabeça, e bater com testes correspondentes. Se a próxima ideia de teste é uma variação trivial de um já existente, parou.

## Sinais de boa suíte

- ✅ Refatoração interna do Aggregate **sem mudar comportamento** não quebra testes.
- ✅ Mudar uma invariante **sempre quebra pelo menos um teste**.
- ✅ Adicionar um Domain Event novo sem teste é gritante (lacuna óbvia).
- ✅ Quem lê só os nomes dos testes entende o que o Aggregate faz.

## Sinais de suíte com problema

- ❌ **Setup gigante** em cada teste → faltam Mothers.
- ❌ **Testes que só verificam getters** → ruído sem valor.
- ❌ **Asserções compostas** (`Assert.True(a && b && c)`) → falhas sem informação.
- ❌ **Comparação de mensagens em PT** → quebra com qualquer ajuste de texto.
- ❌ **Tudo passa, mas bug em produção** → faltam casos extremos (parametrize com `[Theory]`).
- ❌ **Testes com `DateTime.UtcNow`, `Guid.NewGuid()`, ou `<Type>Id.New()` aleatórios em arrange** → flakiness.

## Quando perguntar antes de testar

Pergunte ao usuário (não invente) se:
- Faltam invariantes documentadas no código (comentário de invariante implícita).
- A factory de erros está incompleta (alguns erros usados no Aggregate não estão na factory).
- Há transição de status que o código permite mas não documenta como válida.
- Um Domain Event tem campo cuja origem não está clara (ex.: `BillApproved.Amount` é o valor antes ou depois do desconto?).

Pergunte 1-3 itens objetivos. Não trave o usuário com 10 perguntas.

## Quando NÃO perguntar (decida e siga)

- Convenções de nome de teste, organização de pastas, namespaces.
- Defaults razoáveis para Mothers (`itemCount = 3`, `currency = "BRL"`).
- Casos extremos óbvios para parametrizar (`""`, `" "`, `null`, valores limítrofes).
- Asserções em campos óbvios do payload de evento.

Em dúvida: decida e sinalize a suposição no fim ("assumi X — confirma?").
