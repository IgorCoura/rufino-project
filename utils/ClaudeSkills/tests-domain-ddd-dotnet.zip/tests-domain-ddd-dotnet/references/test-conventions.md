# Convenções de teste C# / xUnit para domínio

> Padrões a seguir literalmente em todo teste gerado. Se o usuário pedir desvio explícito, respeite — mas o default é este.

## Idioma

- **Inglês em todo código de teste**: nomes de classe, métodos, variáveis, mensagens.
- **Mensagens de `DomainException` continuam em PT** porque o domínio é PT — mas o teste **NÃO compara mensagem**, compara `Id` (que é constante e linguisticamente neutro).

## Nome dos métodos de teste

Padrão: `MethodName_StateUnderTest_ExpectedBehavior`.

Três blocos separados por underscore. Cada um responde uma pergunta:

| Bloco | Pergunta | Exemplos |
|---|---|---|
| MethodName | Qual método/comportamento? | `Approve`, `AddItem`, `Constructor`, `CanTransitionTo` |
| StateUnderTest | Em que estado/cenário? | `WhenBillIsAwaitingApproval`, `WithEmptyDescription`, `FromDraftToApproved` |
| ExpectedBehavior | O que deve acontecer? | `ShouldChangeStatusToApproved`, `ShouldThrowDomainException`, `ShouldEmitBillApprovedEvent` |

### Exemplos bons

```csharp
public void Approve_WhenBillIsAwaitingApproval_ShouldChangeStatusToApproved()
public void Approve_WhenBillIsDraft_ShouldThrowDomainException()
public void AddItem_WhenBillIsApproved_ShouldThrowDomainException()
public void AddItem_WithValidData_ShouldRecalculateTotal()
public void Create_WithEmptyCurrency_ShouldThrowDomainException()
public void Equals_WithSameAmountAndCurrency_ShouldReturnTrue()
public void CanTransitionTo_FromDraftToAwaitingApproval_ShouldReturnTrue()
public void CanTransitionTo_FromPaidToAnyStatus_ShouldReturnFalse()
```

### Exemplos ruins

```csharp
public void TestApprove()                          // sem cenário, sem expectativa
public void Approve_Test()                         // idem
public void ApproveWorks()                         // não diz nada
public void Bill_Approve()                         // só nome do método repetido
public void Approve_DoesNotThrow()                 // expectativa vaga
```

## Estrutura AAA (Arrange / Act / Assert)

Separe os 3 blocos por **linha em branco**. **Sem comentários `// Arrange`, `// Act`, `// Assert`** — o espaço delimita visualmente, comentários são ruído.

```csharp
[Fact]
public void Approve_WhenBillIsAwaitingApproval_ShouldChangeStatusToApproved()
{
    var bill = BillMother.AwaitingApproval();
    var approver = UserId.New();
    var occurredAt = new DateTime(2024, 1, 15, 10, 0, 0, DateTimeKind.Utc);

    bill.Approve(approver, occurredAt);

    Assert.Equal(BillStatus.Approved, bill.Status);
    Assert.Equal(occurredAt, bill.UpdatedAt);
}
```

## `[Fact]` vs `[Theory]`

### `[Fact]` — caso único e específico
Use quando o teste cobre **um cenário** com inputs/outputs únicos.

```csharp
[Fact]
public void Approve_WhenBillIsDraft_ShouldThrowDomainException()
{
    var bill = BillMother.Draft();

    var ex = Assert.Throws<DomainException>(
        () => bill.Approve(UserId.New(), DateTime.UnixEpoch));

    Assert.Equal("APD.BIL01", ex.Id);
}
```

### `[Theory]` + `[InlineData]` — múltiplos inputs, mesma lógica
Use quando você quer cobrir **vários casos** que seguem a mesma estrutura — sobretudo:
- Matrizes de transição de Smart Enum
- Valores inválidos de VO (vários inputs ruins, mesma exception esperada)
- Variações de input válido (vários valores aceitos)

```csharp
[Theory]
[InlineData("")]
[InlineData(" ")]
[InlineData("ABCD")]   // 4 letters
[InlineData("AB")]     // 2 letters
[InlineData("123")]    // not letters
public void Constructor_WithInvalidCurrency_ShouldThrowDomainException(string invalidCurrency)
{
    var ex = Assert.Throws<DomainException>(
        () => new Money(100m, invalidCurrency));

    Assert.Equal("APD.MNY01", ex.Id);
}
```

```csharp
[Theory]
[InlineData(1, 2, true)]   // Draft -> AwaitingApproval
[InlineData(1, 6, true)]   // Draft -> Cancelled
[InlineData(2, 3, true)]   // AwaitingApproval -> Approved
[InlineData(2, 7, true)]   // AwaitingApproval -> Rejected
[InlineData(5, 1, false)]  // Paid -> Draft (invalid)
[InlineData(5, 6, false)]  // Paid -> Cancelled (invalid)
public void CanTransitionTo_ShouldReturnExpectedResult(int fromId, int toId, bool expected)
{
    var from = Enumeration.FromValue<BillStatus>(fromId);
    var to = Enumeration.FromValue<BillStatus>(toId);

    var result = from.CanTransitionTo(to);

    Assert.Equal(expected, result);
}
```

## `Assert` nativas — uso correto

| Cenário | Asserção |
|---|---|
| Comparação simples | `Assert.Equal(expected, actual)` |
| Comparação de coleções | `Assert.Equal(expectedCollection, actualCollection)` (ordem importa) ou `Assert.Equivalent` (ordem não importa) |
| Boolean true | `Assert.True(condition)` ou `Assert.True(condition, "message")` |
| Boolean false | `Assert.False(condition)` |
| Null | `Assert.Null(obj)` / `Assert.NotNull(obj)` |
| Exceção esperada | `var ex = Assert.Throws<DomainException>(() => action());` |
| Tipo esperado | `Assert.IsType<BillApproved>(@event)` |
| Item em coleção | `Assert.Contains(item, collection)` |
| Coleção vazia | `Assert.Empty(collection)` |
| Coleção não-vazia | `Assert.NotEmpty(collection)` |
| Quantidade exata | `Assert.Single(collection)` ou `Assert.Equal(3, collection.Count)` |
| String contém | `Assert.Contains("substring", actualString)` |

### Anti-padrões

```csharp
// Ruim — só verifica que algo aconteceu, não O que
Assert.NotNull(bill.Status);

// Bom — verifica o estado esperado
Assert.Equal(BillStatus.Approved, bill.Status);
```

```csharp
// Ruim — assert composto sem nome, falha não diz qual parte quebrou
Assert.True(bill.Status == BillStatus.Approved && bill.UpdatedAt == occurredAt);

// Bom — asserts separados, falha mostra qual exatamente quebrou
Assert.Equal(BillStatus.Approved, bill.Status);
Assert.Equal(occurredAt, bill.UpdatedAt);
```

```csharp
// Ruim — comparação de mensagem em PT, frágil e específica de idioma
Assert.Equal("Bill em estado de rascunho não pode ser aprovada.", ex.Message);

// Bom — comparação de Id (constante, neutro)
Assert.Equal("APD.BIL01", ex.Id);
```

## DateTime e Guid em testes

**Problema**: `DateTime.UtcNow` e `Guid.NewGuid()` em arrange tornam testes não-determinísticos. Falhas viram heisenbugs.

**Solução**: fixe valores ou parametrize via Mother.

```csharp
// Ruim — não-determinístico
var bill = Bill.Create(BillId.New(), SupplierId.New(), new DueDate(DateTime.UtcNow.AddDays(30)), DateTime.UtcNow);

// Bom — fixo
var fixedTime = new DateTime(2024, 1, 15, 10, 0, 0, DateTimeKind.Utc);
var billId = BillId.From(new Guid("11111111-1111-1111-1111-111111111111"));
var supplierId = SupplierId.From(new Guid("22222222-2222-2222-2222-222222222222"));
var bill = Bill.Create(billId, supplierId, new DueDate(fixedTime.AddDays(30)), fixedTime);

// Melhor ainda — via Mother que cuida disso pra você
var bill = BillMother.Draft();
```

### Constantes de tempo

Quando o teste precisa de tempos relativos, defina constantes no topo do arquivo de teste:

```csharp
public class BillTests
{
    private static readonly DateTime FIXED_NOW = new(2024, 1, 15, 10, 0, 0, DateTimeKind.Utc);
    private static readonly DateTime FUTURE_DATE = FIXED_NOW.AddDays(30);
    private static readonly DateTime PAST_DATE = FIXED_NOW.AddDays(-7);

    // testes...
}
```

## Organização interna do arquivo de teste

Agrupe testes do mesmo método juntos. Para Aggregates com muitos métodos, use **classes aninhadas** (`public class WhenApproving { ... }`) ou **regiões** (`#region Approve`).

Exemplo com classes aninhadas (preferido — xUnit suporta nativamente):

```csharp
public class BillTests
{
    public class WhenCreating
    {
        [Fact]
        public void Create_WithValidData_ShouldReturnBillInDraftStatus() { ... }

        [Fact]
        public void Create_ShouldEmitBillCreatedEvent() { ... }
    }

    public class WhenApproving
    {
        [Fact]
        public void Approve_WhenBillIsAwaitingApproval_ShouldChangeStatus() { ... }

        [Fact]
        public void Approve_WhenBillIsDraft_ShouldThrowDomainException() { ... }
    }
}
```

Para Aggregates pequenos (3-5 métodos), basta agrupar visualmente sem classes aninhadas.

## Constantes em testes

Mesma regra da skill de codegen: **constantes em `MAIÚSCULAS_COM_UNDERSCORE`** declaradas no topo da classe.

```csharp
public class BillTests
{
    private static readonly DateTime FIXED_NOW = new(2024, 1, 15, 10, 0, 0, DateTimeKind.Utc);
    private const string DEFAULT_CURRENCY = "BRL";
    private const string ERROR_INVALID_TRANSITION = "APD.BIL01";

    // testes...
}
```

## O que NÃO testar

- **Getters/setters triviais**: se a propriedade só guarda o valor passado no construtor, não vale teste isolado. O teste do construtor já cobre.
- **Construtores privados via reflexão**: Aggregate/Entity tem construtor `private` para EF — não teste isso.
- **Comportamento da base SeedWork**: `Entity.Equals`, `ValueObject.GetHashCode`, etc. são código herdado, testado uma vez na própria base. Não retestar em cada Entity/VO concreto.
- **Métodos `internal` de Entity interna**: teste sempre **via Root** (que é o ponto de entrada legítimo).
- **Frameworks**: não teste se EF, xUnit, ou C# funcionam.
