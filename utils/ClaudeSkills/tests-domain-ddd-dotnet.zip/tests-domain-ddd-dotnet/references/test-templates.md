# Templates de teste por categoria

> Templates prontos para cada tipo de teste do domínio. Use como ponto de partida e adapte aos detalhes do código real do usuário.

## Aggregate Root: testes essenciais

Para cada método público do Aggregate Root, gere testes cobrindo:

1. **Caminho feliz** (estado válido + input válido)
2. **Cada invariante violada** (estado inválido ou input inválido)
3. **Cada transição de status disparada** (válida e inválida)
4. **Eventos emitidos** (existência, tipo, payload)
5. **Side effects** (`UpdatedAt` atualizado, totais recalculados, coleções modificadas)

### Template completo

```csharp
// AccountsPayable.Domain.Tests/Bills/BillTests.cs
namespace AccountsPayable.Domain.Tests.Bills;

using AccountsPayable.Domain.Bills;
using AccountsPayable.Domain.Bills.Enumerations;
using AccountsPayable.Domain.Bills.Events;
using AccountsPayable.Domain.Bills.ValueObjects;
using AccountsPayable.Domain.SeedWork;
using AccountsPayable.Domain.Tests.Bills.Mothers;

public class BillTests
{
    private static readonly DateTime FIXED_NOW = new(2024, 1, 15, 10, 0, 0, DateTimeKind.Utc);

    public class WhenCreating
    {
        [Fact]
        public void Create_WithValidData_ShouldReturnBillInDraftStatus()
        {
            var id = BillId.New();
            var supplierId = SupplierId.New();
            var dueDate = new DueDate(FIXED_NOW.AddDays(30));

            var bill = Bill.Create(id, supplierId, dueDate, FIXED_NOW);

            Assert.Equal(id, bill.Id);
            Assert.Equal(supplierId, bill.SupplierId);
            Assert.Equal(BillStatus.Draft, bill.Status);
            Assert.Empty(bill.Items);
            Assert.Equal(FIXED_NOW, bill.CreatedAt);
            Assert.Equal(FIXED_NOW, bill.UpdatedAt);
        }

        [Fact]
        public void Create_ShouldEmitBillCreatedEvent()
        {
            var id = BillId.New();
            var supplierId = SupplierId.New();

            var bill = Bill.Create(
                id,
                supplierId,
                new DueDate(FIXED_NOW.AddDays(30)),
                FIXED_NOW);

            var events = bill.PullDomainEvents();
            var createdEvent = Assert.Single(events);
            var billCreated = Assert.IsType<BillCreated>(createdEvent);
            Assert.Equal(id, billCreated.BillId);
            Assert.Equal(supplierId, billCreated.SupplierId);
            Assert.Equal(FIXED_NOW, billCreated.OccurredAt);
        }
    }

    public class WhenAddingItem
    {
        [Fact]
        public void AddItem_WhenBillIsDraft_ShouldAddItemToCollection()
        {
            var bill = BillMother.Draft();
            var amount = new Money(150m, "BRL");

            bill.AddItem("Consulting service", amount, "OPEX", FIXED_NOW);

            Assert.Single(bill.Items);
            var item = bill.Items.First();
            Assert.Equal("Consulting service", item.Description);
            Assert.Equal(amount, item.Amount);
            Assert.Equal("OPEX", item.CategoryCode);
        }

        [Fact]
        public void AddItem_ShouldRecalculateTotal()
        {
            var bill = BillMother.Draft();

            bill.AddItem("First", new Money(100m, "BRL"), "OPEX", FIXED_NOW);
            bill.AddItem("Second", new Money(250m, "BRL"), "OPEX", FIXED_NOW);

            Assert.Equal(new Money(350m, "BRL"), bill.TotalAmount);
        }

        [Fact]
        public void AddItem_WhenBillIsApproved_ShouldThrowDomainException()
        {
            var bill = BillMother.Approved();

            var ex = Assert.Throws<DomainException>(
                () => bill.AddItem("Late item", new Money(50m, "BRL"), "OPEX", FIXED_NOW));

            Assert.Equal("APD.BIL02", ex.Id);
        }

        [Fact]
        public void AddItem_WhenAtMaxCapacity_ShouldThrowDomainException()
        {
            var bill = BillMother.DraftWithItems(itemCount: 200);

            var ex = Assert.Throws<DomainException>(
                () => bill.AddItem("Overflow", new Money(50m, "BRL"), "OPEX", FIXED_NOW));

            Assert.Equal("APD.BIL05", ex.Id);
        }
    }

    public class WhenSubmittingForApproval
    {
        [Fact]
        public void SubmitForApproval_WhenBillIsDraftWithItems_ShouldChangeStatus()
        {
            var bill = BillMother.DraftWithItems();

            bill.SubmitForApproval(FIXED_NOW);

            Assert.Equal(BillStatus.AwaitingApproval, bill.Status);
            Assert.Equal(FIXED_NOW, bill.UpdatedAt);
        }

        [Fact]
        public void SubmitForApproval_WhenBillHasNoItems_ShouldThrowDomainException()
        {
            var bill = BillMother.Draft();

            var ex = Assert.Throws<DomainException>(
                () => bill.SubmitForApproval(FIXED_NOW));

            Assert.Equal("APD.BIL03", ex.Id);
        }

        [Fact]
        public void SubmitForApproval_ShouldEmitBillSubmittedForApprovalEvent()
        {
            var bill = BillMother.DraftWithItems();
            bill.PullDomainEvents();   // Drains creation events

            bill.SubmitForApproval(FIXED_NOW);

            var events = bill.PullDomainEvents();
            var submittedEvent = Assert.Single(events);
            var billSubmitted = Assert.IsType<BillSubmittedForApproval>(submittedEvent);
            Assert.Equal(bill.Id, billSubmitted.BillId);
            Assert.Equal(FIXED_NOW, billSubmitted.OccurredAt);
        }
    }

    public class WhenApproving
    {
        [Fact]
        public void Approve_WhenBillIsAwaitingApproval_ShouldChangeStatus()
        {
            var bill = BillMother.AwaitingApproval();

            bill.Approve(UserId.New(), FIXED_NOW);

            Assert.Equal(BillStatus.Approved, bill.Status);
        }

        [Fact]
        public void Approve_WhenBillIsDraft_ShouldThrowDomainException()
        {
            var bill = BillMother.Draft();

            var ex = Assert.Throws<DomainException>(
                () => bill.Approve(UserId.New(), FIXED_NOW));

            Assert.Equal("APD.BIL01", ex.Id);
        }

        [Fact]
        public void Approve_ShouldEmitBillApprovedEventWithCorrectPayload()
        {
            var bill = BillMother.AwaitingApproval(itemCount: 2, itemAmount: 75m);
            var approver = UserId.New();
            bill.PullDomainEvents();   // Drains previous events

            bill.Approve(approver, FIXED_NOW);

            var events = bill.PullDomainEvents();
            var approvedEvent = Assert.Single(events);
            var billApproved = Assert.IsType<BillApproved>(approvedEvent);
            Assert.Equal(bill.Id, billApproved.BillId);
            Assert.Equal(approver, billApproved.ApprovedBy);
            Assert.Equal(150m, billApproved.Amount);          // 2 items * 75
            Assert.Equal("BRL", billApproved.Currency);
            Assert.Equal(FIXED_NOW, billApproved.OccurredAt);
        }
    }
}
```

### Notas sobre Aggregate Root

- **Drene eventos antes do act** quando quiser verificar só os eventos novos: `bill.PullDomainEvents();` no fim do arrange.
- **Verifique cada campo do payload** individualmente — não use `Assert.Equal(expectedEvent, actualEvent)` porque `EventId` é gerado e nunca casa.
- **Evento de criação** sempre tem teste próprio (separado dos testes de `Create`).
- **Use `Assert.Single`** quando espera exatamente 1 evento — falha automaticamente se houver 0 ou >1.

## Value Object: testes essenciais

Para cada VO, gere testes de:

1. **Construção válida** — caminho feliz, prop populadas corretamente
2. **Construção inválida** — cada regra de validação dispara `DomainException`
3. **Igualdade** — instâncias com mesmo valor são iguais
4. **Desigualdade** — instâncias com valor diferente não são iguais
5. **Imutabilidade** — métodos retornam novo VO (opcional, depende do VO)
6. **Métodos de comportamento** — `Add`, `Subtract`, `Combine`, etc.

### Template completo

```csharp
// AccountsPayable.Domain.Tests/Bills/MoneyTests.cs
namespace AccountsPayable.Domain.Tests.Bills;

using AccountsPayable.Domain.Bills.ValueObjects;
using AccountsPayable.Domain.SeedWork;

public class MoneyTests
{
    public class WhenConstructing
    {
        [Fact]
        public void Constructor_WithValidAmountAndCurrency_ShouldCreateMoney()
        {
            var money = new Money(100m, "BRL");

            Assert.Equal(100m, money.Amount);
            Assert.Equal("BRL", money.Currency);
        }

        [Theory]
        [InlineData(0.01)]
        [InlineData(100)]
        [InlineData(999999.99)]
        public void Constructor_WithValidAmount_ShouldStoreAmount(decimal amount)
        {
            var money = new Money(amount, "BRL");

            Assert.Equal(amount, money.Amount);
        }

        [Theory]
        [InlineData("BRL")]
        [InlineData("USD")]
        [InlineData("EUR")]
        public void Constructor_WithValidCurrency_ShouldStoreCurrencyUpperCase(string currency)
        {
            var money = new Money(100m, currency);

            Assert.Equal(currency.ToUpperInvariant(), money.Currency);
        }

        [Fact]
        public void Constructor_WithLowerCaseCurrency_ShouldNormalizeToUpperCase()
        {
            var money = new Money(100m, "brl");

            Assert.Equal("BRL", money.Currency);
        }

        [Theory]
        [InlineData("")]
        [InlineData(" ")]
        [InlineData(null)]
        [InlineData("AB")]
        [InlineData("ABCD")]
        [InlineData("12A")]
        public void Constructor_WithInvalidCurrency_ShouldThrowDomainException(string? invalidCurrency)
        {
            var ex = Assert.Throws<DomainException>(
                () => new Money(100m, invalidCurrency!));

            Assert.Equal("APD.MNY01", ex.Id);
        }
    }

    public class WhenComparing
    {
        [Fact]
        public void Equals_WithSameAmountAndCurrency_ShouldReturnTrue()
        {
            var a = new Money(100m, "BRL");
            var b = new Money(100m, "BRL");

            Assert.Equal(a, b);
            Assert.True(a.Equals(b));
        }

        [Fact]
        public void Equals_WithDifferentAmount_ShouldReturnFalse()
        {
            var a = new Money(100m, "BRL");
            var b = new Money(200m, "BRL");

            Assert.NotEqual(a, b);
        }

        [Fact]
        public void Equals_WithDifferentCurrency_ShouldReturnFalse()
        {
            var a = new Money(100m, "BRL");
            var b = new Money(100m, "USD");

            Assert.NotEqual(a, b);
        }

        [Fact]
        public void GetHashCode_WithSameValues_ShouldReturnSameHash()
        {
            var a = new Money(100m, "BRL");
            var b = new Money(100m, "BRL");

            Assert.Equal(a.GetHashCode(), b.GetHashCode());
        }
    }

    public class WhenOperating
    {
        [Fact]
        public void Add_WithSameCurrency_ShouldReturnSumAsNewMoney()
        {
            var a = new Money(100m, "BRL");
            var b = new Money(50m, "BRL");

            var result = a.Add(b);

            Assert.Equal(new Money(150m, "BRL"), result);
        }

        [Fact]
        public void Add_ShouldNotMutateOriginal()
        {
            var a = new Money(100m, "BRL");
            var b = new Money(50m, "BRL");

            a.Add(b);

            Assert.Equal(100m, a.Amount);
        }

        [Fact]
        public void Add_WithDifferentCurrency_ShouldThrowDomainException()
        {
            var a = new Money(100m, "BRL");
            var b = new Money(50m, "USD");

            var ex = Assert.Throws<DomainException>(() => a.Add(b));

            Assert.Equal("APD.MNY03", ex.Id);
        }

        [Fact]
        public void Subtract_WithSameCurrency_ShouldReturnDifferenceAsNewMoney()
        {
            var a = new Money(100m, "BRL");
            var b = new Money(30m, "BRL");

            var result = a.Subtract(b);

            Assert.Equal(new Money(70m, "BRL"), result);
        }
    }

    public class WhenUsingFactories
    {
        [Theory]
        [InlineData("BRL")]
        [InlineData("USD")]
        public void Zero_ShouldReturnMoneyWithZeroAmount(string currency)
        {
            var zero = Money.Zero(currency);

            Assert.Equal(0m, zero.Amount);
            Assert.Equal(currency, zero.Currency);
        }
    }
}
```

## Smart Enum (Enumeration): testes essenciais

Para cada Smart Enum, gere testes de:

1. **Cada transição válida** retorna `true`
2. **Cada transição inválida** retorna `false` (matriz completa via `[Theory]`)
3. **`FromValue` / `FromDisplayName`** retornam instância correta
4. **`TryFromValue` / `TryFromDisplayName`** retornam null em ausência
5. **`GetAll`** retorna todas as instâncias

### Template

```csharp
// AccountsPayable.Domain.Tests/Bills/BillStatusTests.cs
namespace AccountsPayable.Domain.Tests.Bills;

using AccountsPayable.Domain.Bills.Enumerations;
using AccountsPayable.Domain.SeedWork;

public class BillStatusTests
{
    public class WhenCheckingTransitions
    {
        [Theory]
        [InlineData(1, 2)]   // Draft -> AwaitingApproval
        [InlineData(1, 6)]   // Draft -> Cancelled
        [InlineData(2, 3)]   // AwaitingApproval -> Approved
        [InlineData(2, 7)]   // AwaitingApproval -> Rejected
        [InlineData(2, 6)]   // AwaitingApproval -> Cancelled
        [InlineData(3, 4)]   // Approved -> Scheduled
        [InlineData(3, 6)]   // Approved -> Cancelled
        [InlineData(4, 5)]   // Scheduled -> Paid
        public void CanTransitionTo_WithValidTransition_ShouldReturnTrue(int fromId, int toId)
        {
            var from = Enumeration.FromValue<BillStatus>(fromId);
            var to = Enumeration.FromValue<BillStatus>(toId);

            var result = from.CanTransitionTo(to);

            Assert.True(result);
        }

        [Theory]
        [InlineData(1, 3)]   // Draft -> Approved (skipping AwaitingApproval)
        [InlineData(1, 4)]   // Draft -> Scheduled
        [InlineData(1, 5)]   // Draft -> Paid
        [InlineData(3, 1)]   // Approved -> Draft (backwards)
        [InlineData(5, 1)]   // Paid -> Draft (terminal)
        [InlineData(5, 6)]   // Paid -> Cancelled (terminal)
        [InlineData(6, 1)]   // Cancelled -> Draft (terminal)
        [InlineData(7, 3)]   // Rejected -> Approved (terminal)
        public void CanTransitionTo_WithInvalidTransition_ShouldReturnFalse(int fromId, int toId)
        {
            var from = Enumeration.FromValue<BillStatus>(fromId);
            var to = Enumeration.FromValue<BillStatus>(toId);

            var result = from.CanTransitionTo(to);

            Assert.False(result);
        }
    }

    public class WhenLookingUp
    {
        [Theory]
        [InlineData(1, "DRAFT")]
        [InlineData(2, "AWAITING_APPROVAL")]
        [InlineData(3, "APPROVED")]
        [InlineData(5, "PAID")]
        public void FromValue_WithValidId_ShouldReturnMatchingInstance(int id, string expectedName)
        {
            var status = Enumeration.FromValue<BillStatus>(id);

            Assert.Equal(expectedName, status.Name);
            Assert.Equal(id, status.Id);
        }

        [Fact]
        public void FromValue_WithInvalidId_ShouldThrowInvalidOperationException()
        {
            Assert.Throws<InvalidOperationException>(
                () => Enumeration.FromValue<BillStatus>(999));
        }

        [Fact]
        public void TryFromValue_WithInvalidId_ShouldReturnNull()
        {
            var status = Enumeration.TryFromValue<BillStatus>(999);

            Assert.Null(status);
        }

        [Fact]
        public void GetAll_ShouldReturnAllStatuses()
        {
            var all = Enumeration.GetAll<BillStatus>().ToList();

            Assert.Equal(7, all.Count);
            Assert.Contains(BillStatus.Draft, all);
            Assert.Contains(BillStatus.Paid, all);
            Assert.Contains(BillStatus.Cancelled, all);
        }
    }
}
```

## Entity interna: testes via Root

**Entity interna não tem teste isolado** — construtor é `internal`, métodos são `internal`. Tudo é exercitado **via Root**.

```csharp
// AccountsPayable.Domain.Tests/Bills/BillItemTests.cs
namespace AccountsPayable.Domain.Tests.Bills;

using AccountsPayable.Domain.Bills.ValueObjects;
using AccountsPayable.Domain.SeedWork;
using AccountsPayable.Domain.Tests.Bills.Mothers;

public class BillItemTests
{
    private static readonly DateTime FIXED_NOW = new(2024, 1, 15, 10, 0, 0, DateTimeKind.Utc);

    [Fact]
    public void AddItem_WithValidData_ShouldCreateItemThroughRoot()
    {
        var bill = BillMother.Draft();

        bill.AddItem("Consulting", new Money(500m, "BRL"), "OPEX", FIXED_NOW);

        var item = Assert.Single(bill.Items);
        Assert.Equal("Consulting", item.Description);
        Assert.Equal(new Money(500m, "BRL"), item.Amount);
        Assert.Equal("OPEX", item.CategoryCode);
        Assert.NotEqual(Guid.Empty, item.Id);
    }

    [Theory]
    [InlineData("")]
    [InlineData(" ")]
    public void AddItem_WithEmptyDescription_ShouldThrowDomainException(string description)
    {
        var bill = BillMother.Draft();

        var ex = Assert.Throws<DomainException>(
            () => bill.AddItem(description, new Money(100m, "BRL"), "OPEX", FIXED_NOW));

        Assert.Equal("APD.BIL10", ex.Id);
    }

    [Theory]
    [InlineData("")]
    [InlineData(" ")]
    public void AddItem_WithEmptyCategory_ShouldThrowDomainException(string category)
    {
        var bill = BillMother.Draft();

        var ex = Assert.Throws<DomainException>(
            () => bill.AddItem("Valid description", new Money(100m, "BRL"), category, FIXED_NOW));

        Assert.Equal("APD.BIL11", ex.Id);
    }
}
```

## Factory de erros: testes de existência

Verifica que cada erro:
1. Existe (compila)
2. Tem `Id` no padrão esperado
3. Tem `MessageTemplate` não-vazia
4. Aceita os parâmetros declarados

### Template

```csharp
// AccountsPayable.Domain.Tests/Bills/BillErrorsTests.cs
namespace AccountsPayable.Domain.Tests.Bills;

using AccountsPayable.Domain.Bills;
using AccountsPayable.Domain.SeedWork;

public class BillErrorsTests
{
    [Fact]
    public void InvalidStatusTransition_ShouldHaveCorrectIdAndParameters()
    {
        var error = BillErrors.InvalidStatusTransition("DRAFT", "APPROVED");

        Assert.Equal("APD.BIL01", error.Id);
        Assert.NotEmpty(error.MessageTemplate);
        Assert.Equal(2, error.Parameters.Count);
        Assert.Equal("DRAFT", error.Parameters[0]);
        Assert.Equal("APPROVED", error.Parameters[1]);
        Assert.NotEmpty(error.SourcePath);
    }

    [Fact]
    public void CannotModifyBillInStatus_ShouldHaveCorrectIdAndParameter()
    {
        var error = BillErrors.CannotModifyBillInStatus("APPROVED");

        Assert.Equal("APD.BIL02", error.Id);
        Assert.Single(error.Parameters);
        Assert.Equal("APPROVED", error.Parameters[0]);
    }

    [Fact]
    public void EmptyBillCannotBeSubmitted_ShouldHaveCorrectIdAndNoParameters()
    {
        var error = BillErrors.EmptyBillCannotBeSubmitted();

        Assert.Equal("APD.BIL03", error.Id);
        Assert.Empty(error.Parameters);
    }

    [Fact]
    public void AllErrors_ShouldHaveUniqueIds()
    {
        var errors = new[]
        {
            BillErrors.InvalidStatusTransition("X", "Y").Id,
            BillErrors.CannotModifyBillInStatus("X").Id,
            BillErrors.EmptyBillCannotBeSubmitted().Id,
            BillErrors.ItemAmountCannotBeNegative(-1m).Id,
            BillErrors.MaxItemsExceeded(200).Id,
            BillErrors.ItemDescriptionRequired().Id,
            BillErrors.ItemCategoryRequired().Id,
        };

        Assert.Equal(errors.Length, errors.Distinct().Count());
    }
}
```

## Domain Event: testes via Aggregate

Domain Events são testados via emissão pelo Aggregate (já coberto nos testes do Aggregate Root). Em geral, **não há teste isolado de Domain Event** — eles são records simples sem comportamento.

Exceção: se o Event tem método auxiliar (raro, mas possível), teste-o em arquivo próprio.

## DueDate (VO com comportamento de tempo)

VOs que dependem de tempo devem aceitar parâmetro `now` em vez de usar `DateTime.UtcNow`:

```csharp
public class DueDateTests
{
    [Theory]
    [InlineData("2024-01-15", "2024-01-20", false)]   // not yet overdue
    [InlineData("2024-01-15", "2024-01-15", false)]   // exactly today, not overdue
    [InlineData("2024-01-15", "2024-01-14", true)]    // overdue by 1 day
    public void IsOverdue_ShouldReturnExpectedResult(string nowIso, string dueIso, bool expected)
    {
        var now = DateTime.Parse(nowIso, null, DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal);
        var due = new DueDate(DateTime.Parse(dueIso, null, DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal));

        var result = due.IsOverdue(now);

        Assert.Equal(expected, result);
    }
}
```
