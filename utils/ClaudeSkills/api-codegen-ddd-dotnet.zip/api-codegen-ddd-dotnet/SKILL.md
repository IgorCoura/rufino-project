---
name: api-codegen-ddd-dotnet
description: Cria e mantém a camada API (host HTTP) de projetos .NET com Clean Architecture e DDD que usam mediator próprio (skill-irmã application-codegen-ddd-dotnet). Use sempre que o usuário pedir para criar controller, expor Command/Query via HTTP, montar endpoint, configurar autenticação Keycloak, adicionar filtros de exceção, blindar IDOR multi-tenant, decorar endpoint com autorização granular, configurar OpenAPI, CORS ou Program.cs — inclusive quando ele não cita API (frases como expor X via HTTP, monta endpoint pra Y, recebe Z pela rota, cria o controller de W também devem disparar). Cobre Controllers (BaseController e padrão de 5 passos), filtros para DomainException/ApplicationException/erros inesperados, autenticação JWT via Keycloak.AuthServices, atributo ProtectedResource (recurso, ação), TenantAuthorizationFilter anti-IDOR, e Program.cs com extensões CORS/OpenAPI/headers. Não cria projeto csproj. Não cobre Application, Infra nem Domain — use application-codegen-ddd-dotnet e domain-modeler para essas camadas.
---

# api-codegen-ddd-dotnet

A camada API tem **muito pouco código próprio** — propositalmente. Ela é o adaptador HTTP que recebe request, dispara Command/Query no mediator da Application, e converte exceção em JSON. Toda a lógica vive em Application/Domain.

## Filosofia

1. **Controller é Humble Object.** 5 a 8 linhas por endpoint. Se passa disso, há lógica indevida — mover para Application.
2. **Exceção vira envelope JSON via filtro central**, não `try/catch` espalhado.
3. **Autenticação é configuração, não código.** A biblioteca `Keycloak.AuthServices` resolve. A skill **configura**.
4. **Autorização aspect-based.** `[ProtectedResource("bill", "approve")]` em cada endpoint diz o que ele exige. Sem `if` de role pelo código.
5. **Multi-tenant em primeiro lugar.** `TenantAuthorizationFilter` global garante que o `{tenantId}` do path bate com o `tenant_ids` do JWT. Defesa em profundidade junto com o filtro do Handler/Query da Application.
6. **Convenção rígida sobre URL.** `api/v1/{tenantId}/<recurso>/...` para todo endpoint multi-tenant.

## Quando o usuário pede algo nesta camada — fluxo

### Cenário A: usuário pede um Controller novo (ex.: "cria o controller de Bills")

1. **Confirmar que a Application já tem os Commands/Queries.** Se não, parar e indicar `application-codegen-ddd-dotnet`. A API não inventa Commands.
2. **Listar com o usuário** quais operações expor (geralmente: List, GetById, Create, Alter*, ações de domínio, Delete) e qual cada uma mapeia na Application.
3. **Gerar `<Aggregate>sController.cs`** seguindo o padrão de 5 passos por endpoint (ver `references/controller-anatomy.md`).
4. **Decorar cada endpoint com `[ProtectedResource("<recurso>", "<ação>")]`**. Convenção: recurso = nome do agregado em lowercase singular (`bill`, `employee`); ação = verbo (`read`, `create`, `approve`, `delete`).
5. **Confirmar `[Route("api/v1/{tenantId:guid}/<plural>")]`** no controller.

### Cenário B: usuário pede setup inicial da API (ex.: "configura a camada API")

Gerar **em uma sequência**:

1. `Program.cs` enxuto chamando as extensões.
2. `Extension/AuthExtensions.cs` — `AddKeycloakAuth` (JWT + Authorization + ProtectedResource).
3. `Extension/ApiExtensions.cs` — `AddControllers` + JSON + filtros globais.
4. `Extension/CorsExtensions.cs` — `AddCorsForFront`.
5. `Extension/OpenApiExtensions.cs` — `AddOpenApiDocs` (Bearer + Idempotency-Key).
6. `Filters/DomainExceptionFilter.cs`, `Filters/ApplicationExceptionFilter.cs`, `Filters/UnhandledExceptionFilter.cs`, `Filters/TenantAuthorizationFilter.cs`.
7. `Authorization/ProtectedResourceAttribute.cs`, `...Requirement.cs`, `...Handler.cs`, `...PolicyProvider.cs`, `...Extensions.cs`.
8. `Controllers/BaseController.cs`.
9. Bloco `Keycloak` e `Cors` em `appsettings.json`.

Detalhes em `references/program-and-di.md`.

### Cenário C: usuário pede mudança pontual (ex.: "adiciona um endpoint Approve no controller")

- "Adicionar endpoint em controller existente" → só adiciona o método. Mantém o resto do arquivo intocado.
- "Trocar nome do header de idempotência" → ajusta nos endpoints + na extensão OpenAPI. Confirmar com o usuário antes (mudança quebra clientes).
- "Mudar audience do Keycloak" → muda `appsettings.json` (chave `verify-token-audience` e `resource`).

## O que esta skill NÃO faz

- **Não cria projetos** (.csproj). Assume que `MeuSaaS.API/` já existe.
- **Não cria Application/Infra/Domain.** Usa as skills correspondentes.
- **Não escreve regras de negócio dentro do Controller.** Se aparecer `if` que decide algo de domínio, parar e mover para a Application.
- **Não implementa autenticação do zero.** Usa `Keycloak.AuthServices` (NuGet). Se o usuário pedir Identity Provider customizado, recusar e indicar IdentityServer/OpenIddict.
- **Não cria validação de input dentro do Controller.** Validação é responsabilidade da Application (`IValidator<TCommand>` + `ValidatorBehavior`).
- **Não monta autenticação de usuário/login.** A API é Resource Server, não Authorization Server. Login acontece no front contra Keycloak.

## Estrutura de pastas

```
MeuSaaS.API/
├── Controllers/
│   ├── BaseController.cs
│   └── <Aggregate>sController.cs
├── Filters/
│   ├── DomainExceptionFilter.cs            ← DomainException → 422 + envelope
│   ├── ApplicationExceptionFilter.cs       ← ApplicationException → 4xx por code
│   ├── UnhandledExceptionFilter.cs         ← fallback → 500 + correlationId
│   └── TenantAuthorizationFilter.cs        ← defesa anti-IDOR (global)
├── Authorization/
│   ├── ProtectedResourceAttribute.cs
│   ├── ProtectedResourceRequirement.cs
│   ├── ProtectedResourceHandler.cs         ← lê role 'recurso:ação' do JWT
│   ├── ProtectedResourcePolicyProvider.cs
│   └── ProtectedResourceExtensions.cs
├── Extension/
│   ├── AuthExtensions.cs                   ← AddKeycloakAuth
│   ├── ApiExtensions.cs                    ← AddControllers + filtros + JSON
│   ├── CorsExtensions.cs                   ← AddCorsForFront
│   └── OpenApiExtensions.cs                ← AddOpenApiDocs (Bearer + Idempotency-Key)
├── Program.cs
├── appsettings.json
└── appsettings.Development.json
```

## Template mental — endpoint de Command em 5 passos

```csharp
[HttpPost]
[ProtectedResource("bill", "create")]
public async Task<ActionResult<CreateBillResponse>> Create(
    [FromRoute]                            Guid             tenantId,
    [FromBody]                             CreateBillModel  model,
    [FromHeader(Name = "Idempotency-Key")] Guid             requestId,
    CancellationToken                                       ct)
{
    // 1. Model → Command (TenantId vem da rota)
    // 2. Embrulhar em IdentifiedCommand (idempotência)
    // 3. Despachar pelo mediator
    // 4. (Filter cuida das exceções)
    // 5. Retornar Ok com Response
    var identified = new IdentifiedCommand<CreateBillCommand, CreateBillResponse>(
        model.ToCommand(tenantId), requestId);
    return OkResponse(await mediator.Send(identified, ct));
}
```

Detalhes (Query, ação de domínio, upload, delete, ações sem Model) em `references/controller-anatomy.md`.

## Decisões fundamentais já fixadas

A skill foi feita assumindo estas escolhas — se o usuário pedir mudança, alertar do impacto antes de gerar.

| Tema | Decisão |
|---|---|
| Provedor de autenticação | Keycloak (OAuth2/OIDC) + biblioteca `Keycloak.AuthServices` |
| Modelo de autorização | Aspect-based via `[ProtectedResource("recurso", "ação")]` mapeando para roles JWT `recurso:ação`. **Sem** chamada extra ao Keycloak por request. |
| Formato do payload de erro | Envelope custom `{ errors: [{ code, message, params? }], correlationId }`. **Não** ProblemDetails. |
| Header de idempotência | `Idempotency-Key` (padrão de fato da indústria) |
| Status HTTP | 422 para `DomainException`; 4xx por code para `ApplicationException`; 500 + correlationId para erro inesperado |

Detalhe e racional em `references/conventions.md`.

## Referências

Leia o arquivo correspondente quando começar o cenário:

- `references/controller-anatomy.md` — `BaseController`, padrão de endpoint por tipo (CRUD, ação, upload, delete, lista), esqueleto completo, anti-padrões, checklist. **Leia antes de gerar qualquer controller.**
- `references/error-filters.md` — `DomainExceptionFilter`, `ApplicationExceptionFilter`, `UnhandledExceptionFilter`, formato do envelope `{ errors: [...] }`, mapa de codes → HTTP, ordem de registro. **Leia no setup inicial (cenário B).**
- `references/auth-keycloak.md` — configuração `Keycloak.AuthServices`, JwtBearer, claim `tenant_ids`, `TenantAuthorizationFilter`, mapper do Keycloak. **Leia no setup inicial (cenário B).**
- `references/protected-resource.md` — atributo `[ProtectedResource]` completo (attribute + requirement + handler + policy provider + DI), convenções de naming, composite roles do Keycloak, quando usar UMA. **Leia ao criar a primeira autorização do projeto.**
- `references/program-and-di.md` — `Program.cs` enxuto, extensões CORS, OpenAPI (Bearer + Idempotency-Key documentados), ordem do pipeline. **Leia no setup inicial (cenário B).**
- `references/conventions.md` — convenções de URL, status HTTP, headers, verbos de ação. **Consulte sempre.**
