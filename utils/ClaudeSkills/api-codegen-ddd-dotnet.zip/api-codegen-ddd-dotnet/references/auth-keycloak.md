# Autenticação Keycloak — `Keycloak.AuthServices` + multi-tenant guard

A camada API usa a biblioteca [`Keycloak.AuthServices.Authentication`](https://www.nuget.org/packages/Keycloak.AuthServices.Authentication) (NuGet, mantida por Oleksii Nikiforov). É a biblioteca padrão da comunidade .NET para integração com Keycloak.

A skill **não** reimplementa autenticação JWT. A skill **configura** a biblioteca e adiciona uma única peça customizada por cima:

1. Configuração `AddKeycloakWebApiAuthentication` (autenticação JWT via OIDC discovery do Keycloak).
2. `TenantAuthorizationFilter` global — defesa anti-IDOR multi-tenant. **Esta é a única peça customizada de autenticação.**

## Pacotes NuGet

```xml
<PackageReference Include="Keycloak.AuthServices.Authentication" Version="3.*" />
<PackageReference Include="Keycloak.AuthServices.Authorization" Version="3.*" />
```

## Configuração — `appsettings.json`

```json
{
  "Keycloak": {
    "realm": "meusaas",
    "auth-server-url": "https://auth.meusaas.com/",
    "ssl-required": "external",
    "resource": "meusaas-api",
    "verify-token-audience": true,
    "credentials": {
      "secret": ""
    },
    "confidential-port": 0
  }
}
```

| Campo | O que é |
|---|---|
| `realm` | Realm do Keycloak (escopo de tenants do Keycloak — não confundir com seu tenant de aplicação) |
| `auth-server-url` | URL base do Keycloak |
| `ssl-required` | `external` em prod (TLS obrigatório fora da rede interna), `none` em dev |
| `resource` | Client ID do Keycloak — corresponde ao client criado para a API (audience do JWT) |
| `verify-token-audience` | `true` em prod — força que `aud` do JWT == `resource`. Defesa contra token de outro client |
| `credentials.secret` | Só necessário se a API for client confidencial (raro para resource server). Em dev pode ficar vazio. |

`appsettings.Development.json` sobrescreve `auth-server-url` para `http://localhost:8080/` (o Keycloak local).

## Setup — `AuthExtensions.cs`

```csharp
// Extension/AuthExtensions.cs
namespace MeuSaaS.API.Extension;

using Keycloak.AuthServices.Authentication;
using Keycloak.AuthServices.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;

public static class AuthExtensions
{
    public static IServiceCollection AddKeycloakAuth(
        this IServiceCollection services, IConfiguration config)
    {
        // 1. JwtBearer + OIDC discovery (a lib resolve via /.well-known/openid-configuration)
        services.AddKeycloakWebApiAuthentication(config, opts =>
        {
            opts.RequireHttpsMetadata = !IsDev();   // false em dev local
            opts.SaveToken            = true;       // permite acessar JWT raw em HttpContext
        });

        // 2. Autorização padrão exige autenticação ativa
        services.AddAuthorization(opts =>
        {
            opts.FallbackPolicy = new AuthorizationPolicyBuilder()
                .RequireAuthenticatedUser()
                .Build();
        });

        // 3. ProtectedResource (handler de policy customizado — ver protected-resource.md)
        services.AddProtectedResourceAuthorization();

        return services;
    }

    private static bool IsDev() =>
        Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == "Development";
}
```

## Pipeline — `Program.cs`

```csharp
// trecho do Program.cs
app.UseAuthentication();   // valida JWT, popula User
app.UseAuthorization();    // dispara policies + ProtectedResource
app.MapControllers();
```

A ordem **importa**. Authentication antes de Authorization, e Authorization antes de MapControllers (senão policies não rodam).

## Estrutura do JWT esperada

A biblioteca `Keycloak.AuthServices` consome o JWT padrão do Keycloak. Estrutura mínima de claims que esta skill assume:

```json
{
  "sub":  "user-uuid-aqui",
  "iss":  "https://auth.meusaas.com/realms/meusaas",
  "aud":  "meusaas-api",
  "exp":  1735689600,
  "iat":  1735686000,

  "preferred_username": "joao@meusaas.com",
  "email":              "joao@meusaas.com",

  "realm_access": {
    "roles": ["bill:read", "bill:create", "bill:approve", "employee:read"]
  },

  "tenant_ids": ["7e3d-...-uuid", "1a2b-...-uuid"]
}
```

Pontos:

- **`realm_access.roles`** carrega os pares `recurso:ação` que o `[ProtectedResource]` consome. Mapeamento configurado em `protected-resource.md`.
- **`tenant_ids`** é a lista dos tenants em que o usuário tem membership. Usada pelo `TenantAuthorizationFilter`. Configurado no Keycloak via **mapper** custom (ver "Configurando tenant_ids no Keycloak" abaixo).

## `TenantAuthorizationFilter` — defesa anti-IDOR

Toda rota com `{tenantId}` no path **precisa** garantir que o `tenantId` recebido pertence ao usuário do JWT. Sem isso, qualquer cliente autenticado pode trocar o segmento e acessar dados de outro tenant — IDOR clássico.

A defesa em profundidade aqui:

1. **TenantAuthorizationFilter (esta skill)** — global, valida `tenantId` da rota contra `tenant_ids` do JWT.
2. **Handler/Query da Application** — filtra por `TenantId` em todo `Where`. Mesmo se o filtro acima falhar.
3. **Global Query Filter no DbContext (Infra)** — opcional, terceira camada.

```csharp
// Filters/TenantAuthorizationFilter.cs
namespace MeuSaaS.API.Filters;

using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

public sealed class TenantAuthorizationFilter : IAsyncActionFilter
{
    public async Task OnActionExecutionAsync(
        ActionExecutingContext context, ActionExecutionDelegate next)
    {
        // Só age se a rota tem {tenantId} (ex.: rotas /admin/ não têm)
        if (context.RouteData.Values.TryGetValue("tenantId", out var raw) &&
            Guid.TryParse(raw?.ToString(), out var routeTenantId))
        {
            var userTenants = ExtractTenantIds(context.HttpContext.User);

            if (!userTenants.Contains(routeTenantId))
            {
                context.Result = new ObjectResult(new
                {
                    errors = new[]
                    {
                        new
                        {
                            code    = "UNAUTHORIZED_TENANT_ACCESS",
                            message = "Usuário não pertence a este tenant."
                        }
                    },
                    correlationId = context.HttpContext.TraceIdentifier
                })
                {
                    StatusCode = StatusCodes.Status403Forbidden
                };
                return;
            }
        }

        await next();
    }

    private static HashSet<Guid> ExtractTenantIds(ClaimsPrincipal user)
    {
        // tenant_ids é claim multi-valor — JWT pode trazer como string CSV ou múltiplos claims com mesmo nome.
        // A lib Keycloak.AuthServices, com mapper "multivalued = true", popula múltiplos claims.
        return user.FindAll("tenant_ids")
            .Select(c => Guid.TryParse(c.Value, out var g) ? (Guid?)g : null)
            .Where(g => g.HasValue)
            .Select(g => g!.Value)
            .ToHashSet();
    }
}
```

Registrado em `AddApiExtensions` (ver `error-filters.md`):

```csharp
opts.Filters.Add<TenantAuthorizationFilter>();
```

> **Por que `IAsyncActionFilter` e não `IAuthorizationFilter`?** Porque ele roda **depois** do model binding (já temos `tenantId` resolvido) e **depois** do `[Authorize]`/`[ProtectedResource]` (já temos o `User` autenticado). Ele é a última camada antes do método do Controller.

## Configurando `tenant_ids` no Keycloak

Para que `tenant_ids` apareça no JWT, configure no Keycloak Admin Console:

1. **Atributo customizado no usuário**: edite o usuário, adicione atributo `tenant_ids` com valor `uuid1,uuid2,uuid3` (separado por vírgula).
2. **Mapper no client**: na configuração do client `meusaas-api`, vá em **Client scopes → meusaas-api-dedicated → Mappers → Add mapper → User Attribute**. Configure:
   - **Name**: `tenant_ids`
   - **User Attribute**: `tenant_ids`
   - **Token Claim Name**: `tenant_ids`
   - **Claim JSON Type**: `String`
   - **Add to access token**: ON
   - **Multivalued**: ON (importante — sem isso vira string única, não array)
   - **Aggregate attribute values**: ON

Resultado no JWT: `"tenant_ids": ["uuid1", "uuid2", "uuid3"]`.

A skill **não automatiza** essa configuração no Keycloak (não tem como — é UI/admin). Documenta o passo.

## Acessando o usuário no Controller (quando preciso)

Raramente o Controller precisa do `User`. Quando precisar:

```csharp
[HttpGet("/api/v1/me/tenants")]
public ActionResult<IReadOnlyList<Guid>> MyTenants()
{
    var ids = User.FindAll("tenant_ids")
        .Select(c => Guid.Parse(c.Value))
        .ToList();
    return OkResponse(ids);
}
```

Para usar o `User.Sub` no Handler (ex.: registrar quem aprovou um Bill), passe pelo Command. **Não acesse `IHttpContextAccessor` em Handler** — quebra a fronteira da Application.

```csharp
// API: extrai sub do JWT, monta Command com ApproverId
[HttpPost("{billId:guid}/approve")]
public async Task<...> Approve([FromRoute] Guid tenantId, [FromRoute] Guid billId, ...)
{
    var approverId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
    var command = model.ToCommand(tenantId, billId, approverId);   // approverId injetado aqui
    // ...
}
```

## Anti-padrões

```csharp
// ❌ Validar tenantId manualmente em cada Controller
public async Task<...> GetById([FromRoute] Guid tenantId, ...)
{
    if (!User.HasTenant(tenantId)) return Forbid();   // disperso, fácil esquecer
    // ...
}
// O TenantAuthorizationFilter resolve global. Não repita por Controller.

// ❌ Confiar só no [Authorize] sem TenantAuthorizationFilter
[Authorize] // só checa "está autenticado", não checa membership do tenant
public async Task<...> GetById([FromRoute] Guid tenantId, ...) { ... }
// JWT válido + tenantId arbitrário = IDOR. Sempre TenantAuthorizationFilter.

// ❌ Buscar tenant_ids no banco a cada request
var userTenants = await db.UserTenants.Where(x => x.UserId == userId).ToListAsync();
// Lento. tenant_ids vem no JWT. Se mudar, JWT precisa ser refrescado (lifetime curto + refresh token).

// ❌ Reimplementar JWT validation manualmente
JwtSecurityTokenHandler handler = new(); var jwt = handler.ReadJwtToken(...);
// A biblioteca Keycloak.AuthServices faz isso bem. Não duplique.
```

## Checklist

- [ ] Pacotes `Keycloak.AuthServices.Authentication` e `Keycloak.AuthServices.Authorization` instalados.
- [ ] Bloco `Keycloak` no `appsettings.json` configurado.
- [ ] `AddKeycloakAuth(config)` chamado no `Program.cs`.
- [ ] `app.UseAuthentication()` antes de `app.UseAuthorization()`, ambos antes de `app.MapControllers()`.
- [ ] Mapper `tenant_ids` configurado no client do Keycloak (manual, via Admin Console).
- [ ] `TenantAuthorizationFilter` registrado global.
- [ ] Toda rota multi-tenant usa `{tenantId:guid}` na rota.
- [ ] **Não** valida `tenantId` manualmente no Controller (delegado ao filtro).
- [ ] **Não** acessa `User`/`HttpContext` no Handler (Application) — passa pelo Command.
