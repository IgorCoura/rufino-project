# Convenções — URL, status HTTP, headers, verbos

Resumo curto, consultado por **todos** os cenários da skill.

## URLs

| Tipo de endpoint | Rota |
|---|---|
| Listar | `GET    api/v1/{tenantId}/bills?cursor=...&pageSize=...` |
| Detalhar | `GET    api/v1/{tenantId}/bills/{billId}` |
| Criar | `POST   api/v1/{tenantId}/bills` |
| Alterar campo específico | `PATCH  api/v1/{tenantId}/bills/{billId}/status` |
| Ação de domínio | `POST   api/v1/{tenantId}/bills/{billId}/approve` |
| Deletar | `DELETE api/v1/{tenantId}/bills/{billId}` |

Regras:

- Prefixo `api/v1/` em todo recurso. Versão na URL para quebra explícita; mudanças aditivas não precisam de v2.
- `{tenantId:guid}` em rotas multi-tenant — constraint força validação de Guid antes do controller.
- Recurso no plural lowercase (`bills`, `employees`, `customers`).
- Ação de domínio vira `POST` num sub-recurso (`/{id}/approve`, `/{id}/submit`). **Não use `PUT`** — semântica idempotente do PUT entra em conflito com domínio rico.

## Status HTTP

| Resposta | Status | Body |
|---|---|---|
| Sucesso com retorno | 200 | `Response` JSON |
| Sucesso sem retorno | 204 | (vazio) |
| Lista paginada | 200 | `PagedResult<T>` |
| `DomainException` (regra de negócio violada) | **422 Unprocessable Entity** | `{ errors: [{ code, message, params? }], correlationId }` |
| `ApplicationException` `NOT_FOUND` | **404** | idem |
| `ApplicationException` `VALIDATION_FAILED` | **400** | idem |
| `ApplicationException` `CONCURRENCY_CONFLICT` | **409** | idem |
| `ApplicationException` `IDEMPOTENCY_CONFLICT` | **409** | idem |
| `ApplicationException` `UNAUTHORIZED_TENANT_ACCESS` | **403** | idem |
| Sem JWT ou JWT inválido | 401 | (a biblioteca Keycloak.AuthServices trata) |
| Sem permissão (`[ProtectedResource]`) | 403 | (handler de policy trata) |
| Erro inesperado | 500 | `{ errors: [{ code: "INTERNAL_ERROR" }], correlationId }` |

**Por que 422 para DomainException, não 400?** A request é sintaticamente válida (binding ok), mas o estado de domínio não permite a operação (regra de negócio violada). 422 é a semântica correta — "input bom, mas viola regra".

## Headers

| Header | Direção | Quem produz | Para que serve |
|---|---|---|---|
| `Authorization: Bearer <jwt>` | request | front | autenticação (Keycloak.AuthServices valida) |
| `Idempotency-Key: <guid>` | request | front | idempotência (vai pro `IdentifiedCommand` da Application) |
| `X-Correlation-Id: <guid>` | request | gateway/middleware (gera se ausente) | tracing distribuído ponta-a-ponta |
| `X-Correlation-Id: <guid>` | response | esta API | espelho do request, exposto ao front |

`Idempotency-Key` é **obrigatório** em todo endpoint mutante (`POST`, `PUT`, `PATCH`, `DELETE`). A skill documenta isso no OpenAPI via `IOperationFilter` (ver `references/program-and-di.md`).

## Verbos de Action (do `[ProtectedResource]`)

Padronização do segundo argumento de `[ProtectedResource("recurso", "<ação>")]`:

| Operação | Action |
|---|---|
| Listar / Detalhar | `read` (mesmo verbo para os dois) |
| Criar | `create` |
| Alterar genérico | `update` |
| Alterar campo específico | nome do método rico do agregado, lowercase com hifen: `alter-status`, `change-approver` |
| Deletar | `delete` |
| Ação de domínio | verbo do método rico: `approve`, `submit`, `cancel`, `pay`, `reconcile` |
| Upload | `attach` |

A regra do par `recurso:ação` mapeia 1-para-1 com a role do Keycloak. **Mantenha consistência** — se um endpoint usa `bill:approve`, todos os endpoints relacionados a aprovação usam `bill:approve` (não `bills:approve` no plural, não `bill:approval` substantivo).

## Recurso (primeiro argumento de `[ProtectedResource]`)

| Tipo | Padrão |
|---|---|
| Agregado | Nome em **lowercase singular**: `bill`, `employee`, `customer`, `contract` |
| Funcionalidade transversal | Nome funcional: `admin`, `dashboard`, `tenant-config` |
