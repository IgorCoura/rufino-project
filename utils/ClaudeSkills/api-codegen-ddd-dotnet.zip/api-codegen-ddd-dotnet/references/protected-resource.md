# `[ProtectedResource("recurso", "ação")]` — autorização aspect-based

Atributo customizado desta skill que decora endpoints com a permissão exigida (par `recurso:ação`). Usado em **todo endpoint** que faz algo.

## Mecanismo

Por baixo, é um `IAuthorizationRequirement` + `AuthorizationHandler`. O atributo aplica uma policy dinâmica via `IAuthorizationPolicyProvider`. O handler lê as roles do JWT (Keycloak) procurando a string `<recurso>:<ação>`.

Este modelo:

- **Funciona com Keycloak** sem precisar configurar UMA/Authorization Services (modelo (1) das opções de Keycloak — roles em `realm_access.roles`).
- **É decisão local** — sem chamada extra ao Keycloak por request. Performance alta.
- **É legível no código** — vê o controller e sabe imediatamente o que cada endpoint exige.
- **É auditável** — `grep -r '\[ProtectedResource'` lista toda a superfície de autorização do sistema.

## Setup

### `Authorization/ProtectedResourceAttribute.cs`

```csharp
namespace MeuSaaS.API.Authorization;

using Microsoft.AspNetCore.Authorization;

[AttributeUsage(AttributeTargets.Method | AttributeTargets.Class, AllowMultiple = false)]
public sealed class ProtectedResourceAttribute : AuthorizeAttribute
{
    public string Resource { get; }
    public string Action   { get; }

    public ProtectedResourceAttribute(string resource, string action)
    {
        if (string.IsNullOrWhiteSpace(resource))
            throw new ArgumentException("Resource is required.", nameof(resource));
        if (string.IsNullOrWhiteSpace(action))
            throw new ArgumentException("Action is required.", nameof(action));

        Resource = resource;
        Action   = action;

        // O Policy é dinâmico: "ProtectedResource:<recurso>:<ação>".
        // O AuthorizationPolicyProvider abaixo cria a policy on-demand.
        Policy = $"ProtectedResource:{resource}:{action}";
    }
}
```

Herdar de `AuthorizeAttribute` é o que faz o ASP.NET Core acionar a pipeline de autorização automaticamente quando o atributo está no método.

### `Authorization/ProtectedResourceRequirement.cs`

```csharp
namespace MeuSaaS.API.Authorization;

using Microsoft.AspNetCore.Authorization;

public sealed class ProtectedResourceRequirement(string resource, string action)
    : IAuthorizationRequirement
{
    public string Resource { get; } = resource;
    public string Action   { get; } = action;

    /// <summary>
    /// Role do JWT necessária. Default: "{resource}:{action}".
    /// Override permite mapear para outras convenções (ex.: ":read:bill").
    /// </summary>
    public string RequiredRole => $"{Resource}:{Action}";
}
```

### `Authorization/ProtectedResourceHandler.cs`

```csharp
namespace MeuSaaS.API.Authorization;

using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Logging;

public sealed class ProtectedResourceHandler(ILogger<ProtectedResourceHandler> logger)
    : AuthorizationHandler<ProtectedResourceRequirement>
{
    protected override Task HandleRequirementAsync(
        AuthorizationHandlerContext context,
        ProtectedResourceRequirement requirement)
    {
        if (context.User.Identity?.IsAuthenticated != true)
            return Task.CompletedTask; // sem usuário → falha

        // Roles do Keycloak vêm em `realm_access.roles` no JWT.
        // A lib Keycloak.AuthServices, por padrão, mapeia esses valores para claims
        // com nome ClaimTypes.Role ou "roles" (depende da versão/config).
        // Aqui aceitamos ambos.
        var hasRole = context.User.HasClaim(c =>
                          (c.Type == "roles" || c.Type == System.Security.Claims.ClaimTypes.Role)
                          && string.Equals(c.Value, requirement.RequiredRole, StringComparison.OrdinalIgnoreCase));

        if (hasRole)
        {
            context.Succeed(requirement);
        }
        else
        {
            logger.LogWarning(
                "----- ProtectedResource denied: {Resource}:{Action} for user {User} -----",
                requirement.Resource, requirement.Action,
                context.User.Identity?.Name ?? "<anonymous>");
        }

        return Task.CompletedTask;
    }
}
```

### `Authorization/ProtectedResourcePolicyProvider.cs`

ASP.NET Core não chama o handler diretamente — ele exige uma policy registrada. Como queremos policies dinâmicas (qualquer `{resource}:{action}`), implementamos um `IAuthorizationPolicyProvider`:

```csharp
namespace MeuSaaS.API.Authorization;

using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;

public sealed class ProtectedResourcePolicyProvider(IOptions<AuthorizationOptions> options)
    : IAuthorizationPolicyProvider
{
    private const string Prefix = "ProtectedResource:";

    private readonly DefaultAuthorizationPolicyProvider _fallback = new(options);

    public Task<AuthorizationPolicy?> GetPolicyAsync(string policyName)
    {
        if (policyName.StartsWith(Prefix, StringComparison.Ordinal))
        {
            // policyName: "ProtectedResource:bill:approve" → ["ProtectedResource", "bill", "approve"]
            var parts = policyName.Split(':');
            if (parts.Length == 3)
            {
                var policy = new AuthorizationPolicyBuilder()
                    .RequireAuthenticatedUser()
                    .AddRequirements(new ProtectedResourceRequirement(parts[1], parts[2]))
                    .Build();
                return Task.FromResult<AuthorizationPolicy?>(policy);
            }
        }
        return _fallback.GetPolicyAsync(policyName);
    }

    public Task<AuthorizationPolicy> GetDefaultPolicyAsync() => _fallback.GetDefaultPolicyAsync();

    public Task<AuthorizationPolicy?> GetFallbackPolicyAsync() => _fallback.GetFallbackPolicyAsync();
}
```

### Registro — extensão DI

```csharp
// Authorization/ProtectedResourceExtensions.cs
namespace MeuSaaS.API.Authorization;

using Microsoft.AspNetCore.Authorization;

public static class ProtectedResourceExtensions
{
    public static IServiceCollection AddProtectedResourceAuthorization(this IServiceCollection services)
    {
        services.AddSingleton<IAuthorizationPolicyProvider, ProtectedResourcePolicyProvider>();
        services.AddSingleton<IAuthorizationHandler, ProtectedResourceHandler>();
        return services;
    }
}
```

Chamado de `AuthExtensions.AddKeycloakAuth` (ver `auth-keycloak.md`).

## Convenções de nomenclatura

### Resource

Nome do **agregado** em **lowercase**, sem `s` (singular):

| Agregado | Resource |
|---|---|
| Bill | `bill` |
| Employee | `employee` |
| Customer | `customer` |
| Contract | `contract` |

Resources transversais (não atrelados a agregado) usam nome funcional:

| Conceito | Resource |
|---|---|
| Visualizar dashboards | `dashboard` |
| Operações de admin | `admin` |
| Configuração de tenant | `tenant-config` |

### Action

Verbo **lowercase**, padronizado por convenção:

| Operação | Action |
|---|---|
| Listar | `read` |
| Detalhar | `read` (mesmo da listar) |
| Criar | `create` |
| Alterar (qualquer mutação) | `update` (genérico) ou específico (`alter-status`, `change-approver`) — consistente com o método rico do agregado |
| Deletar | `delete` |
| Aprovar/Submeter/Cancelar (ações de domínio) | verbo da própria ação: `approve`, `submit`, `cancel`, `pay` |
| Upload | `attach` |

Exemplos completos:

```csharp
[ProtectedResource("bill",     "read")]
[ProtectedResource("bill",     "create")]
[ProtectedResource("bill",     "approve")]
[ProtectedResource("bill",     "delete")]
[ProtectedResource("employee", "read")]
[ProtectedResource("employee", "create")]
[ProtectedResource("admin",    "sync-jobs")]
[ProtectedResource("dashboard","read")]
```

A regra do par `recurso:ação` é o que vai pra role do Keycloak. **Mantenha consistência** — se um endpoint usa `bill:approve`, todos os endpoints relacionados a aprovação usam `bill:approve` (não `bills:approve` no plural, não `bill:approval`).

## Configurando roles no Keycloak

No Admin Console do Keycloak:

1. **Realm Roles** ou **Client Roles** (escolha um padrão e fixe).
2. Crie roles com nome exatamente `recurso:ação` — ex.: `bill:approve`, `bill:read`, `employee:create`.
3. Atribua roles aos usuários (ou via grupos, ou via mapper de claims do IdP federado).

A skill **não automatiza** isso (não tem como — é UI/admin). Documenta o passo.

### Composite Roles (recomendado)

Para evitar atribuir 20 roles individuais a cada usuário, use **composite roles** do Keycloak:

- Crie role composite `bill:manager` que agrega `bill:read`, `bill:create`, `bill:update`, `bill:approve`, `bill:delete`.
- Crie role composite `employee:manager` similar.
- Atribua a role composite ao usuário; ele herda todas as filhas.

A API **não precisa saber das composites** — o Keycloak resolve antes de emitir o JWT (o JWT vem com as roles filhas expandidas).

## Comportamento esperado (HTTP)

| Cenário | HTTP |
|---|---|
| JWT ausente | 401 Unauthorized (Keycloak.AuthServices) |
| JWT inválido / expirado | 401 Unauthorized (Keycloak.AuthServices) |
| JWT válido, sem role `recurso:ação` | 403 Forbidden (handler, sem corpo) |
| JWT válido, com role, tenant ok | 2xx |

403 sem corpo é o default do ASP.NET Core. Se quiser corpo no formato `{ errors: [...] }`, customize `IAuthorizationMiddlewareResultHandler` — geralmente não vale o trabalho.

## Anti-padrões

```csharp
// ❌ Endpoint sem [ProtectedResource]
[HttpPost]
public async Task<...> Create(...) { ... }
// Toda operação tem [ProtectedResource]. Sem exceção.

// ❌ Vários [ProtectedResource] no mesmo endpoint
[ProtectedResource("bill", "create")]
[ProtectedResource("bill", "approve")]    // dois? OR ou AND?
public async Task<...> Approve(...) { ... }
// AllowMultiple = false no atributo. Um endpoint, uma ação.

// ❌ Resource em PascalCase ou plural
[ProtectedResource("Bills", "Approve")]
// lowercase, singular. "bill", "approve".

// ❌ Action genérica para tudo
[ProtectedResource("bill", "execute")]
// "execute" não diz nada. Use o verbo do método rico do agregado.

// ❌ Usar [Authorize] junto com [ProtectedResource]
[Authorize, ProtectedResource("bill", "approve")]
// Redundante. ProtectedResource herda AuthorizeAttribute — já exige autenticação.

// ❌ Passar tenantId no Resource
[ProtectedResource($"bill-{tenantId}", "approve")]
// Tenant não é dimensão de autorização — é dimensão de escopo. Quem cuida do tenant é o TenantAuthorizationFilter.

// ❌ Logar a role no JWT (vaza permissões em log público)
logger.LogInformation("User has roles: {Roles}", string.Join(",", userRoles));
// Em log de erro/warning ok (com correlation), mas não em log de info por request.
```

## Quando usar Authorization Services do Keycloak (UMA) em vez disso

Se você precisa de:

- **Permissões dinâmicas** (sem deploy para mudar quem pode o quê).
- **Permissões em nível de instância** (usuário X pode aprovar **este** Bill, não outros).
- **Decisão centralizada auditável** com policies em arvore complexas.

Aí você usa o pacote `Keycloak.AuthServices.Authorization` no modo Authorization Services + UMA. Isso traz overhead (chamada extra ao Keycloak por request, normalmente cacheada) mas dá flexibilidade enorme.

A skill **default** é o modelo simples (roles `recurso:ação`). Se o usuário pedir UMA explicitamente, é mudança grande — alerta para o trade-off antes de gerar.

## Checklist

- [ ] `Authorization/ProtectedResourceAttribute.cs` criado.
- [ ] `Authorization/ProtectedResourceRequirement.cs` criado.
- [ ] `Authorization/ProtectedResourceHandler.cs` criado.
- [ ] `Authorization/ProtectedResourcePolicyProvider.cs` criado.
- [ ] `AddProtectedResourceAuthorization()` registrado no DI.
- [ ] Todo endpoint do projeto tem `[ProtectedResource("recurso", "ação")]`.
- [ ] Roles `recurso:ação` criadas no Keycloak (manual via Admin Console).
- [ ] Convenção lowercase singular para resource, lowercase verbo para action.
