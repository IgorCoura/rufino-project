# Filtros de exceção — convertem `DomainException` e `ApplicationException` em JSON

A camada API tem **dois filtros separados**, refletindo a separação de erros que a Application/Domain mantêm. Cada um traduz seu tipo de exceção para HTTP + envelope JSON `{ errors: [...] }`.

Filtros são `IExceptionFilter` registrados global em `AddControllers(opts => opts.Filters.Add<...>())`.

## Envelope JSON — formato único

Tanto `DomainException` quanto `ApplicationException` retornam o **mesmo formato**:

```json
{
  "errors": [
    {
      "code":     "APD.BIL01",
      "message":  "Transição inválida de status: DRAFT → PAID.",
      "params":   ["DRAFT", "PAID"]
    }
  ],
  "correlationId": "9f1e8c2d-..."
}
```

Campos:

| Campo | Tipo | Origem |
|---|---|---|
| `errors[].code` | string | `DomainException.Id` ou `ApplicationException.Code` |
| `errors[].message` | string | `Exception.Message` (já formatado pela exception) |
| `errors[].params` | array opcional | `DomainException.Parameters` ou `ApplicationException.Parameters` (omite se vazio) |
| `correlationId` | string | `HttpContext.TraceIdentifier` ou header `X-Correlation-Id` |

`errors` é **sempre array** mesmo quando há um só. Cliente itera sempre.

## `DomainExceptionFilter`

```csharp
// Filters/DomainExceptionFilter.cs
namespace MeuSaaS.API.Filters;

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using MeuSaaS.Domain.SeedWork; // DomainException

public sealed class DomainExceptionFilter(ILogger<DomainExceptionFilter> logger) : IExceptionFilter
{
    public void OnException(ExceptionContext context)
    {
        if (context.Exception is not DomainException ex) return;

        logger.LogWarning(ex,
            "----- DomainException [{Id}] - {Message} - at {Source} -----",
            ex.Id, ex.Message, ex.SourcePath);

        context.Result = new ObjectResult(new
        {
            errors = new[]
            {
                new
                {
                    code    = ex.Id,
                    message = ex.Message,
                    @params = ex.Parameters.Count == 0 ? null : ex.Parameters
                }
            },
            correlationId = context.HttpContext.TraceIdentifier
        })
        {
            StatusCode = StatusCodes.Status422UnprocessableEntity
        };

        context.ExceptionHandled = true;
    }
}
```

**`DomainException` sempre vira 422 Unprocessable Entity.** Razão: a request foi sintaticamente válida (binding ok), mas o estado do domínio não permite a operação (regra de negócio violada). 422 é a semântica correta — não é "input ruim" (400), é "input bom mas viola regra".

## `ApplicationExceptionFilter`

```csharp
// Filters/ApplicationExceptionFilter.cs
namespace MeuSaaS.API.Filters;

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using AppException = MeuSaaS.Application.Errors.ApplicationException;

public sealed class ApplicationExceptionFilter(ILogger<ApplicationExceptionFilter> logger) : IExceptionFilter
{
    public void OnException(ExceptionContext context)
    {
        if (context.Exception is not AppException ex) return;

        logger.LogWarning(ex,
            "----- ApplicationException [{Code}] - {Message} - at {Source} -----",
            ex.Code, ex.Message, ex.SourcePath);

        var status = ex.Code switch
        {
            "NOT_FOUND"                  => StatusCodes.Status404NotFound,
            "VALIDATION_FAILED"          => StatusCodes.Status400BadRequest,
            "CONCURRENCY_CONFLICT"       => StatusCodes.Status409Conflict,
            "IDEMPOTENCY_CONFLICT"       => StatusCodes.Status409Conflict,
            "UNAUTHORIZED_TENANT_ACCESS" => StatusCodes.Status403Forbidden,
            _                            => StatusCodes.Status400BadRequest
        };

        context.Result = new ObjectResult(new
        {
            errors = new[]
            {
                new
                {
                    code    = ex.Code,
                    message = ex.Message,
                    @params = ex.Parameters.Count == 0 ? null : ex.Parameters
                }
            },
            correlationId = context.HttpContext.TraceIdentifier
        })
        {
            StatusCode = status
        };

        context.ExceptionHandled = true;
    }
}
```

**Ponto importante**: o `using` aliasa `MeuSaaS.Application.Errors.ApplicationException` → `AppException` para evitar conflito com `System.ApplicationException` (que existe na BCL e ninguém usa, mas o compilador acha primeiro).

### Mapa de códigos → HTTP

| Code | HTTP | Quando |
|---|---|---|
| `NOT_FOUND` | 404 | `repo.FirstOrDefaultAsync(...) == null`, `GetByIdAsync` etc. |
| `VALIDATION_FAILED` | 400 | `ValidatorBehavior` agregou falhas de `IValidator<TCommand>` |
| `CONCURRENCY_CONFLICT` | 409 | `DbUpdateConcurrencyException` re-lançada como ApplicationException |
| `IDEMPOTENCY_CONFLICT` | 409 | mesmo `Idempotency-Key` usado para Command diferente |
| `UNAUTHORIZED_TENANT_ACCESS` | 403 | guarda extra: agregado encontrado pertence a outro tenant (não devia chegar aqui graças aos filtros do Handler/Query, mas é defesa em profundidade) |
| _outros_ | 400 | fallback conservador |

## Filtro genérico de fallback (`UnhandledExceptionFilter`)

Para erros **não tratados** (bug, falha técnica), retorna 500 com correlation id e mensagem genérica:

```csharp
// Filters/UnhandledExceptionFilter.cs
namespace MeuSaaS.API.Filters;

public sealed class UnhandledExceptionFilter(ILogger<UnhandledExceptionFilter> logger) : IExceptionFilter
{
    public void OnException(ExceptionContext context)
    {
        // Já tratado por filtros mais específicos? sai.
        if (context.ExceptionHandled) return;

        logger.LogError(context.Exception,
            "----- Unhandled exception - CorrelationId: {CorrelationId} -----",
            context.HttpContext.TraceIdentifier);

        context.Result = new ObjectResult(new
        {
            errors = new[]
            {
                new
                {
                    code    = "INTERNAL_ERROR",
                    message = "Ocorreu um erro inesperado. Anote o correlationId e contate o suporte."
                }
            },
            correlationId = context.HttpContext.TraceIdentifier
        })
        {
            StatusCode = StatusCodes.Status500InternalServerError
        };

        context.ExceptionHandled = true;
    }
}
```

**Importante**: este filtro **nunca** vaza `ex.Message` ou stack trace para o cliente. Mensagem genérica + correlationId. O time vê detalhes nos logs, o cliente vê o suficiente para reportar.

## Registro

Em `Extension/ApiExtensions.cs`:

```csharp
namespace MeuSaaS.API.Extension;

public static class ApiExtensions
{
    public static IServiceCollection AddApiExtensions(this IServiceCollection services)
    {
        services.AddControllers(opts =>
        {
            // ORDEM IMPORTA: específicos primeiro, genérico por último.
            opts.Filters.Add<DomainExceptionFilter>();
            opts.Filters.Add<ApplicationExceptionFilter>();
            opts.Filters.Add<UnhandledExceptionFilter>();

            // TenantAuthorizationFilter — defesa anti-IDOR (ver auth-keycloak.md)
            opts.Filters.Add<TenantAuthorizationFilter>();
        })
        .AddJsonOptions(opts =>
        {
            opts.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
            opts.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
            opts.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
            opts.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
        });

        return services;
    }
}
```

A ordem `Domain → Application → Unhandled` garante que o tipo correto seja capturado primeiro. `Unhandled` só roda quando nenhum filtro anterior tratou a exceção.

## Anti-padrões

```csharp
// ❌ Filter retornando ProblemDetails
context.Result = new ObjectResult(new ProblemDetails { ... });
// Conflita com a decisão do projeto: envelope { errors: [...] }.

// ❌ Filter expondo SourcePath ou stack trace para o cliente
errors = new[] { new { code, message, source = ex.SourcePath, stack = ex.StackTrace } };
// Vaza interno. Source vai pro log, não pro response.

// ❌ Filter capturando DomainException pra "padronizar mensagem"
context.Result = new ObjectResult(new { errors = new[] { new { code = "DOMAIN_ERROR", message = "Operação não permitida." } } });
// Apaga o ID e a mensagem específica. Cliente perde capacidade de tratamento fino.

// ❌ Filter que loga ex.Message como erro
logger.LogError("Erro: {Message}", ex.Message);
// Sem stack, sem correlation, sem nível adequado. DomainException não é "Error" — é Warning (regra violada é fluxo esperado).

// ❌ Filter que retorna a exception inteira serializada
context.Result = new ObjectResult(ex);
// Vaza tudo (stack, source, propriedades internas). Nunca.
```

## Checklist

- [ ] `Filters/DomainExceptionFilter.cs` mapeia `DomainException` → 422 + envelope.
- [ ] `Filters/ApplicationExceptionFilter.cs` mapeia `ApplicationException` → 4xx por code.
- [ ] `Filters/UnhandledExceptionFilter.cs` mapeia tudo o resto → 500 + correlation id, sem vazar `Message` real.
- [ ] Aliasing de `Application.Errors.ApplicationException` para evitar conflito com `System.ApplicationException`.
- [ ] Ordem de registro: Domain → Application → Unhandled (último).
- [ ] Filtros sempre `sealed` e injetam só `ILogger`.
- [ ] `correlationId` em todo response.
- [ ] `errors` é sempre array (mesmo com 1 erro).
