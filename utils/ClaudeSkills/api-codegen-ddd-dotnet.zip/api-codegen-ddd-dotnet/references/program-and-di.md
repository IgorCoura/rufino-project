# `Program.cs` enxuto + extensões de bootstrap

Tudo que monta o pipeline HTTP. Zero lógica de negócio. As extensões abaixo ficam em `Extension/` na camada API; cada uma cuida de uma concern.

## `Program.cs` — referência completa

```csharp
using MeuSaaS.API.Extension;
using MeuSaaS.Application.Extension;
using MeuSaaS.Application.Mediator;
using MeuSaaS.Infra.Extension;

var builder = WebApplication.CreateBuilder(args);

// ----- Logging (Serilog recomendado — fora desta skill) -----
// builder.Host.UseSerilog(...);

// ----- Camadas -----
builder.Services
    .AddInfraDependencies(builder.Configuration)        // Infra: DbContext, repos, etc.
    .AddApplicationDependencies()                       // Application: Queries, Behaviors, Validators
    .AddCustomMediator(typeof(CommandAssembly).Assembly); // Mediator + scan de Handlers

// ----- API -----
builder.Services
    .AddApiExtensions()         // Controllers + JSON + Filters globais (Domain/App/Tenant/Unhandled)
    .AddKeycloakAuth(builder.Configuration)  // JWT + Authorization + ProtectedResource
    .AddCorsForFront(builder.Configuration)
    .AddOpenApiDocs(builder.Configuration);

var app = builder.Build();

// ----- Pipeline (ORDEM IMPORTA) -----
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseCors();              // antes de Authentication
app.UseAuthentication();    // valida JWT, popula User
app.UseAuthorization();     // policies + ProtectedResource
app.MapControllers();

app.Run();
```

Pontos:

- `Program.cs` cabe em ~30 linhas. Tudo o resto vai pras extensões.
- Cada `Add*` retorna `IServiceCollection` para chaining.
- Pipeline em ordem fixa: Swagger (dev) → HTTPS → CORS → Auth → Authz → Endpoints.

## `Extension/CorsExtensions.cs`

```csharp
namespace MeuSaaS.API.Extension;

public static class CorsExtensions
{
    public static IServiceCollection AddCorsForFront(
        this IServiceCollection services, IConfiguration config)
    {
        var origins = config.GetSection("Cors:AllowedOrigins").Get<string[]>()
                      ?? Array.Empty<string>();

        services.AddCors(opts =>
        {
            opts.AddDefaultPolicy(policy =>
                policy.WithOrigins(origins)
                      .AllowAnyHeader()
                      .AllowAnyMethod()
                      .AllowCredentials()
                      .WithExposedHeaders("X-Correlation-Id"));
        });

        return services;
    }
}
```

`appsettings.json`:

```json
{
  "Cors": {
    "AllowedOrigins": [
      "https://app.meusaas.com",
      "https://admin.meusaas.com"
    ]
  }
}
```

`appsettings.Development.json` adiciona `http://localhost:3000` (Flutter web em dev).

**Nunca use `AllowAnyOrigin()` em produção.** Permite credenciais cruzadas e abre vetor de CSRF se houver cookies (mesmo que a API use Bearer).

## `Extension/OpenApiExtensions.cs`

```csharp
namespace MeuSaaS.API.Extension;

using Microsoft.OpenApi.Models;

public static class OpenApiExtensions
{
    public static IServiceCollection AddOpenApiDocs(
        this IServiceCollection services, IConfiguration config)
    {
        services.AddEndpointsApiExplorer();

        services.AddSwaggerGen(opts =>
        {
            opts.SwaggerDoc("v1", new OpenApiInfo
            {
                Title       = "MeuSaaS API",
                Version     = "v1",
                Description = "API multi-tenant — Clean Architecture + DDD"
            });

            // ----- Bearer JWT -----
            opts.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
            {
                Name         = "Authorization",
                Type         = SecuritySchemeType.Http,
                Scheme       = "bearer",
                BearerFormat = "JWT",
                In           = ParameterLocation.Header,
                Description  = "JWT do Keycloak: 'Bearer <token>'"
            });
            opts.AddSecurityRequirement(new OpenApiSecurityRequirement
            {
                [ new OpenApiSecurityScheme
                  {
                      Reference = new OpenApiReference
                      {
                          Type = ReferenceType.SecurityScheme,
                          Id   = "Bearer"
                      }
                  } ] = Array.Empty<string>()
            });

            // ----- Header Idempotency-Key documentado para POST/PUT/DELETE -----
            opts.OperationFilter<IdempotencyKeyHeaderFilter>();

            // ----- XML comments dos Controllers, se houver -----
            // var xml = Path.Combine(AppContext.BaseDirectory, "MeuSaaS.API.xml");
            // if (File.Exists(xml)) opts.IncludeXmlComments(xml);
        });

        return services;
    }
}

internal sealed class IdempotencyKeyHeaderFilter : Swashbuckle.AspNetCore.SwaggerGen.IOperationFilter
{
    public void Apply(
        Microsoft.OpenApi.Models.OpenApiOperation operation,
        Swashbuckle.AspNetCore.SwaggerGen.OperationFilterContext context)
    {
        var method = context.ApiDescription.HttpMethod;
        if (method is "POST" or "PUT" or "PATCH" or "DELETE")
        {
            // Já existe se o endpoint usa [FromHeader(Name="Idempotency-Key")] — a lib detecta.
            // Aqui apenas garantimos que o header apareça para QUALQUER endpoint mutante,
            // documentando como obrigatório.
            var hasParam = operation.Parameters.Any(p =>
                p.In == ParameterLocation.Header &&
                string.Equals(p.Name, "Idempotency-Key", StringComparison.OrdinalIgnoreCase));

            if (!hasParam)
            {
                operation.Parameters.Add(new Microsoft.OpenApi.Models.OpenApiParameter
                {
                    Name = "Idempotency-Key",
                    In = ParameterLocation.Header,
                    Required = true,
                    Description = "Guid único por intenção do cliente. Reusar = idempotência.",
                    Schema = new Microsoft.OpenApi.Models.OpenApiSchema { Type = "string", Format = "uuid" }
                });
            }
        }
    }
}
```

NuGet: `Swashbuckle.AspNetCore` (padrão de fato, ainda mais usado que o `Microsoft.AspNetCore.OpenApi` mais recente).

## `Extension/ApiExtensions.cs` — referência completa

Já mostrado em `error-filters.md`, repetida aqui consolidada:

```csharp
namespace MeuSaaS.API.Extension;

using System.Text.Json;
using System.Text.Json.Serialization;
using MeuSaaS.API.Filters;

public static class ApiExtensions
{
    public static IServiceCollection AddApiExtensions(this IServiceCollection services)
    {
        services.AddControllers(opts =>
        {
            // ORDEM IMPORTA: específicos primeiro, genérico por último.
            opts.Filters.Add<DomainExceptionFilter>();
            opts.Filters.Add<ApplicationExceptionFilter>();
            opts.Filters.Add<UnhandledExceptionFilter>();

            // Defesa anti-IDOR multi-tenant
            opts.Filters.Add<TenantAuthorizationFilter>();
        })
        .AddJsonOptions(opts =>
        {
            opts.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
            opts.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
            opts.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter(JsonNamingPolicy.CamelCase));
            opts.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
        });

        return services;
    }
}
```

## Ordem do pipeline — por que importa

```
HTTP request
  ↓
[UseHttpsRedirection]      ← força HTTPS (302 em http://)
  ↓
[UseCors]                  ← responde CORS preflight, antes de qualquer auth
  ↓
[UseAuthentication]        ← lê JWT, popula HttpContext.User
  ↓
[UseAuthorization]         ← roda policies, [ProtectedResource], [Authorize]
  ↓
[MapControllers]           ← roteamento + model binding + filtros (incl. TenantAuthorizationFilter)
  ↓
Endpoint (Controller method)
```

Erros comuns:

- **CORS depois de Auth** → preflight `OPTIONS` chega autenticado. Como `OPTIONS` não tem Bearer, retorna 401 e o front nem tenta a request real. **CORS sempre antes de Auth.**
- **Authentication depois de Authorization** → `[Authorize]` roda em `User = anonymous` e nega tudo. **Auth antes de Authz.**
- **MapControllers antes de Authorization** → policies não rodam. **MapControllers por último.**

## `appsettings.json` consolidado (referência)

```json
{
  "ConnectionStrings": {
    "Default": "Host=localhost;Database=meusaas;Username=postgres;Password=postgres"
  },
  "Keycloak": {
    "realm": "meusaas",
    "auth-server-url": "https://auth.meusaas.com/",
    "ssl-required": "external",
    "resource": "meusaas-api",
    "verify-token-audience": true,
    "credentials": { "secret": "" },
    "confidential-port": 0
  },
  "Cors": {
    "AllowedOrigins": [
      "https://app.meusaas.com"
    ]
  },
  "Serilog": {
    "MinimumLevel": {
      "Default": "Information",
      "Override": {
        "Microsoft": "Warning",
        "Microsoft.EntityFrameworkCore.Database.Command": "Warning",
        "System": "Warning"
      }
    }
  },
  "Logging": {
    "LogLevel": {
      "Default": "Information"
    }
  }
}
```

## Anti-padrões

```csharp
// ❌ Lógica no Program.cs além de bootstrap
app.MapPost("/api/admin/reset", async (ICacheService cache) => { await cache.Reset(); });
// Use Controller. Map* inline são pra prototipagem.

// ❌ Múltiplos AddControllers
services.AddControllers();   // primeiro
services.AddControllers(opts => opts.Filters.Add<X>());  // segundo
// O segundo NÃO sobrescreve — adiciona. Use uma única chamada com todas as opções.

// ❌ AllowAnyOrigin em produção
.AllowAnyOrigin().AllowCredentials()
// O ASP.NET Core lança InvalidOperationException — não dá pra combinar. Mas se trocar AllowCredentials, ainda vaza acesso.

// ❌ Esquecer UseAuthentication
app.UseAuthorization();
app.MapControllers();
// User sempre anonymous, [Authorize] sempre nega.

// ❌ HttpsRedirection em produção atrás de proxy reverso
app.UseHttpsRedirection();
// O proxy (nginx/cloudflare) já faz HTTPS termination. Aqui o request chega em HTTP plain — UseHttpsRedirection vai mandar 302 para um endereço errado. Configure UseForwardedHeaders e remova HttpsRedirection (ou mantenha só em ambiente sem proxy).
```

## Checklist

- [ ] `Program.cs` enxuto, ~30 linhas.
- [ ] Pipeline na ordem: HTTPS → CORS → Auth → Authz → Endpoints.
- [ ] `AddApiExtensions()` com filtros globais e JSON options.
- [ ] `AddKeycloakAuth(config)` com `AddProtectedResourceAuthorization` dentro.
- [ ] `AddCorsForFront(config)` com origins do `appsettings.json`, sem `AllowAnyOrigin`.
- [ ] `AddOpenApiDocs(config)` com Bearer e `Idempotency-Key` documentados.
- [ ] Bloco `Keycloak` no `appsettings.json` configurado.
- [ ] `Cors.AllowedOrigins` populado por ambiente.
- [ ] `appsettings.Development.json` sobrescreve só o necessário (URL local do Keycloak, origens de dev).
