# Anatomia de Controller — API HTTP enxuta

Controller é Humble Object. Faz só:

1. Binding HTTP (rota + body + header).
2. `model.ToCommand(tenantId)` (quando há Model) ou usa `Command` direto (quando body == Command).
3. `mediator.Send(...)` (Commands) **ou** `IXxxQueries.MétodoAsync(...)` (Queries).
4. Retornar `Ok(...)` / `NoContent()` com a Response.

Lógica de negócio aqui é proibida. Se aparece `if`, ou é binding (continuar) ou é regra (mover pra Application/Domain).

## `BaseController`

```csharp
// Controllers/BaseController.cs
namespace MeuSaaS.API.Controllers;

[ApiController]
[Authorize] // todo controller exige JWT por padrão; endpoints públicos usam [AllowAnonymous]
public abstract class BaseController : ControllerBase
{
    protected ActionResult<T> OkResponse<T>(T result) => Ok(result);

    protected ActionResult OkOrNoContent(bool any) => any ? Ok() : NoContent();

    /// <summary>
    /// Quando o método retorna T?, `null` → 404 / valor → 200.
    /// Útil para Find* (oposto de Get* que já lança ApplicationException).
    /// </summary>
    protected ActionResult<T> OkOrNotFound<T>(T? result) where T : class
        => result is null ? NotFound() : Ok(result);
}
```

Sem campo `_logger` nem outras dependências aqui — tudo é injetado nos controllers concretos via primary constructor.

## Endpoint padrão para Command (5 passos)

```csharp
[HttpPost]
[ProtectedResource("bill", "create")]
public async Task<ActionResult<CreateBillResponse>> Create(
    [FromRoute]                            Guid                   tenantId,
    [FromBody]                             CreateBillModel        model,
    [FromHeader(Name = "Idempotency-Key")] Guid                   requestId,
    CancellationToken                                             ct)
{
    var command = model.ToCommand(tenantId);
    var identified = new IdentifiedCommand<CreateBillCommand, CreateBillResponse>(command, requestId);
    var result = await mediator.Send(identified, ct);
    return OkResponse(result);
}
```

**Pontos invioláveis:**

- `[ApiController]` herdado do `BaseController` ativa model-binding implícito + 400 automático em binding inválido.
- `[Authorize]` no `BaseController` exige JWT em **todo** endpoint. Endpoints públicos (raro) usam `[AllowAnonymous]`.
- `[ProtectedResource("recurso", "ação")]` em **todo** endpoint que faz algo. Sem exceção.
- `[FromRoute] Guid tenantId` — sempre o primeiro parâmetro do método.
- `[FromHeader(Name = "Idempotency-Key")] Guid requestId` — em **todo Command**. Sem isso, `model.binding` lança 400 (header obrigatório).
- `[FromBody]` apenas no Model (ou Command direto, ver abaixo).
- `CancellationToken ct` — sempre o último parâmetro.
- `await mediator.Send(identified, ct)` — o `await` é importante (sem `Task.ContinueWith` ou similares).
- `OkResponse(result)` — método helper do `BaseController`.

## Quando o body é exatamente o Command (sem Model)

```csharp
// Application: Command sem TenantId? Raro — só pra endpoints sem tenant na rota.
public record SyncBackgroundJobCommand(string JobName) : IRequest<SyncBackgroundJobResponse>;

// API:
[HttpPost("api/v1/admin/jobs/sync")]
[ProtectedResource("admin", "sync-jobs")]
public async Task<ActionResult<SyncBackgroundJobResponse>> Sync(
    [FromBody]                             SyncBackgroundJobCommand command,
    [FromHeader(Name = "Idempotency-Key")] Guid                     requestId,
    CancellationToken                                               ct)
{
    var identified = new IdentifiedCommand<SyncBackgroundJobCommand, SyncBackgroundJobResponse>(command, requestId);
    return OkResponse(await mediator.Send(identified, ct));
}
```

Sem chamada a `ToCommand`. Caso raríssimo — geralmente todo Command tem `TenantId`.

## Endpoint para Query

Queries **não** passam pelo mediator e **não** precisam de `Idempotency-Key` (são GET, sem efeito colateral).

### Detalhe (GetById)

```csharp
[HttpGet("{billId:guid}")]
[ProtectedResource("bill", "read")]
public async Task<ActionResult<BillDto>> GetById(
    [FromRoute] Guid              tenantId,
    [FromRoute] Guid              billId,
    CancellationToken             ct)
{
    var bill = await queries.GetByIdAsync(tenantId, billId, ct);
    return OkResponse(bill);
}
```

`GetByIdAsync` lança `ApplicationException` `NOT_FOUND` se não encontrar — o filter converte em 404.

Se preferir 404 sem exceção (caminho de menor custo), use `FindByIdAsync` + `OkOrNotFound`:

```csharp
[HttpGet("{billId:guid}")]
[ProtectedResource("bill", "read")]
public async Task<ActionResult<BillDto>> GetById(
    [FromRoute] Guid              tenantId,
    [FromRoute] Guid              billId,
    CancellationToken             ct)
{
    var bill = await queries.FindByIdAsync(tenantId, billId, ct);
    return OkOrNotFound(bill);
}
```

Escolha um padrão e fixe — não misture.

### Lista paginada

```csharp
[HttpGet]
[ProtectedResource("bill", "read")]
public async Task<ActionResult<PagedResult<BillListItemDto>>> List(
    [FromRoute] Guid               tenantId,
    [FromQuery] BillListParams     parameters,
    CancellationToken              ct)
{
    var page = await queries.ListAsync(tenantId, parameters, ct);
    return OkResponse(page);
}
```

`BillListParams` (definido em `Application/Queries/BillQueries/Params/`) tem `PageSize`, `Cursor`, `SortBy`, `SortOrder`. Vem por query string. ASP.NET Core faz o binding automático em records.

## Endpoint para ação de domínio

```csharp
[HttpPost("{billId:guid}/approve")]
[ProtectedResource("bill", "approve")]
public async Task<ActionResult<ApproveBillResponse>> Approve(
    [FromRoute]                            Guid                tenantId,
    [FromRoute]                            Guid                billId,
    [FromBody]                             ApproveBillModel    model,
    [FromHeader(Name = "Idempotency-Key")] Guid                requestId,
    CancellationToken                                          ct)
{
    var command = model.ToCommand(tenantId, billId);
    var identified = new IdentifiedCommand<ApproveBillCommand, ApproveBillResponse>(command, requestId);
    return OkResponse(await mediator.Send(identified, ct));
}
```

`ApproveBillModel.ToCommand(tenantId, billId)` recebe **dois** parâmetros porque tanto `tenantId` quanto `billId` vêm da rota — Model HTTP carrega só os campos extras (ex.: `ApproverId`, `Notes`).

## Endpoint para upload de arquivo

```csharp
[HttpPost("{billId:guid}/attachments")]
[ProtectedResource("bill", "attach")]
[RequestSizeLimit(20 * 1024 * 1024)] // 20 MB
public async Task<ActionResult<AttachBillFileResponse>> Attach(
    [FromRoute]                            Guid       tenantId,
    [FromRoute]                            Guid       billId,
    [FromForm]                             IFormFile  file,
    [FromHeader(Name = "Idempotency-Key")] Guid       requestId,
    CancellationToken                                 ct)
{
    var command = new AttachBillFileCommand(
        tenantId, billId,
        fileName:    file.FileName,
        contentType: file.ContentType,
        content:     file.OpenReadStream());

    var identified = new IdentifiedCommand<AttachBillFileCommand, AttachBillFileResponse>(command, requestId);
    return OkResponse(await mediator.Send(identified, ct));
}
```

- `[FromForm]` com `IFormFile` quando upload.
- `[RequestSizeLimit]` declarado por endpoint — não global. Diferentes uploads têm tamanhos diferentes.
- O `Stream` (`file.OpenReadStream()`) vai pro Command. **Não** carregue em `byte[]` aqui — desperdiça memória se arquivo grande.
- Sem Model. Como o Stream e o IFormFile são tipos web, fazer Model que vira Command com `ToCommand(...)` adiciona indireção sem ganho. Construa o Command direto.

## Endpoint para Delete

```csharp
[HttpDelete("{billId:guid}")]
[ProtectedResource("bill", "delete")]
public async Task<ActionResult> Delete(
    [FromRoute]                            Guid       tenantId,
    [FromRoute]                            Guid       billId,
    [FromHeader(Name = "Idempotency-Key")] Guid       requestId,
    CancellationToken                                 ct)
{
    var command = new DeleteBillCommand(tenantId, billId);
    var identified = new IdentifiedCommand<DeleteBillCommand, DeleteBillResponse>(command, requestId);
    await mediator.Send(identified, ct);
    return NoContent();
}
```

DELETE não retorna body por convenção REST → `204 NoContent`. Se a Application retornar info útil no `DeleteBillResponse`, troca `NoContent()` por `OkResponse(...)`.

## Esqueleto completo de um Controller

```csharp
namespace MeuSaaS.API.Controllers;

using MeuSaaS.Application.Commands.BillCommands.CreateBill;
using MeuSaaS.Application.Commands.BillCommands.ApproveBill;
// ... outros usings

[Route("api/v1/{tenantId:guid}/bills")]
public sealed class BillsController(IMediator mediator, IBillQueries queries) : BaseController
{
    [HttpGet]
    [ProtectedResource("bill", "read")]
    public async Task<ActionResult<PagedResult<BillListItemDto>>> List(
        [FromRoute] Guid tenantId,
        [FromQuery] BillListParams parameters,
        CancellationToken ct)
        => OkResponse(await queries.ListAsync(tenantId, parameters, ct));

    [HttpGet("{billId:guid}")]
    [ProtectedResource("bill", "read")]
    public async Task<ActionResult<BillDto>> GetById(
        [FromRoute] Guid tenantId,
        [FromRoute] Guid billId,
        CancellationToken ct)
        => OkResponse(await queries.GetByIdAsync(tenantId, billId, ct));

    [HttpPost]
    [ProtectedResource("bill", "create")]
    public async Task<ActionResult<CreateBillResponse>> Create(
        [FromRoute] Guid tenantId,
        [FromBody]  CreateBillModel model,
        [FromHeader(Name = "Idempotency-Key")] Guid requestId,
        CancellationToken ct)
    {
        var identified = new IdentifiedCommand<CreateBillCommand, CreateBillResponse>(
            model.ToCommand(tenantId), requestId);
        return OkResponse(await mediator.Send(identified, ct));
    }

    [HttpPost("{billId:guid}/approve")]
    [ProtectedResource("bill", "approve")]
    public async Task<ActionResult<ApproveBillResponse>> Approve(
        [FromRoute] Guid tenantId,
        [FromRoute] Guid billId,
        [FromBody]  ApproveBillModel model,
        [FromHeader(Name = "Idempotency-Key")] Guid requestId,
        CancellationToken ct)
    {
        var identified = new IdentifiedCommand<ApproveBillCommand, ApproveBillResponse>(
            model.ToCommand(tenantId, billId), requestId);
        return OkResponse(await mediator.Send(identified, ct));
    }

    [HttpDelete("{billId:guid}")]
    [ProtectedResource("bill", "delete")]
    public async Task<ActionResult> Delete(
        [FromRoute] Guid tenantId,
        [FromRoute] Guid billId,
        [FromHeader(Name = "Idempotency-Key")] Guid requestId,
        CancellationToken ct)
    {
        var identified = new IdentifiedCommand<DeleteBillCommand, DeleteBillResponse>(
            new DeleteBillCommand(tenantId, billId), requestId);
        await mediator.Send(identified, ct);
        return NoContent();
    }
}
```

Pontos:

- `sealed` sempre.
- Primary constructor injeta `IMediator` e `IXxxQueries`.
- Cada endpoint cabe em 5–8 linhas (incluindo binding). Se passar disso, há lógica indevida.
- `[Route("api/v1/{tenantId:guid}/bills")]` — rota base no controller. Endpoints só completam.
- `tenantId:guid` constraint — ASP.NET Core valida que o segmento é Guid antes de chegar no método.
- `billId:guid` idem.
- Ordem dos parâmetros sempre: rota → body → header → CancellationToken.

## Anti-padrões

```csharp
// ❌ Lógica no Controller
[HttpPost]
public async Task<...> Create(...)
{
    if (model.Amount > 1000) return BadRequest("Amount muito alto");  // regra → Domain
    if (model.Status == "DRAFT") { /* ... */ }                         // estado → Domain
    var company = await db.Companies.FindAsync(...);                   // I/O fora de mediator
    // ...
}

// ❌ Tratar exceção no Controller
try { await mediator.Send(...); }
catch (DomainException ex) { return BadRequest(ex.Message); }
// O filter trata. Controller não faz catch.

// ❌ Construir DTO de resposta no Controller
var dto = new BillResponse { Id = result.Id, Name = "..." };
return Ok(dto);
// Application já retorna o Response pronto. Controller só repassa.

// ❌ Logar no Controller
_logger.LogInformation("Creating bill...");
// Logging é cross-cutting. LoggingBehavior do mediator faz isso.

// ❌ Validar no Controller
if (string.IsNullOrEmpty(model.Description)) return BadRequest(...);
// Valida no IValidator<TCommand> da Application.

// ❌ Endpoint sem [ProtectedResource]
[HttpPost]
public async Task<...> Create(...) { ... }
// Esqueceu autorização. Toda operação tem [ProtectedResource].

// ❌ Endpoint sem [FromHeader(Name = "Idempotency-Key")] em Command
[HttpPost]
public async Task<...> Create(... [FromBody] CreateBillModel model, ...)
{
    var command = model.ToCommand(tenantId);
    return Ok(await mediator.Send(command, ct));   // sem IdentifiedCommand
}
// Toda operação de escrita exige idempotência.

// ❌ Endpoint que retorna Entity/agregado direto
return Ok(bill); // bill é o Aggregate do Domain
// Controller retorna DTO/Response da Application. Nunca Aggregate.
```

## Checklist do Controller

- [ ] Herda `BaseController`.
- [ ] `sealed`.
- [ ] Primary constructor injetando só `IMediator` e/ou `IXxxQueries`.
- [ ] `[Route("api/v1/{tenantId:guid}/<plural-do-recurso>")]`.
- [ ] Cada endpoint tem `[ProtectedResource("recurso", "ação")]`.
- [ ] Cada endpoint de Command tem `[FromHeader(Name = "Idempotency-Key")] Guid requestId`.
- [ ] Cada endpoint despacha via `IdentifiedCommand<TCmd, TRes>`.
- [ ] Cada endpoint cabe em 5–8 linhas.
- [ ] Sem `try/catch`, sem `if` de regra, sem logging, sem validação.
- [ ] Retorna `OkResponse(...)`, `NoContent()`, `OkOrNotFound(...)` — não constrói DTO no Controller.
- [ ] `CancellationToken ct` como último parâmetro, sempre.
