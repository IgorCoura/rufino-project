# External Services — Adaptadores

> Toda integração com o mundo externo (banco S3, API de pagamento, gateway de assinatura, e-mail, fila) segue **um único padrão**. Aprenda esse padrão e replique. A regra mãe: **interface no Domain, implementação na Infra com nome do fornecedor**.

---

## 1. O padrão (em 4 passos)

### Passo 1 — Defina a interface no Domain

A interface fala **a linguagem do domínio**, não a linguagem do fornecedor. Os parâmetros são conceitos do negócio, não JSON do SDK.

```csharp
// Domain/Services/IDocumentSignatureService.cs
namespace BillsToPay.Domain.Services;

public interface IDocumentSignatureService
{
    Task<DocumentSignatureSession> CreateAsync(
        DocumentSignatureRequest request,
        CancellationToken ct);

    Task<DocumentSignatureSession> GetStatusAsync(
        DocumentSignatureSessionId sessionId,
        CancellationToken ct);
}

public sealed record DocumentSignatureRequest(
    string FileName,
    byte[] FileContent,
    Signer[] Signers,
    DocumentSignatureChannel Channel);

public sealed record DocumentSignatureSession(
    DocumentSignatureSessionId Id,
    DocumentSignatureSessionStatus Status,
    Uri? CompletedDocumentUrl);

public enum DocumentSignatureChannel { Email, WhatsApp, Sms }
public enum DocumentSignatureSessionStatus { Pending, Signed, Expired, Canceled }
```

Note: **nada de ZapSign, ClickSign, DocuSign**. A interface fala em "channel", não em "ZapSignProvider".

### Passo 2 — POCO de Options

Configuração tipada, **nunca** `Configuration["..."]` direto:

```csharp
// Infra/Services/Options/ZapSignOptions.cs
namespace BillsToPay.Infra.Services.Options;

public sealed class ZapSignOptions
{
    public const string SectionName = "ZapSign";

    public required string BaseUrl { get; init; }
    public required string ApiToken { get; init; }
    public TimeSpan DefaultTimeout { get; init; } = TimeSpan.FromSeconds(30);
}
```

E no `appsettings.json`:

```json
{
  "ZapSign": {
    "BaseUrl": "https://api.zapsign.com.br",
    "ApiToken": "seu-token-aqui",
    "DefaultTimeout": "00:00:30"
  }
}
```

### Passo 3 — Implementação na Infra com prefixo do fornecedor

```csharp
// Infra/Services/ZapSignDocumentSignatureService.cs
using BillsToPay.Domain.Services;
using BillsToPay.Infra.Services.Options;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.Net.Http.Json;

namespace BillsToPay.Infra.Services;

public class ZapSignDocumentSignatureService : IDocumentSignatureService
{
    private readonly HttpClient _http;
    private readonly ZapSignOptions _opts;
    private readonly ILogger<ZapSignDocumentSignatureService> _logger;

    public ZapSignDocumentSignatureService(
        HttpClient http,
        IOptions<ZapSignOptions> opts,
        ILogger<ZapSignDocumentSignatureService> logger)
    {
        _http = http;
        _opts = opts.Value;
        _logger = logger;
    }

    public async Task<DocumentSignatureSession> CreateAsync(
        DocumentSignatureRequest request,
        CancellationToken ct)
    {
        // método privado parametrizado evita duplicação entre Email/WhatsApp
        return await SendToSignature(request, ct);
    }

    public async Task<DocumentSignatureSession> GetStatusAsync(
        DocumentSignatureSessionId sessionId,
        CancellationToken ct)
    {
        try
        {
            var response = await _http.GetFromJsonAsync<ZapSignSessionResponse>(
                $"/api/v1/sessions/{sessionId.Value}", ct);

            return MapToSession(response!);
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex,
                "ZapSign GetStatus failed for session {SessionId}", sessionId.Value);

            // Traduz a exceção do SDK/HTTP para erro de domínio
            throw new ExternalServiceException("ZapSign", "Failed to get signature status", ex);
        }
    }

    private async Task<DocumentSignatureSession> SendToSignature(
        DocumentSignatureRequest request,
        CancellationToken ct)
    {
        var payload = new ZapSignCreateRequest
        {
            Name = request.FileName,
            Content = Convert.ToBase64String(request.FileContent),
            Channel = MapChannel(request.Channel),
            Signers = request.Signers.Select(s => new ZapSignSigner
            {
                Name = s.Name,
                Email = s.Email,
                Phone = s.Phone
            }).ToArray()
        };

        var response = await _http.PostAsJsonAsync("/api/v1/sessions", payload, ct);
        response.EnsureSuccessStatusCode();

        var dto = await response.Content.ReadFromJsonAsync<ZapSignSessionResponse>(ct);
        return MapToSession(dto!);
    }

    // DTOs internos da Infra (escondidos do Domain) ----
    private record ZapSignCreateRequest
    {
        public required string Name { get; init; }
        public required string Content { get; init; }
        public required string Channel { get; init; }
        public required ZapSignSigner[] Signers { get; init; }
    }
    private record ZapSignSigner
    {
        public required string Name { get; init; }
        public string? Email { get; init; }
        public string? Phone { get; init; }
    }
    private record ZapSignSessionResponse(string Id, string Status, string? Url);

    private static string MapChannel(DocumentSignatureChannel ch) => ch switch
    {
        DocumentSignatureChannel.Email    => "email",
        DocumentSignatureChannel.WhatsApp => "whatsapp",
        DocumentSignatureChannel.Sms      => "sms",
        _ => throw new ArgumentOutOfRangeException(nameof(ch))
    };

    private static DocumentSignatureSession MapToSession(ZapSignSessionResponse dto)
    {
        var status = dto.Status switch
        {
            "pending"  => DocumentSignatureSessionStatus.Pending,
            "signed"   => DocumentSignatureSessionStatus.Signed,
            "expired"  => DocumentSignatureSessionStatus.Expired,
            "canceled" => DocumentSignatureSessionStatus.Canceled,
            _ => DocumentSignatureSessionStatus.Pending
        };

        return new DocumentSignatureSession(
            new DocumentSignatureSessionId(dto.Id),
            status,
            dto.Url is null ? null : new Uri(dto.Url));
    }
}
```

### Passo 4 — Registre no DI com `HttpClient` + Polly

```csharp
// Infra/ExtensionClass/ServiceCollectionExtensions.cs (recorte)
services.Configure<ZapSignOptions>(configuration.GetSection(ZapSignOptions.SectionName));

services.AddHttpClient<IDocumentSignatureService, ZapSignDocumentSignatureService>((sp, client) =>
{
    var opts = sp.GetRequiredService<IOptions<ZapSignOptions>>().Value;
    client.BaseAddress = new Uri(opts.BaseUrl);
    client.DefaultRequestHeaders.Authorization =
        new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", opts.ApiToken);
    client.Timeout = opts.DefaultTimeout;
})
.AddPolicyHandler((sp, _) => HttpPolicyFactory.GetCombinedPolicy(retryCount: 6, timeoutSeconds: 30))
.SetHandlerLifetime(TimeSpan.FromMinutes(5));
```

---

## 2. Múltiplos provedores para a mesma capacidade

Se você quer trocar de fornecedor (ZapSign → ClickSign), **mantenha os dois compilando** e escolha qual injetar:

```csharp
// Pelo nome (named option)
services.AddHttpClient<ClickSignDocumentSignatureService>(...);
services.AddHttpClient<ZapSignDocumentSignatureService>(...);

// Decida qual implementa IDocumentSignatureService
if (configuration["SignatureProvider"] == "ZapSign")
    services.AddScoped<IDocumentSignatureService, ZapSignDocumentSignatureService>();
else
    services.AddScoped<IDocumentSignatureService, ClickSignDocumentSignatureService>();
```

Ou via **feature flag**, ou via **`AddKeyedScoped`** (.NET 8+) para escolher por chave em runtime. Esse padrão facilita migração e A/B test sem reescrever a Application.

---

## 3. Adaptadores de Blob/File Storage

API consistente independente do provider:

```csharp
// Domain/Services/IBlobService.cs
public interface IBlobService
{
    Task<Uri> UploadAsync(string containerName, string fileName, Stream content, string contentType, CancellationToken ct);
    Task<Stream> DownloadAsync(string containerName, string fileName, CancellationToken ct);
    Task DeleteAsync(string containerName, string fileName, CancellationToken ct);
    Task<bool> ExistsAsync(string containerName, string fileName, CancellationToken ct);
}
```

```csharp
// Infra/Services/S3BlobService.cs
public class S3BlobService : IBlobService
{
    private readonly IAmazonS3 _s3;
    private readonly S3Options _opts;
    private readonly ILogger<S3BlobService> _logger;

    public S3BlobService(IAmazonS3 s3, IOptions<S3Options> opts, ILogger<S3BlobService> logger)
    {
        _s3 = s3;
        _opts = opts.Value;
        _logger = logger;
    }

    public async Task<Uri> UploadAsync(
        string containerName,    // <- vira "bucket prefix" ou subfolder por tenant
        string fileName,
        Stream content,
        string contentType,
        CancellationToken ct)
    {
        var key = $"{containerName}/{fileName}";

        var request = new PutObjectRequest
        {
            BucketName = _opts.BucketName,
            Key = key,
            InputStream = content,
            ContentType = contentType,
            ServerSideEncryptionMethod = ServerSideEncryptionMethod.AES256
        };

        var response = await _s3.PutObjectAsync(request, ct);
        if (response.HttpStatusCode != HttpStatusCode.OK)
            throw new ExternalServiceException("S3", $"Upload failed: {response.HttpStatusCode}");

        return new Uri($"https://{_opts.BucketName}.s3.{_opts.Region}.amazonaws.com/{key}");
    }
    // ... DownloadAsync, DeleteAsync, ExistsAsync seguem o mesmo padrão
}
```

> **`containerName` por tenant**: em SaaS multi-tenant, use o `TenantId` (ou um slug) como nome de container/prefix. Garante segregação física: um tenant nunca vê arquivo do outro mesmo se houver bug na lógica de autorização.

---

## 4. Tradução de exceções

**Nunca vaze `AmazonS3Exception`, `StripeException`, `HttpRequestException` para a Application.** Traduza para `DomainException` ou um `Result<T>`:

```csharp
public class ExternalServiceException : Exception
{
    public string ServiceName { get; }
    public ExternalServiceException(string serviceName, string message, Exception? inner = null)
        : base($"[{serviceName}] {message}", inner)
    {
        ServiceName = serviceName;
    }
}
```

Padrão de uso:

```csharp
try
{
    var charge = await _stripe.CreateChargeAsync(...);
    return Result.Ok(new PaymentResult(charge.Id));
}
catch (StripeException ex) when (ex.StripeError?.Code == "card_declined")
{
    return Result.Fail("Cartão recusado pelo banco emissor.");
}
catch (StripeException ex)
{
    _logger.LogError(ex, "Stripe API error: {Code}", ex.StripeError?.Code);
    throw new ExternalServiceException("Stripe", "Payment failed", ex);
}
```

---

## 5. Logs estruturados — todas as chamadas

Toda chamada a serviço externo precisa, no mínimo:
- `correlationId` (do request HTTP, propagado).
- nome do método invocado.
- parâmetros relevantes (não logue PII/senha/token).
- resultado (sucesso/falha).

```csharp
using var _ = _logger.BeginScope(new Dictionary<string, object>
{
    ["CorrelationId"] = _correlationContext.Id,
    ["Service"] = "ZapSign",
    ["Method"] = nameof(CreateAsync),
    ["FileName"] = request.FileName
});

_logger.LogInformation("Calling ZapSign CreateAsync");
// chamada
_logger.LogInformation("ZapSign CreateAsync returned status {Status}", response.Status);
```

Use Serilog ou OpenTelemetry para propagação automática de correlation id.

---

## 6. Webhooks recebidos do fornecedor

Webhooks também são "serviços externos", mas no sentido inverso (eles te chamam). Padrão:

1. Endpoint na API recebe o payload.
2. **Valida assinatura** (HMAC com secret) — sem isso, qualquer um manda webhook.
3. Persiste o payload bruto numa tabela de auditoria (`webhook_events`).
4. Resolve via factory para o handler do tipo certo.
5. Responde **200 OK rapidamente** (< 5s) — processamento pesado vai pra fila/job.

```csharp
public class ZapSignWebhookValidator : IZapSignWebhookValidator
{
    private readonly ZapSignOptions _opts;

    public bool IsValid(string payload, string receivedSignature)
    {
        var expected = ComputeHmacSha256(payload, _opts.WebhookSecret);
        return CryptographicOperations.FixedTimeEquals(
            Encoding.UTF8.GetBytes(expected),
            Encoding.UTF8.GetBytes(receivedSignature));
    }
    // ...
}
```

---

## 7. Lista de adaptadores comuns num SaaS típico

| Capacidade | Interface (Domain) | Implementações (Infra) |
|---|---|---|
| Storage de arquivo | `IBlobService` | `S3BlobService`, `AzureBlobService`, `GcsBlobService` |
| Assinatura digital | `IDocumentSignatureService` | `ZapSignDocumentSignatureService`, `ClickSignDocumentSignatureService` |
| Pagamento | `IPaymentService` | `StripePaymentService`, `MercadoPagoPaymentService` |
| E-mail transacional | `IEmailService` | `SendGridEmailService`, `SesEmailService` |
| WhatsApp | `IWhatsAppService` | `TwilioWhatsAppService`, `ZApiWhatsAppService` |
| OCR / Extração de dados | `IDocumentExtractionService` | `OpenAiDocumentExtractionService`, `ClaudeDocumentExtractionService` |
| Open Finance | `IOpenFinanceService` | `BelvoOpenFinanceService`, `PluggyOpenFinanceService` |
| Geração de PDF | `IPdfGenerationService` | `PuppeteerPdfService`, `WkHtmlToPdfService` |
| Fila / Mensageria | `IEventBus` | `SqsEventBus`, `RabbitMqEventBus`, `AzureServiceBusEventBus` |
| Validação de CPF/CNPJ | `IDocumentValidator` | `SerproDocumentValidator` |

---

## 8. Checklist do adaptador

- [ ] Interface no Domain, expressa em conceitos de domínio (não nomes do SDK).
- [ ] Implementação na Infra com prefixo do fornecedor (`Stripe...`, `S3...`).
- [ ] Configuração via `IOptions<XxxOptions>` com `SectionName` constante.
- [ ] `HttpClient` registrado via `AddHttpClient<I, Impl>`.
- [ ] Polly aplicado (retry + timeout + circuit breaker).
- [ ] Logs estruturados com `correlationId` em toda chamada.
- [ ] Erros do SDK traduzidos para `DomainException` / `Result<T>` / `ExternalServiceException`.
- [ ] Nunca vaza tipo do SDK do fornecedor (DTOs internos privados).
- [ ] Todos os métodos com `CancellationToken`.
- [ ] Webhooks validam assinatura HMAC antes de processar.

---

## 9. Diagrama: fluxo de chamada típico (Mermaid)

```mermaid
sequenceDiagram
    participant A as Application Handler
    participant ID as IDocumentSignatureService
    participant Z as ZapSignDocumentSignatureService
    participant P as Polly Policy<br/>(Retry+Timeout+CB)
    participant H as HttpClient
    participant API as ZapSign API

    A->>ID: CreateAsync(request, ct)
    ID->>Z: CreateAsync(request, ct)
    Z->>P: PostAsJsonAsync(...)
    P->>H: HttpRequest
    H->>API: POST /api/v1/sessions
    API-->>H: 503 Service Unavailable
    H-->>P: HttpResponse 503
    P->>P: backoff 2s, retry
    P->>H: HttpRequest (retry 1)
    H->>API: POST /api/v1/sessions
    API-->>H: 200 OK
    H-->>P: HttpResponse 200
    P-->>Z: HttpResponse
    Z->>Z: MapToSession(dto)
    Z-->>ID: DocumentSignatureSession
    ID-->>A: DocumentSignatureSession
```
