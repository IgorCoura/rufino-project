# EF Configurations — Mapeamento de Aggregates

> O `Mapping/` é onde você ensina o EF Core a traduzir os agregados modelados em DDD para tabelas relacionais — **sem** que esse mapeamento force o Domain a se contorcer. O Domain define como o agregado se comporta; o Map define como ele se persiste. Mantenha essa separação.

---

## 1. Classe base `EntityMap<T>`

Toda entidade de domínio compartilha 3 coisas: id (gerado pelo Domain, não pelo banco), `CreatedAt`, `UpdatedAt`. Centralize numa base abstrata:

```csharp
// Infra/Mapping/EntityMap.cs
using BillsToPay.Domain.SeedWork;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BillsToPay.Infra.Mapping;

public abstract class EntityMap<T> : IEntityTypeConfiguration<T> where T : Entity
{
    public virtual void Configure(EntityTypeBuilder<T> builder)
    {
        builder.HasKey(x => x.Id);

        // Id é gerado pelo Domain (em geral Guid v7 ou typed Id) — EF não gera
        builder.Property(x => x.Id)
               .ValueGeneratedNever();

        builder.Property(x => x.CreatedAt)
               .HasColumnType("timestamptz")
               .IsRequired();

        builder.Property(x => x.UpdatedAt)
               .HasColumnType("timestamptz")
               .IsRequired();

        // DomainEvents é coleção em memória — não persiste
        builder.Ignore("_domainEvents");
    }
}
```

Os maps concretos chamam `base.Configure(builder)` antes de configurar o resto:

```csharp
public class BillMap : EntityMap<Bill>
{
    public override void Configure(EntityTypeBuilder<Bill> builder)
    {
        base.Configure(builder);   // <- aplica id + timestamps
        builder.ToTable("bills");
        // configurações específicas do Bill...
    }
}
```

---

## 2. Mapeando o aggregate root completo

Exemplo realista: `Bill` (conta a pagar) com:
- Id tipado (`BillId`).
- Value Object `Money` (Amount + Currency).
- Smart Enum `BillStatus`.
- Coleção interna de `Installment` (entidade interna do agregado).
- FK para outro agregado: `SupplierId` (sem navigation).

```csharp
// Infra/Mapping/BillMap.cs
using BillsToPay.Domain.Bills;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BillsToPay.Infra.Mapping;

public class BillMap : EntityMap<Bill>
{
    public override void Configure(EntityTypeBuilder<Bill> builder)
    {
        base.Configure(builder);

        builder.ToTable("bills");

        // ----- Id tipado -----
        builder.Property(b => b.Id)
               .HasConversion(id => id.Value, value => new BillId(value));

        // ----- Tenant -----
        builder.Property(b => b.TenantId)
               .HasConversion(id => id.Value, value => new TenantId(value))
               .IsRequired();
        builder.HasIndex(b => b.TenantId);   // multi-tenant: índice obrigatório

        // ----- Description (VO de 1 campo: string) -----
        builder.Property(b => b.Description)
               .HasConversion(d => d.Value, value => new Description(value))
               .HasMaxLength(Description.MAX_LENGTH)
               .IsRequired();

        // ----- Amount (VO Money: 2 campos) -----
        builder.OwnsOne(b => b.Amount, money =>
        {
            money.Property(m => m.Value)
                 .HasColumnName("amount_value")
                 .HasColumnType("numeric(18,2)")
                 .IsRequired();

            money.Property(m => m.Currency)
                 .HasColumnName("amount_currency")
                 .HasMaxLength(3)
                 .IsRequired();
        });

        // ----- Status (Smart Enum) -----
        builder.Property(b => b.Status)
               .HasConversion(
                    s => s.Id,
                    id => Enumeration.FromValue<BillStatus>(id))
               .IsRequired();

        // ----- DueDate -----
        builder.Property(b => b.DueDate)
               .HasColumnType("date")
               .IsRequired();

        // ----- FK para outro aggregate (sem navigation) -----
        builder.Property(b => b.SupplierId)
               .HasConversion(id => id.Value, value => new SupplierId(value))
               .IsRequired();
        builder.HasIndex(b => b.SupplierId);
        // SEM HasOne — o agregado Supplier vive em outro contexto/repositório

        // ----- Installments (entidade interna do agregado, OwnsMany) -----
        builder.OwnsMany(b => b.Installments, inst =>
        {
            inst.ToTable("bill_installments");
            inst.HasKey(i => i.Id);
            inst.Property(i => i.Id)
                .HasConversion(id => id.Value, value => new InstallmentId(value))
                .ValueGeneratedNever();

            inst.Property(i => i.Number).IsRequired();
            inst.Property(i => i.DueDate).HasColumnType("date").IsRequired();
            inst.Property(i => i.Status)
                .HasConversion(s => s.Id, id => Enumeration.FromValue<InstallmentStatus>(id));

            // Money owned dentro de owned (sub-OwnsOne)
            inst.OwnsOne(i => i.Amount, money =>
            {
                money.Property(m => m.Value)
                     .HasColumnName("amount_value")
                     .HasColumnType("numeric(18,2)");
                money.Property(m => m.Currency)
                     .HasColumnName("amount_currency")
                     .HasMaxLength(3);
            });

            inst.WithOwner().HasForeignKey("bill_id");
        });

        // ----- Constraints e índices de negócio -----
        builder.HasIndex(b => new { b.TenantId, b.Status, b.DueDate });
    }
}
```

---

## 3. Value Objects — regras

### VO de 1 campo (string, int, date)
Use `HasConversion`:

```csharp
builder.Property(b => b.Description)
       .HasConversion(d => d.Value, value => new Description(value))
       .HasMaxLength(Description.MAX_LENGTH);
```

### VO de 2+ campos (Money, Address)
Use `OwnsOne`:

```csharp
builder.OwnsOne(b => b.Amount, money =>
{
    money.Property(m => m.Value).HasColumnName("amount_value");
    money.Property(m => m.Currency).HasColumnName("amount_currency");
});
```

> **Por que `OwnsOne` e não tabela separada?** Porque VO é parte do agregado. Tabela separada quebraria a invariante "tudo do agregado salva numa transação só" e introduziria orfandade. `OwnsOne` faz o EF criar **colunas** na mesma tabela, não outra tabela.

### Coleção de VO
Use `OwnsMany`:

```csharp
builder.OwnsMany(b => b.Tags, tag =>
{
    tag.ToTable("bill_tags");
    tag.WithOwner().HasForeignKey("bill_id");
    tag.Property<int>("Id").ValueGeneratedOnAdd();   // shadow id
    tag.HasKey("Id");
    tag.Property(t => t.Name).IsRequired().HasMaxLength(50);
});
```

### MUITO IMPORTANTE: constantes de tamanho ficam no VO

Não no Map. Por quê? Porque o **Domain** valida o tamanho na construção do VO; o Map só replica para o banco. Se você duplica o número, eles divergem com o tempo.

```csharp
// Domain/Bills/Description.cs
public sealed class Description
{
    public const int MAX_LENGTH = 500;

    public string Value { get; }

    public Description(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            throw new DomainException("Description não pode ser vazio.");
        if (value.Length > MAX_LENGTH)
            throw new DomainException($"Description excede {MAX_LENGTH} caracteres.");
        Value = value;
    }
}
```

```csharp
// Infra/Mapping/BillMap.cs
builder.Property(b => b.Description)
       .HasMaxLength(Description.MAX_LENGTH);   // <- referencia a constante
```

---

## 4. Smart Enums (`Enumeration<T>`)

Padrão Microsoft eShop. A classe base no Domain:

```csharp
// Domain/SeedWork/Enumeration.cs (já existe)
public abstract class Enumeration : IComparable
{
    public int Id { get; }
    public string Name { get; }

    protected Enumeration(int id, string name) { Id = id; Name = name; }

    public static T FromValue<T>(int value) where T : Enumeration
    {
        var matchingItem = GetAll<T>().FirstOrDefault(item => item.Id == value)
            ?? throw new InvalidOperationException($"Invalid {typeof(T).Name} id: {value}");
        return matchingItem;
    }

    public static IEnumerable<T> GetAll<T>() where T : Enumeration
    {
        return typeof(T).GetFields(BindingFlags.Public | BindingFlags.Static | BindingFlags.DeclaredOnly)
            .Select(f => f.GetValue(null))
            .Cast<T>();
    }
    // ...
}

// Domain/Bills/BillStatus.cs
public sealed class BillStatus : Enumeration
{
    public static readonly BillStatus Pending  = new(1, "Pending");
    public static readonly BillStatus Approved = new(2, "Approved");
    public static readonly BillStatus Paid     = new(3, "Paid");
    public static readonly BillStatus Canceled = new(4, "Canceled");

    private BillStatus(int id, string name) : base(id, name) { }
}
```

No Map:

```csharp
builder.Property(b => b.Status)
       .HasConversion(s => s.Id, id => Enumeration.FromValue<BillStatus>(id));
```

Persiste o `int` na coluna; `FromValue<T>` resolve de volta para a instância singleton.

---

## 5. Coleções complexas que viram JSON

Às vezes você tem uma coleção dentro do agregado que **não merece tabela** (não é consultada, só serializa/deserializa em bloco). Nesses casos, JSON inline:

```csharp
builder.Property(b => b.Tags)
    .HasConversion(
        v => JsonSerializer.Serialize(v, JsonSerializerOptions.Default),
        v => JsonSerializer.Deserialize<string[]>(v, JsonSerializerOptions.Default) ?? Array.Empty<string>(),
        new ValueComparer<string[]>(
            (a, b) => a!.SequenceEqual(b!),
            v => v.Aggregate(0, (h, s) => HashCode.Combine(h, s.GetHashCode())),
            v => v.ToArray()));
```

**Por que o `ValueComparer` é obrigatório?** Sem ele, o EF não detecta mudança em coleções convertidas — você modifica o array, salva, e nada vai pro banco. O ValueComparer fornece (a) igualdade por valor (`SequenceEqual`), (b) hash, (c) **snapshot** (cópia profunda), que é o que permite o ChangeTracker comparar antes/depois.

> **Use isso com moderação.** Se a coleção é consultada (`WHERE tag = 'urgent'`), vire tabela própria via `OwnsMany`. JSON inline só para coleções "estado interno", lidas inteiras quando carrega o agregado.

---

## 6. Foreign Keys entre agregados

Regra de DDD: **um agregado nunca tem navigation property para outro agregado**. Só guarda o `Id`.

```csharp
// CORRETO
builder.Property(b => b.SupplierId)
       .HasConversion(id => id.Value, value => new SupplierId(value));
builder.HasIndex(b => b.SupplierId);

// ERRADO - cria navigation, fere encapsulamento
// builder.HasOne(b => b.Supplier).WithMany().HasForeignKey(b => b.SupplierId);
```

Se você precisar **declarar** a FK ao banco para integridade referencial, faça assim, mas **sem property de navegação**:

```csharp
builder.HasOne<Supplier>()    // sem (b => b.Supplier) porque a property não existe
       .WithMany()
       .HasForeignKey(b => b.SupplierId)
       .OnDelete(DeleteBehavior.Restrict);
```

`Restrict` é o default seguro — apagar um Supplier com Bills associadas dá erro. Use `Cascade` **apenas** quando o relacionamento é parte do agregado (raiz → entidade interna).

---

## 7. Índices únicos para regras de negócio

Toda regra de unicidade do Domain (`Cnpj` único, `Email` único por tenant) **tem que estar refletida no banco**:

```csharp
builder.HasIndex(s => s.Cnpj).IsUnique();
builder.HasIndex(s => new { s.TenantId, s.Email }).IsUnique();
```

Se a regra é de domínio, o Aggregate **também** valida (na construção/método). Mas o banco é a última linha de defesa contra race condition.

---

## 8. Configuração de constraints e checks

```csharp
// Domínio expressa "Amount > 0" como invariante; o banco também garante:
builder.HasCheckConstraint("ck_bills_amount_positive", "amount_value > 0");
```

---

## 9. Tabelas de junção (many-to-many entre raízes — RARO em DDD)

DDD desencoraja many-to-many entre agregados. Geralmente você modela um agregado de junção (ex.: `BillTagAssignment`). Se for inevitável e for navegação simples (sem dados extras na junção):

```csharp
builder.HasMany<Tag>("_tags")
       .WithMany()
       .UsingEntity(j => j.ToTable("bill_tag"));
```

Mas pense duas vezes — quase sempre o relacionamento tem dados próprios (data de associação, quem associou, etc) e merece ser um agregado.

---

## 10. ApplyConfigurationsFromAssembly — descoberta automática

No `OnModelCreating`:

```csharp
modelBuilder.ApplyConfigurationsFromAssembly(typeof(BillsToPayContext).Assembly);
```

Pega toda classe `IEntityTypeConfiguration<T>` do assembly e aplica. Você não precisa adicionar map por map — basta criar a classe na pasta `Mapping/`.

---

## 11. Checklist do mapeamento

- [ ] `EntityMap<T>` base aplicado a toda raiz.
- [ ] `ToTable("snake_case")` em cada Map (PostgreSQL convention).
- [ ] Id tipado com `HasConversion`.
- [ ] `ValueGeneratedNever()` (id vem do Domain).
- [ ] VO de 1 campo: `HasConversion`.
- [ ] VO de N campos: `OwnsOne` / `OwnsMany`.
- [ ] Smart Enum: `HasConversion(s => s.Id, id => Enumeration.FromValue<T>(id))`.
- [ ] Coleção JSON: `HasConversion` + `ValueComparer` (sequence equal + hash + snapshot).
- [ ] FK de outro agregado: só `Id`, sem navigation property, `OnDelete(Restrict)`.
- [ ] FK interna do agregado: pode ter `Cascade`.
- [ ] Constantes de tamanho referenciadas do VO/Entity (`Name.MAX_LENGTH`).
- [ ] Índices únicos para regras de negócio que envolvem unicidade.
- [ ] Índice em `TenantId` (multi-tenant).
- [ ] `ApplyConfigurationsFromAssembly` no `OnModelCreating`.

---

## 12. Diagrama: Aggregate Bill mapeado para tabelas (Mermaid ER)

```mermaid
erDiagram
    bills ||--o{ bill_installments : "OwnsMany"
    bills ||..|| suppliers : "FK SupplierId (sem navigation)"

    bills {
        uuid id PK
        uuid tenant_id FK
        uuid supplier_id FK
        string description
        numeric amount_value
        string amount_currency
        int status
        date due_date
        timestamptz created_at
        timestamptz updated_at
    }

    bill_installments {
        uuid id PK
        uuid bill_id FK
        int number
        date due_date
        numeric amount_value
        string amount_currency
        int status
    }

    suppliers {
        uuid id PK
        string name
        string cnpj UK
    }
```
