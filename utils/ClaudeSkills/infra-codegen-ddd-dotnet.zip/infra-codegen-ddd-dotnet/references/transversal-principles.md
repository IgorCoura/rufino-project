# Princípios Transversais — O Que NÃO Vai na Infra

> Esses dois lados andam juntos: (1) os **princípios** que toda decisão na Infra obedece, e (2) o **anti-checklist** das coisas que parecem que cabem na Infra mas não cabem. Se você seguir só o lado de lá (gerar arquivos), mas furar esses princípios, a camada apodrece em 6 meses. Cuide aqui antes de qualquer outra coisa.

---

## 1. Princípios — em ordem de prioridade

### Princípio 1 — Infra implementa, Domain define

Toda interface que descreve **uma capacidade do sistema** vive no **Domain**. A Infra só fornece a implementação:

- `IRepository<T>`, `IUnitOfWork` → Domain.
- `IBlobService`, `IPaymentService`, `IDocumentSignatureService`, `IEventBus` → Domain.
- `IDateTimeProvider`, `ICurrentUserAccessor`, `ICurrentTenantAccessor` → Application (são técnicas, não de domínio).

A Infra **nunca** define interfaces para a Application consumir. Isso inverteria a dependência. Se você sentir necessidade — pare. A interface tem que pertencer ao Domain ou à Application; a Infra só implementa.

### Princípio 2 — Nada do EF cruza pra Application

Não pode aparecer na Application:

- `DbContext`
- `IQueryable<T>`
- `EntityState`
- `DbUpdateException`
- `DbSet<T>`
- `IIncludableQueryable<T, P>` (esse pode aparecer **na assinatura** de um método de Repository quando o caller passa includes — mas é EF e fica restrito à fronteira do Domain/Infra; veja [`repositories.md`](repositories.md) para o trade-off)
- `[Table]`, `[Column]`, `[Key]` (Data Annotations de EF)

Se algum desses vazar, é bug de arquitetura. Repositórios e adaptadores **devolvem agregados, VOs, primitivos ou DTOs definidos no Domain/Application** — nunca tipos do EF.

### Princípio 3 — Nenhuma regra de negócio na Infra

Se você se viu escrevendo `if (bill.Status == Pending && bill.DueDate < today)` dentro de um `Repository` ou `Service`, **pare**. Isso é regra de domínio. Mova para o Aggregate (`bill.IsOverdue(today)`) e o Repository só chama.

A Infra **só** faz três coisas:
- Persiste (`Repository`).
- Fala com o mundo externo (`Service`).
- Configura o framework (`Map`, `DI`, `Polly`).

Tudo que envolve "se isso, então aquilo" do **negócio** mora no Aggregate ou no Domain Service.

### Princípio 4 — Configuração externa = Options POCO, sempre

`Configuration["Stripe:ApiKey"]` lido dentro de `StripePaymentService` é **proibido**. Sempre:

```csharp
services.Configure<StripeOptions>(configuration.GetSection(StripeOptions.SectionName));
// ...
public StripePaymentService(IOptions<StripeOptions> opts) { _opts = opts.Value; }
```

Por quê:
- Tipado (não há erro de digitação em runtime).
- Validável (`ValidateOnStart()`).
- Testável (você passa `Options.Create(new StripeOptions { ... })` no teste).
- Documentado (a classe `StripeOptions` é a documentação do que precisa estar no `appsettings`).

### Princípio 5 — Multi-tenant explícito > implícito

Filtro de `TenantId` em **todo método** de repositório. Não confie em middleware mágico (`HasQueryFilter` global) sem teste cobrindo. Detalhes em [`multi-tenancy.md`](multi-tenancy.md).

### Princípio 6 — `CancellationToken` em todo método I/O

Sem exceção. Repository, Service, Query — todos os métodos que tocam banco/HTTP/disco recebem `CancellationToken`. Se o método não tem, ele está errado.

### Princípio 7 — Sem `static` mutável

Singleton via DI: ok. `static field` mutável: **proibido**. Razões:
- Testes não conseguem isolar.
- Race conditions.
- Tempo de vida invisível ao container.

`static readonly` (constantes, factories puras) é fino. `static` mutável, não.

### Princípio 8 — Um repositório por aggregate root, não por tabela

Se `Bill` tem `Installment` como entidade interna do agregado, **não** existe `InstallmentRepository`. Você acessa via `BillRepository.GetByIdWithInstallmentsAsync(...)`. A raiz é o ponto de entrada. Quem viola isso quebra a invariante "tudo do agregado salva numa transação só".

### Princípio 9 — `async`/`await` correto, sem `async void`

- Todo método I/O retorna `Task` ou `Task<T>`. Se for "void", retorna `Task`.
- `async void` **só** em event handlers do framework (raríssimo na Infra).
- Não use `.Result`, `.Wait()`, `GetAwaiter().GetResult()` — deadlock potencial. Sempre `await`.
- Use `ConfigureAwait(false)` em libraries publicadas (em apps ASP.NET Core moderno é menos crítico, mas não atrapalha).

### Princípio 10 — Logs estruturados, sem PII

Logue com placeholders nomeados, não interpolação:

```csharp
// CORRETO
_logger.LogInformation("Bill {BillId} scheduled for tenant {TenantId}", bill.Id, bill.TenantId);

// ERRADO — não estruturado
_logger.LogInformation($"Bill {bill.Id} scheduled for tenant {bill.TenantId}");
```

E **nunca logue**: senha, token, CPF/CNPJ inteiro, número de cartão, dados sensíveis. Se precisar correlacionar, logue um hash ou os 4 últimos dígitos.

---

## 2. O Anti-Checklist — o que NÃO vai na Infra

### Validação de input do usuário (FluentValidation)

Onde mora: **Application** (validação de Command) e **Domain** (validação de invariante de agregado).

A Infra não valida nada do que o usuário digitou. Quando o agregado chega no `Repository`, ele já está válido — porque o Domain garantiu na construção. Se o agregado é inválido, o erro é da Application/Domain, não da Infra.

```csharp
// ERRADO — na Infra
public async Task<Bill> InsertAsync(Bill model, CancellationToken ct)
{
    if (string.IsNullOrEmpty(model.Description.Value))   // <- isso é trabalho do VO!
        throw new ArgumentException("Description vazia");
    return await base.InsertAsync(model, ct);
}

// CERTO — no Domain (Description VO)
public Description(string value)
{
    if (string.IsNullOrWhiteSpace(value))
        throw new DomainException("Description não pode ser vazio.");
    Value = value;
}
```

### Lógica de autorização (quem pode fazer o quê)

Onde mora: **API** (atributos `[Authorize]`, policy handlers) e **Application** (regra do tipo "só admin pode aprovar").

A Infra **não pergunta** se o usuário pode executar a ação. Quando o `Repository` recebe `InsertAsync(bill)`, a permissão já foi verificada lá em cima.

### Mapeamento `Command → Aggregate` ou `Aggregate → DTO`

Onde mora: **Application** (Command Handlers, AutoMapper/Mapper manual).

A Infra recebe **agregados prontos** e devolve **agregados puros**. Se a sua Application está pedindo pra Infra "mapear esse Command em Bill", você está acoplando errado.

### Definição dos Domain Events

Onde mora: **Domain** (a classe do evento).

A Infra **só hospeda o dispatcher** (`MediatorExtension.DispatchDomainEventsAsync`). Os eventos em si (`BillScheduled`, `BillPaid`) e seus handlers ficam fora — eventos no Domain, handlers na Application (ou no Domain quando são side effects de domínio puro).

### DTOs de Query da Application

Onde mora: **Application** (na Query/Read Model).

A Infra **pode** ter classes `XxxQuery` que retornam DTO da Application — mas o **DTO** é definido na Application, e a Query implementa a interface da Application. A Infra não inventa DTOs.

### Cache de aplicação

Onde mora: **Application** (decora o Handler com cache) ou um **adapter dedicado** (`IRedisCacheService` na Infra implementando uma interface da Application).

A Infra **não** decide o que cachear. Ela só fornece a primitiva (`IRedisCacheService.Get/Set`). A Application é quem usa.

### Geração de identidade do agregado (`Bill.Id`)

Onde mora: **Domain** (no factory do agregado: `Bill.Schedule(...)` cria com `Guid.CreateVersion7()` lá dentro).

A Infra **não** gera Id (lembra: `ValueGeneratedNever()` no Map). O Id chega pronto. Se você está vendo o EF gerando Id, sua factory do Domain está incompleta.

### Polimorfismo de fluxo de domínio (state machine)

Onde mora: **Domain** (no agregado, ex.: `BillStatus.Pending.CanTransitionTo(Approved)`).

A Infra não decide transição de estado. Ela só persiste o estado final. Se o agregado violou a transição na construção, o Domain joga exceção; a Infra nem chega a chamar `SaveChanges`.

### Helpers de negócio (`BusinessDateCalculator`, `WorkdayService`)

Onde mora: **Domain Service** (no Domain, se é regra do domínio) ou **Infra** (se é wrapper de SDK externo, ex.: feriados via API).

Se o cálculo é matemático puro do domínio: Domain. Se é "consulta API de feriados da Receita Federal": Infra (com interface no Domain `IHolidayService`).

### Configuração de Logging / Telemetria / Tracing

Onde mora: **API** (`Program.cs` configura Serilog, OpenTelemetry).

A Infra **usa** `ILogger<T>` injetado, mas **não** configura o framework de logging. A composição é da API.

---

## 3. Erros comuns — antes/depois

### Erro 1: Repository chamando serviço externo

```csharp
// ANTI-PADRÃO
public class BillRepository : Repository<Bill>, IBillRepository
{
    private readonly IEmailService _email;

    public override async Task<Bill> InsertAsync(Bill bill, CancellationToken ct)
    {
        var inserted = await base.InsertAsync(bill, ct);
        await _email.SendAsync(...);   // ❌ Repository não envia email
        return inserted;
    }
}
```

**Correto**: o agregado dispara um Domain Event (`BillScheduled`); um handler dele (na Application) chama `IEmailService`. O Repository **só** persiste.

### Erro 2: Adaptador validando regra de negócio

```csharp
// ANTI-PADRÃO
public class StripePaymentService : IPaymentService
{
    public async Task<PaymentResult> ChargeAsync(Bill bill, CancellationToken ct)
    {
        if (bill.Status != BillStatus.Approved)   // ❌ regra de negócio
            throw new InvalidOperationException("Só aprova");
        // ...
    }
}
```

**Correto**: a regra "só Bill aprovado pode ser cobrado" mora no Aggregate (`bill.RequestPayment()` lança se não estiver aprovada). O `StripePaymentService` recebe um `PaymentRequest` já validado.

### Erro 3: Lendo configuração direto

```csharp
// ANTI-PADRÃO
public class S3BlobService : IBlobService
{
    private readonly IConfiguration _cfg;

    public S3BlobService(IConfiguration cfg) => _cfg = cfg;

    public async Task<Uri> UploadAsync(...)
    {
        var bucket = _cfg["S3:BucketName"];   // ❌
        // ...
    }
}
```

**Correto**: `IOptions<S3Options>` no construtor; `_opts.BucketName` no método.

### Erro 4: Vazando IQueryable

```csharp
// ANTI-PADRÃO
public interface IBillRepository
{
    IQueryable<Bill> Query();   // ❌ vaza EF
}

// Application:
var overdue = _billRepo.Query()
    .Include(b => b.Installments)
    .Where(b => b.DueDate < today)
    .ToListAsync(ct);
```

**Correto**: método com intenção de domínio:

```csharp
public interface IBillRepository
{
    Task<IEnumerable<Bill>> GetOverdueAsync(DateOnly referenceDate, CancellationToken ct);
}
```

### Erro 5: Repositório por entidade interna

```csharp
// ANTI-PADRÃO
public interface IInstallmentRepository
{
    Task<Installment?> GetAsync(InstallmentId id, CancellationToken ct);
}
```

`Installment` é entidade **interna** do agregado `Bill`. Acesso é via `BillRepository.GetByIdWithInstallmentsAsync(...)`. A raiz é o ponto de entrada.

### Erro 6: `HttpQueryFilter` global sem teste

```csharp
// PERIGOSO
modelBuilder.Entity<Bill>().HasQueryFilter(b => b.TenantId == _currentTenant.Id);
```

Funciona, mas: (1) `IgnoreQueryFilters()` desliga sem alarme; (2) testes precisam validar que ninguém chamou `IgnoreQueryFilters()` em produção; (3) joins entre entidades exigem que cada uma tenha o filtro.

**Preferível**: filtro **explícito** no Repository. Mais código, mais segurança. Detalhes em [`multi-tenancy.md`](multi-tenancy.md).

---

## 4. Diagrama: fronteiras das camadas (Mermaid)

```mermaid
flowchart TB
    subgraph API["API (Composition Root)"]
        Prog[Program.cs<br/>Controllers/Endpoints<br/>Middlewares de auth]
    end

    subgraph App["Application"]
        Hdl[CommandHandlers<br/>QueryHandlers<br/>Validators]
        AppItf[ICurrentTenantAccessor<br/>ICurrentUserAccessor<br/>IDateTimeProvider]
        Cmd[Commands / Queries / DTOs]
    end

    subgraph Dom["Domain"]
        Agg[Aggregates / Entities / VOs<br/>Smart Enums<br/>Domain Services<br/>Domain Events]
        DomItf[IRepository&lt;T&gt;<br/>IUnitOfWork<br/>IBlobService<br/>IPaymentService<br/>IDocumentSignatureService]
    end

    subgraph Infra["Infra"]
        Ctx[DbContext]
        Repo[Repositories]
        Map[EF Mappings]
        Mig[Migrations]
        Svc[ZapSign / Stripe / S3<br/>HttpPolicyFactory]
        Acc[HttpCurrentTenantAccessor<br/>SystemDateTimeProvider]
        DI[ServiceCollectionExtensions]
    end

    API --> Infra
    API --> App
    Infra --> Dom
    Infra --> App
    App --> Dom

    style Dom fill:#fef3c7,stroke:#92400e,color:#000
    style Infra fill:#dbeafe,stroke:#1e40af,color:#000
    style App fill:#d1fae5,stroke:#065f46,color:#000
    style API fill:#fce7f3,stroke:#9f1239,color:#000
```

Setas representam dependência (quem importa quem). Note:
- **Domain não depende de ninguém**.
- **Infra implementa interfaces do Domain e da Application** (depende dos dois).
- **Application depende só do Domain**.
- **API depende de tudo** (é onde compõe).

---

## 5. Auto-checklist final — cole na PR

Antes de aprovar a PR de Infra:

- [ ] Toda interface usada vem do Domain ou Application — nenhuma definida na Infra para "Application consumir".
- [ ] Nenhum método retorna `IQueryable<T>`, `DbSet<T>`, `EntityEntry`.
- [ ] Nenhum método I/O sem `CancellationToken`.
- [ ] Toda configuração externa via `IOptions<XxxOptions>`.
- [ ] Nenhum `Configuration["Key"]` fora do Composition Root.
- [ ] Nenhum `static` mutável.
- [ ] Nenhum `async void` (exceto event handler do framework).
- [ ] Nenhum `.Result` / `.Wait()`.
- [ ] Nenhum lógica de validação de input ou regra de domínio em Repository/Service.
- [ ] Nenhum repositório por entidade interna (só raízes).
- [ ] Multi-tenant: filtro de `TenantId` aplicado **explicitamente** em todo método.
- [ ] DTOs de query são da Application — Infra implementa.
- [ ] Domain Events: definidos no Domain; só dispatcher mora na Infra.
- [ ] Logs estruturados, sem PII.
- [ ] Tradução de exceção do banco (`UniqueConstraintException` → `DomainException`) configurada.
- [ ] Composition Root é uma única extension `AddInfraDependencies` chamada na API.

---

## 6. Como reagir quando o usuário pede algo que viola esses princípios

A skill **deve** recusar gerar código que viola os princípios, mesmo se pedido. Resposta padrão:

> "Isso vai colocar regra de negócio na Infra e amarrar a Application a EF. Vou propor a alternativa: [explica solução correta]. Posso seguir com ela?"

Não gere o código errado "pra dar uma opção". Explique e ofereça o correto. Se o usuário insistir após a explicação, gere com aviso explícito de que está fora do padrão.
