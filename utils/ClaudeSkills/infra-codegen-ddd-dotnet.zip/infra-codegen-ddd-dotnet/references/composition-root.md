# Composition Root — Dependency Injection

> O **Composition Root** é o único lugar onde você declara como as classes se conectam. Para a Infra, isso é uma extension method: `AddInfraDependencies(this IServiceCollection s, IConfiguration cfg)`. Tudo é registrado lá. A `Program.cs` da API só chama essa extension.

---

## 1. A extension principal

```csharp
// Infra/ExtensionClass/ServiceCollectionExtensions.cs
using BillsToPay.Domain.Bills;
using BillsToPay.Domain.RecurringBills;
using BillsToPay.Domain.Services;
using BillsToPay.Domain.SeedWork;
using BillsToPay.Infra.Context;
using BillsToPay.Infra.Idempotency;
using BillsToPay.Infra.Policies;
using BillsToPay.Infra.Repository;
using BillsToPay.Infra.Services;
using BillsToPay.Infra.Services.Options;
using EntityFrameworkCore.Exceptions.PostgreSQL;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace BillsToPay.Infra.ExtensionClass;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddInfraDependencies(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services
            .AddOptions(configuration)
            .AddPersistence(configuration)
            .AddRepositories()
            .AddExternalServices(configuration)
            .AddIdempotency();

        return services;
    }

    private static IServiceCollection AddOptions(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.Configure<DatabaseOptions>(configuration.GetSection(DatabaseOptions.SectionName));
        services.Configure<S3Options>(configuration.GetSection(S3Options.SectionName));
        services.Configure<ZapSignOptions>(configuration.GetSection(ZapSignOptions.SectionName));
        services.Configure<StripeOptions>(configuration.GetSection(StripeOptions.SectionName));
        return services;
    }

    private static IServiceCollection AddPersistence(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.AddDbContext<BillsToPayContext>((sp, options) =>
        {
            var dbOpts = sp.GetRequiredService<IOptions<DatabaseOptions>>().Value;
            options.UseNpgsql(dbOpts.ConnectionString, npg =>
            {
                npg.EnableRetryOnFailure(dbOpts.MaxRetryCount, dbOpts.MaxRetryDelay, null);
                npg.CommandTimeout(dbOpts.CommandTimeoutSeconds);
                npg.MigrationsHistoryTable("__EFMigrationsHistory", BillsToPayContext.DEFAULT_SCHEMA);
            });
            options.UseExceptionProcessor();
        });

        services.AddDbContextFactory<BillsToPayContext>((sp, options) =>
        {
            var dbOpts = sp.GetRequiredService<IOptions<DatabaseOptions>>().Value;
            options.UseNpgsql(dbOpts.ConnectionString, npg =>
            {
                npg.EnableRetryOnFailure(dbOpts.MaxRetryCount, dbOpts.MaxRetryDelay, null);
                npg.MigrationsHistoryTable("__EFMigrationsHistory", BillsToPayContext.DEFAULT_SCHEMA);
            });
            options.UseExceptionProcessor();
        }, lifetime: ServiceLifetime.Scoped);

        return services;
    }

    private static IServiceCollection AddRepositories(this IServiceCollection services)
    {
        // Genérico (caso algum lugar peça IRepository<T> direto — opcional)
        services.AddScoped(typeof(IRepository<>), typeof(Repository<>));

        // Específicos
        services.AddScoped<IBillRepository, BillRepository>();
        services.AddScoped<IRecurringBillRepository, RecurringBillRepository>();

        return services;
    }

    private static IServiceCollection AddExternalServices(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        // Blob: AWS S3 (singleton — IAmazonS3 é seguro como singleton)
        services.AddSingleton<IAmazonS3>(sp =>
        {
            var opts = sp.GetRequiredService<IOptions<S3Options>>().Value;
            return new AmazonS3Client(opts.AccessKey, opts.SecretKey,
                Amazon.RegionEndpoint.GetBySystemName(opts.Region));
        });
        services.AddScoped<IBlobService, S3BlobService>();

        // Document Signature: ZapSign (HTTP-based, scoped via HttpClientFactory)
        services.AddHttpClient<IDocumentSignatureService, ZapSignDocumentSignatureService>((sp, client) =>
        {
            var opts = sp.GetRequiredService<IOptions<ZapSignOptions>>().Value;
            client.BaseAddress = new Uri(opts.BaseUrl);
            client.DefaultRequestHeaders.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", opts.ApiToken);
            client.Timeout = Timeout.InfiniteTimeSpan;
        })
        .AddPolicyHandler((sp, _) => HttpPolicyFactory.GetCombinedPolicy(retryCount: 6, timeoutSeconds: 30))
        .SetHandlerLifetime(TimeSpan.FromMinutes(5));

        // Payment: Stripe
        services.AddHttpClient<IPaymentService, StripePaymentService>((sp, client) =>
        {
            var opts = sp.GetRequiredService<IOptions<StripeOptions>>().Value;
            client.BaseAddress = new Uri(opts.BaseUrl);
            client.DefaultRequestHeaders.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", opts.ApiKey);
            client.Timeout = Timeout.InfiniteTimeSpan;
        })
        .AddPolicyHandler((sp, _) => HttpPolicyFactory.GetCombinedPolicy(retryCount: 6, timeoutSeconds: 30))
        .SetHandlerLifetime(TimeSpan.FromMinutes(5));

        return services;
    }

    private static IServiceCollection AddIdempotency(this IServiceCollection services)
    {
        services.AddScoped<IRequestManager, RequestManager>();
        return services;
    }
}
```

---

## 2. `Program.cs` — uso

```csharp
// Api/Program.cs
var builder = WebApplication.CreateBuilder(args);

// Application (CQRS handlers, MediatR, etc) — fora desta skill
builder.Services.AddApplicationDependencies();

// Infra
builder.Services.AddInfraDependencies(builder.Configuration);

// Outros (autenticação, swagger, etc)
builder.Services.AddAuthentication(...);
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Aplicar migrations em dev
if (app.Environment.IsDevelopment())
{
    using var scope = app.Services.CreateScope();
    var ctx = scope.ServiceProvider.GetRequiredService<BillsToPayContext>();
    if ((await ctx.Database.GetPendingMigrationsAsync()).Any())
        await ctx.Database.MigrateAsync();
}

app.MapControllers();
app.MapHealthChecks("/health");
app.Run();
```

---

## 3. Convenções de tempo de vida (Lifetime)

| Componente | Lifetime | Motivo |
|---|---|---|
| `DbContext` | **Scoped** | Mantém ChangeTracker durante a request; descarta no fim. |
| `IDbContextFactory<T>` | **Scoped** | Cria contextos efêmeros sob demanda. Singleton só se sabe que é seguro (raro). |
| Repositórios (`IXxxRepository`) | **Scoped** | Compartilham o `DbContext` da request. |
| `IUnitOfWork` | (resolvido via repo) | Não registre direto; vem de `IRepository<T>.UnitOfWork`. |
| `IRequestManager` (idempotência) | **Scoped** | Usa o `DbContext`. |
| Adaptadores HTTP (`StripePaymentService`) | **Scoped** (via `AddHttpClient`) | `HttpClient` real é singleton no factory; o serviço é scoped. |
| Adaptadores stateful (cache local, browser provider) | **Singleton** | Compartilham estado entre requests. |
| `IAmazonS3`, `StripeClient`, etc (clientes de SDK thread-safe) | **Singleton** | Documentação do SDK confirma thread-safety. |
| `IOptions<XxxOptions>` | (registrado pelo framework) | Singleton sob o capô. |
| `IMediator` | **Transient** (default do MediatR) | Stateless. |

**Regras práticas**:
- Nunca registre `DbContext` como Transient ou Singleton — vai dar erro.
- Nunca injete um Scoped dentro de um Singleton — captura de scope vazio em runtime. Use `IServiceProvider` ou `IServiceScopeFactory` se for inevitável.
- HTTP-based services: deixe o `HttpClientFactory` cuidar — o lifetime do serviço é Scoped, mas a conexão HTTP subjacente é gerenciada pelo factory (com `SetHandlerLifetime(TimeSpan.FromMinutes(5))` para reciclar handlers).

---

## 4. `ICurrentTenantAccessor` e `ICurrentUserAccessor` — interfaces "técnicas"

Diferente das interfaces de **domínio** (que ficam no Domain), há interfaces que são **técnicas** mas usadas pela Application:

```csharp
// Application/Common/ICurrentTenantAccessor.cs (na Application, não no Domain)
public interface ICurrentTenantAccessor
{
    TenantId Id { get; }
}

// Application/Common/ICurrentUserAccessor.cs
public interface ICurrentUserAccessor
{
    UserId Id { get; }
    string Email { get; }
    bool IsAdmin { get; }
}
```

A Infra implementa lendo o `HttpContext`:

```csharp
// Infra/Services/HttpCurrentTenantAccessor.cs
public class HttpCurrentTenantAccessor : ICurrentTenantAccessor
{
    private readonly IHttpContextAccessor _http;
    public HttpCurrentTenantAccessor(IHttpContextAccessor http) => _http = http;

    public TenantId Id
    {
        get
        {
            var claim = _http.HttpContext?.User.FindFirst("tenant_id")
                ?? throw new UnauthorizedAccessException("No tenant_id claim.");
            return new TenantId(Guid.Parse(claim.Value));
        }
    }
}
```

E registra:

```csharp
services.AddHttpContextAccessor();
services.AddScoped<ICurrentTenantAccessor, HttpCurrentTenantAccessor>();
services.AddScoped<ICurrentUserAccessor, HttpCurrentUserAccessor>();
```

> **Por que essas interfaces ficam na Application e não no Domain?** Porque o Domain não conhece o conceito de "request HTTP" ou "claims". É a Application que precisa saber "qual o tenant atual" pra orquestrar; o Domain só recebe o `TenantId` como parâmetro. A Application define o contrato; a Infra fornece a implementação que lê do HTTP.

---

## 5. Validação das opções na inicialização

`IOptions<T>` é resolvido **lazy**. Se a config tiver erro de tipo, você só descobre quando uma request chega. Para falhar rápido na subida da app, valide:

```csharp
services.AddOptions<DatabaseOptions>()
    .Bind(configuration.GetSection(DatabaseOptions.SectionName))
    .ValidateDataAnnotations()        // se usar [Required], [Range], etc
    .Validate(opts =>
        !string.IsNullOrEmpty(opts.ConnectionString) && opts.MaxRetryCount > 0,
        "DatabaseOptions inválido")
    .ValidateOnStart();               // ← valida na subida
```

---

## 6. Múltiplos `DbContext` na mesma app (multi-bounded-context)

Se a API hospeda mais de um bounded context (ex.: `BillsToPay` e `Suppliers`), cada um tem sua extension:

```csharp
// Program.cs
builder.Services
    .AddBillsToPayInfraDependencies(builder.Configuration)
    .AddSuppliersInfraDependencies(builder.Configuration);
```

Cada extension registra seu próprio `DbContext` apontando para o seu próprio schema. Os repositórios de cada bounded context são scoped ao seu próprio contexto.

---

## 7. Composition Root e Clean Architecture

Pela regra de dependência da Clean Architecture:

```
API (composition root) → Infra → Application → Domain
```

A API **compõe** Infra + Application + Domain. Mas o composition root da Infra (a extension) **só conhece** Domain (interfaces que implementa) e configurações. Não conhece Application.

```mermaid
flowchart LR
    Api[API<br/>Program.cs]
    Infra[Infra<br/>AddInfraDependencies]
    App[Application<br/>AddApplicationDependencies]
    Dom[Domain]

    Api --> Infra
    Api --> App
    Infra --> Dom
    App --> Dom
```

Note: Infra **não conhece** Application. Application **não conhece** Infra. Ambos conhecem Domain. A API junta tudo.

---

## 8. Testes com fakes — como a estrutura facilita

Com tudo dependendo de interfaces do Domain, você pode trocar implementações em teste:

```csharp
// Test/Fakes/InMemoryBillRepository.cs
public class InMemoryBillRepository : IBillRepository
{
    private readonly List<Bill> _bills = new();
    public IUnitOfWork UnitOfWork => new FakeUnitOfWork();
    public Task<Bill> InsertAsync(Bill b, CancellationToken ct) { _bills.Add(b); return Task.FromResult(b); }
    public Task<Bill?> FirstOrDefaultAsync(Expression<Func<Bill,bool>> f, CancellationToken ct)
        => Task.FromResult(_bills.AsQueryable().FirstOrDefault(f));
    // ...
}

// Test setup
services.AddScoped<IBillRepository, InMemoryBillRepository>();
services.AddScoped<IBlobService, FakeBlobService>();
// não adicionou DbContext, S3 nem nada da Infra real → testa Application puro
```

---

## 9. Checklist do Composition Root

- [ ] Uma única extension method `AddInfraDependencies(this IServiceCollection, IConfiguration)`.
- [ ] Sub-métodos privados por área (`AddPersistence`, `AddRepositories`, `AddExternalServices`).
- [ ] Toda config externa via `Configure<XxxOptions>(GetSection(...))`.
- [ ] `ValidateOnStart()` em options críticas (database, secrets).
- [ ] Lifetime correto para cada componente (DbContext=Scoped, SDK clients thread-safe=Singleton, HttpClients=Scoped via factory).
- [ ] `AddHttpContextAccessor()` registrado se houver `ICurrentTenantAccessor`.
- [ ] `IDbContextFactory<T>` registrado se houver queries paralelas.
- [ ] Polly aplicado em todo `AddHttpClient`.
- [ ] Health check do banco registrado.
- [ ] Migrations aplicadas em dev no startup; em produção via job de deploy.

---

## 10. Diagrama: dependências resolvidas pelo container (Mermaid)

```mermaid
flowchart TD
    BR[BillRepository] --> Ctx[BillsToPayContext]
    Ctx --> DbOpts[IOptions DatabaseOptions]
    Ctx --> Med[IMediator]

    Z[ZapSignDocumentSignatureService] --> HC1[HttpClient]
    Z --> ZOpts[IOptions ZapSignOptions]
    HC1 --> Polly1[CombinedPolicy]

    S[StripePaymentService] --> HC2[HttpClient]
    S --> SOpts[IOptions StripeOptions]
    HC2 --> Polly2[CombinedPolicy]

    BS[S3BlobService] --> S3[IAmazonS3 singleton]
    BS --> BOpts[IOptions S3Options]

    RM[RequestManager] --> Ctx

    HC1 -.HttpClientFactory.- HCF[HttpMessageHandler<br/>lifetime 5min]
    HC2 -.HttpClientFactory.- HCF
```
