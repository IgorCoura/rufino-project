# HTTP Resilience — Polly

> Toda chamada HTTP para o mundo externo passa por Polly. **Sem exceção.** A internet falha, APIs ficam fora, latência varia. Polly trata isso de forma centralizada e configurável, sem poluir o código de negócio.

---

## 1. Por que Polly e não tentar/exceto manual?

Tentação clássica:

```csharp
// ANTI-PADRÃO
for (var i = 0; i < 3; i++)
{
    try { return await _http.GetAsync(url, ct); }
    catch (HttpRequestException) { await Task.Delay(1000); }
}
```

Problemas:
- Sem backoff exponencial — três falhas seguidas em 3 segundos sobrecarregam ainda mais o destino já em apuros.
- Sem distinção entre erro transiente (5xx, timeout) e permanente (4xx) — você re-tenta um 401 que jamais vai ter sucesso.
- Sem timeout por tentativa — uma tentativa lenta consome o orçamento das outras.
- Sem circuit breaker — se a API caiu, você continua martelando.
- Espalhado por todo lugar, divergindo entre serviços.

Polly resolve tudo isso em uma fábrica centralizada.

---

## 2. A `HttpPolicyFactory`

```csharp
// Infra/Policies/HttpPolicyFactory.cs
using Microsoft.Extensions.Logging;
using Polly;
using Polly.Extensions.Http;
using Polly.Timeout;

namespace BillsToPay.Infra.Policies;

public static class HttpPolicyFactory
{
    /// <summary>
    /// Política combinada padrão para chamadas HTTP a serviços externos.
    /// Ordem importa: CircuitBreaker fora, Retry no meio, Timeout interno.
    /// Cada tentativa do retry tem seu próprio timeout.
    /// </summary>
    public static IAsyncPolicy<HttpResponseMessage> GetCombinedPolicy(
        int retryCount = 6,
        int timeoutSeconds = 30,
        int circuitBreakerThreshold = 5,
        int circuitBreakerDurationSeconds = 30)
    {
        return Policy.WrapAsync(
            GetCircuitBreakerPolicy(circuitBreakerThreshold, circuitBreakerDurationSeconds),
            GetRetryPolicy(retryCount),
            GetTimeoutPolicy(timeoutSeconds));
    }

    /// <summary>
    /// Versão "agressiva" — para webhooks ou operações onde re-entrega vale o custo.
    /// </summary>
    public static IAsyncPolicy<HttpResponseMessage> GetAggressivePolicy(
        int retryCount = 16,
        int timeoutSeconds = 60)
    {
        return Policy.WrapAsync(
            GetRetryPolicy(retryCount),
            GetTimeoutPolicy(timeoutSeconds));
    }

    private static IAsyncPolicy<HttpResponseMessage> GetRetryPolicy(int retryCount)
    {
        return HttpPolicyExtensions
            .HandleTransientHttpError()                       // 5xx, 408
            .Or<TimeoutRejectedException>()                   // timeout do Polly
            .WaitAndRetryAsync(
                retryCount,
                retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),  // 2s, 4s, 8s, 16s...
                onRetry: (outcome, delay, attempt, ctx) =>
                {
                    var logger = ctx.GetLogger();
                    logger?.LogWarning(
                        "Retry {Attempt} after {Delay}s — Reason: {Reason}",
                        attempt,
                        delay.TotalSeconds,
                        outcome.Exception?.Message ?? outcome.Result?.StatusCode.ToString());
                });
    }

    private static IAsyncPolicy<HttpResponseMessage> GetTimeoutPolicy(int seconds)
    {
        return Policy.TimeoutAsync<HttpResponseMessage>(
            TimeSpan.FromSeconds(seconds),
            TimeoutStrategy.Optimistic);   // respeita o CancellationToken passado
    }

    private static IAsyncPolicy<HttpResponseMessage> GetCircuitBreakerPolicy(
        int threshold, int durationSeconds)
    {
        return HttpPolicyExtensions
            .HandleTransientHttpError()
            .Or<TimeoutRejectedException>()
            .CircuitBreakerAsync(
                handledEventsAllowedBeforeBreaking: threshold,
                durationOfBreak: TimeSpan.FromSeconds(durationSeconds),
                onBreak: (outcome, breakDelay, ctx) =>
                {
                    var logger = ctx.GetLogger();
                    logger?.LogError(
                        "Circuit breaker OPEN for {BreakDelay}s — Reason: {Reason}",
                        breakDelay.TotalSeconds,
                        outcome.Exception?.Message ?? outcome.Result?.StatusCode.ToString());
                },
                onReset: ctx =>
                {
                    var logger = ctx.GetLogger();
                    logger?.LogInformation("Circuit breaker RESET");
                });
    }
}

internal static class PollyContextExtensions
{
    private const string LoggerKey = "Logger";

    public static Context WithLogger(this Context ctx, ILogger logger)
    {
        ctx[LoggerKey] = logger;
        return ctx;
    }

    public static ILogger? GetLogger(this Context ctx)
        => ctx.TryGetValue(LoggerKey, out var logger) ? logger as ILogger : null;
}
```

---

## 3. Por que essa ordem: `CircuitBreaker → Retry → Timeout`?

`Policy.WrapAsync(outer, inner1, inner2)` executa de fora pra dentro: `outer` recebe a primeira chamada, delega para `inner1`, que delega para `inner2`. Logo:

- **Circuit Breaker (mais externo)**: vê o resultado **final** após todas as tentativas. Se 5 chamadas (cada uma com seus retries) falharam, ele abre. Se o CB estivesse no meio, ele contaria cada retry como uma falha — abriria rápido demais.
- **Retry (meio)**: vê falhas isoladas e decide se tenta de novo.
- **Timeout (mais interno)**: limita **cada tentativa individual**. Sem isso, uma tentativa lenta consome o orçamento das outras.

Visualmente:

```
[Caller] → [CircuitBreaker] → [Retry] → [Timeout] → [HttpClient]
                                ↑           ↑
                                |           |
                          retry decision   per-attempt timeout
```

---

## 4. Aplicando no `HttpClient` (DI)

```csharp
// Infra/ExtensionClass/ServiceCollectionExtensions.cs (recorte)
services.AddHttpClient<IDocumentSignatureService, ZapSignDocumentSignatureService>((sp, client) =>
{
    var opts = sp.GetRequiredService<IOptions<ZapSignOptions>>().Value;
    client.BaseAddress = new Uri(opts.BaseUrl);
    client.Timeout = Timeout.InfiniteTimeSpan;   // ← Polly cuida do timeout
})
.AddPolicyHandler((sp, request) =>
{
    var logger = sp.GetRequiredService<ILogger<ZapSignDocumentSignatureService>>();
    return HttpPolicyFactory.GetCombinedPolicy(retryCount: 6, timeoutSeconds: 30);
})
.SetHandlerLifetime(TimeSpan.FromMinutes(5));
```

> **Importante**: `client.Timeout = Timeout.InfiniteTimeSpan` é proposital. O timeout do `HttpClient` é "burro" — corta a chamada e não interage com Polly. Deixe Polly comandar o timeout.

---

## 5. Quando usar a versão "agressiva"

`GetAggressivePolicy(retryCount: 16)` é para casos especiais:

- **Webhooks recebidos**: reentrega importa mais que rapidez. Se o fornecedor manda webhook e você processa via fila, vale a pena tentar muito antes de desistir.
- **Operações idempotentes em batch noturno**: o job tem 8h pra rodar; pode esperar.

**Não use** para chamadas de UI síncrona — usuário não espera 16 retries de 60s cada.

---

## 6. Erros que **não** devem disparar retry

Por padrão, `HandleTransientHttpError()` cobre `5xx` e `408`. Mas alguns erros são "trate especial":

```csharp
// Custom: 429 Too Many Requests respeita o header Retry-After
.OrResult(r => r.StatusCode == HttpStatusCode.TooManyRequests)
.WaitAndRetryAsync(
    retryCount,
    sleepDurationProvider: (attempt, response, ctx) =>
    {
        // Se a API mandou Retry-After, respeita
        var retryAfter = response.Result?.Headers.RetryAfter?.Delta;
        return retryAfter ?? TimeSpan.FromSeconds(Math.Pow(2, attempt));
    },
    onRetryAsync: (outcome, delay, attempt, ctx) => Task.CompletedTask);
```

**Nunca tentar de novo**:
- `400 Bad Request` — sua requisição está errada, retry não conserta.
- `401 Unauthorized` / `403 Forbidden` — credencial inválida, retry não conserta.
- `404 Not Found` — recurso não existe, retry não conserta.
- `409 Conflict` — geralmente conflito lógico, retry pode piorar.

Polly por padrão não retentar 4xx (exceto 408/429), o que é o comportamento certo.

---

## 7. Observabilidade — sem logs, é caixa-preta

Cada retry, cada break do circuit, cada timeout precisa virar log estruturado. A `HttpPolicyFactory` acima já loga via `Polly.Context["Logger"]`.

Para propagar o logger para o contexto:

```csharp
.AddPolicyHandler((sp, request) =>
{
    var logger = sp.GetRequiredService<ILogger<ZapSignDocumentSignatureService>>();
    var ctx = new Context { ["Logger"] = logger };

    // Anexa o contexto ao request — Polly o repassa em todos os hooks
    request.SetPolicyExecutionContext(ctx);

    return HttpPolicyFactory.GetCombinedPolicy(retryCount: 6, timeoutSeconds: 30);
});
```

**Métricas**: registre via OpenTelemetry/Prometheus contadores de:
- `http_retries_total{service, attempt}` — histograma.
- `http_circuit_breaker_state{service}` — gauge (0=closed, 1=half-open, 2=open).
- `http_timeouts_total{service}` — counter.

---

## 8. Combinando com Cancellation Token

`TimeoutStrategy.Optimistic` (que usamos) **respeita o `CancellationToken`** passado pelo caller. Isso é importante: se o usuário cancelou a request HTTP de entrada, o cancelamento propaga até o Polly e até o `HttpClient`, abortando tentativas futuras.

A alternativa `TimeoutStrategy.Pessimistic` cria um token interno e ignora o externo — só use se você não puder propagar `CancellationToken` (raríssimo).

---

## 9. Por que circuit breaker importa

Cenário: a API ZapSign caiu. Sem circuit breaker:

1. Sua API recebe 100 req/s pedindo assinatura.
2. Cada uma faz 6 retries com 2/4/8/16/32/64s = 126s.
3. Você tem 100×6 = 600 req/s indo pra ZapSign que já está caída.
4. Suas threads ficam todas presas esperando timeout.
5. Sua API trava por sobrecarga interna.

Com circuit breaker:
1. Após 5 falhas consecutivas, o CB **abre** por 30s.
2. Próximas chamadas falham **imediatamente** (`BrokenCircuitException`) — sem ir pra ZapSign.
3. Suas threads liberam rápido. Sua API segue respondendo (com erro 503 para a feature de assinatura, mas sem cair).
4. Após 30s, o CB entra em "half-open" — testa **uma** chamada. Se ok, fecha. Se não, abre por mais 30s.

---

## 10. Tratando `BrokenCircuitException` na Application

Quando o CB está aberto, qualquer chamada lança `BrokenCircuitException`. A Application deve traduzir isso para o usuário:

```csharp
try
{
    var session = await _signatureService.CreateAsync(req, ct);
    return Result.Ok(session);
}
catch (BrokenCircuitException)
{
    return Result.Fail("Serviço de assinatura temporariamente indisponível. Tente em alguns segundos.");
}
```

Ou, melhor: traduza no próprio adaptador para `ExternalServiceException`:

```csharp
public async Task<DocumentSignatureSession> CreateAsync(...)
{
    try { /* ... */ }
    catch (BrokenCircuitException)
    {
        throw new ExternalServiceException("ZapSign", "Service temporarily unavailable (circuit breaker open).");
    }
}
```

---

## 11. Checklist da resiliência

- [ ] `HttpPolicyFactory` centralizada — não há `Policy.X` espalhado.
- [ ] Toda registro de `HttpClient` aplica `.AddPolicyHandler(...)`.
- [ ] Política combinada: CircuitBreaker + Retry + Timeout (nessa ordem do mais externo ao mais interno).
- [ ] `client.Timeout = Timeout.InfiniteTimeSpan` (Polly comanda timeout).
- [ ] Logs em retry, break, reset.
- [ ] `TimeoutStrategy.Optimistic` (respeita `CancellationToken`).
- [ ] Versão "agressiva" disponível para webhooks/jobs.
- [ ] Exceções tratadas: `BrokenCircuitException` → `ExternalServiceException`.
- [ ] Métricas/observabilidade configuradas.

---

## 12. Diagrama: estados do Circuit Breaker (Mermaid)

```mermaid
stateDiagram-v2
    [*] --> Closed
    Closed --> Open: 5 falhas consecutivas
    Open --> HalfOpen: após 30s
    HalfOpen --> Closed: 1 sucesso
    HalfOpen --> Open: 1 falha
    Closed --> Closed: sucesso

    note right of Closed
        Estado normal:
        chamadas passam para o servidor.
    end note

    note right of Open
        Estado degradado:
        chamadas falham imediatamente
        com BrokenCircuitException.
    end note

    note right of HalfOpen
        Estado de teste:
        permite UMA chamada.
        Sucesso fecha; falha reabre.
    end note
```
