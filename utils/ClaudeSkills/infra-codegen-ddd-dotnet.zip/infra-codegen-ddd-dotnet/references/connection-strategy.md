# Connection & Transaction Strategy

> Como configurar a conexão com o PostgreSQL, lidar com falhas transitórias, separar contextos de leitura e escrita, e traduzir exceções do banco em algo que o Domain entenda.

---

## 1. `EnableRetryOnFailure` — não negocie

Toda conexão com PostgreSQL **tem que** habilitar retry transitório. Falhas de rede, restart de instância no RDS, failover de replica — tudo isso é transiente e o EF resolve sozinho **se** estiver configurado.

```csharp
services.AddDbContext<BillsToPayContext>((sp, options) =>
{
    var conn = configuration.GetConnectionString("BillsToPay")!;
    options.UseNpgsql(conn, npg =>
    {
        npg.EnableRetryOnFailure(
            maxRetryCount: 5,
            maxRetryDelay: TimeSpan.FromSeconds(10),
            errorCodesToAdd: null);

        npg.MigrationsHistoryTable("__EFMigrationsHistory", BillsToPayContext.DEFAULT_SCHEMA);
    });
    options.UseExceptionProcessor();
});
```

> **Cuidado com transações manuais**: `EnableRetryOnFailure` **desabilita** transações de usuário (`Database.BeginTransaction()`). Se você precisar de transação manual, use `Database.CreateExecutionStrategy().ExecuteAsync(...)` que reabilita o retry dentro de uma transação. Em DDD bem feito você raramente precisa de transação manual — o `SaveChangesAsync` já é a transação do agregado.

---

## 2. `AddDbContext` + `AddDbContextFactory` — leitura e escrita separadas

**Cenário 1**: aplicação só faz CRUD simples → só `AddDbContext`. Pronto.

**Cenário 2**: aplicação tem read models, queries paralelas, ou jobs em background lendo enquanto outro request escreve → registre **ambos**:

```csharp
// Para escrita: scoped, segue o ciclo da request
services.AddDbContext<BillsToPayContext>(ConfigureNpgsql);

// Para leitura: cria contextos efêmeros sob demanda
services.AddDbContextFactory<BillsToPayContext>(ConfigureNpgsql, lifetime: ServiceLifetime.Scoped);

void ConfigureNpgsql(IServiceProvider sp, DbContextOptionsBuilder options)
{
    var conn = configuration.GetConnectionString("BillsToPay")!;
    options.UseNpgsql(conn, npg =>
    {
        npg.EnableRetryOnFailure(5, TimeSpan.FromSeconds(10), null);
        npg.MigrationsHistoryTable("__EFMigrationsHistory", BillsToPayContext.DEFAULT_SCHEMA);
    });
    options.UseExceptionProcessor();
}
```

Uso típico do factory em uma Query (read model):

```csharp
public class BillsDashboardQuery
{
    private readonly IDbContextFactory<BillsToPayContext> _factory;

    public BillsDashboardQuery(IDbContextFactory<BillsToPayContext> factory) => _factory = factory;

    public async Task<DashboardDto> GetAsync(TenantId tenantId, CancellationToken ct)
    {
        await using var ctx = await _factory.CreateDbContextAsync(ct);
        // contexto isolado, sem ChangeTracker contaminado por writes em andamento
        return await ctx.Bills.AsNoTracking()
            .Where(b => b.TenantId == tenantId)
            .GroupBy(b => b.Status)
            .Select(g => new { Status = g.Key, Count = g.Count() })
            .ToDictionaryAsync(x => x.Status, x => x.Count, ct)
            .ContinueWith(t => MapToDto(t.Result), ct);
    }
}
```

> **Por que isolar?** Cada `using var ctx = factory.CreateDbContext()` é um `DbContext` novinho — sem ChangeTracker compartilhado, sem state leak entre requests, sem race condition. Ideal para read-only que pode rodar em paralelo.

**Lifetime do factory**: `Scoped` é o default seguro. Use `Singleton` apenas se você sabe que nada do `DbContext` vaza estado mutável (e na prática isso é difícil garantir — fique no Scoped).

---

## 3. Connection string — via Options pattern, não direto

```csharp
// Infra/Services/Options/DatabaseOptions.cs
public sealed class DatabaseOptions
{
    public const string SectionName = "Database";
    public required string ConnectionString { get; init; }
    public int MaxRetryCount { get; init; } = 5;
    public TimeSpan MaxRetryDelay { get; init; } = TimeSpan.FromSeconds(10);
    public int CommandTimeoutSeconds { get; init; } = 30;
}
```

```json
{
  "Database": {
    "ConnectionString": "Host=localhost;Database=billstopay;Username=app;Password=...",
    "MaxRetryCount": 5,
    "MaxRetryDelay": "00:00:10",
    "CommandTimeoutSeconds": 30
  }
}
```

```csharp
services.Configure<DatabaseOptions>(configuration.GetSection(DatabaseOptions.SectionName));

services.AddDbContext<BillsToPayContext>((sp, options) =>
{
    var dbOpts = sp.GetRequiredService<IOptions<DatabaseOptions>>().Value;
    options.UseNpgsql(dbOpts.ConnectionString, npg =>
    {
        npg.EnableRetryOnFailure(dbOpts.MaxRetryCount, dbOpts.MaxRetryDelay, null);
        npg.CommandTimeout(dbOpts.CommandTimeoutSeconds);
        npg.MigrationsHistoryTable("__EFMigrationsHistory", BillsToPayContext.DEFAULT_SCHEMA);
    });
    options.UseExceptionProcessor();
});
```

**Em produção** a connection string vem de variável de ambiente / secret manager:

```bash
export Database__ConnectionString="Host=...;Database=...;Username=...;Password=..."
```

---

## 4. `EntityFramework.Exceptions.PostgreSQL` — exceções tipadas

Sem essa lib, qualquer erro do banco vira um genérico `DbUpdateException`. Você não consegue distinguir "violou unique" de "FK quebrada" sem inspecionar a `InnerException` por mensagem (frágil).

Com a lib:

```csharp
options.UseExceptionProcessor();
```

Agora você captura erros tipados:

```csharp
try
{
    await _ctx.SaveChangesAsync(ct);
}
catch (UniqueConstraintException ex)
{
    // já sabe que é violação de unique — mapeia para erro de domínio
    throw new DomainException("Já existe uma conta com esse número.", ex);
}
catch (ReferenceConstraintException ex)
{
    throw new DomainException("Não é possível remover: existem registros vinculados.", ex);
}
catch (MaxLengthExceededException ex)
{
    throw new DomainException("Algum campo excedeu o tamanho máximo permitido.", ex);
}
catch (NumericOverflowException ex)
{
    throw new DomainException("Valor numérico excede o limite suportado.", ex);
}
```

> **Onde tratar isso?** Em um middleware/filtro **global** da API que mapeia para HTTP status:
> - `DomainException` → 422 Unprocessable Entity
> - `UniqueConstraintException` → 409 Conflict (ou via mapping para `DomainException` antes)
> - Tudo o mais → 500 + log

Pacotes:
- `EntityFramework.Exceptions.PostgreSQL` (npgsql)
- `EntityFramework.Exceptions.SqlServer` (SQL Server)
- `EntityFramework.Exceptions.MySQL.Pomelo`

---

## 5. Aplicação de migrations no startup

Para **dev** e ambientes pequenos:

```csharp
// Program.cs (após app.Build())
using (var scope = app.Services.CreateScope())
{
    var ctx = scope.ServiceProvider.GetRequiredService<BillsToPayContext>();

    if ((await ctx.Database.GetPendingMigrationsAsync()).Any())
    {
        app.Logger.LogInformation("Applying pending migrations...");
        await ctx.Database.MigrateAsync();
    }
}
```

Para **produção**, **separe**: rode migration no pipeline de deploy (job dedicado), **não** no startup da aplicação. Razões:

1. Várias instâncias da app subindo em paralelo não competem pra rodar a mesma migration.
2. Migration falhar não derruba a aplicação (a app sobe na versão antiga).
3. DBA pode revisar antes de aplicar.

```bash
# Job de deploy (separado)
dotnet ef database update --project BillsToPay.Infra --startup-project BillsToPay.Api
```

---

## 6. Health check — confirma conexão com o banco

```csharp
services.AddHealthChecks()
    .AddDbContextCheck<BillsToPayContext>(name: "billstopay-db", failureStatus: HealthStatus.Unhealthy);

// Program.cs
app.MapHealthChecks("/health");
```

Endpoint `/health` retorna 200 se o banco está acessível, 503 se não. Útil pro orquestrador (Kubernetes, ECS) decidir se a instância está viva.

---

## 7. Pool de conexão — Npgsql cuida sozinho

A connection string já configura pool:

```
Host=...;Database=...;Username=...;Password=...;
Maximum Pool Size=100;Minimum Pool Size=5;Connection Idle Lifetime=300
```

Defaults bons:
- `Maximum Pool Size = 100` (suficiente para a maioria das apps).
- `Minimum Pool Size = 5` (mantém algumas conexões prontas).
- `Connection Idle Lifetime = 300` (fecha após 5min sem uso).

Em SaaS multi-tenant com **muitos tenants e poucas conexões**, vale considerar pgbouncer na frente.

---

## 8. Transação manual — quando precisa, e como

99% das vezes você não precisa: `SaveChangesAsync` já abre/fecha transação automaticamente em volta de todas as mudanças.

**Quando precisa**:
- Você quer modificar **dois agregados** numa transação só (eventualmente isso vira sinal de que deveriam ser um). Exceção: idempotência (gravar a tabela `idempotent_requests` junto com o agregado).
- Você precisa de operação que mistura raw SQL + EF.

```csharp
var strategy = _ctx.Database.CreateExecutionStrategy();
await strategy.ExecuteAsync(async () =>
{
    await using var transaction = await _ctx.Database.BeginTransactionAsync(ct);

    await _ctx.IdempotentRequests.AddAsync(idempotentRequest, ct);
    await _ctx.SaveChangesWithoutDispatchEventsAsync(ct);

    await _billRepository.InsertAsync(bill, ct);
    await _ctx.SaveChangesAsync(ct);   // dispatch de eventos aqui

    await transaction.CommitAsync(ct);
});
```

`CreateExecutionStrategy().ExecuteAsync` re-executa o bloco inteiro em caso de falha transiente (por isso o bloco precisa ser **idempotente** — se o `bill` já foi inserido, o segundo retry deve detectar).

---

## 9. Snapshot do estado do banco (`__EFMigrationsHistory`)

O EF mantém uma tabela `__EFMigrationsHistory` que registra qual migration está aplicada. Ao usar schema dedicado:

```csharp
npg.MigrationsHistoryTable("__EFMigrationsHistory", BillsToPayContext.DEFAULT_SCHEMA);
```

Cria a tabela em `bills_to_pay.__EFMigrationsHistory`. Se você tem múltiplos contextos no mesmo banco, cada um tem sua própria tabela em seu próprio schema — sem colisão.

---

## 10. Checklist da estratégia de conexão

- [ ] `EnableRetryOnFailure` configurado.
- [ ] `UseExceptionProcessor()` aplicado (lib `EntityFramework.Exceptions.<Provider>`).
- [ ] Connection string lida via `IOptions<DatabaseOptions>`.
- [ ] Connection string em produção vem de env var / secret manager.
- [ ] `MigrationsHistoryTable` aponta para o schema do contexto.
- [ ] Health check do banco registrado.
- [ ] Migration de produção aplicada via job de deploy (não no startup).
- [ ] `AddDbContextFactory` registrado **se** houver queries paralelas a writes.
- [ ] Excepções tipadas (`UniqueConstraintException` etc) mapeadas para `DomainException` em filtro global.
- [ ] Transação manual usa `CreateExecutionStrategy().ExecuteAsync` (compatível com retry).

---

## 11. Diagrama: ciclo de uma escrita (Mermaid)

```mermaid
sequenceDiagram
    participant H as Handler
    participant R as IBillRepository
    participant U as IUnitOfWork
    participant ES as ExecutionStrategy<br/>(retry transiente)
    participant DB as PostgreSQL

    H->>R: InsertAsync(bill, ct)
    R->>R: _set.AddAsync(bill)
    H->>U: SaveChangesAsync(ct)
    U->>ES: ExecuteAsync(() => SaveChanges)
    ES->>DB: BEGIN; INSERT bill; COMMIT
    DB-->>ES: 1 row affected
    ES-->>U: 1
    U-->>H: 1
    
    Note over ES,DB: Se falha transiente (timeout, deadlock):<br/>ExecutionStrategy refaz a operação<br/>até maxRetryCount=5
```
