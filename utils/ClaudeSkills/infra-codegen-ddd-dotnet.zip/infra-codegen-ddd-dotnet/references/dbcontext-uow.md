# DbContext como Unit of Work

> O `DbContext` é o coração da Infra. Ele é, ao mesmo tempo: (1) o ORM, (2) o `IUnitOfWork` que a Application enxerga, (3) o ponto de despacho de Domain Events. Esses três papéis têm que ficar **claros e separados em código**, mesmo morando na mesma classe.

---

## 1. Princípio: DbContext implementa `IUnitOfWork`

A Application **não conhece** `DbContext`. Ela só vê `IUnitOfWork`, que é uma interface do Domain:

```csharp
// Domain/SeedWork/IUnitOfWork.cs
namespace BillsToPay.Domain.SeedWork;

public interface IUnitOfWork
{
    Task<int> SaveChangesAsync(CancellationToken ct = default);
}
```

E o `DbContext` da Infra implementa essa interface:

```csharp
// Infra/Context/BillsToPayContext.cs
public class BillsToPayContext : DbContext, IUnitOfWork
{
    // ...
}
```

**Por que isso importa?** O Handler da Application escreve assim:

```csharp
public async Task Handle(ScheduleBillCommand cmd, CancellationToken ct)
{
    var bill = Bill.Schedule(cmd.SupplierId, cmd.Amount, cmd.DueDate);
    await _billRepository.InsertAsync(bill, ct);
    await _billRepository.UnitOfWork.SaveChangesAsync(ct);
}
```

O Handler nunca importa `Microsoft.EntityFrameworkCore`. Trocar EF Core por Dapper amanhã envolve reescrever a Infra, não a Application.

---

## 2. Estrutura completa do `DbContext`

```csharp
using BillsToPay.Domain.SeedWork;
using BillsToPay.Domain.Bills;
using BillsToPay.Domain.RecurringBills;
using BillsToPay.Infra.Idempotency;
using BillsToPay.Infra.ExtensionClass;
using EntityFrameworkCore.Exceptions.PostgreSQL;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;

namespace BillsToPay.Infra.Context;

public class BillsToPayContext : DbContext, IUnitOfWork
{
    public const string DEFAULT_SCHEMA = "bills_to_pay";

    private readonly IMediator? _mediator;

    public BillsToPayContext(DbContextOptions<BillsToPayContext> options)
        : base(options) { }

    // construtor usado pela API (recebe MediatR para despachar Domain Events)
    public BillsToPayContext(DbContextOptions<BillsToPayContext> options, IMediator mediator)
        : base(options)
    {
        _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
    }

    // DbSet APENAS de aggregate roots
    public DbSet<Bill> Bills => Set<Bill>();
    public DbSet<RecurringBill> RecurringBills => Set<RecurringBill>();

    // Tabelas auxiliares (não de domínio)
    public DbSet<IdempotentRequest> IdempotentRequests => Set<IdempotentRequest>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema(DEFAULT_SCHEMA);

        // Aplica TODAS as IEntityTypeConfiguration<T> deste assembly.
        // Cada classe de Mapping/ é descoberta automaticamente.
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(BillsToPayContext).Assembly);
    }

    public override async Task<int> SaveChangesAsync(CancellationToken ct = default)
    {
        // 1. Despacha eventos de domínio ANTES de persistir
        if (_mediator is not null)
            await _mediator.DispatchDomainEventsAsync(this);

        // 2. Atualiza CreatedAt / UpdatedAt automáticos
        UpdateDatetimeEntities();

        // 3. Persiste
        return await base.SaveChangesAsync(ct);
    }

    // Versão sem dispatch — para jobs e tabela de idempotência
    public Task<int> SaveChangesWithoutDispatchEventsAsync(CancellationToken ct = default)
    {
        UpdateDatetimeEntities();
        return base.SaveChangesAsync(ct);
    }

    private void UpdateDatetimeEntities()
    {
        var now = DateTime.UtcNow;

        var entries = ChangeTracker.Entries()
            .Where(e => e.Entity is Entity && (e.State == EntityState.Added || e.State == EntityState.Modified));

        foreach (var entry in entries)
        {
            var entity = (Entity)entry.Entity;

            if (entry.State == EntityState.Added)
                entity.SetCreatedAt(now);

            entity.SetUpdatedAt(now);
        }
    }
}
```

---

## 3. Estratégias de despacho de Domain Events

Há duas estratégias. **Antes** ou **depois** do `SaveChanges`. Cada uma tem trade-off:

### Despachar **ANTES** do SaveChanges (recomendado por padrão)

- Os handlers podem **alterar outros agregados** na mesma transação.
- Útil quando vários agregados precisam reagir e ainda manter consistência transacional.
- **Risco**: se o handler falhar, a transação inteira faz rollback — incluindo o agregado que disparou o evento.

### Despachar **DEPOIS** do SaveChanges (transactional outbox)

- Os handlers só rodam após o agregado estar salvo.
- Mais seguro: o agregado original é persistido mesmo se um handler falhar.
- Exige **outbox pattern**: gravar o evento em uma tabela na mesma transação, e um worker entrega depois.

> **Recomendação inicial**: comece com a estratégia ANTES (mais simples). Se a aplicação crescer e precisar de outbox de verdade (integração entre serviços, reentrega garantida), evolua.

---

## 4. Dispatcher de Domain Events

Está numa extension dentro de `ExtensionClass/`:

```csharp
// Infra/ExtensionClass/MediatorExtension.cs
using BillsToPay.Domain.SeedWork;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace BillsToPay.Infra.ExtensionClass;

public static class MediatorExtension
{
    public static async Task DispatchDomainEventsAsync(this IMediator mediator, DbContext ctx)
    {
        // Caça todas as Entity com eventos pendentes no ChangeTracker
        var entitiesWithEvents = ctx.ChangeTracker
            .Entries<Entity>()
            .Select(e => e.Entity)
            .Where(e => e.DomainEvents.Count > 0)
            .ToList();

        // Concatena e limpa antes de despachar (evita re-disparo se algum handler salvar de novo)
        var events = entitiesWithEvents
            .SelectMany(e => e.DomainEvents)
            .ToList();

        foreach (var entity in entitiesWithEvents)
            entity.ClearDomainEvents();

        // Despacha todos
        foreach (var domainEvent in events)
            await mediator.Publish(domainEvent);
    }
}
```

Pré-requisito: a `Entity` do Domain precisa ter:

```csharp
// Domain/SeedWork/Entity.cs (já existe — só pra referência)
public abstract class Entity
{
    private readonly List<IDomainEvent> _domainEvents = [];
    public IReadOnlyCollection<IDomainEvent> DomainEvents => _domainEvents.AsReadOnly();

    protected void AddDomainEvent(IDomainEvent e) => _domainEvents.Add(e);
    public void ClearDomainEvents() => _domainEvents.Clear();
    // ...
}
```

---

## 5. Esquema (schema) do banco

`HasDefaultSchema("bills_to_pay")` faz com que **todas** as tabelas deste contexto fiquem no schema `bills_to_pay`. Por que isso importa:

- **Múltiplos bounded contexts no mesmo banco**: cada um no seu schema, sem colisão de nomes.
- **Gestão de permissão**: você pode dar `GRANT` por schema para usuários distintos do banco.
- **Migrations isoladas**: cada contexto tem sua própria tabela `__EFMigrationsHistory` automaticamente quando combina com:

```csharp
options.UseNpgsql(connStr, npg => npg.MigrationsHistoryTable(
    "__EFMigrationsHistory", BillsToPayContext.DEFAULT_SCHEMA));
```

---

## 6. Configuração no DI (resumo — detalhe em [composition-root.md](composition-root.md))

```csharp
services.AddDbContext<BillsToPayContext>((sp, options) =>
{
    var connectionString = configuration.GetConnectionString("BillsToPay")!;
    options.UseNpgsql(connectionString, npg =>
    {
        npg.EnableRetryOnFailure(maxRetryCount: 5, maxRetryDelay: TimeSpan.FromSeconds(10), null);
        npg.MigrationsHistoryTable("__EFMigrationsHistory", BillsToPayContext.DEFAULT_SCHEMA);
    });
    options.UseExceptionProcessor();    // EntityFrameworkCore.Exceptions.PostgreSQL
});
```

---

## 7. O que **não** colocar no DbContext

- **Lógica de validação de domínio**: lugar é no Aggregate.
- **Filtro de tenant via `HasQueryFilter` global** sem teste comprovando que não dá pra bypassar: vira incidente de segurança. Prefira filtro explícito no Repository.
- **Invocação de serviços externos** (`StripeClient.Charge(...)` dentro de `SaveChanges`): é responsabilidade do handler do evento, não do DbContext.
- **Cache** ou **lock** próprio: se precisar, é responsabilidade da Application ou de um serviço externo (Redis).

---

## 8. Diagrama: fluxo do `SaveChangesAsync` (Mermaid)

```mermaid
sequenceDiagram
    participant H as Handler<br/>(Application)
    participant R as IBillRepository
    participant U as IUnitOfWork<br/>(= DbContext)
    participant M as IMediator
    participant DH as DomainEventHandlers
    participant DB as PostgreSQL

    H->>R: InsertAsync(bill, ct)
    H->>U: SaveChangesAsync(ct)
    U->>U: ChangeTracker varre Entities<br/>com DomainEvents
    U->>M: Publish(BillScheduled)
    M->>DH: Handle(BillScheduled)
    DH-->>U: (pode alterar outros aggregates)
    U->>U: UpdateDatetimeEntities<br/>(CreatedAt/UpdatedAt)
    U->>DB: BEGIN TRANSACTION
    U->>DB: INSERT/UPDATE...
    U->>DB: COMMIT
    U-->>H: int (linhas afetadas)
```
