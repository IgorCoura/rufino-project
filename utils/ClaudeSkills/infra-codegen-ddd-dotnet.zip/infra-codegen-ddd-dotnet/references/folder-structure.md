# Folder Structure — Camada Infra

> Princípio fundamental: **separe por responsabilidade, não por agregado**. Não faça `Bill/` com tudo dentro. Faça `Repository/`, `Mapping/`, `Services/` e dentro de cada um você tem os arquivos de cada agregado/integração.

## Estrutura mínima

```
src/
├── BillsToPay.Domain/                  # já existe — só pra referência
│   ├── SeedWork/
│   │   ├── Entity.cs
│   │   ├── IAggregateRoot.cs
│   │   ├── IUnitOfWork.cs
│   │   ├── IRepository.cs
│   │   ├── IDomainEvent.cs
│   │   └── Enumeration.cs
│   ├── Bills/                           # agregado
│   │   ├── Bill.cs                      # raiz
│   │   ├── BillStatus.cs                # smart enum
│   │   ├── Money.cs                     # value object
│   │   ├── IBillRepository.cs           # interface no Domain!
│   │   └── Events/
│   │       └── BillScheduled.cs
│   └── Services/                        # contratos de serviços externos
│       ├── IBlobService.cs
│       ├── IDocumentSignatureService.cs
│       └── IPaymentService.cs
│
└── BillsToPay.Infra/                    # ← O que esta skill gera
    ├── BillsToPay.Infra.csproj
    ├── Context/
    │   └── BillsToPayContext.cs         # DbContext = IUnitOfWork
    ├── Repository/
    │   ├── Repository.cs                # genérico Repository<T>
    │   ├── BillRepository.cs            # : Repository<Bill>, IBillRepository
    │   └── RecurringBillRepository.cs
    ├── Mapping/
    │   ├── EntityMap.cs                 # base abstrata
    │   ├── BillMap.cs
    │   └── RecurringBillMap.cs
    ├── Migrations/
    │   ├── 20251108_InitialCreate.cs    # gerada pelo EF — NUNCA editar
    │   └── BillsToPayContextModelSnapshot.cs
    ├── Services/
    │   ├── S3BlobService.cs             # implementa IBlobService
    │   ├── ZapSignDocumentSignatureService.cs
    │   ├── StripePaymentService.cs
    │   └── Options/
    │       ├── S3Options.cs
    │       ├── ZapSignOptions.cs
    │       └── StripeOptions.cs
    ├── Idempotency/
    │   ├── RequestManager.cs            # registra request_id para "exactly once"
    │   ├── IdempotentRequestMap.cs
    │   └── IdempotentRequest.cs
    ├── Policies/
    │   └── HttpPolicyFactory.cs         # Polly: retry / timeout / circuit breaker
    ├── ExtensionClass/
    │   ├── MediatorExtension.cs         # dispatcher de Domain Events
    │   └── ServiceCollectionExtensions.cs   # AddInfraDependencies
    └── DataForTests/                    # opcional — seed de dev
        └── BillsSeed.cs
```

## Por que cada pasta

### `Context/`
Casa do `DbContext`. Em projetos pequenos só tem 1 arquivo. Não misture com Repository — o DbContext é a Unit of Work, é uma coisa.

### `Repository/`
Implementações concretas dos repositórios. Cada repositório por **agregado raiz**, não por tabela. Se `Bill` tem `Installment` como entidade interna, **não existe** `InstallmentRepository`.

### `Mapping/`
Configurações do EF Core (`IEntityTypeConfiguration<T>`). Uma classe por aggregate root. Se a raiz tem entidades internas, elas são configuradas dentro do mesmo arquivo via `OwnsMany` / `OwnsOne`.

### `Migrations/`
Gerada pelo EF Core. **Nunca editar manualmente após aplicada em ambiente compartilhado**. Se errou, gere uma nova migration corrigindo. Se ainda não foi aplicada em produção, pode regenerar (`dotnet ef migrations remove`).

### `Services/`
Adaptadores para o mundo externo. Cada arquivo implementa **uma interface do Domain** (`IBlobService`, `IPaymentService`). O nome do arquivo tem o **prefixo do fornecedor** (`S3BlobService`, `StripePaymentService`) — facilita trocar provider depois.

`Services/Options/` agrupa os POCOs de configuração (`S3Options`, `StripeOptions`) lidos de `appsettings.json`.

### `Idempotency/`
Registro de request_ids para garantir "exactly once" em commands HTTP. Tabela própria, fora do agregado de domínio.

### `Policies/`
Fábrica de políticas Polly. Centralizada porque várias integrações compartilham as mesmas políticas (retry padrão de 6 tentativas, timeout de 30s, etc).

### `ExtensionClass/`
Extensions internas da camada:
- `MediatorExtension` — caça `Entity` com `DomainEvents` e despacha via MediatR.
- `ServiceCollectionExtensions` — onde mora `AddInfraDependencies(this IServiceCollection s, IConfiguration cfg)`.

### `DataForTests/`
Opcional. Seed de dados para desenvolvimento local. **Não inclua em produção** — proteja com `if (env.IsDevelopment())`.

---

## O que **não** vai nessas pastas

- `Domain/` ou `Aggregates/` dentro da Infra — Domain é outro projeto.
- `DTOs/` — DTO é trabalho de Application/Query. Infra retorna agregado, ponto.
- `Mappers/` (de DTO para Aggregate) — também é Application.
- `Validators/` (FluentValidation de input do usuário) — Application.
- `Authorization/` — quem decide é a API; Infra só obtém token/claims.

---

## Convenção de nomes

- Classes terminadas em `Service` → adaptador de integração externa.
- Classes terminadas em `Repository` → repositório de agregado.
- Classes terminadas em `Map` → configuração EF.
- Classes terminadas em `Options` → POCO de configuração.
- Classes terminadas em `Factory` → criadores de objetos com lógica não-trivial.

---

## Diagrama de dependências entre pastas (Mermaid)

```mermaid
flowchart TD
    Repo[Repository/]
    Map[Mapping/]
    Ctx[Context/]
    Svc[Services/]
    Pol[Policies/]
    Ide[Idempotency/]
    Ext[ExtensionClass/]
    Mig[Migrations/]

    Domain[(Domain Layer)]:::external

    Repo --> Ctx
    Map --> Ctx
    Mig --> Ctx
    Ide --> Ctx
    Svc --> Pol
    Ext --> Ctx
    Ctx --> Domain
    Repo --> Domain
    Svc --> Domain
    Map --> Domain
    Ide --> Domain

    classDef external fill:#fef3c7,stroke:#92400e
```

A seta significa "depende de". Note que **toda pasta da Infra depende do Domain**, mas o Domain não depende de nenhuma. Essa é a regra de dependência da Clean Architecture aplicada aqui.
