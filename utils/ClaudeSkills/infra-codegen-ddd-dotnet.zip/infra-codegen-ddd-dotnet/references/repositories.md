# Repository — Genérico + Específicos

> Regras inegociáveis: (1) **um repositório por aggregate root**, nunca por tabela. (2) Métodos retornam **agregado**, nunca DTO. (3) **Nunca** retorne `IQueryable<T>` — vaza EF para fora da Infra. (4) Receba `Expression<Func<T, bool>>` e `Func<IQueryable<T>, IIncludableQueryable<T, object>>` para o caller decidir filtros e includes sem ficar preso ao EF.

---

## 1. Interface base no Domain

A interface `IRepository<T>` mora **no Domain**, não na Infra. A Infra só implementa.

```csharp
// Domain/SeedWork/IRepository.cs
namespace BillsToPay.Domain.SeedWork;

using System.Linq.Expressions;

public interface IRepository<T> where T : Entity, IAggregateRoot
{
    IUnitOfWork UnitOfWork { get; }

    Task<T> InsertAsync(T model, CancellationToken ct = default);
    Task<T?> FirstOrDefaultAsync(Expression<Func<T, bool>> filter, CancellationToken ct = default);
    Task<IEnumerable<T>> GetDataAsync(
        Expression<Func<T, bool>>? filter = null,
        int? skip = null,
        int? take = null,
        CancellationToken ct = default);
    Task<bool> AnyAsync(Expression<Func<T, bool>> filter, CancellationToken ct = default);
    void Update(T model);
    void Remove(T model);
}
```

Cada agregado tem **sua própria** interface, **estendendo** `IRepository<T>`:

```csharp
// Domain/Bills/IBillRepository.cs
namespace BillsToPay.Domain.Bills;

using BillsToPay.Domain.SeedWork;

public interface IBillRepository : IRepository<Bill>
{
    Task<Bill?> GetByIdWithInstallmentsAsync(BillId id, CancellationToken ct);
    Task<IEnumerable<Bill>> GetOverdueAsync(TenantId tenantId, DateOnly referenceDate, CancellationToken ct);
}
```

Os métodos extras **só existem se houver razão de domínio**. Não crie `GetByName`, `GetByCreatedAt` só por gerar.

---

## 2. Repositório genérico na Infra

```csharp
// Infra/Repository/Repository.cs
using BillsToPay.Domain.SeedWork;
using BillsToPay.Infra.Context;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query;
using System.Linq.Expressions;

namespace BillsToPay.Infra.Repository;

public class Repository<T> : IRepository<T> where T : Entity, IAggregateRoot
{
    protected readonly BillsToPayContext _ctx;
    protected readonly DbSet<T> _set;

    public Repository(BillsToPayContext ctx)
    {
        _ctx = ctx ?? throw new ArgumentNullException(nameof(ctx));
        _set = ctx.Set<T>();
    }

    public IUnitOfWork UnitOfWork => _ctx;

    public virtual async Task<T> InsertAsync(T model, CancellationToken ct = default)
    {
        var entry = await _set.AddAsync(model, ct);
        return entry.Entity;
    }

    public virtual Task<T?> FirstOrDefaultAsync(
        Expression<Func<T, bool>> filter,
        CancellationToken ct = default)
        => _set.AsTracking().FirstOrDefaultAsync(filter, ct);

    /// <summary>
    /// Versão com include — caller passa expressão de include sem expor IQueryable.
    /// </summary>
    public virtual Task<T?> FirstOrDefaultAsync(
        Expression<Func<T, bool>> filter,
        Func<IQueryable<T>, IIncludableQueryable<T, object>>? include,
        CancellationToken ct = default)
    {
        IQueryable<T> query = _set.AsTracking();
        if (include is not null) query = include(query);
        return query.FirstOrDefaultAsync(filter, ct);
    }

    public virtual async Task<IEnumerable<T>> GetDataAsync(
        Expression<Func<T, bool>>? filter = null,
        int? skip = null,
        int? take = null,
        CancellationToken ct = default)
    {
        IQueryable<T> query = _set.AsNoTracking();
        if (filter is not null) query = query.Where(filter);
        if (skip is not null) query = query.Skip(skip.Value);
        if (take is not null) query = query.Take(take.Value);
        return await query.ToListAsync(ct);
    }

    public virtual Task<bool> AnyAsync(
        Expression<Func<T, bool>> filter,
        CancellationToken ct = default)
        => _set.AsNoTracking().AnyAsync(filter, ct);

    public virtual void Update(T model) => _set.Update(model);

    public virtual void Remove(T model) => _set.Remove(model);

    /// <summary>
    /// Acessa entidades já carregadas no ChangeTracker (sem ir ao banco).
    /// Útil quando o handler complexo modifica o agregado e precisa lê-lo
    /// novamente antes do SaveChanges.
    /// </summary>
    protected IEnumerable<T> Local => _set.Local;
}
```

### Decisões de design (por que está assim)

- **`AsTracking()` em writes** — você vai modificar o agregado e o EF precisa rastrear.
- **`AsNoTracking()` em reads** — mais rápido e evita memory leak em loops longos.
- **`virtual`** em todos os métodos — repositórios específicos podem sobrescrever quando precisarem.
- **Sem `IQueryable` exposto** — qualquer método externo recebe expressões e retorna `T` ou `IEnumerable<T>`. Se o caller quiser paginação inteligente, oferece `skip` e `take`.

---

## 3. Repositório específico

```csharp
// Infra/Repository/BillRepository.cs
using BillsToPay.Domain.Bills;
using BillsToPay.Infra.Context;
using Microsoft.EntityFrameworkCore;

namespace BillsToPay.Infra.Repository;

public class BillRepository : Repository<Bill>, IBillRepository
{
    public BillRepository(BillsToPayContext ctx) : base(ctx) { }

    public Task<Bill?> GetByIdWithInstallmentsAsync(BillId id, CancellationToken ct)
        => _set.AsTracking()
               .Include(b => b.Installments)
               .FirstOrDefaultAsync(b => b.Id == id, ct);

    public async Task<IEnumerable<Bill>> GetOverdueAsync(
        TenantId tenantId,
        DateOnly referenceDate,
        CancellationToken ct)
    {
        return await _set.AsNoTracking()
            .Where(b => b.TenantId == tenantId
                     && b.Status == BillStatus.Pending
                     && b.DueDate < referenceDate)
            .ToListAsync(ct);
    }
}
```

**Observação importante**: o método `GetByIdWithInstallmentsAsync` carrega o agregado **completo** (com todas as suas Installments). Em DDD, o repositório retorna **aggregates inteiros, não pedaços**. Se você precisa só de uma Installment isoladamente, ou (a) modela como agregado próprio, ou (b) reconsidere o que está fazendo: query de leitura otimizada é trabalho de read model/CQRS, não do repositório de escrita.

---

## 4. Multi-tenancy explícita

Se o sistema é multi-tenant, **todo método** do repositório aplica filtro de tenant. Não confie em `HasQueryFilter` global silencioso.

```csharp
// Infra/Repository/BillRepository.cs (versão multi-tenant)
public class BillRepository : Repository<Bill>, IBillRepository
{
    private readonly ICurrentTenantAccessor _currentTenant;

    public BillRepository(BillsToPayContext ctx, ICurrentTenantAccessor currentTenant)
        : base(ctx)
    {
        _currentTenant = currentTenant;
    }

    public async Task<Bill?> GetByIdAsync(BillId id, CancellationToken ct)
    {
        var tenantId = _currentTenant.Id;
        return await _set.AsTracking()
            .FirstOrDefaultAsync(b => b.Id == id && b.TenantId == tenantId, ct);
    }
    // ...
}
```

**`ICurrentTenantAccessor`** é uma interface da Application (ou do SeedWork) — a Infra implementa lendo do `HttpContext`. Ver [composition-root.md](composition-root.md).

---

## 5. Por que **não** retornar `IQueryable<T>`?

Tentação clássica:

```csharp
// ANTI-PADRÃO — não faça
public IQueryable<Bill> Query() => _set.AsNoTracking();
```

Problemas:

1. **Vaza EF para a Application**: o Handler agora pode escrever `query.Include(...).Where(...).Select(...).ToList()` — virou autor da query, e a fronteira da camada se desfez.
2. **Performance imprevisível**: ninguém sabe quais queries SQL serão geradas. Você acha que está fazendo `WHERE`, mas o Handler adicionou `Include` que multiplicou linhas.
3. **Dificulta troca de ORM**: o dia que você quer trocar EF Core por Dapper, encontra `IQueryable` espalhado pela Application.
4. **Quebra encapsulamento do agregado**: `query.Select(b => b.Installments.Count)` permite o caller bisbilhotar a estrutura interna do agregado.

**Solução correta**: o repositório expõe métodos com **intenção de domínio**:

```csharp
Task<int> CountOverdueAsync(TenantId tenantId, CancellationToken ct);
Task<IEnumerable<Bill>> GetByStatusAsync(BillStatus status, int skip, int take, CancellationToken ct);
```

---

## 6. Quando você precisa de query muito complexa (CQRS sem cerimônia)

Se você está montando um dashboard com 12 colunas, joins, agregações — isso **não é** trabalho do repositório de escrita. É um **read model**. Crie uma classe de Query separada, na Application ou na Infra:

```csharp
// Infra/Queries/BillsDashboardQuery.cs
public class BillsDashboardQuery : IBillsDashboardQuery
{
    private readonly IDbContextFactory<BillsToPayContext> _factory;

    public BillsDashboardQuery(IDbContextFactory<BillsToPayContext> factory)
    {
        _factory = factory;
    }

    public async Task<DashboardDto> GetAsync(TenantId tenantId, CancellationToken ct)
    {
        await using var ctx = await _factory.CreateDbContextAsync(ct);
        return await ctx.Bills.AsNoTracking()
            .Where(b => b.TenantId == tenantId)
            .GroupBy(b => b.Status)
            .Select(g => new DashboardLineDto(g.Key, g.Count(), g.Sum(b => b.Amount)))
            .ToListAsync(ct)
            // monta o DashboardDto aqui
            ;
    }
}
```

A Query retorna **DTO**, não agregado. Vive separada do `Repository` justamente por ter padrão diferente: read-only, projeção, performance.

> Regra prática: se a query retorna agregado e modifica → `Repository`. Se retorna DTO e só lê → `Query`.

---

## 7. Diagrama de classes (Mermaid)

```mermaid
classDiagram
    class IUnitOfWork {
        <<interface>>
        +SaveChangesAsync(ct) Task~int~
    }

    class IRepository~T~ {
        <<interface>>
        +UnitOfWork: IUnitOfWork
        +InsertAsync(T, ct) Task~T~
        +FirstOrDefaultAsync(filter, ct) Task~T?~
        +GetDataAsync(filter, skip, take, ct) Task~IEnumerable~T~~
        +AnyAsync(filter, ct) Task~bool~
        +Update(T) void
        +Remove(T) void
    }

    class IBillRepository {
        <<interface>>
        +GetByIdWithInstallmentsAsync(id, ct) Task~Bill?~
        +GetOverdueAsync(tenantId, date, ct) Task~IEnumerable~Bill~~
    }

    class Repository~T~ {
        #_ctx: BillsToPayContext
        #_set: DbSet~T~
        +UnitOfWork: IUnitOfWork
        +InsertAsync(...) Task~T~
        +FirstOrDefaultAsync(...) Task~T?~
        +GetDataAsync(...) Task~IEnumerable~T~~
        +AnyAsync(...) Task~bool~
        +Update(T) void
        +Remove(T) void
        #Local: IEnumerable~T~
    }

    class BillRepository {
        +GetByIdWithInstallmentsAsync(...) Task~Bill?~
        +GetOverdueAsync(...) Task~IEnumerable~Bill~~
    }

    class BillsToPayContext {
        <<DbContext>>
        +Bills: DbSet~Bill~
        +SaveChangesAsync(ct) Task~int~
    }

    IRepository~T~ ..|> IUnitOfWork : exposes via property
    IBillRepository --|> IRepository~T~
    Repository~T~ ..|> IRepository~T~
    BillRepository --|> Repository~T~
    BillRepository ..|> IBillRepository
    Repository~T~ --> BillsToPayContext : uses
    BillsToPayContext ..|> IUnitOfWork
```

---

## 8. Checklist do repositório

- [ ] Interface (`IXxxRepository`) está no Domain, junto com o agregado.
- [ ] Implementação herda de `Repository<T>` e adiciona apenas métodos com intenção de domínio.
- [ ] Nenhum método retorna `IQueryable<T>`.
- [ ] `AsTracking()` em writes; `AsNoTracking()` em reads.
- [ ] Todos os métodos têm `CancellationToken`.
- [ ] Multi-tenant: filtro de `TenantId` aplicado **explicitamente** em todos os métodos.
- [ ] Repositório retorna agregado, não DTO.
- [ ] `Include` para carregar entidades internas do agregado quando necessário (não para outros agregados).
- [ ] Não há lógica de domínio no repositório (validação, regra de negócio).
