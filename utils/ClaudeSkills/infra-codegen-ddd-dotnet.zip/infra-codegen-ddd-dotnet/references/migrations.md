# Migrations — Regras Inegociáveis

> Migration mal-feita = downtime, perda de dados, rollback impossível. As regras abaixo não são burocracia, são autodefesa.

---

## 1. Regra de ouro: **migration só via comando `dotnet ef migrations add`**

**Nunca** crie um arquivo de migration manualmente. **Nunca** edite uma migration depois de aplicada em ambiente compartilhado (staging, prod). Se você precisa "consertar" uma migration aplicada, você precisa de **outra migration** que conserta.

Comando padrão:

```bash
dotnet ef migrations add NomeDescritivoDaMigration \
  --project src/BillsToPay.Infra \
  --startup-project src/BillsToPay.Api \
  --context BillsToPayContext \
  --output-dir Migrations
```

**Se há múltiplos contextos** na mesma solution, sempre passe `--context`.

---

## 2. Naming — descritivo, no infinitivo

| Bom | Ruim |
|---|---|
| `AddBillsTable` | `Migration1` |
| `AddInstallmentsToBills` | `FixStuff` |
| `RenameSupplierColumnToVendor` | `UpdateMigration` |
| `AddIndexOnBillsDueDate` | `IndexMigration` |
| `MakeBillNumberUnique` | `Update2` |

Quando alguém olha o histórico de migrations daqui a 6 meses, deve entender o que aconteceu sem abrir o código.

---

## 3. Aplicar migration

**Em desenvolvimento**:

```bash
dotnet ef database update \
  --project src/BillsToPay.Infra \
  --startup-project src/BillsToPay.Api \
  --context BillsToPayContext
```

Ou no startup da app (em dev apenas — ver [connection-strategy.md](connection-strategy.md)).

**Em produção**: pipeline de deploy roda `database update` num **job dedicado**, **antes** de subir a versão nova da app. Nunca no startup da app de produção.

---

## 4. Reverter migration

```bash
# Reverte para o estado da migration anterior
dotnet ef database update PreviousMigrationName --project ...

# Remove a última migration NÃO aplicada
dotnet ef migrations remove --project ...
```

> **`migrations remove`** só funciona se a migration **não foi aplicada** em nenhum banco rastreado. Se já foi aplicada em dev e você precisa desfazer: `database update PreviousMigrationName` primeiro, **depois** `migrations remove`.

---

## 5. Migration com perda de dados — sempre revisar

EF Core **avisa** quando uma migration vai perder dados (renomear coluna em alguns providers, alterar tipo incompatível, deletar coluna). Quando isso acontece, ele gera código com `migrationBuilder.AlterColumn(...)` que pode falhar em runtime.

**Sempre revise** o `.cs` gerado. Para casos delicados, separe em duas migrations:

1. **Migration N**: cria nova coluna, **copia dados** da antiga, marca antiga como nullable.
2. **Deploy + warm-up**: aplica e aguarda nova versão funcionar.
3. **Migration N+1** (após deploy estável): remove coluna antiga.

Esse padrão é o **expand-contract** e evita downtime em rolling deployments.

---

## 6. SQL bruto numa migration — quando precisa

Algumas operações o EF não gera nativamente:
- Trigger / function do PostgreSQL.
- Recriação de índice CONCURRENTLY (sem lock de tabela).
- Backfill de dados de uma coluna nova baseado em outra.

```csharp
// Migrations/20251108_BackfillBillNumber.cs
protected override void Up(MigrationBuilder migrationBuilder)
{
    migrationBuilder.Sql(@"
        UPDATE bills_to_pay.bills
        SET number = subquery.row_num
        FROM (
            SELECT id, ROW_NUMBER() OVER (PARTITION BY tenant_id ORDER BY created_at) AS row_num
            FROM bills_to_pay.bills
        ) subquery
        WHERE bills.id = subquery.id;
    ");
}

protected override void Down(MigrationBuilder migrationBuilder)
{
    migrationBuilder.Sql("UPDATE bills_to_pay.bills SET number = 0;");
}
```

**Sempre** escreva `Down` que faz sentido. Mesmo que você nunca rode em produção, em dev você reverte e aplica de novo o tempo todo — `Down` quebrado quebra teu fluxo.

---

## 7. Migration de produção: lock de tabela é inimigo

Operações que travam tabela em PostgreSQL:
- `ALTER TABLE ... ADD COLUMN ... NOT NULL DEFAULT ...` (escreve linha por linha — em tabela grande pode demorar minutos).
- `CREATE INDEX` sem `CONCURRENTLY`.
- `ALTER TABLE ... ALTER COLUMN type` quando tipo muda fisicamente.

Em tabela com muitos dados, o lock derruba a aplicação. Estratégia:

**Adicionar coluna NOT NULL com default em produção**:

```sql
-- Errado (lock longo):
ALTER TABLE bills ADD COLUMN status_v2 INT NOT NULL DEFAULT 0;

-- Certo (3 passos, sem lock longo):
-- 1. Adiciona nullable (rápido)
ALTER TABLE bills ADD COLUMN status_v2 INT;

-- 2. Backfill em batches (background)
UPDATE bills SET status_v2 = 0 WHERE status_v2 IS NULL AND id IN (...) -- batch

-- 3. Marca NOT NULL (rápido se 100% backfilled)
ALTER TABLE bills ALTER COLUMN status_v2 SET NOT NULL;
ALTER TABLE bills ALTER COLUMN status_v2 SET DEFAULT 0;
```

EF Core **não** faz isso sozinho. Em tabela grande, edite a migration ou separe em múltiplas migrations.

**Criar índice em tabela grande**:

```csharp
migrationBuilder.Sql("CREATE INDEX CONCURRENTLY idx_bills_due_date ON bills_to_pay.bills(due_date);");
```

> `CONCURRENTLY` no PostgreSQL não pode rodar dentro de transação — e migrations EF rodam dentro de transação por default. Solução: marca a migration com `[DbContext(TransactionalDdl = false)]` ou rode esse SQL fora do EF (script manual no pipeline).

---

## 8. Tabela `__EFMigrationsHistory` — não toque

EF rastreia migrations aplicadas nessa tabela. **Nunca** edite manualmente. Se precisar "fingir" que uma migration foi aplicada (porque você aplicou o SQL manualmente):

```bash
dotnet ef migrations script --idempotent
# revise o SQL e aplica manualmente
# depois marca no histórico:
INSERT INTO bills_to_pay."__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20251108_NomeDaMigration', '10.0.0');
```

Mas isso é **último recurso**. Prefira sempre `dotnet ef database update`.

---

## 9. Múltiplos `DbContext` — múltiplas pastas de Migrations

Cada `DbContext` tem sua própria pasta. Estrutura típica:

```
src/BillsToPay.Infra/
└── Migrations/
    └── BillsToPay/        # contexto BillsToPay
        ├── 20251108_InitialCreate.cs
        └── BillsToPayContextModelSnapshot.cs

src/Suppliers.Infra/
└── Migrations/
    └── Suppliers/         # contexto Suppliers
        ├── 20251108_InitialCreate.cs
        └── SuppliersContextModelSnapshot.cs
```

Comando especifica `--context` e `--output-dir`:

```bash
dotnet ef migrations add InitialCreate \
  --project src/BillsToPay.Infra \
  --context BillsToPayContext \
  --output-dir Migrations/BillsToPay
```

---

## 10. Workflow recomendado (passo a passo)

1. **Modele a entidade no Domain** (ou adicione propriedade nova).
2. **Atualize o `Map`** (ou crie um novo na pasta `Mapping/`).
3. **Compile**: `dotnet build`. Se erro, corrige.
4. **Gere a migration**: `dotnet ef migrations add NomeDescritivo ...`.
5. **Revise o `.cs` gerado** — confirme que faz o que você espera.
6. **Aplica em dev**: `dotnet ef database update ...`.
7. **Testa** que a aplicação funciona com a nova estrutura.
8. **Commit**: o `.cs` da migration **e** o `ContextModelSnapshot.cs` (ambos vão pro git).
9. **Em produção**: pipeline aplica via `database update` antes de subir nova app.

---

## 11. Anti-padrões para recusar

- **Editar migration aplicada**: gere outra.
- **Deletar migration aplicada do disco**: `__EFMigrationsHistory` ainda referencia. Você quebra `database update` futuro.
- **Migration "fix-it-all"** com 30 alterações sem relação: separe.
- **Migration sem `Down`**: você nunca vai reverter em dev?
- **`migrationBuilder.Sql` com lógica de negócio**: lógica fica no Domain. Migration é estrutura/dados, não regra.
- **Aplicar migration em produção via app startup**: corrida entre instâncias. Faça em job dedicado.
- **Modificar `__EFMigrationsHistory` manualmente**: último recurso.

---

## 12. Checklist antes de gerar migration

- [ ] Domain compilou.
- [ ] Map atualizado.
- [ ] Nome da migration é descritivo no infinitivo.
- [ ] Revisei o `.cs` gerado e ele faz o que espero.
- [ ] `Down()` está consistente.
- [ ] Se tem operação cara (índice em tabela grande, ALTER COLUMN), considerei `CONCURRENTLY` ou expand-contract.
- [ ] Se tem perda de dados, separei em expand → backfill → contract.
- [ ] Snapshot atualizado e commitado junto.

---

## 13. Diagrama: vida de uma migration (Mermaid)

```mermaid
flowchart TD
    A[Mudança no Domain<br/>ou no Map] --> B[dotnet ef migrations add NomeX]
    B --> C{Migration<br/>gerada}
    C --> D[Revisar .cs]
    D --> E{OK?}
    E -- Sim --> F[dotnet ef database update<br/>em dev]
    E -- Não --> G[dotnet ef migrations remove]
    G --> A
    F --> H[Testes locais]
    H --> I{Passou?}
    I -- Sim --> J[Commit migration<br/>+ snapshot]
    I -- Não --> G
    J --> K[Pipeline em produção:<br/>job aplica antes de deploy]
    K --> L[Deploy nova app]
    L --> M[Health check OK]

    style G fill:#fee2e2,stroke:#991b1b
    style M fill:#d1fae5,stroke:#065f46
```
