# Multi-Tenancy — Explícita, Não Mágica

> Multi-tenancy é uma das fontes mais frequentes de incidente de segurança em SaaS. **Um bug de filtro = vazamento de dados entre clientes**. Por isso a regra é: **filtro de `TenantId` é explícito em todo método de repositório**, nunca implícito via `HasQueryFilter` global sem teste cobrindo.

---

## 1. Decisão arquitetural: como isolar tenants?

Três modelos clássicos, do mais isolado pro menos isolado:

| Modelo | Isolamento | Custo | Quando usar |
|---|---|---|---|
| **Database por tenant** | Total (banco separado) | Alto (operação, conexões, backups) | Setor regulado (saúde, gov), tenants enterprise |
| **Schema por tenant** | Médio (schemas separados, mesmo banco) | Médio | Tenants médios; precisa de DDL dinâmico |
| **Shared database, shared schema (`TenantId` em toda tabela)** | Lógico (filtro em todo query) | Baixo | SaaS típico — **default para PMEs** |

A skill assume **shared database, shared schema** com `TenantId` em todas as tabelas de domínio. É a opção mais comum em SaaS B2B early-stage.

---

## 2. Modelagem do `TenantId`

```csharp
// Domain/SeedWork/TenantId.cs (no SeedWork porque é compartilhado entre todos os agregados)
public readonly record struct TenantId(Guid Value)
{
    public static TenantId Empty => new(Guid.Empty);
    public override string ToString() => Value.ToString();
}
```

Toda raiz de agregado tem `TenantId`:

```csharp
public class Bill : Entity, IAggregateRoot
{
    public TenantId TenantId { get; private set; }
    // ...

    private Bill() { }   // EF

    public static Bill Schedule(TenantId tenantId, /* outros params */)
    {
        var bill = new Bill { TenantId = tenantId, /* ... */ };
        // ...
        return bill;
    }
}
```

**Por que no construtor/factory e não setado depois?** Porque o `TenantId` é parte da identidade do agregado — ele nasce pertencendo a um tenant e morre pertencendo a esse tenant. Não há cenário válido de "transferir" um agregado entre tenants.

---

## 3. `ICurrentTenantAccessor` — quem é o tenant atual?

Interface da Application:

```csharp
// Application/Common/ICurrentTenantAccessor.cs
public interface ICurrentTenantAccessor
{
    TenantId Id { get; }
}
```

Implementação na Infra (lendo do JWT ou header):

```csharp
// Infra/Services/HttpCurrentTenantAccessor.cs
public class HttpCurrentTenantAccessor : ICurrentTenantAccessor
{
    private readonly IHttpContextAccessor _http;

    public HttpCurrentTenantAccessor(IHttpContextAccessor http) => _http = http;

    public TenantId Id
    {
        get
        {
            var claim = _http.HttpContext?.User.FindFirst("tenant_id")?.Value
                ?? throw new UnauthorizedAccessException(
                    "Request sem tenant_id. Verifique a autenticação.");

            if (!Guid.TryParse(claim, out var guid))
                throw new InvalidOperationException(
                    $"tenant_id inválido no token: {claim}");

            return new TenantId(guid);
        }
    }
}
```

> **Importante**: lance exceção **agressivamente** se não houver tenant_id. Não retorne `Empty` ou `null` "pra não quebrar" — é melhor a request falhar com 401 do que processar como se fosse algum tenant especial.

---

## 4. Filtro explícito em todo repositório

```csharp
public class BillRepository : Repository<Bill>, IBillRepository
{
    private readonly ICurrentTenantAccessor _tenant;

    public BillRepository(BillsToPayContext ctx, ICurrentTenantAccessor tenant) : base(ctx)
    {
        _tenant = tenant;
    }

    public async Task<Bill?> GetByIdAsync(BillId id, CancellationToken ct)
    {
        var tenantId = _tenant.Id;   // dispara exception se não houver
        return await _set.AsTracking()
            .FirstOrDefaultAsync(b => b.Id == id && b.TenantId == tenantId, ct);
    }

    public async Task<IEnumerable<Bill>> GetOverdueAsync(DateOnly referenceDate, CancellationToken ct)
    {
        var tenantId = _tenant.Id;
        return await _set.AsNoTracking()
            .Where(b => b.TenantId == tenantId
                     && b.Status == BillStatus.Pending
                     && b.DueDate < referenceDate)
            .ToListAsync(ct);
    }

    // Sobrescreve métodos genéricos para forçar filtro
    public override Task<Bill?> FirstOrDefaultAsync(
        Expression<Func<Bill, bool>> filter,
        CancellationToken ct = default)
    {
        var tenantId = _tenant.Id;

        // Combina o filtro do caller com o filtro de tenant
        var tenantFilter = (Expression<Func<Bill, bool>>)(b => b.TenantId == tenantId);
        return _set.AsTracking()
            .Where(tenantFilter)
            .FirstOrDefaultAsync(filter, ct);
    }
}
```

> **Por que sobrescrever os genéricos?** Porque se um Handler novato chamar `_billRepository.FirstOrDefaultAsync(b => b.Status == Pending)` sem se preocupar com tenant, sem o override ele consultaria **todos** os tenants. Sobrescrever garante que o filtro de tenant **sempre** está aplicado.

---

## 5. Inserção: validar consistência

Quando o Handler cria um agregado e insere, valide que o `TenantId` do agregado bate com o do contexto atual:

```csharp
public override async Task<Bill> InsertAsync(Bill model, CancellationToken ct = default)
{
    var currentTenant = _tenant.Id;
    if (model.TenantId != currentTenant)
        throw new InvalidOperationException(
            $"Tentativa de inserir Bill no tenant {model.TenantId} pelo contexto do tenant {currentTenant}.");

    return await base.InsertAsync(model, ct);
}
```

Isso bloqueia bug do tipo "Application esqueceu de pegar o tenant atual e usou um hardcoded".

---

## 6. `HasQueryFilter` global — quando usar (com cautela)

EF Core suporta filtro global automático:

```csharp
modelBuilder.Entity<Bill>().HasQueryFilter(b => b.TenantId == _tenant.Id);
```

**Vantagem**: filtro aplicado mesmo se o dev esquecer.
**Desvantagens**:
1. Bypass acidental: `IgnoreQueryFilters()` desliga sem alarme.
2. Joins em outros agregados precisam do mesmo filtro lá — facil esquecer.
3. Difícil testar sem subir banco.
4. Migration de dados (job sem usuário) precisa desligar — vira gambiarra.

**Recomendação**: prefira **filtro explícito no repositório**. Se decidir usar `HasQueryFilter`, **escreva testes** que provam:
- Sem o filtro, a query retornaria N linhas (de outros tenants).
- Com o filtro, retorna só M linhas (do tenant atual).
- Que `IgnoreQueryFilters` não foi adicionado em lugar nenhum do código de produção.

---

## 7. Audit trail por tenant

Toda ação relevante deve registrar **quem fez** + **em qual tenant**:

```csharp
public class AuditLog : Entity
{
    public TenantId TenantId { get; private set; }
    public UserId UserId { get; private set; }
    public string Action { get; private set; }
    public string Entity { get; private set; }
    public Guid EntityId { get; private set; }
    public DateTime Timestamp { get; private set; }
}
```

E indexe por `(TenantId, Timestamp DESC)` para investigação posterior.

---

## 8. Job em background — sem `HttpContext`

Jobs do Hangfire/Quartz/timers não têm `HttpContext`. Logo `HttpCurrentTenantAccessor` não funciona. Soluções:

**Opção A — `BackgroundTenantAccessor`** ambiental:

```csharp
public class BackgroundTenantAccessor : ICurrentTenantAccessor
{
    private static readonly AsyncLocal<TenantId?> _current = new();

    public TenantId Id => _current.Value
        ?? throw new InvalidOperationException(
            "Background job sem tenant configurado. Use BackgroundTenantScope.");

    public static IDisposable BeginScope(TenantId tenantId)
    {
        var previous = _current.Value;
        _current.Value = tenantId;
        return new ScopeDisposer(() => _current.Value = previous);
    }

    private class ScopeDisposer : IDisposable
    {
        private readonly Action _onDispose;
        public ScopeDisposer(Action onDispose) => _onDispose = onDispose;
        public void Dispose() => _onDispose();
    }
}

// Uso no job:
public async Task ExecuteAsync(JobPayload payload, CancellationToken ct)
{
    using var _ = BackgroundTenantAccessor.BeginScope(payload.TenantId);
    // tudo que rodar aqui dentro vê o tenant correto
    await _someHandler.Handle(...);
}
```

**Opção B** — passar `TenantId` explicitamente como parâmetro em todo método (mais verboso, mais seguro).

---

## 9. Chave composta vs. UUID global

**Recomendação**: use **UUID global** (`Guid v7`) para Ids, não chave composta `(TenantId, Id)`. Razões:

- Ids únicos globalmente facilitam logs, rastreamento, debug.
- Você ainda **filtra** por `TenantId` em toda query — segurança igual.
- Chave composta complica relacionamentos e migrações.

Único caso onde chave composta vale: tenant tem **sequencial humano** (`Bill #1`, `#2`...) que reseta por tenant. Aí você tem `Bill.Id (UUID)` + `Bill.Number (int, sequencial por tenant)`.

---

## 10. Checklist da multi-tenancy

- [ ] `TenantId` value object no SeedWork.
- [ ] Toda raiz de agregado tem `TenantId` no construtor/factory.
- [ ] Toda tabela de domínio tem coluna `tenant_id` indexada.
- [ ] `ICurrentTenantAccessor` na Application.
- [ ] `HttpCurrentTenantAccessor` na Infra (lê do JWT).
- [ ] Lança exceção se não houver tenant_id (não retorna Empty).
- [ ] Toda método de repositório aplica `WHERE tenant_id = @current` **explicitamente**.
- [ ] Métodos genéricos sobrescritos no repositório específico para forçar filtro.
- [ ] `InsertAsync` valida que o `TenantId` do agregado bate com o atual.
- [ ] Jobs em background usam scope explícito (`BackgroundTenantAccessor.BeginScope`).
- [ ] Audit log registra `TenantId + UserId` em ações relevantes.
- [ ] Testes de segurança específicos: "request do tenant A não enxerga dados do tenant B".

---

## 11. Diagrama: fluxo de uma request multi-tenant (Mermaid)

```mermaid
sequenceDiagram
    participant Client as Client (tenant A)
    participant Auth as JWT Middleware
    participant API as API Endpoint
    participant H as Handler
    participant Repo as BillRepository
    participant TA as ICurrentTenantAccessor
    participant DB as PostgreSQL

    Client->>Auth: HTTP + Bearer JWT (tenant_id=A)
    Auth->>Auth: valida assinatura<br/>extrai claims
    Auth->>API: HttpContext.User com claim tenant_id=A
    API->>H: Handle(GetOverdueQuery)
    H->>Repo: GetOverdueAsync(ct)
    Repo->>TA: Id
    TA->>TA: lê HttpContext.User.FindFirst("tenant_id")
    TA-->>Repo: TenantId(A)
    Repo->>DB: SELECT ... WHERE tenant_id = A AND status = 'Pending' AND due_date < ...
    DB-->>Repo: rows do tenant A apenas
    Repo-->>H: IEnumerable<Bill>
    H-->>API: Result<DTO>
    API-->>Client: 200 OK
```
