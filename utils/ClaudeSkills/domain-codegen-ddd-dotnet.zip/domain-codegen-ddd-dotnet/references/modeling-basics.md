# Modelagem básica para escolher VO / Entity / Aggregate / Event

> Carregue este arquivo quando o usuário não tiver markdown pronto e estiver criando ou editando domínio direto. É um **guia de decisão**, não um tratado de DDD. Se já houver modelo claro, ignore este arquivo.

## VO ou Entity? — Casos comparativos

### Caso 1 — `Money`
- "R$ 100,00" tem identidade própria? Não. Duas notas de R$ 100 são intercambiáveis.
- Você modifica o valor "deste R$ 100" para virar R$ 150? Não — você cria outro `Money(150)`.
- → **Value Object.**

### Caso 2 — `Address`
- "Rua X, 123, SP" tem identidade própria? Depende. Como propriedade do Customer no momento ("o endereço dele agora é X"), é VO. Se você precisa rastrear `AddressId`, com histórico de quem morou nele, é Entity de outro domínio.
- → **Geralmente VO** quando é "snapshot de endereço" associado a um Customer.

### Caso 3 — `Customer`
- O `Customer` muda de nome, e-mail, endereço — e ainda é o mesmo Customer? Sim.
- Outros objetos referenciam `customerId`? Sim.
- → **Entity** (e provavelmente Aggregate Root próprio).

### Caso 4 — `BillItem`
- Faz sentido falar "este item específico do pedido"? Sim — você muda quantidade dele, sem trocar a referência.
- Tem identidade dentro do pedido? Sim (`Guid Id` herdado de `Entity`).
- Outros Aggregates referenciam o item? Não — só o Bill conhece os itens.
- → **Entity interna** do Aggregate `Bill`.

### Caso 5 — `EmailAddress`
- Você muda o "valor" desse email? Não — cria outro `EmailAddress`.
- Tem regra de validação (formato, presença de @)? Sim.
- → **VO** com validação no construtor.

### Heurística rápida
Se você fica confortável dizendo `objeto.Equals(outroObjeto)` retornando `true` quando os atributos são iguais → **VO**. Se "dois objetos com mesmos atributos mas IDs diferentes são entidades distintas" → **Entity**.

## Aggregate próprio ou parte de outro? — Casos

### Caso 1 — `Bill` e `BillItem`
- Invariante: total da Bill = soma dos `Items.Amount`. Quando muda quantidade de um item, total tem que ser recalculado **na mesma transação**.
- → Mesmo Aggregate. Root: `Bill`. `BillItem` é Entity interna.

### Caso 2 — `Bill` e `Supplier`
- Invariante entre eles? "Bill só pode existir se Supplier existir" — referencial, não transacional. Mudar o nome do Supplier afeta a Bill? Não diretamente; a Bill captura os dados relevantes no momento.
- → Aggregates **separados**. Bill referencia `SupplierId`, não `Supplier`.

### Caso 3 — `Customer` com lista de `Order`
- Invariante: "Customer não pode ter mais de N pedidos abertos."
- A janela de inconsistência (criar 6º enquanto outro está sendo criado) é tolerável? **Sim, na prática quase sempre.**
- → Aggregates **separados**. `Order` referencia `CustomerId`. Verificação acontece no momento da criação, com aceitação de janela rara.

### Caso 4 — `Pedido` e `Pagamento`
- Invariante: "Pedido pago não pode ser cancelado." Quando muda status de pagamento, pedido reflete isso?
- Se a regra é "pedido detecta o pagamento ao reagir a um evento" → Aggregates separados. Pagamento emite `PaymentReceived`; pedido reage.
- Se a regra é "muda os dois atomicamente sempre" → mesmo Aggregate (geralmente sinal de modelo errado, releia).

### Default: comece pequeno
Cada Entity é seu próprio Aggregate até que uma invariante real exija agrupamento. É **muito mais fácil** unir depois do que quebrar um Aggregate gigante.

## Quando emitir Domain Event? — Casos

### Caso 1 — `Bill.Approve()`
- Outro processo precisa saber? Sim: agendamento de pagamento, notificação, contabilização.
- → Emita `BillApproved`.

### Caso 2 — `Bill.RecalculateTotal()` (interno, após `AddItem`)
- Outro processo precisa saber? Não — é cálculo interno do Aggregate.
- → **Não emita.** É operação privada/auxiliar.

### Caso 3 — `Customer.UpdateAddress()`
- Outro processo precisa saber? Talvez (sistema de entrega, fiscal). Em geral, sim.
- → Emita `CustomerAddressChanged` (ou `CustomerRelocated` se for mudança maior).

### Caso 4 — `Bill.AddItem()`
- Outro processo precisa saber? Geralmente não — é manipulação dentro do mesmo Aggregate em estado `DRAFT`.
- → **Não emita.** Só emita se algum consumer realmente precisar (auditoria detalhada, por exemplo).

### Princípio
Eventos são **fatos significativos para o negócio**, não logs. Se você não consegue nomear um consumer ou um workflow que reage, provavelmente é estado interno.

## Invariantes — onde pôr

### Invariante de criação
Verifique no construtor / factory `Create`. Estado inválido nunca existe.

```csharp
public static Bill Create(BillId id, SupplierId supplierId, DueDate dueDate, DateTime occurredAt)
{
    // sem itens ainda; mas precisa ter SupplierId e DueDate válidos.
    // (validações dos VOs já garantem; aqui é só montagem.)
    var bill = new Bill(id) { ... };
    bill.AddDomainEvent(new BillCreated(...));
    return bill;
}
```

### Invariante de transição
Verifique antes de mudar estado.

```csharp
public void Approve(UserId approver, DateTime occurredAt)
{
    EnsureTransitionAllowed(BillStatus.Approved);
    Status = BillStatus.Approved;
    AddDomainEvent(new BillApproved(...));
}
```

### Invariante de consistência (cálculo derivado)
Recalcule em qualquer método que mexa nos componentes.

```csharp
public void AddItem(...) 
{ 
    EnsureCanModify();
    _items.Add(new BillItem(...));
    RecalculateTotal();   // mantém invariante: total = soma
}
```

### Invariante "isto nunca pode mudar depois de X"
Cheque o estado no início do método.

```csharp
private void EnsureCanModify()
{
    if (Status == BillStatus.Paid)
        throw BillErrors.CannotModifyPaidBill();
}
```

## Quando perguntar antes de codar

Pergunte (não invente) se:
- Não está claro se um conceito é VO ou Entity.
- Não está claro se duas coisas estão no mesmo Aggregate.
- O usuário menciona um "evento" mas não diz quem reage.
- Há regra mencionada vagamente ("tem que validar") sem critério explícito.
- Falta tipo de um atributo (é `decimal`? `int`? `string`?).
- Há máquina de estados implícita mas as transições não foram listadas.

Pergunta vale **uma rodada**: faça 1-3 perguntas objetivas, não 10. O usuário não está aqui para ser entrevistado.

## Quando NÃO perguntar (decida e siga)

- Decisões puramente de convenção (nomenclatura padrão, ordem de parâmetros, namespace).
- Validações óbvias que VOs já fazem (`string.IsNullOrWhiteSpace`, valor positivo onde claramente faz sentido).
- Tipos óbvios pelo contexto (`amount: dinheiro` → `Money`; `quando ocorreu` → `DateTime`).

Em dúvida entre perguntar e decidir: **decida com a melhor escolha disponível e sinalize a suposição no fim** ("assumi X — confirma?"). Isso é mais respeitoso do que travar a conversa.
