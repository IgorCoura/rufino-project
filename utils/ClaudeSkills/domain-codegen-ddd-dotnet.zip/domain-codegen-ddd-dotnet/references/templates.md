# Templates Prontos

> Bases canônicas do projeto. Todo código de domínio gerado pela skill segue **exatamente** estas classes base. Não substitua por records, não simplifique, não invente alternativas.

## Pasta `SeedWork`

As bases canônicas vivem **dentro de cada projeto de Bounded Context**, em `<BoundedContext>.Domain/SeedWork/`. Cada BC tem sua própria cópia (ou referencia um projeto compartilhado, se o usuário tiver definido essa convenção). A skill segue o padrão que o usuário já adota; **nunca cria projeto novo**.

```
<BoundedContext>.Domain/
└── SeedWork/
    ├── IEntityId.cs              ← contrato dos strongly-typed Ids
    ├── Entity.cs
    ├── AggregateRoot.cs
    ├── ValueObject.cs
    ├── Enumeration.cs
    ├── IDomainEvent.cs
    ├── DomainException.cs
    └── SeedWorkErrors.cs
```

## `IEntityId<TSelf>` (contrato dos strongly-typed Ids)

```csharp
// <BoundedContext>.Domain/SeedWork/IEntityId.cs
namespace AccountsPayable.Domain.SeedWork;

/// <summary>
/// Contrato comum para todos os strongly-typed Ids do domínio.
/// Cada Aggregate/Entity define seu próprio record struct (BillId, SupplierId, etc.)
/// que implementa este contrato. Permite que Entity<TId> construa novos Ids
/// sem reflexão.
/// </summary>
public interface IEntityId<TSelf> where TSelf : struct, IEntityId<TSelf>
{
    Guid Value { get; }
    static abstract TSelf New();
    static abstract TSelf From(Guid value);
    static abstract TSelf Empty { get; }
}
```

**Importante**:
- Requer **C# 11+** (static abstract members em interfaces). Se o projeto está em C# anterior, será necessário um workaround com factory delegada.
- Cada Id concreto (`BillId`, `SupplierId`, `UserId`, etc.) é `readonly record struct` implementando esta interface.
- `New()` gera ID novo (geralmente `Guid.CreateVersion7()` para ordenação temporal).
- `From(Guid)` reconstrói a partir de um Guid existente (útil para reidratação a partir de banco/serialização).
- `Empty` representa "id ainda não definido" (equivalente a `Guid.Empty`).

### Template de um Id concreto

```csharp
// <BoundedContext>.Domain/<Aggregate>/<Aggregate>Id.cs
namespace AccountsPayable.Domain.Bills;

using AccountsPayable.Domain.SeedWork;

public readonly record struct BillId(Guid Value) : IEntityId<BillId>
{
    public static BillId New() => new(Guid.CreateVersion7());
    public static BillId From(Guid value) => new(value);
    public static BillId Empty => new(Guid.Empty);
    public override string ToString() => Value.ToString();
}
```

**Pontos não-negociáveis**:
- `readonly record struct` — imutável, igualdade automática, leve.
- **Sem `implicit operator Guid`** — para extrair o `Guid`, use `id.Value` explicitamente. Isso preserva type-safety (passar `BillId` num lugar que espera `SupplierId` falha em compile time).
- `New()` usa `Guid.CreateVersion7()` (.NET 9+) para Ids ordenados temporalmente — melhora muito performance de inserção em índices clusterizados. Em .NET 8, troque por `Guid.NewGuid()` ou pelo package [`UUIDNext`](https://www.nuget.org/packages/UUIDNext).
- `From(Guid)` é o caminho **único** de reconstruir a partir de um `Guid` cru (vindo do banco, JSON, etc.).
- `Empty` é o estado "transiente" da Entity antes de receber identidade.

### Convenção de nome dos Ids

Para cada Entity (Aggregate Root **ou** Entity interna), exista um Id correspondente:

| Entity | Id |
|---|---|
| `Bill` (Aggregate Root) | `BillId` |
| `BillItem` (Entity interna) | `BillItemId` |
| `Supplier` (Aggregate Root) | `SupplierId` |
| `User` (Aggregate Root, em outro BC) | `UserId` |

Aggregates **referenciam outros Aggregates pelo Id strongly-typed** (`Bill.SupplierId` é do tipo `SupplierId`, não `Guid`). Isso evita o bug clássico de passar o Id errado.

## `Entity<TId>` (class abstrata generic)

```csharp
// <BoundedContext>.Domain/SeedWork/Entity.cs
namespace AccountsPayable.Domain.SeedWork;

public abstract class Entity<TId> where TId : struct, IEntityId<TId>
{
    private int? _requestedHashCode;
    private TId _Id;

    public DateTime CreatedAt { get; protected set; }
    public DateTime UpdatedAt { get; protected set; }

    /// <summary>
    /// Construtor sem id: gera automaticamente um novo Id via TId.New().
    /// Use em criação de novas entidades. EF Core também usa este construtor
    /// na rehidratação e depois sobrescreve o Id via reflexão.
    /// </summary>
    protected Entity()
    {
        _Id = TId.New();
    }

    /// <summary>
    /// Construtor com id: usado quando o id já existe (ex.: reidratação manual,
    /// reconstrução a partir de evento). NUNCA passe TId.Empty.
    /// </summary>
    protected Entity(TId id)
    {
        if (id.Equals(TId.Empty))
            throw SeedWorkErrors.EmptyId(this.GetType().Name);
        _Id = id;
    }

    public virtual TId Id
    {
        get
        {
            return _Id;
        }
        protected set
        {
            if (value.Equals(TId.Empty))
                throw SeedWorkErrors.EmptyId(this.GetType().Name);
            _Id = value;
        }
    }

    public bool IsTransient()
    {
        return this.Id.Equals(TId.Empty);
    }

    public override bool Equals(object? obj)
    {
        if (obj == null || obj is not Entity<TId>)
            return false;

        if (Object.ReferenceEquals(this, obj))
            return true;

        if (this.GetType() != obj.GetType())
            return false;

        Entity<TId> item = (Entity<TId>)obj;

        if (item.IsTransient() || this.IsTransient())
            return false;
        else
            return item.Id.Equals(this.Id);
    }

    public override int GetHashCode()
    {
        if (!IsTransient())
        {
            if (!_requestedHashCode.HasValue)
                _requestedHashCode = this.Id.GetHashCode() ^ 31;

            return _requestedHashCode.Value;
        }
        else
            return base.GetHashCode();
    }

    public static bool operator ==(Entity<TId> left, Entity<TId> right)
    {
        if (Object.Equals(left, null))
            return Object.Equals(right, null);
        else
            return left.Equals(right);
    }

    public static bool operator !=(Entity<TId> left, Entity<TId> right)
    {
        return !(left == right);
    }
}
```

**Importante**:
- Generic `TId` constrained a `struct, IEntityId<TId>` — garante que é um `record struct` implementando o contrato.
- Auto-geração via `TId.New()` (interface estática).
- Validação contra `TId.Empty` (em vez de `Guid.Empty`).
- Igualdade comparada via `id.Equals(other)` (e não `==`) porque Equals em record struct compara o valor interno corretamente.
- `Entity` **não** carrega Domain Events. Eventos vivem só no `AggregateRoot<TId>`.

## `AggregateRoot<TId>` (Entity generic + emissão de eventos)

```csharp
// <BoundedContext>.Domain/SeedWork/AggregateRoot.cs
namespace AccountsPayable.Domain.SeedWork;

public abstract class AggregateRoot<TId> : Entity<TId> where TId : struct, IEntityId<TId>
{
    private readonly List<IDomainEvent> _domainEvents = [];
    public IReadOnlyCollection<IDomainEvent> DomainEvents => _domainEvents.AsReadOnly();

    protected AggregateRoot() : base() { }

    protected AggregateRoot(TId id) : base(id) { }

    protected void AddDomainEvent(IDomainEvent eventItem)
    {
        _domainEvents.Add(eventItem);
    }

    protected void RemoveDomainEvent(IDomainEvent eventItem)
    {
        _domainEvents.Remove(eventItem);
    }

    public void ClearDomainEvents()
    {
        _domainEvents.Clear();
    }

    /// <summary>
    /// Drains the accumulated events. Called by the repository / unit of work
    /// after persisting the Aggregate, to forward to the Outbox.
    /// </summary>
    public IReadOnlyList<IDomainEvent> PullDomainEvents()
    {
        var events = _domainEvents.ToList();
        _domainEvents.Clear();
        return events;
    }
}
```

**Importante**:
- `AggregateRoot<TId>` herda de `Entity<TId>` com a mesma constraint `where TId : struct, IEntityId<TId>`.
- Apenas Aggregate Roots herdam de `AggregateRoot<TId>`. Entities internas herdam direto de `Entity<TId>`.
- Se uma Entity interna precisar "emitir" um evento, ela **chama um método na Root** que aciona `AddDomainEvent`. A Root é a única responsável por publicar fatos.
- `PullDomainEvents()` é o ponto de drenagem que o Repository/UoW usa após persistir.

## `ValueObject` (class abstrata, base canônica do projeto)

```csharp
// <BoundedContext>.Domain/SeedWork/ValueObject.cs
namespace <BoundedContext>.Domain.SeedWork;

using System.Reflection;

public abstract class ValueObject
{
    protected static bool EqualOperator(ValueObject left, ValueObject right)
    {
        if (left is null ^ right is null)
        {
            return false;
        }
        return left is null || left.Equals(right);
    }

    protected static bool NotEqualOperator(ValueObject left, ValueObject right)
    {
        return !(EqualOperator(left, right));
    }

    protected abstract IEnumerable<object?> GetEqualityComponents();

    public override string ToString()
    {
        Type t = this.GetType();

        PropertyInfo[] propInfos = t.GetProperties();
        var values = propInfos.Select(x =>
        {
            var value = x.GetValue(this);

            if (value != null && value.GetType().IsArray)
            {
                Object[]? array = value as Object[];
                value = "null";
                if (array != null)
                {
                    value = "[";
                    foreach (var ar in array)
                    {
                        value += ar.ToString();
                        if (ar != array.Last())
                            value += ",";
                    }
                    value += "]";
                }
            }

            value ??= "null";

            return $"{x.Name}:{value}";
        });

        var result = "{";
        foreach (var value in values)
        {
            result += value;
            if (value != values.Last())
                result += ",";
        }
        result += "}";
        return result;
    }

    public override bool Equals(object? obj)
    {
        if (obj == null)
            return false;
        try
        {
            var other = (ValueObject)obj;
            return this.GetEqualityComponents().SequenceEqual(other.GetEqualityComponents());
        }
        catch
        {
            return false;
        }
    }

    public override int GetHashCode()
    {
        return GetEqualityComponents()
            .Select(x => x != null ? x.GetHashCode() : 0)
            .Aggregate((x, y) => x ^ y);
    }

    public ValueObject GetCopy()
    {
        return this.MemberwiseClone() as ValueObject ?? throw new NullReferenceException();
    }
}
```

**Como herdar (template para qualquer VO)**:

```csharp
// <BoundedContext>.Domain/<Aggregate>/ValueObjects/Money.cs
namespace AccountsPayable.Domain.Bills.ValueObjects;

public sealed class Money : ValueObject
{
    private const string DEFAULT_CURRENCY = "BRL";

    public decimal Amount { get; }
    public string Currency { get; }

    public Money(decimal amount, string currency)
    {
        if (string.IsNullOrWhiteSpace(currency) || currency.Length != 3)
            throw MoneyErrors.InvalidCurrencyCode(currency ?? string.Empty);

        Amount = decimal.Round(amount, 2, MidpointRounding.ToEven);
        Currency = currency.ToUpperInvariant();
    }

    public static Money Zero(string currency) => new(0m, currency);

    public Money Add(Money other)
    {
        EnsureSameCurrency(other);
        return new Money(Amount + other.Amount, Currency);
    }

    public Money Subtract(Money other)
    {
        EnsureSameCurrency(other);
        return new Money(Amount - other.Amount, Currency);
    }

    private void EnsureSameCurrency(Money other)
    {
        if (Currency != other.Currency)
            throw MoneyErrors.CurrencyMismatch(Currency, other.Currency);
    }

    protected override IEnumerable<object?> GetEqualityComponents()
    {
        yield return Amount;
        yield return Currency;
    }
}
```

**Pontos não-negociáveis para todo VO**:
- `sealed class` herdando de `ValueObject` (nunca record).
- Construtor valida; lança erro via factory de erros (`MoneyErrors.X(...)`), não `throw new DomainException` direto.
- `GetEqualityComponents()` listando os campos que entram na igualdade — pode ser subset das propriedades.
- Métodos retornam **novos VOs** (imutável).
- Constantes `MAIÚSCULAS_COM_UNDERSCORE` no topo da classe.
- Sem dependência de infra (sem JSON, sem EF, sem nada).

## `Enumeration` (class abstrata, Smart Enum base canônica)

```csharp
// <BoundedContext>.Domain/SeedWork/Enumeration.cs
namespace <BoundedContext>.Domain.SeedWork;

using System.Reflection;

public abstract class Enumeration : IComparable
{
    public string Name { get; private set; }

    public int Id { get; private set; }

    protected Enumeration(int id, string name) => (Id, Name) = (id, name);

    public override string ToString() => Name;

    public static IEnumerable<T> GetAll<T>() where T : Enumeration =>
        typeof(T).GetFields(BindingFlags.Public |
                            BindingFlags.Static |
                            BindingFlags.DeclaredOnly)
                    .Select(f => f.GetValue(null))
                    .Cast<T>();

    public override bool Equals(object? obj)
    {
        if (obj is not Enumeration otherValue)
        {
            return false;
        }

        var typeMatches = GetType().Equals(obj.GetType());
        var valueMatches = Id.Equals(otherValue.Id);

        return typeMatches && valueMatches;
    }

    public override int GetHashCode() => Id.GetHashCode();

    public static int AbsoluteDifference(Enumeration firstValue, Enumeration secondValue)
    {
        var absoluteDifference = Math.Abs(firstValue.Id - secondValue.Id);
        return absoluteDifference;
    }

    public static T FromValue<T>(int value) where T : Enumeration
    {
        var matchingItem = Parse<T, int>(value, "value", item => item.Id == value);
        return matchingItem;
    }

    public static T? TryFromValue<T>(int value) where T : Enumeration
    {
        var matchingItem = TryParse<T, int>(item => item.Id == value);
        return matchingItem;
    }

    public static T FromDisplayName<T>(string displayName) where T : Enumeration
    {
        var matchingItem = Parse<T, string>(displayName, "display name", item => item.Name.Equals(displayName, StringComparison.CurrentCultureIgnoreCase));
        return matchingItem;
    }

    public static T? TryFromDisplayName<T>(string displayName) where T : Enumeration
    {
        var matchingItem = TryParse<T, string>(item => item.Name.Equals(displayName, StringComparison.CurrentCultureIgnoreCase));
        return matchingItem;
    }

    private static T Parse<T, K>(K value, string description, Func<T, bool> predicate) where T : Enumeration
    {
        var matchingItem = GetAll<T>().FirstOrDefault(predicate);

        return matchingItem ?? throw new InvalidOperationException($"'{value}' is not a valid {description} in {typeof(T)}");
    }

    private static T? TryParse<T, K>(Func<T, bool> predicate) where T : Enumeration
    {
        var matchingItem = GetAll<T>().FirstOrDefault(predicate);

        return matchingItem;
    }

    public int CompareTo(object? other) => Id.CompareTo(((Enumeration?)other)?.Id);
}
```

**Como herdar (template para qualquer Smart Enum com transições)**:

```csharp
// <BoundedContext>.Domain/<Aggregate>/Enumerations/BillStatus.cs
namespace AccountsPayable.Domain.Bills.Enumerations;

public sealed class BillStatus : Enumeration
{
    public static readonly BillStatus Draft = new(1, "DRAFT");
    public static readonly BillStatus AwaitingApproval = new(2, "AWAITING_APPROVAL");
    public static readonly BillStatus Approved = new(3, "APPROVED");
    public static readonly BillStatus Scheduled = new(4, "SCHEDULED");
    public static readonly BillStatus Paid = new(5, "PAID");
    public static readonly BillStatus Cancelled = new(6, "CANCELLED");
    public static readonly BillStatus Rejected = new(7, "REJECTED");

    private BillStatus(int id, string name) : base(id, name) { }

    public bool CanTransitionTo(BillStatus target)
    {
        return (Id, target.Id) switch
        {
            (1, 2) => true, // Draft -> AwaitingApproval
            (1, 6) => true, // Draft -> Cancelled
            (2, 3) => true, // AwaitingApproval -> Approved
            (2, 7) => true, // AwaitingApproval -> Rejected
            (2, 6) => true, // AwaitingApproval -> Cancelled
            (3, 4) => true, // Approved -> Scheduled
            (3, 6) => true, // Approved -> Cancelled
            (4, 5) => true, // Scheduled -> Paid
            _ => false
        };
    }
}
```

**Pontos não-negociáveis para todo Smart Enum**:
- `sealed class` herdando de `Enumeration` (nunca record, nunca enum nativo C#).
- Instâncias estáticas `public static readonly` com `MAIÚSCULAS_COM_UNDERSCORE`? **Não**: por convenção de Smart Enum, instâncias seguem `PascalCase` (são "nomes próprios" semanticamente, como `BillStatus.Draft`). Mas os **códigos** que elas carregam (`"DRAFT"`, `"AWAITING_APPROVAL"`) seguem MAIÚSCULAS.
- Construtor `private` — instâncias só são criadas pelos `static readonly` da própria classe.
- Lógica de transições/regras como métodos da Smart Enum, não em outras classes.

## `IDomainEvent`

```csharp
// <BoundedContext>.Domain/SeedWork/IDomainEvent.cs
namespace <BoundedContext>.Domain.SeedWork;

public interface IDomainEvent
{
    Guid EventId { get; }
    DateTime OccurredAt { get; }
}
```

Cada Domain Event concreto:

```csharp
// <BoundedContext>.Domain/<Aggregate>/Events/BillApproved.cs
namespace AccountsPayable.Domain.Bills.Events;

using AccountsPayable.Domain.SeedWork;
using AccountsPayable.Domain.Suppliers;
using AccountsPayable.Domain.Users;

public sealed record BillApproved(
    Guid EventId,
    BillId BillId,
    UserId ApprovedBy,
    decimal Amount,
    string Currency,
    DateTime OccurredAt) : IDomainEvent;
```

**Pontos**:
- `sealed record` (records são bons aqui — eventos são DTOs imutáveis sem comportamento, é o caso para o qual records foram desenhados).
- Implementa `IDomainEvent`.
- Nome no passado em inglês (`BillApproved`, `OrderPlaced`, `CustomerOnboarded`).
- **IDs strongly-typed no payload** (`BillId`, `UserId`) — consistência com o resto do domínio. Records struct serializam direto com System.Text.Json desde .NET 8 (precisam de `JsonConverter` customizado em alguns ORMs/serializadores; ver seção de Outbox).
- Carrega dados auto-suficientes — não use VOs ricos do domínio no payload, só identificadores e primitivos.
- `EventId = Guid.NewGuid()` no momento da emissão (este continua `Guid` puro — é metadata do evento, não identifica entity de domínio).

## `DomainException`

→ Padrão completo em `references/exception-pattern.md`. Resumo:

```csharp
// <BoundedContext>.Domain/SeedWork/DomainException.cs
namespace <BoundedContext>.Domain.SeedWork;

using System.Text.RegularExpressions;

public sealed class DomainException : Exception
{
    private static readonly Regex ID_PATTERN =
        new(@"^[A-Z]{3}(\.[A-Z]{3})?\d+$", RegexOptions.Compiled);

    public string Id { get; }
    public string MessageTemplate { get; }
    public IReadOnlyList<object> Parameters { get; }
    public string SourcePath { get; }

    public DomainException(
        string id,
        string messageTemplate,
        IReadOnlyList<object> parameters,
        string sourcePath)
        : base(BuildMessage(messageTemplate, parameters))
    {
        if (string.IsNullOrWhiteSpace(id))
            throw new ArgumentException("Id is required.", nameof(id));
        if (!ID_PATTERN.IsMatch(id))
            throw new ArgumentException(
                $"Id '{id}' does not match pattern XXX## or XXX.YYY##.", nameof(id));
        if (string.IsNullOrWhiteSpace(messageTemplate))
            throw new ArgumentException(
                "MessageTemplate is required.", nameof(messageTemplate));
        if (parameters is null)
            throw new ArgumentNullException(nameof(parameters));
        if (parameters.Any(p => p is null))
            throw new ArgumentException(
                "Parameters cannot contain null values.", nameof(parameters));
        if (string.IsNullOrWhiteSpace(sourcePath))
            throw new ArgumentException(
                "SourcePath is required.", nameof(sourcePath));

        Id = id;
        MessageTemplate = messageTemplate;
        Parameters = parameters;
        SourcePath = sourcePath;
    }

    private static string BuildMessage(string template, IReadOnlyList<object> parameters)
    {
        if (string.IsNullOrWhiteSpace(template))
            return template ?? string.Empty;
        if (parameters is null || parameters.Count == 0)
            return template;
        return string.Format(template, parameters.ToArray());
    }

    public override string ToString() =>
        $"[{Id}] {Message} | at {SourcePath}";
}
```

## Suporte a Outbox (referência — não é geração desta skill)

Quando o usuário pedir explicitamente, gere isto na **camada de infraestrutura**, não no domínio:

```csharp
// Infrastructure/Outbox/OutboxMessage.cs
namespace Project.Infrastructure.Outbox;

public sealed class OutboxMessage
{
    public Guid Id { get; private set; }
    public string EventType { get; private set; } = default!;
    public string Payload { get; private set; } = default!;
    public DateTime OccurredAt { get; private set; }
    public DateTime? ProcessedAt { get; private set; }
    public string? Error { get; private set; }
    public int RetryCount { get; private set; }

    private OutboxMessage() { }

    public static OutboxMessage From(IDomainEvent @event, string serializedPayload)
    {
        return new OutboxMessage
        {
            Id = @event.EventId,
            EventType = @event.GetType().FullName!,
            Payload = serializedPayload,
            OccurredAt = @event.OccurredAt,
            RetryCount = 0
        };
    }

    public void MarkProcessed(DateTime at)
    {
        ProcessedAt = at;
        Error = null;
    }

    public void MarkFailed(string error)
    {
        RetryCount++;
        Error = error;
    }
}
```

## Estrutura de pastas

**Cada Bounded Context é seu próprio projeto .NET.** O nome do projeto reflete o BC, com sufixo `.Domain`. Exemplos: `AccountsPayable.Domain`, `BillIngestion.Domain`, `PeopleManagement.Domain`.

A skill **não cria projetos novos** e **não inventa Bounded Contexts**. Quem decide quais BCs existem é o usuário (decisão estratégica). A skill apenas gera código **dentro** de um projeto de BC já existente, ou recomenda em qual projeto um Aggregate deve ser colocado quando o usuário diz qual BC ele pertence.

A camada `SeedWork` (bases canônicas) vive **dentro de cada projeto de BC** — ou em um projeto compartilhado (`Shared.Domain`) se o usuário tiver definido essa convenção. A skill segue o padrão que o usuário já adota; se não houver projeto compartilhado, replica o `SeedWork` em cada projeto de BC.

### Estrutura interna de um projeto de BC

```
<BoundedContext>.Domain/
├── SeedWork/
│   ├── IEntityId.cs                    ← contrato dos strongly-typed Ids
│   ├── Entity.cs                       ← Entity<TId> generic
│   ├── AggregateRoot.cs                ← AggregateRoot<TId> generic
│   ├── ValueObject.cs
│   ├── Enumeration.cs
│   ├── IDomainEvent.cs
│   ├── DomainException.cs
│   └── SeedWorkErrors.cs               ← erros do SeedWork — sigla SWK
├── <BoundedContext>Errors.cs           ← erros genéricos do BC, na raiz
├── Services/                           ← Domain Services (se houver), na raiz
│   ├── <Service1>Service.cs
│   ├── <Service1>Errors.cs
│   └── ...
└── <Aggregate>/
    ├── <Aggregate>.cs                  ← Aggregate Root (herda AggregateRoot<TId>)
    ├── <Aggregate>Id.cs                ← Strongly-typed Id (record struct)
    ├── <Aggregate>Errors.cs            ← Factory de erros do Aggregate
    ├── Entities/
    │   ├── <InternalEntity>.cs         ← herda Entity<TId>
    │   └── <InternalEntity>Id.cs       ← Id da Entity interna (record struct)
    ├── ValueObjects/
    │   └── <ValueObject>.cs            ← herda ValueObject
    ├── Enumerations/
    │   └── <SmartEnum>.cs              ← herda Enumeration
    └── Events/
        └── <DomainEvent>.cs            ← record implementando IDomainEvent
```

Note: **não há camada `<BoundedContext>/`** dentro do projeto. O projeto inteiro É o BC.

A pasta `Services/` é **opcional** — só existe quando há regras de negócio que envolvem múltiplos Aggregates (ver `references/domain-services.md`). Se todas as regras cabem em Aggregates, não há Services no projeto.

### Exemplo concreto

```
AccountsPayable.Domain/
├── SeedWork/
│   ├── IEntityId.cs
│   ├── Entity.cs
│   ├── AggregateRoot.cs
│   ├── ValueObject.cs
│   ├── Enumeration.cs
│   ├── IDomainEvent.cs
│   ├── DomainException.cs
│   └── SeedWorkErrors.cs
├── AccountsPayableErrors.cs            ← erros transversais do BC
├── Services/                           ← Domain Services (opcional)
│   ├── BillClassificationService.cs
│   └── BillClassificationErrors.cs
└── Bills/
    ├── Bill.cs                         ← AggregateRoot<BillId>
    ├── BillId.cs                       ← record struct : IEntityId<BillId>
    ├── BillErrors.cs
    ├── Entities/
    │   ├── BillItem.cs                 ← Entity<BillItemId>
    │   └── BillItemId.cs               ← record struct : IEntityId<BillItemId>
    ├── ValueObjects/
    │   ├── Money.cs                    ← ValueObject
    │   └── DueDate.cs                  ← ValueObject
    ├── Enumerations/
    │   └── BillStatus.cs               ← Enumeration
    └── Events/
        ├── BillCreated.cs
        ├── BillSubmittedForApproval.cs
        ├── BillApproved.cs
        ├── BillRejected.cs
        ├── BillScheduled.cs
        ├── BillPaid.cs
        └── BillCancelled.cs
```

### Solução com múltiplos BCs

Quando o sistema tem múltiplos BCs, cada um é um projeto irmão na mesma solução:

```
src/
├── AccountsPayable.Domain/             ← um BC
├── BillIngestion.Domain/               ← outro BC
├── ContractManagement.Domain/          ← outro BC
└── ...
```

**A skill nunca move código entre projetos automaticamente.** Se o usuário pedir "cria um Aggregate `Contract` no `AccountsPayable.Domain`" e isso parecer estar no BC errado, **pergunte** antes de gerar — pode ser intencional, pode ser engano.

## Checklist final por Aggregate gerado

Antes de entregar o código, verifique:

- [ ] Todo o código está em **inglês** (classes, propriedades, métodos, parâmetros, variáveis, namespaces, eventos)?
- [ ] Mensagens de erro em PT, demais textos em EN?
- [ ] **Constantes em `MAIÚSCULAS_COM_UNDERSCORE` e declaradas no topo da classe** (antes de campos, propriedades, construtor)?
- [ ] **Constantes de tamanho/limite que infra precisa replicar (MAX_LENGTH, MIN_LENGTH, MAX_VALUE, etc.) declaradas como `public const`** no VO/Entity que as valida, para que EF mapping leia do domínio (`.HasMaxLength(Name.MAX_LENGTH)`) em vez de duplicar o valor?
- [ ] **Constantes internas (defaults, thresholds comportamentais, prefixos de erro) declaradas como `private const`** — não vazam para fora do domínio.
- [ ] **Toda constante `public const MAX_LENGTH` (ou similar) tem validação correspondente no construtor do VO/Entity**, para evitar que a invariante seja violada e gere exceção de banco na infra?
- [ ] **Cada propriedade de Aggregate Root/Entity com regra de validação tem um setter `Set<PropertyName>` privado (ou `internal` em Entity interna) que valida e atribui**, sem atualizar `UpdatedAt` e sem emitir evento? **`Create`, `Rehydrate` e métodos de mutação reusam o setter**, nunca duplicam validação?
- [ ] **Métodos de mutação públicos têm nome de verbo de negócio** (`ChangeDescription`, `Reschedule`, `Approve`), não `SetXxx`? Setter promovido a `public` apenas quando o método público envolvente seria trivial (só repassa)?
- [ ] `sealed` no Aggregate Root e em cada VO/Smart Enum/Entity interna?
- [ ] Aggregate Root herda de `AggregateRoot<TId>` (com Id strongly-typed, não direto de `Entity`)?
- [ ] Entities internas herdam de `Entity<TId>` (com Id strongly-typed, sem eventos)?
- [ ] **Cada Entity (Aggregate Root e interna) tem seu `record struct <Entity>Id : IEntityId<<Entity>Id>` correspondente em arquivo próprio**?
- [ ] **Strongly-typed Ids sem `implicit operator`** — extração para `Guid` é via `id.Value` explícito?
- [ ] **Outros Aggregates referenciados pelo Id strongly-typed** (`SupplierId`, `UserId`), nunca por `Guid` solto?
- [ ] **Domain Events também usam Ids strongly-typed no payload** (`BillId`, `UserId`)?
- [ ] VOs herdam de `ValueObject` e implementam `GetEqualityComponents()`?
- [ ] Smart Enums herdam de `Enumeration` com instâncias `public static readonly`?
- [ ] Construtor da Aggregate Root `private` + factory `Create` estática?
- [ ] Construtor de Entities internas `internal` + criação só via método da Root?
- [ ] Todas as propriedades com `private set` ou `init` (nunca `public set`)?
- [ ] Coleções públicas usam `IReadOnlyCollection<T>` (ou `IReadOnlyList<T>` quando ordem importa) + `.AsReadOnly()` no campo privado `List<T>`? (NUNCA expor `List<T>`, `ICollection<T>`, `IList<T>` ou `T[]` em propriedade pública. NUNCA usar cast direto sem `.AsReadOnly()`.)
- [ ] Domain Events são `sealed record` implementando `IDomainEvent`?
- [ ] Eventos emitidos **só pela Aggregate Root** via `AddDomainEvent` (Entity interna chama método na Root, não emite direto)?
- [ ] Cada método público recebe `DateTime occurredAt` (sem `DateTime.UtcNow` inline)?
- [ ] Existe arquivo `<Aggregate>Errors.cs` com factory de erros, e nada lança `throw new DomainException(...)` direto?
- [ ] IDs de erro seguem `<BC>.<AGG>##` ou `<BC>##` e são únicos no arquivo?
- [ ] Mensagens de erro **não vazam** dado sensível (senhas, tokens, dados de outros tenants, IDs externos sigilosos)?
- [ ] Status com transições usa Smart Enum herdando de `Enumeration` com `CanTransitionTo`?
- [ ] Nenhuma referência a `Microsoft.EntityFrameworkCore`, `System.Text.Json`, `Newtonsoft.Json` no domínio?
- [ ] **Domain Services (se houver) ficam em `Services/` na raiz do projeto, são `sealed class` stateless, sem interface, sem async, sem dependência de infra?**
- [ ] **Domain Services não emitem eventos** — só recebem Aggregates como parâmetros e chamam métodos deles?
- [ ] **Domain Services têm factory de erros próprio** com prefixo `<BC>.<SVC>##`?
