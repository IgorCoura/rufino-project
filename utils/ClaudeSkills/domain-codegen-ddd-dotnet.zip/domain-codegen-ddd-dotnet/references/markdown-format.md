# Formato esperado do markdown de entrada

> Como interpretar o markdown que o usuário entrega. A skill **lê**, não inventa. Se algo está ambíguo, pergunte.

## Estrutura típica reconhecida

O usuário do projeto usa markdown com seções como as dos arquivos `01-bill-ingestion.md`, `02-expected-recurring-bills.md`, `03-expense-classification.md`. A skill deve reconhecer variações.

### Cabeçalhos comuns a procurar

A skill aceita variações; bata pelo significado, não literalmente:

| Seção semântica | Cabeçalhos prováveis |
|---|---|
| Aggregate Root | `## Aggregate: <Nome>`, `### Aggregate Root`, `### Aggregate <Nome>` |
| Identidade | `### Identifier`, dentro do Aggregate, ou inferido pelo nome (`<Aggregate>Id`) |
| Value Objects | `### Value Objects`, `## Value Objects`, `### VOs` |
| Entities internas | `### Entities`, `### Entidades internas` |
| Domain Events | `### Domain Events`, `### Eventos`, `## Events` |
| Invariantes | `### Invariantes`, `### Invariants`, `### Regras` |
| Comportamentos | `### Comportamentos`, `### Métodos`, `### Behavior`, `### Operações` |
| Estados/Transições | `### Estados`, `### Status`, `### Máquina de Estados`, `### Lifecycle` |
| Bounded Context | `# <Nome do BC>`, `## Contexto`, `## Bounded Context: <Nome>` |

## Padrões de descrição que a skill mapeia

### Value Object descrito assim:

```markdown
### Value Objects

- **Money**: { amount: decimal, currency: string ISO 3 letras }. Não pode ter currency vazio. Operações: add, subtract (mesma moeda).
- **DueDate**: { value: date }. Métodos: isOverdue(now), daysUntil(now).
```

→ Gere um arquivo por VO, com construtor que valida, props read-only, métodos como descritos.

### Entity interna descrita assim:

```markdown
### Entities

- **BillItem** (interna):
  - id: BillItemId
  - description: string (não vazio)
  - amount: Money
  - categoryCode: string
  - método interno: changeAmount(newAmount: Money)
```

→ Gere `BillItem : Entity<BillItemId>` com construtor `internal`, props com `private set`, método `internal void ChangeAmount(...)`. Lembre de gerar também o arquivo `BillItemId.cs` (`record struct : IEntityId<BillItemId>`).

### Aggregate Root descrito assim:

```markdown
## Aggregate: Bill

**Root**: Bill

**Propriedades**:
- id: BillId
- supplierId: SupplierId
- totalAmount: Money (calculado a partir dos items)
- dueDate: DueDate
- status: BillStatus
- items: List<BillItem>

**Invariantes**:
- Status segue máquina: DRAFT → AWAITING_APPROVAL → APPROVED → SCHEDULED → PAID
- TotalAmount = soma dos amounts dos items
- Bill com status PAID é imutável
- Bill em status diferente de DRAFT não permite addItem

**Comportamentos**:
- Create(id, supplierId, dueDate, occurredAt) → emite BillCreated
- AddItem(description, amount, categoryCode) → recalcula total
- SubmitForApproval(occurredAt) → emite BillSubmittedForApproval; exige >= 1 item
- Approve(approver, occurredAt) → emite BillApproved
- Reject(reason, occurredAt) → emite BillRejected
- Schedule(date, account, occurredAt) → emite BillScheduled
- Cancel(occurredAt) → emite BillCancelled

**Domain Events**:
- BillCreated { billId, supplierId, occurredAt }
- BillSubmittedForApproval { billId, occurredAt }
- BillApproved { billId, approvedBy, amount, occurredAt }
- BillRejected { billId, reason, occurredAt }
- BillScheduled { billId, scheduledFor, account, occurredAt }
- BillPaid { billId, paidAt, amount, occurredAt }
- BillCancelled { billId, occurredAt }
```

→ Mapeamento direto. Cada método vira método público no Root. Cada evento vira `sealed record`.

### Máquina de estados descrita assim:

```markdown
### Status (BillStatus) — transições válidas:
- DRAFT → AWAITING_APPROVAL (via SubmitForApproval)
- DRAFT → CANCELLED (via Cancel)
- AWAITING_APPROVAL → APPROVED (via Approve)
- AWAITING_APPROVAL → REJECTED (via Reject)
- AWAITING_APPROVAL → CANCELLED (via Cancel)
- APPROVED → SCHEDULED (via Schedule)
- APPROVED → CANCELLED (via Cancel)
- SCHEDULED → PAID (via execute_payment_succeeded — externo)
```

→ Gere Smart Enum `BillStatus` com método `CanTransitionTo` cobrindo exatamente esses pares. O Aggregate usa `EnsureTransitionAllowed` antes de mutar.

## O que fazer em caso de ambiguidade

- **Tipo do atributo não especificado**: pergunte. Não chute.
- **Identifier de outro Aggregate sem nome**: assuma `<Outro>Id` mas confirme.
- **Validações implícitas ("deve ser válido")**: pergunte qual a regra exata.
- **Evento mencionado em comportamento mas não definido na seção Events**: liste como ambiguidade no fim, sugira o payload provável.
- **Nome em PT vs EN inconsistente**: siga o uso predominante do markdown. Termos DDD (Aggregate, Value Object) ficam em EN; termos de negócio seguem o markdown.

## Exemplo de saída quando há ambiguidade

Ao final da resposta, sempre que aplicável:

```
## Pontos de ambiguidade resolvidos

1. `Money` não tinha tipo de `amount` no markdown. Assumi `decimal`. Confirma?
2. O evento `BillScheduled` foi mencionado em `Schedule(...)` mas não definido na seção Events. Assumi payload `{ billId, scheduledFor, account, occurredAt }` — ajuste se for diferente.
3. `DueDate.isOverdue` precisa de "agora" para comparar. Adicionei parâmetro `DateTime now` em vez de `DateTime.UtcNow`. Se preferir injetar `IClock`, me avisa.
```

Sem inventar — só explicitar suposições e pedir confirmação.
