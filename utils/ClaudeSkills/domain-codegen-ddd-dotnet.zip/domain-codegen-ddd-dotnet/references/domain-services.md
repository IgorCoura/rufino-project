# Domain Service

> Quando uma regra de negócio envolve **múltiplos Aggregates** (ou múltiplas Entities de Aggregates diferentes) e não cabe naturalmente em nenhum deles, ela vai num **Domain Service**. Carregue este arquivo quando o usuário pedir um Domain Service ou quando você identificar que a regra precisa de um.

## Quando criar Domain Service

A pergunta-mãe: **"Essa regra envolve múltiplos Aggregates e não cabe em nenhum deles individualmente?"**

✅ **Cria Domain Service quando**:
- A operação envolve **dois ou mais Aggregates** que precisam coordenar.
- Forçar a regra dentro de um Aggregate faria-o saber demais sobre outro.
- A operação é **stateless** por natureza (não tem identidade nem ciclo de vida).
- A linguagem de negócio expressa essa operação como um verbo independente (`TransferFunds`, `AssessCreditRisk`, `CalculateAutomaticClassification`).

❌ **NÃO cria Domain Service quando**:
- A regra envolve um único Aggregate → vai como **método do Aggregate Root**.
- A operação é orquestração de caso de uso (transação, autorização, DTO) → é **Application Service**, não Domain Service.
- A "regra" é só um cálculo simples num único Value Object → vai como **método do VO**.

### Exemplo: cabe em Aggregate vs. Domain Service

❌ **Errado** — operação envolvendo 2 Aggregates dentro de um deles:

```csharp
public sealed class SourceAccount : AggregateRoot<AccountId>
{
    public void TransferTo(TargetAccount target, Money amount, DateTime occurredAt)
    {
        // SourceAccount agora sabe sobre TargetAccount.
        // Acopla os dois Aggregates. Vaza encapsulamento.
        if (this.Balance.Amount < amount.Amount)
            throw AccountErrors.InsufficientBalance();
        if (target.IsBlocked)
            throw AccountErrors.TargetIsBlocked();
        this.Debit(amount);
        target.Credit(amount);
    }
}
```

✅ **Correto** — Domain Service coordena os dois:

```csharp
public sealed class FundsTransferService
{
    public void Transfer(SourceAccount source, TargetAccount target, Money amount, DateTime occurredAt)
    {
        if (source.Balance.Amount < amount.Amount)
            throw FundsTransferErrors.InsufficientBalance();
        if (target.IsBlocked)
            throw FundsTransferErrors.TargetIsBlocked();

        source.Debit(amount, occurredAt);     // Source emite SourceDebited
        target.Credit(amount, occurredAt);    // Target emite TargetCredited
    }
}
```

## Regras obrigatórias

### Forma da classe

- **`public sealed class`** com nome em inglês, sufixo `Service` (ex.: `FundsTransferService`, `BillClassificationService`, `CreditRiskAssessmentService`).
- **Sem interface** — classe direta. Domain Service é puro domínio, sem necessidade de inversão de dependência (não tem implementação externa).
- **Stateless**: nenhum campo de instância exceto constantes (`MAIÚSCULAS_COM_UNDERSCORE` no topo). Nunca guarde Aggregate como campo.
- **Construtor sem parâmetros** (ou ausente). Service não tem estado a inicializar, não recebe dependências.

### O que faz e o que não faz

- ✅ Recebe **Aggregates como parâmetros** dos métodos.
- ✅ Executa a regra de coordenação.
- ✅ Chama métodos dos Aggregates passados (que mantêm seus invariantes e emitem seus eventos).
- ✅ Lança `DomainException` via factory de erros próprio (`<Service>Errors.cs`).
- ❌ **NÃO emite Domain Events diretamente.** Quem emite é o Aggregate. Se o resultado da operação coordenada precisa virar um evento de "processo", esse evento é emitido por **um dos Aggregates participantes** (geralmente o "principal" da operação).
- ❌ **NÃO acessa Repository, banco, API externa, file system, ou qualquer infra.** Se precisa, é Application Service.
- ❌ **NÃO tem `async`/`await`** — domínio puro é síncrono.
- ❌ **NÃO carrega Aggregate de Repository internamente.** Quem carrega é o Application Service, que passa o Aggregate já hidratado.
- ❌ **NÃO tem getters/setters de estado** — é stateless.

### Erros do Domain Service

Cada Domain Service tem seu próprio arquivo de factory de erros, seguindo o padrão da skill:

```
Services/
├── FundsTransferService.cs
└── FundsTransferErrors.cs        ← Factory de erros do Service
```

A sigla do erro segue o mesmo padrão `<BC>.<SVC>##` (3 letras do BC + ponto + 3 letras do Service + número):

- `BNK.FTS01` = Banking → Funds Transfer Service → erro 01
- `APD.BCS01` = Accounts Payable → Bill Classification Service → erro 01

## Estrutura de pastas

Domain Services ficam em **`Services/`** na **raiz do projeto BC**, separados dos Aggregates. Razão: Service que coordena 2+ Aggregates não pertence a nenhum deles em particular.

```
<BoundedContext>.Domain/
├── SeedWork/
├── <BoundedContext>Errors.cs
├── Services/                              ← Domain Services aqui, na raiz
│   ├── <Service1>Service.cs
│   ├── <Service1>Errors.cs
│   ├── <Service2>Service.cs
│   └── <Service2>Errors.cs
└── <Aggregate>/
    └── ...
```

Exemplo concreto:

```
AccountsPayable.Domain/
├── SeedWork/
├── AccountsPayableErrors.cs
├── Services/
│   ├── BillClassificationService.cs
│   ├── BillClassificationErrors.cs
│   ├── AutoApprovalEligibilityService.cs
│   └── AutoApprovalEligibilityErrors.cs
└── Bills/
    ├── Bill.cs
    └── ...
```

## Template completo

```csharp
// AccountsPayable.Domain/Services/BillClassificationService.cs
namespace AccountsPayable.Domain.Services;

using AccountsPayable.Domain.Bills;
using AccountsPayable.Domain.Suppliers;

public sealed class BillClassificationService
{
    private const decimal AUTO_APPROVAL_THRESHOLD = 500m;

    public BillClassification Classify(
        Bill bill,
        Supplier supplier,
        DateTime occurredAt)
    {
        if (bill is null)
            throw BillClassificationErrors.BillRequired();
        if (supplier is null)
            throw BillClassificationErrors.SupplierRequired();

        var isOperational = supplier.Category.Equals(SupplierCategory.Operational);
        var isWithinThreshold = bill.TotalAmount.Amount <= AUTO_APPROVAL_THRESHOLD;
        var isTrustedSupplier = supplier.TrustLevel.Equals(TrustLevel.High);

        if (isOperational && isWithinThreshold && isTrustedSupplier)
            return BillClassification.AutoApprove;

        if (bill.TotalAmount.Amount > AUTO_APPROVAL_THRESHOLD * 10)
            return BillClassification.RequiresSeniorApproval;

        return BillClassification.RequiresHumanReview;
    }
}
```

```csharp
// AccountsPayable.Domain/Services/BillClassificationErrors.cs
namespace AccountsPayable.Domain.Services;

using AccountsPayable.Domain.SeedWork;
using System.IO;
using System.Runtime.CompilerServices;

public static class BillClassificationErrors
{
    private const string SERVICE_PREFIX = "APD.BCS";

    public static DomainException BillRequired(
        [CallerFilePath] string filePath = "",
        [CallerMemberName] string memberName = "",
        [CallerLineNumber] int lineNumber = 0)
        => new(
            id: $"{SERVICE_PREFIX}01",
            messageTemplate: "Bill é obrigatória para classificação.",
            parameters: Array.Empty<object>(),
            sourcePath: BuildSourcePath(filePath, memberName, lineNumber));

    public static DomainException SupplierRequired(
        [CallerFilePath] string filePath = "",
        [CallerMemberName] string memberName = "",
        [CallerLineNumber] int lineNumber = 0)
        => new(
            id: $"{SERVICE_PREFIX}02",
            messageTemplate: "Supplier é obrigatório para classificação.",
            parameters: Array.Empty<object>(),
            sourcePath: BuildSourcePath(filePath, memberName, lineNumber));

    private static string BuildSourcePath(string filePath, string memberName, int lineNumber)
        => $"{Path.GetFileName(filePath)}:{lineNumber} ({memberName})";
}
```

## Padrões de assinatura de método

### Variação 1 — Service que coordena mutação em múltiplos Aggregates

Recebe os Aggregates e os modifica via seus métodos. Retorna `void`.

```csharp
public void Transfer(SourceAccount source, TargetAccount target, Money amount, DateTime occurredAt)
```

### Variação 2 — Service que calcula/avalia (não muta)

Recebe os Aggregates e retorna um valor (geralmente VO ou enum).

```csharp
public BillClassification Classify(Bill bill, Supplier supplier, DateTime occurredAt)
public CreditRisk Assess(Customer customer, IReadOnlyList<Bill> openBills)
public bool IsEligibleForAutoApproval(Bill bill, User approver)
```

### Variação 3 — Service que retorna informação para o Aggregate emitir evento

Service decide algo, Aggregate aplica e emite. Útil quando a decisão é complexa mas a mutação é simples.

```csharp
// Domain Service decide
var classification = classificationService.Classify(bill, supplier, occurredAt);

// Aggregate aplica e emite o evento
bill.ApplyClassification(classification, occurredAt);
```

## Anti-padrões

### ❌ Service com estado

```csharp
public sealed class FundsTransferService
{
    private readonly Account _source;   // ❌ estado
    private readonly Account _target;   // ❌ estado

    public FundsTransferService(Account source, Account target) { ... }   // ❌

    public void Execute() { ... }
}
```

Service deve ser stateless. Aggregates entram nos métodos, não no construtor.

### ❌ Service que carrega Repository

```csharp
public sealed class BillClassificationService
{
    private readonly IBillRepository _bills;   // ❌ infra no domínio
    
    public BillClassification ClassifyById(Guid billId)   // ❌ deveria receber a Bill já hidratada
    {
        var bill = _bills.FindById(billId);
        ...
    }
}
```

Carregar Aggregate é responsabilidade de Application Service, não Domain Service.

### ❌ Service que emite Domain Event

```csharp
public sealed class BillClassificationService
{
    public BillClassification Classify(Bill bill, Supplier supplier, DateTime occurredAt)
    {
        var classification = ...;
        bill.AddDomainEvent(new BillClassified(bill.Id, classification, occurredAt));   // ❌
        return classification;
    }
}
```

Service não emite eventos. Service retorna o resultado, e quem chama (geralmente o Application Service) aplica no Aggregate via método de domínio que emite o evento corretamente. Ou:

```csharp
// Service retorna a decisão
var classification = classificationService.Classify(bill, supplier, occurredAt);

// Aggregate aplica E emite
bill.ApplyClassification(classification, occurredAt);   // ← aqui dentro emite BillClassified
```

### ❌ "Service" que é só procedural por preguiça

```csharp
public sealed class BillService
{
    public void Approve(Bill bill, UserId approver, DateTime occurredAt) { ... }
    public void Reject(Bill bill, UserId approver, DateTime occurredAt) { ... }
    public void Cancel(Bill bill, DateTime occurredAt) { ... }
}
```

Tudo isso é comportamento do **próprio `Bill`**, não Domain Service. Coloque como métodos do Aggregate Root. Service só justifica-se quando há **coordenação real entre múltiplos Aggregates**.

### ❌ Service com `async`/`await`

```csharp
public sealed class BillClassificationService
{
    public async Task<BillClassification> ClassifyAsync(...)   // ❌
}
```

Domínio é síncrono. Async é sintoma de I/O, que pertence a Application Service ou Infrastructure.

## Checklist ao gerar Domain Service

- [ ] A regra envolve **múltiplos Aggregates** ou **múltiplas Entities** de Aggregates diferentes?
- [ ] A regra **não cabe** dentro de um Aggregate sem fazê-lo saber demais sobre outro?
- [ ] `public sealed class` com sufixo `Service`?
- [ ] Sem interface (a menos que o usuário tenha pedido explicitamente)?
- [ ] **Stateless** (sem campos de instância exceto constantes)?
- [ ] Sem dependência de infra (Repository, HTTP, banco, file system)?
- [ ] Não emite Domain Events?
- [ ] Não tem `async`/`await`?
- [ ] Erros via factory `<Service>Errors.cs` com prefixo `<BC>.<SVC>##`?
- [ ] Em `Services/` na raiz do projeto BC?
