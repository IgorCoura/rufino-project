# Convenções de código C# / .NET para DDD

> Regras a seguir literalmente. Se o usuário pedir desvio explícito, respeite — mas o default é este.

## Idioma do código

**Tudo em inglês**: nomes de classes, propriedades, métodos, parâmetros, variáveis locais, namespaces, eventos, enums, IDs de erro, comentários técnicos, nomes de arquivos.

**Em português**: apenas as **mensagens de erro** das `DomainException` e mensagens visíveis ao usuário.

```csharp
// Bom
public sealed class Bill : AggregateRoot<BillId>
{
    public void Approve(UserId approver, DateTime occurredAt) { ... }
}

// BillErrors.cs
public static DomainException CannotApproveDraftBill(...)
    => new(
        id: "APD.BIL01",
        messageTemplate: "Bill em estado de rascunho não pode ser aprovada.",  // PT
        ...);
```

```csharp
// Ruim — código em PT
public sealed class Conta : RaizAgregada
{
    public void Aprovar(Guid aprovador, DateTime ocorridoEm) { ... }
}
```

**Termos consagrados de DDD em inglês**: `Aggregate`, `Entity`, `ValueObject`, `Repository`, `DomainEvent`, `BoundedContext`. Não traduza para "Agregado", "Entidade", "ObjetoDeValor", etc.

## Versão e features

- **C# 12+ / .NET 8+** assumido.
- **`#nullable enable`** sempre. Não suprimir com `!` exceto em casos justificados.
- **File-scoped namespaces** (`namespace X.Y;` sem chaves).
- **`global using` permitidos** se o projeto já adota.
- **Collection expressions** (`List<T> _items = []`) preferidas a `new List<T>()`.

## Constantes no domínio

**Toda constante (`const`, `static readonly` que funcione como constante) em qualquer classe do domínio** — Aggregate Root, Entity, Value Object, Smart Enum, factory de erros — segue duas regras:

1. **Nome em `MAIÚSCULAS_COM_UNDERSCORE`** (SCREAMING_SNAKE_CASE), não PascalCase.
2. **Declarada no topo da classe**, antes dos campos privados, antes do construtor, antes de qualquer outro membro.

### Padrão

```csharp
public sealed class Bill : AggregateRoot<BillId>
{
    // Constants — always at the top, always SCREAMING_SNAKE_CASE
    private const int MAX_ITEMS_PER_BILL = 200;
    private const decimal MIN_ITEM_AMOUNT = 0.01m;
    private const string DEFAULT_CURRENCY = "BRL";

    // Private fields after (always _camelCase)
    private readonly List<BillItem> _items = [];

    // Properties after (PascalCase)
    public SupplierId SupplierId { get; private set; }
    public Money TotalAmount { get; private set; } = default!;

    // Constructor after
    private Bill() : base() { }

    // Methods after
    public static Bill Create(...) { ... }
}
```

### Aplicação por tipo

- **Aggregate Root / Entity**: limites de negócio (`MAX_ITEMS`, `MIN_AMOUNT`), defaults (`DEFAULT_CURRENCY`).
- **Value Object**: validações fixas (`MIN_LENGTH`, `MAX_LENGTH`, `EMAIL_REGEX_PATTERN`).
- **Smart Enum (Enumeration)**: códigos de status como `const` antes das instâncias estáticas.
- **Factory de erros**: prefixos de ID (`AGGREGATE_PREFIX = "APD.BIL"`).

### Visibilidade: `public const` vs `private const`

A regra de visibilidade depende de **quem precisa conhecer a constante**.

#### Regra de ouro

> **O domínio é a fonte única da verdade.** Se uma constante representa uma regra de negócio que outras camadas (infraestrutura, API, UI) precisam replicar, ela vive no domínio como `public const` e as outras camadas **leem dela** — nunca duplicam o valor.

Por quê: se o domínio diz `Name.MAX_LENGTH = 100` e valida no construtor, mas a infra define `.HasMaxLength(255)` no EF mapping, há **duas verdades**. Em algum momento alguém vai mudar uma sem mudar a outra, e o usuário vai conseguir construir um VO com 200 chars que **passa pela validação do domínio** mas **explode no banco**. Ou pior: o domínio rejeita 150 chars mas o banco aceita 255 — domínio fica artificialmente mais restritivo que a tabela.

#### `public const` — quando a constante é regra de domínio que outras camadas precisam ler

Inclui:
- **Tamanhos de campo de VO/Entity** (`MAX_LENGTH`, `MIN_LENGTH`) — infra usa em `.HasMaxLength(Name.MAX_LENGTH)` no EF Core mapping.
- **Limites numéricos validados** (`MAX_VALUE`, `MIN_VALUE`) — infra pode usar em check constraints, UI pode usar em validação client-side.
- **Limites de coleção** se o banco impõe constraint (raro, mas possível).
- **Patterns regex de validação** se a UI precisa replicar a mesma validação client-side.

Exemplo:

```csharp
// AccountsPayable.Domain/Bills/ValueObjects/SupplierName.cs
public sealed class SupplierName : ValueObject
{
    public const int MAX_LENGTH = 100;
    public const int MIN_LENGTH = 2;

    public string Value { get; }

    public SupplierName(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            throw SupplierNameErrors.Empty();
        if (value.Length < MIN_LENGTH)
            throw SupplierNameErrors.TooShort(MIN_LENGTH);
        if (value.Length > MAX_LENGTH)
            throw SupplierNameErrors.TooLong(MAX_LENGTH);

        Value = value.Trim();
    }

    protected override IEnumerable<object?> GetEqualityComponents()
    {
        yield return Value;
    }
}
```

Infra usa diretamente:

```csharp
// Infrastructure/EF/BillMapping.cs (camada de infra — NÃO é geração desta skill)
modelBuilder.Entity<Bill>()
    .OwnsOne(b => b.Supplier, supplierBuilder =>
    {
        supplierBuilder.Property(s => s.Value)
            .HasMaxLength(SupplierName.MAX_LENGTH);   // ← LÊ do domínio
    });
```

Migration gerada respeita o mesmo limite. UI também pode ler:

```csharp
// API DTO validation (camada de aplicação)
public record CreateBillRequest(string SupplierName)
{
    [MaxLength(Domain.Bills.ValueObjects.SupplierName.MAX_LENGTH)]
    public string SupplierName { get; init; } = SupplierName;
}
```

**Resultado**: muda `MAX_LENGTH` em um lugar (domínio), todas as outras camadas refletem automaticamente.

#### `private const` — quando a constante é detalhe interno do domínio

Inclui:
- **Defaults internos** (`DEFAULT_CURRENCY = "BRL"`) — escolha do domínio, infra não precisa saber.
- **Thresholds de regra puramente de domínio** (`AUTO_APPROVAL_THRESHOLD = 500m`) — regra aplicada só pelo domínio.
- **Prefixos de erro** (`AGGREGATE_PREFIX = "APD.BIL"`) — uso interno da factory de erros.
- **Limites operacionais que NÃO viram constraint de banco** (`MAX_RETRY_COUNT = 3` num Domain Service) — comportamento, não estrutura.

#### Como decidir

Pergunte:

1. **A infra precisa replicar essa regra para evitar inconsistência entre domínio e persistência/UI?** Se sim → `public const`.
2. **A regra é puramente comportamental, aplicada só dentro do domínio?** Se sim → `private const`.
3. **Se eu mudar o valor, alguém fora do domínio precisa saber?** Se sim → `public const`.

#### Exemplo comparativo no mesmo Aggregate

```csharp
public sealed class Bill : AggregateRoot<BillId>
{
    // Public: limite que vira constraint de banco / validação de API
    public const int MAX_ITEMS_PER_BILL = 200;
    public const int MAX_NOTES_LENGTH = 1000;

    // Private: default e threshold puramente de domínio
    private const string DEFAULT_CURRENCY = "BRL";
    private const decimal HIGH_VALUE_THRESHOLD = 100_000m;

    // ... resto da classe
}
```

EF mapping lê `Bill.MAX_NOTES_LENGTH` no `.HasMaxLength(...)`. EF **não lê** `DEFAULT_CURRENCY` nem `HIGH_VALUE_THRESHOLD` — esses são decisões do domínio que não viram coluna nem constraint.

#### Erros típicos a evitar

❌ **Duplicação silenciosa**:
```csharp
// Domínio
public sealed class SupplierName : ValueObject
{
    private const int MAX_LENGTH = 100;   // privado
    // valida com 100
}

// Infra (em outro arquivo, longe)
modelBuilder.Entity<Bill>().Property(b => b.Supplier).HasMaxLength(255);   // ❌ valor diferente
```

✅ **Constante pública, infra lê do domínio**:
```csharp
public sealed class SupplierName : ValueObject
{
    public const int MAX_LENGTH = 100;
    // valida com MAX_LENGTH
}

// Infra
modelBuilder.Entity<Bill>().Property(b => b.Supplier).HasMaxLength(SupplierName.MAX_LENGTH);
```

❌ **Constante de tamanho privada sem validação no construtor**:
```csharp
public sealed class SupplierName : ValueObject
{
    private const int MAX_LENGTH = 100;
    public string Value { get; }
    public SupplierName(string value) { Value = value; }   // ❌ não valida tamanho
}
// Resultado: VO aceita 500 chars no construtor, infra rejeita ao salvar → exceção de banco.
```

✅ **Sempre validar no construtor antes de aceitar o valor**:
```csharp
public sealed class SupplierName : ValueObject
{
    public const int MAX_LENGTH = 100;
    public string Value { get; }
    public SupplierName(string value)
    {
        if (value?.Length > MAX_LENGTH)
            throw SupplierNameErrors.TooLong(MAX_LENGTH);
        Value = value ?? throw SupplierNameErrors.Empty();
    }
}
```

#### Resumo de visibilidade

| Tipo de constante | Visibilidade | Por quê |
|---|---|---|
| `MAX_LENGTH`, `MIN_LENGTH` de VO/Entity | **`public const`** | Infra usa em `.HasMaxLength()`; UI usa em validação |
| `MAX_VALUE`, `MIN_VALUE` numérico validado | **`public const`** | Pode virar check constraint; UI pode usar |
| `EMAIL_REGEX_PATTERN` se UI replica validação | **`public const`** | UI ou API replicam a regex client-side |
| `DEFAULT_CURRENCY`, `DEFAULT_LOCALE` | `private const` | Escolha interna do domínio |
| `THRESHOLD_X` para regra de negócio aplicada só no domínio | `private const` | Comportamental, não estrutural |
| Prefixos de erro (`AGGREGATE_PREFIX`) | `private const` | Uso interno da factory |
| `MAX_RETRY_COUNT` em Domain Service | `private const` | Comportamento do Service, não estrutura de dados |
| Códigos de Smart Enum (`"DRAFT"`, `"APPROVED"`) | Argumento de `new(id, name)` | São identificadores externos via `.Name` da instância |

### Não é constante (não aplique)

- **Campos privados mutáveis** (`_items`, `_domainEvents`) → `_camelCase`.
- **Propriedades públicas** (`Status`, `TotalAmount`) → `PascalCase`.
- **Variáveis locais dentro de métodos** (`var sum = ...`) → `camelCase`.
- **Instâncias estáticas de Smart Enum** (`Draft`, `Approved`) → `PascalCase` (são singletons nomeados como nomes próprios).

## Identidade (strongly-typed Ids)

**Toda Entity tem `Id` strongly-typed** — `record struct` específico do tipo (`BillId`, `SupplierId`, `UserId`, etc.) implementando `IEntityId<TSelf>`.

### Por que strongly-typed

`Guid` solto compila qualquer coisa:

```csharp
public void TransferOwnership(Guid bill, Guid newOwner) { ... }

// Caller:
service.TransferOwnership(command.OwnerId, command.BillId);   // ❌ trocou ordem, compila!
```

Strongly-typed pega isso em compile time:

```csharp
public void TransferOwnership(BillId bill, UserId newOwner) { ... }

// Caller:
service.TransferOwnership(command.OwnerId, command.BillId);   // ✅ erro de compilação
```

### Definição de cada Id

Cada Aggregate Root e cada Entity interna tem um arquivo dedicado para seu Id:

```csharp
// AccountsPayable.Domain/Bills/BillId.cs
namespace AccountsPayable.Domain.Bills;

using AccountsPayable.Domain.SeedWork;

public readonly record struct BillId(Guid Value) : IEntityId<BillId>
{
    public static BillId New() => new(Guid.CreateVersion7());
    public static BillId From(Guid value) => new(value);
    public static BillId Empty => new(Guid.Empty);
    public override string ToString() => Value.ToString();
}
```

### Regras

- **`readonly record struct`** sempre — não use `class`, não use `record class`.
- **Implementa `IEntityId<TSelf>`** com `New()`, `From(Guid)`, `Empty`.
- **Sem `implicit operator Guid`** — extração via `id.Value` explícito. Mais verboso, mas preserva type-safety: passar `BillId` num lugar que espera `SupplierId` falha em compile time, e o cast implícito derrubaria essa garantia.
- `New()` usa `Guid.CreateVersion7()` (.NET 9+) para Ids ordenados temporalmente. Em .NET 8, troque por `Guid.NewGuid()` ou pelo package [`UUIDNext`](https://www.nuget.org/packages/UUIDNext).
- Arquivo separado para cada Id: `<Entity>Id.cs` na mesma pasta da Entity.

### Uso em Aggregate

```csharp
public sealed class Bill : AggregateRoot<BillId>
{
    // Referências a outros Aggregates: Id strongly-typed (NÃO Guid)
    public SupplierId SupplierId { get; private set; }
    public UserId? ApprovedBy { get; private set; }

    // ...
}
```

### Uso em Domain Event

Eventos também usam Ids strongly-typed no payload — consistência em todo domínio:

```csharp
public sealed record BillApproved(
    Guid EventId,                  // EventId é metadata, continua Guid
    BillId BillId,                 // Strongly-typed
    UserId ApprovedBy,             // Strongly-typed
    decimal Amount,
    string Currency,
    DateTime OccurredAt) : IDomainEvent;
```

### Conversão para `Guid` quando precisa

Quando precisar do `Guid` cru (logging, integração com APIs externas que aceitam só `Guid`), use `.Value` explícito:

```csharp
logger.LogInformation("Bill approved: {BillId} by {ApprovedBy}",
    bill.Id.Value,
    approver.Value);
```

### Reidratação a partir do banco

Repository faz a conversão na borda:

```csharp
var bill = Bill.Rehydrate(
    id: BillId.From(row.id),                  // Guid -> BillId
    supplierId: SupplierId.From(row.supplier_id),
    // ...
);
```

### Compatibilidade com EF Core

EF Core 8+ suporta `record struct` como Id via Value Converter. **Cada Id precisa ser configurado** no `DbContext`:

```csharp
modelBuilder.Entity<Bill>()
    .Property(b => b.Id)
    .HasConversion(
        id => id.Value,
        value => BillId.From(value));

modelBuilder.Entity<Bill>()
    .Property(b => b.SupplierId)
    .HasConversion(
        id => id.Value,
        value => SupplierId.From(value));
```

A skill **não gera EF config** — isso é responsabilidade da camada de infra. Mas avise o usuário ao gerar Aggregates novos de que cada `Id` precisa de Value Converter no `DbContext`.

## Value Objects

**Todo VO** herda de `ValueObject` (em `Domain/SeedWork/ValueObject.cs` — implementação completa em `references/templates.md`).

### Caso simples

```csharp
namespace AccountsPayable.Domain.Bills.ValueObjects;

public sealed class EmailAddress : ValueObject
{
    // Public: infra usa em .HasMaxLength(EmailAddress.MAX_LENGTH)
    public const int MAX_LENGTH = 254;   // RFC 5321

    public string Value { get; }

    public EmailAddress(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            throw EmailAddressErrors.EmptyEmail();
        if (value.Length > MAX_LENGTH)
            throw EmailAddressErrors.TooLong(MAX_LENGTH);
        if (!value.Contains('@'))
            throw EmailAddressErrors.InvalidFormat(value);

        Value = value.Trim().ToLowerInvariant();
    }

    protected override IEnumerable<object?> GetEqualityComponents()
    {
        yield return Value;
    }
}
```

### Caso composto

```csharp
namespace AccountsPayable.Domain.Bills.ValueObjects;

public sealed class Money : ValueObject
{
    private const string DEFAULT_CURRENCY = "BRL";

    public decimal Amount { get; }
    public string Currency { get; }

    public Money(decimal amount, string currency)
    {
        if (string.IsNullOrWhiteSpace(currency) || currency.Length != 3)
            throw MoneyErrors.InvalidCurrencyCode(currency ?? string.Empty);

        Amount = decimal.Round(amount, 2, MidpointRounding.ToEven);
        Currency = currency.ToUpperInvariant();
    }

    public static Money Zero(string currency) => new(0m, currency);

    public Money Add(Money other)
    {
        EnsureSameCurrency(other);
        return new Money(Amount + other.Amount, Currency);
    }

    public Money Subtract(Money other)
    {
        EnsureSameCurrency(other);
        return new Money(Amount - other.Amount, Currency);
    }

    private void EnsureSameCurrency(Money other)
    {
        if (Currency != other.Currency)
            throw MoneyErrors.CurrencyMismatch(Currency, other.Currency);
    }

    protected override IEnumerable<object?> GetEqualityComponents()
    {
        yield return Amount;
        yield return Currency;
    }
}
```

### Regras gerais para VO

- `sealed class` herdando de `ValueObject` — **não use record**.
- Construtor valida; estado inválido é impossível. Lança erro via factory de erros, não `throw new DomainException` direto.
- Apenas `get` (sem `set`, sem `init`); props pegam valor uma vez no construtor.
- Métodos retornam **novos VOs** (imutável).
- `GetEqualityComponents()` lista os campos que entram na igualdade — pode ser subset das propriedades se houver campo que não conta (raro, mas suportado).
- Sem dependência de infra (sem JSON, sem EF, sem nada).

## Setters privados reutilizáveis (Aggregate Root e Entity)

> Esta seção se aplica a **Aggregate Root e Entity** (não a Value Object, que é imutável e valida só no construtor).

### Problema

Aggregate/Entity são **mutáveis** via comportamentos. Se você valida só no construtor:

❌ **Inválido depois de criado**:
```csharp
public sealed class Bill : AggregateRoot<BillId>
{
    public const int MAX_DESCRIPTION_LENGTH = 500;
    public string Description { get; private set; } = default!;

    private Bill(BillId id, string description) : base(id)
    {
        if (description.Length > MAX_DESCRIPTION_LENGTH)
            throw BillErrors.DescriptionTooLong(MAX_DESCRIPTION_LENGTH);
        Description = description;
    }

    public void ChangeDescription(string newDescription, DateTime occurredAt)
    {
        Description = newDescription;   // ❌ não revalida — pode ficar com >500 chars
        UpdatedAt = occurredAt;
    }
}
```

A Entity nasce válida, mas `ChangeDescription` permite mutar pra inválido. Quando salvar no banco → exceção de DB. O construtor sozinho **não basta** numa Entity mutável.

❌ **Duplicação de validação**:
```csharp
public sealed class Bill : AggregateRoot<BillId>
{
    public static Bill Create(BillId id, string description, ...)
    {
        if (description.Length > MAX_DESCRIPTION_LENGTH)      // ❌ duplicado
            throw BillErrors.DescriptionTooLong(MAX_DESCRIPTION_LENGTH);
        var bill = new Bill(id);
        bill.Description = description;
        // ...
    }

    public void ChangeDescription(string newDescription, DateTime occurredAt)
    {
        if (newDescription.Length > MAX_DESCRIPTION_LENGTH)   // ❌ duplicado de novo
            throw BillErrors.DescriptionTooLong(MAX_DESCRIPTION_LENGTH);
        Description = newDescription;
        UpdatedAt = occurredAt;
    }
}
```

Se `MAX_DESCRIPTION_LENGTH` muda, ou se a regra ganha condição nova, você tem que mexer em vários lugares. Em algum momento esquece um.

### Padrão: setters privados centralizando validação

Cada propriedade que tem regra de validação ganha um **método setter privado** que:

1. **Recebe o valor candidato**.
2. **Aplica TODAS as validações daquela propriedade** (incluindo as `public const` de tamanho).
3. **Atribui à propriedade** (que tem `private set`).
4. **NÃO** atualiza `UpdatedAt`. **NÃO** emite Domain Event. **NÃO** faz validação de transição de estado (`EnsureCanModify`). Setter é só "atribuir + validar".

```csharp
public sealed class Bill : AggregateRoot<BillId>
{
    public const int MAX_DESCRIPTION_LENGTH = 500;
    public const int MIN_DESCRIPTION_LENGTH = 3;

    public string Description { get; private set; } = default!;

    // ... outras propriedades

    // Setter privado: ÚNICA fonte de validação dessa propriedade
    private void SetDescription(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            throw BillErrors.DescriptionRequired();
        if (value.Length < MIN_DESCRIPTION_LENGTH)
            throw BillErrors.DescriptionTooShort(MIN_DESCRIPTION_LENGTH);
        if (value.Length > MAX_DESCRIPTION_LENGTH)
            throw BillErrors.DescriptionTooLong(MAX_DESCRIPTION_LENGTH);

        Description = value;
    }
}
```

### Quem chama o setter privado

Todo lugar que precisa atribuir o valor reusa o setter — sem duplicar validação.

```csharp
public static Bill Create(
    BillId id,
    SupplierId supplierId,
    string description,
    DueDate dueDate,
    DateTime occurredAt)
{
    var bill = new Bill(id);
    bill.SetSupplierId(supplierId);
    bill.SetDescription(description);          // ← reusa
    bill.SetDueDate(dueDate);
    bill.Status = BillStatus.Draft;            // simples, sem validação
    bill.CreatedAt = occurredAt;
    bill.UpdatedAt = occurredAt;

    bill.AddDomainEvent(new BillCreated(...));  // evento da Root, não dos setters
    return bill;
}

public void ChangeDescription(string newDescription, DateTime occurredAt)
{
    EnsureCanModify();                          // invariante de estado do Aggregate
    SetDescription(newDescription);             // ← reusa validação
    UpdatedAt = occurredAt;
    AddDomainEvent(new BillDescriptionChanged(Id, newDescription, occurredAt));
}
```

**Separação clara**:
- **Setter** = validação de **valor** (tamanho, formato, range).
- **Método de mutação público** = invariante de **estado** (status permite modificar?) + setter + `UpdatedAt` + evento.

### Quando promover setter de `private` para `public`

> Setters começam `private`. Promova para `public` **só quando a lógica de negócio exigir alteração direta da propriedade** sem comportamento adicional.

Critério: se você ia criar um método público `ChangeXxx(value)` cujo corpo é apenas:

```csharp
public void ChangeXxx(string value)
{
    SetXxx(value);
}
```

…então é melhor **deixar `SetXxx` público diretamente**, evitando o método-fantasma sem valor agregado.

✅ **Promova para `public` quando**:
- A alteração é trivial — só atribuir o valor com validação, sem invariante de estado, sem evento, sem atualizar `UpdatedAt`.
- A regra de negócio diz "essa propriedade pode ser alterada diretamente" (raro em domínio rico, mas acontece).

❌ **Mantenha `private` quando**:
- A alteração requer **invariante de estado** (`EnsureCanModify`, status check).
- A alteração precisa **emitir Domain Event**.
- A alteração precisa **atualizar `UpdatedAt`**.
- A alteração precisa **chamar outros setters em sequência** ou recalcular algo.

Nesses casos, exponha um método de mutação **nomeado pelo verbo de negócio** (`ChangeDescription`, `Reprice`, `Reschedule`) e mantenha o setter `private`.

### Convenções de nome

- **Setter privado**: `Set<PropertyName>` — `SetDescription`, `SetDueDate`, `SetTotalAmount`.
- **Método público de mutação**: nome do verbo de negócio — `ChangeDescription`, `Reschedule`, `Approve`, **não** `SetXxx` (mesmo público), porque setter é semanticamente "atribuição+validação", enquanto mutação pública carrega significado de negócio.
- **Exceção**: se o setter foi promovido a `public` (por critério acima), pode chamá-lo `Set<Name>` mesmo — o nome reflete que é trivial.

### Entity interna segue mesmo padrão (mas com visibilidade ajustada)

Entity interna usa `internal` em vez de `private` para os setters, porque a Root precisa acessá-los:

```csharp
public sealed class BillItem : Entity<BillItemId>
{
    public const int MAX_DESCRIPTION_LENGTH = 200;

    public string Description { get; private set; } = default!;
    public Money Amount { get; private set; } = default!;

    // EF
    private BillItem() : base() { }

    // Internal: só a Root cria
    internal BillItem(BillItemId id, string description, Money amount) : base(id)
    {
        SetDescription(description);
        SetAmount(amount);
        CreatedAt = DateTime.UtcNow;  // ou passe occurredAt como param
    }

    // Setter internal: a Root chama via método dela
    internal void SetDescription(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            throw BillErrors.ItemDescriptionRequired();
        if (value.Length > MAX_DESCRIPTION_LENGTH)
            throw BillErrors.ItemDescriptionTooLong(MAX_DESCRIPTION_LENGTH);
        Description = value;
    }

    internal void SetAmount(Money value)
    {
        if (value.Amount < 0)
            throw BillErrors.ItemAmountCannotBeNegative(value.Amount);
        Amount = value;
    }

    // Método de mutação internal (chamado pela Root) — não emite evento
    // (eventos vivem só no Aggregate Root)
    internal void ChangeAmount(Money newAmount, DateTime occurredAt)
    {
        SetAmount(newAmount);   // reusa
        UpdatedAt = occurredAt;
    }
}
```

A **Root** orquestra emissão de evento e estado:

```csharp
public sealed class Bill : AggregateRoot<BillId>
{
    public void ChangeItemAmount(BillItemId itemId, Money newAmount, DateTime occurredAt)
    {
        EnsureCanModify();

        var item = _items.FirstOrDefault(i => i.Id.Equals(itemId))
            ?? throw BillErrors.ItemNotFound(itemId.Value);

        item.ChangeAmount(newAmount, occurredAt);  // delega à Entity interna
        RecalculateTotal();
        UpdatedAt = occurredAt;

        AddDomainEvent(new BillItemAmountChanged(Id, itemId, newAmount, occurredAt));
    }
}
```

### Regras finais para setters privados

- [ ] Cada propriedade com regra de validação tem **um setter privado** `Set<PropertyName>`.
- [ ] Setter **valida e atribui** — nada mais. Sem `UpdatedAt`, sem Domain Event, sem `EnsureCanModify`.
- [ ] `Create`, `Rehydrate` e métodos de mutação **chamam o setter** em vez de duplicar validação.
- [ ] Setter começa `private`. Vira `public` **apenas** quando o método público que o envolveria seria trivial (só repassa).
- [ ] Em Entity interna, setter é `internal` (Root precisa chamar).
- [ ] Métodos de mutação públicos têm **nome de verbo de negócio** (`ChangeDescription`, `Reprice`), não `SetXxx`.
- [ ] Toda `public const MAX_LENGTH` (ou similar) é validada **dentro do setter privado** correspondente.

## Smart Enum (Enumeration)

**Todo "enum com comportamento"** herda de `Enumeration` (em `Domain/SeedWork/Enumeration.cs`). **Não use `enum` nativo do C#** para domínio — não suporta comportamento, transições, ou metadados.

```csharp
namespace AccountsPayable.Domain.Bills.Enumerations;

public sealed class BillStatus : Enumeration
{
    public static readonly BillStatus Draft = new(1, "DRAFT");
    public static readonly BillStatus AwaitingApproval = new(2, "AWAITING_APPROVAL");
    public static readonly BillStatus Approved = new(3, "APPROVED");
    public static readonly BillStatus Scheduled = new(4, "SCHEDULED");
    public static readonly BillStatus Paid = new(5, "PAID");
    public static readonly BillStatus Cancelled = new(6, "CANCELLED");
    public static readonly BillStatus Rejected = new(7, "REJECTED");

    private BillStatus(int id, string name) : base(id, name) { }

    public bool CanTransitionTo(BillStatus target)
    {
        return (Id, target.Id) switch
        {
            (1, 2) => true, // Draft -> AwaitingApproval
            (1, 6) => true, // Draft -> Cancelled
            (2, 3) => true, // AwaitingApproval -> Approved
            (2, 7) => true, // AwaitingApproval -> Rejected
            (2, 6) => true, // AwaitingApproval -> Cancelled
            (3, 4) => true, // Approved -> Scheduled
            (3, 6) => true, // Approved -> Cancelled
            (4, 5) => true, // Scheduled -> Paid
            _ => false
        };
    }
}
```

### Regras

- `sealed class` herdando de `Enumeration`.
- Construtor `private` — instâncias só nos `static readonly`.
- Instâncias `public static readonly` em `PascalCase` (são nomes próprios).
- Códigos (segundo argumento, `name`) em `MAIÚSCULAS_COM_UNDERSCORE` — viram identificadores externos (banco, JSON, logs).
- IDs (`int`) crescentes, **nunca renumerados** após uso.
- Métodos de regra (`CanTransitionTo`, `IsTerminal`, `IsActive`) na própria Smart Enum, não em outras classes.

## Entity (interna do Aggregate)

```csharp
namespace AccountsPayable.Domain.Bills.Entities;

public sealed class BillItem : Entity<BillItemId>
{
    // Public: infra usa em .HasMaxLength(BillItem.MAX_DESCRIPTION_LENGTH)
    public const int MAX_DESCRIPTION_LENGTH = 200;
    public const int MAX_CATEGORY_CODE_LENGTH = 20;

    public string Description { get; private set; } = default!;
    public Money Amount { get; private set; } = default!;
    public string CategoryCode { get; private set; } = default!;

    // EF / serialization
    private BillItem() : base() { }

    // Internal: only the Root creates
    internal BillItem(BillItemId id, string description, Money amount, string categoryCode, DateTime occurredAt)
        : base(id)
    {
        SetDescription(description);
        SetAmount(amount);
        SetCategoryCode(categoryCode);
        CreatedAt = occurredAt;
        UpdatedAt = occurredAt;
    }

    // Setters internal: a Root chama via método dela.
    // Validam e atribuem — não atualizam UpdatedAt, não emitem evento.

    internal void SetDescription(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            throw BillErrors.ItemDescriptionRequired();
        if (value.Length > MAX_DESCRIPTION_LENGTH)
            throw BillErrors.ItemDescriptionTooLong(MAX_DESCRIPTION_LENGTH);
        Description = value;
    }

    internal void SetAmount(Money value)
    {
        if (value.Amount < 0)
            throw BillErrors.ItemAmountCannotBeNegative(value.Amount);
        Amount = value;
    }

    internal void SetCategoryCode(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            throw BillErrors.ItemCategoryRequired();
        if (value.Length > MAX_CATEGORY_CODE_LENGTH)
            throw BillErrors.ItemCategoryCodeTooLong(MAX_CATEGORY_CODE_LENGTH);
        CategoryCode = value;
    }

    // Métodos de mutação internal (Root chama). Atualizam UpdatedAt; eventos ficam na Root.
    internal void ChangeAmount(Money newAmount, DateTime occurredAt)
    {
        SetAmount(newAmount);     // reusa validação
        UpdatedAt = occurredAt;
    }
}
```

### Pontos

- Herda de `Entity<BillItemId>` (não de `AggregateRoot`).
- `sealed class`.
- `internal` no construtor que recebe argumentos e nos setters/métodos — só a Root (no mesmo assembly) acessa.
- Construtor sem parâmetros `private` para EF/serializadores.
- `Id` strongly-typed herdado da base.
- `CreatedAt` / `UpdatedAt` herdadas da base, atualizadas em cada mutação.
- **Setters `internal` reutilizáveis**: cada propriedade com validação tem `SetXxx` próprio; construtor e métodos de mutação reusam.
- **Não emite eventos** — eventos são exclusividade de Aggregate Root. Se algo "interessante" acontecer em uma Entity interna, ela termina retornando algo para a Root, e a Root é quem emite.

## Aggregate Root

```csharp
namespace AccountsPayable.Domain.Bills;

public sealed class Bill : AggregateRoot<BillId>
{
    // Public: limites de domínio que infra precisa replicar
    public const int MAX_NOTES_LENGTH = 1000;

    // Private: defaults e limites operacionais — infra não precisa replicar.
    private const string DEFAULT_CURRENCY = "BRL";
    private const int MAX_ITEMS_PER_BILL = 200;

    private readonly List<BillItem> _items = [];

    public SupplierId SupplierId { get; private set; }
    public Money TotalAmount { get; private set; } = default!;
    public DueDate DueDate { get; private set; } = default!;
    public BillStatus Status { get; private set; } = default!;
    public string? Notes { get; private set; }
    public IReadOnlyCollection<BillItem> Items => _items.AsReadOnly();

    // EF / rehydration
    private Bill() : base() { }

    private Bill(BillId id) : base(id) { }

    // Factory: only legitimate way to create
    public static Bill Create(
        BillId id,
        SupplierId supplierId,
        DueDate dueDate,
        DateTime occurredAt)
    {
        var bill = new Bill(id);
        bill.SetSupplierId(supplierId);
        bill.SetDueDate(dueDate);
        bill.Status = BillStatus.Draft;
        bill.TotalAmount = Money.Zero(DEFAULT_CURRENCY);
        bill.CreatedAt = occurredAt;
        bill.UpdatedAt = occurredAt;

        bill.AddDomainEvent(new BillCreated(
            EventId: Guid.NewGuid(),
            BillId: id,
            SupplierId: supplierId,
            OccurredAt: occurredAt));

        return bill;
    }

    // Setters privados — única fonte de validação por propriedade.
    // Validam e atribuem; não atualizam UpdatedAt, não emitem evento, não checam estado.

    private void SetSupplierId(SupplierId value)
    {
        if (value.Equals(SupplierId.Empty))
            throw BillErrors.SupplierIdRequired();
        SupplierId = value;
    }

    private void SetDueDate(DueDate value)
    {
        DueDate = value ?? throw BillErrors.DueDateRequired();
    }

    private void SetNotes(string? value)
    {
        if (value is not null && value.Length > MAX_NOTES_LENGTH)
            throw BillErrors.NotesTooLong(MAX_NOTES_LENGTH);
        Notes = value;
    }

    // Métodos públicos de mutação — verbo de negócio.
    // Cuidam de invariante de estado, UpdatedAt e Domain Event; delegam validação aos setters.

    public void AddItem(string description, Money amount, string categoryCode, DateTime occurredAt)
    {
        EnsureCanModify();

        if (_items.Count >= MAX_ITEMS_PER_BILL)
            throw BillErrors.MaxItemsExceeded(MAX_ITEMS_PER_BILL);

        var item = new BillItem(
            BillItemId.New(),
            description,
            amount,
            categoryCode,
            occurredAt);

        _items.Add(item);
        RecalculateTotal();
        UpdatedAt = occurredAt;
    }

    public void ChangeNotes(string? newNotes, DateTime occurredAt)
    {
        EnsureCanModify();
        SetNotes(newNotes);             // ← reusa validação
        UpdatedAt = occurredAt;
        AddDomainEvent(new BillNotesChanged(
            EventId: Guid.NewGuid(),
            BillId: Id,
            OccurredAt: occurredAt));
    }

    public void Reschedule(DueDate newDueDate, DateTime occurredAt)
    {
        EnsureCanModify();
        SetDueDate(newDueDate);         // ← reusa validação
        UpdatedAt = occurredAt;
        AddDomainEvent(new BillRescheduled(
            EventId: Guid.NewGuid(),
            BillId: Id,
            NewDueDate: newDueDate.Value,
            OccurredAt: occurredAt));
    }

    public void SubmitForApproval(DateTime occurredAt)
    {
        EnsureTransitionAllowed(BillStatus.AwaitingApproval);
        if (_items.Count == 0)
            throw BillErrors.EmptyBillCannotBeSubmitted();

        Status = BillStatus.AwaitingApproval;
        UpdatedAt = occurredAt;

        AddDomainEvent(new BillSubmittedForApproval(
            EventId: Guid.NewGuid(),
            BillId: Id,
            OccurredAt: occurredAt));
    }

    public void Approve(UserId approver, DateTime occurredAt)
    {
        EnsureTransitionAllowed(BillStatus.Approved);

        Status = BillStatus.Approved;
        UpdatedAt = occurredAt;

        AddDomainEvent(new BillApproved(
            EventId: Guid.NewGuid(),
            BillId: Id,
            ApprovedBy: approver,
            Amount: TotalAmount.Amount,
            Currency: TotalAmount.Currency,
            OccurredAt: occurredAt));
    }

    // Auxiliary invariants
    private void EnsureCanModify()
    {
        if (!Status.Equals(BillStatus.Draft))
            throw BillErrors.CannotModifyBillInStatus(Status.Name);
    }

    private void EnsureTransitionAllowed(BillStatus target)
    {
        if (!Status.CanTransitionTo(target))
            throw BillErrors.InvalidStatusTransition(Status.Name, target.Name);
    }

    private void RecalculateTotal()
    {
        var sum = _items
            .Select(i => i.Amount)
            .Aggregate(Money.Zero(DEFAULT_CURRENCY), (acc, m) => acc.Add(m));
        TotalAmount = sum;
    }
}
```

### Pontos não-negociáveis

- `sealed class` herdando de `AggregateRoot`.
- Construtor sem parâmetros `private` (EF/reidratação).
- Construtor com `<Aggregate>Id id` `private` + factory `Create` estática **pública** (única forma legítima de criar).
- `_items` privado como `List<T>`, exposto como `IReadOnlyCollection<T>`.
- Mutação de Entity interna **somente** via método da Root — nunca `bill.Items.Add(...)` ou `bill.Items[0].ChangeAmount(...)` direto. A Root delega.
- Cada método público:
  1. Verifica invariantes (lança via factory de erros).
  2. Muta estado.
  3. Atualiza `UpdatedAt`.
  4. Emite Domain Event via `AddDomainEvent` (quando significativo).
- `DateTime occurredAt` sempre recebido por parâmetro — não usar `DateTime.UtcNow` direto (exceção: `Create` pode aceitar `occurredAt` ou usar `DateTime.UtcNow` se o usuário do projeto preferir).
- Outros Aggregates referenciados por **`Guid`** (`SupplierId`), nunca por instância da classe (`Supplier`).

## Domain Event

```csharp
namespace AccountsPayable.Domain.Bills.Events;

using AccountsPayable.Domain.SeedWork;
using AccountsPayable.Domain.Users;

public sealed record BillApproved(
    Guid EventId,
    BillId BillId,
    UserId ApprovedBy,
    decimal Amount,
    string Currency,
    DateTime OccurredAt) : IDomainEvent;
```

### Regras

- Sempre `sealed record` (records são adequados aqui — DTOs imutáveis sem comportamento).
- Implementa `IDomainEvent` (`EventId`, `OccurredAt`).
- Nome no passado em **inglês**: `BillApproved`, `OrderPlaced`, `CustomerOnboarded` — nunca `ApproveBill`, nunca `BillApprovedEvent` (sufixo `Event` é redundante).
- **IDs strongly-typed no payload** (`BillId`, `UserId`) — consistência com o resto do domínio. **Não** colocar VOs ricos do domínio no payload (eventos são serializados; só Ids strongly-typed e tipos primitivos).
- `EventId = Guid.NewGuid()` no momento da emissão (este é metadata do evento, não Id de domínio — fica como `Guid` puro).

## Coleções no domínio

### Princípio fundamental

**Nenhuma coleção pública pode permitir mutação externa.** Se o caller consegue fazer `bill.Items.Add(...)`, `bill.Items.Remove(...)`, `bill.Items[0] = x`, ou `bill.Items.Clear()` sem passar por um método do Aggregate Root, **as invariantes podem ser furadas em silêncio**: total dos items deixa de bater com `TotalAmount`, item adicionado fora de horário válido, item em status que não permite, etc.

A coleção interna (campo privado) é um **detalhe de implementação**. O que o mundo externo vê é uma **visão somente leitura** dela.

### Padrão obrigatório

```csharp
public sealed class Bill : AggregateRoot<BillId>
{
    // Campo privado: List<T> mutável (o Aggregate precisa para suas mutações internas)
    private readonly List<BillItem> _items = [];

    // Propriedade pública: IReadOnlyCollection<T> via .AsReadOnly()
    public IReadOnlyCollection<BillItem> Items => _items.AsReadOnly();

    // Mutação acontece SEMPRE via método do Root:
    public void AddItem(string description, Money amount, string categoryCode, DateTime occurredAt)
    {
        EnsureCanModify();
        var item = new BillItem(BillItemId.New(), description, amount, categoryCode);
        _items.Add(item);            // OK: mutação interna controlada
        RecalculateTotal();          // mantém invariante: total = soma
        UpdatedAt = occurredAt;
    }
}
```

### Por que `.AsReadOnly()` e não cast

`IReadOnlyCollection<T>` é só uma **interface**. O objeto subjacente continua sendo um `List<T>` mutável. Há duas formas de expor:

❌ **Errado — vaza mutação via cast**:
```csharp
public IReadOnlyCollection<BillItem> Items => _items;
```

Aparentemente seguro, mas o caller pode fazer:
```csharp
var items = (List<BillItem>)bill.Items;   // downcast funciona
items.Add(itemQualquer);                   // modifica a lista interna do Bill!
```

Pronto, invariante furada. `TotalAmount` agora está dessincronizado de `Items`.

✅ **Correto — `.AsReadOnly()` retorna wrapper imutável**:
```csharp
public IReadOnlyCollection<BillItem> Items => _items.AsReadOnly();
```

`.AsReadOnly()` retorna um `ReadOnlyCollection<T>` que **embrulha** a `List<T>`. Tentativa de cast falha:
```csharp
var items = (List<BillItem>)bill.Items;   // InvalidCastException
```

E não há `Add`, `Remove`, indexador `set`, ou `Clear` no `ReadOnlyCollection<T>`.

### Quando usar `IReadOnlyCollection<T>` vs `IReadOnlyList<T>`

Ambos protegem mutação. A diferença é o que oferecem ao caller:

| Interface | Métodos disponíveis | Quando usar |
|---|---|---|
| `IReadOnlyCollection<T>` | `Count`, `GetEnumerator()` (foreach) | **Default**. Use sempre que ordem ou índice não importa. |
| `IReadOnlyList<T>` | `IReadOnlyCollection<T>` + indexador `[i]` | Use quando a **ordem é semanticamente significativa** e o caller pode precisar acessar por índice. |

Default seguro é `IReadOnlyCollection<T>` — só promova a `IReadOnlyList<T>` quando há razão clara (ex.: `IReadOnlyList<HistoryEntry> History` em ordem cronológica).

### Coleções na assinatura de **entrada** de métodos

Ao **receber** uma coleção como parâmetro de método (caso raro no domínio, mas acontece em factories e Domain Services), use também `IReadOnlyCollection<T>` ou `IReadOnlyList<T>` — o domínio não deve mutar o que recebe.

```csharp
public sealed class CreditRiskAssessmentService
{
    // Recebe IReadOnlyCollection<T>: o Service não vai mutar a lista do caller
    public CreditRisk Assess(Customer customer, IReadOnlyCollection<Bill> openBills)
    {
        // ...só itera, nunca modifica
    }
}
```

Se internamente precisa de uma cópia mutável, faça `openBills.ToList()` para criar uma cópia local.

### Arrays no domínio

**Arrays são mutáveis** (`array[i] = x` funciona). **Nunca exponha arrays públicos** em propriedades de Aggregate/Entity:

❌ **Errado**:
```csharp
public string[] Tags { get; private set; }   // caller faz Tags[0] = "qualquer coisa"
```

✅ **Correto**:
```csharp
private readonly List<string> _tags = [];
public IReadOnlyCollection<string> Tags => _tags.AsReadOnly();
```

Use array só **dentro de métodos privados**, como buffer temporário, nunca como estado exposto.

### `Dictionary<K,V>` e outras coleções

Mesmo princípio. Se for guardar mapa interno, exponha como `IReadOnlyDictionary<K,V>`:

```csharp
private readonly Dictionary<string, decimal> _ratesByCurrency = new();
public IReadOnlyDictionary<string, decimal> RatesByCurrency => _ratesByCurrency;
```

`Dictionary<K,V>` **já implementa** `IReadOnlyDictionary<K,V>` — o cast direto **é seguro** porque a interface não expõe métodos de mutação. Mas o caller pode fazer downcast `(Dictionary<K,V>)bill.RatesByCurrency` e mutar. Para ficar **paranoicamente seguro**, copie ou use `ReadOnlyDictionary<K,V>`:

```csharp
public IReadOnlyDictionary<string, decimal> RatesByCurrency
    => new ReadOnlyDictionary<string, decimal>(_ratesByCurrency);
```

Decida caso a caso. Para a maioria dos domínios, `IReadOnlyDictionary<K,V>` direto basta — o esforço de cast malicioso é claro o bastante para code review pegar.

### Resumo da regra (checklist mental)

Quando uma propriedade do Aggregate/Entity expõe coleção:

- [ ] Campo privado é `List<T>` (ou `Dictionary<K,V>`) mutável — o Aggregate precisa.
- [ ] Propriedade pública usa **`IReadOnlyCollection<T>`** (ou `IReadOnlyList<T>` se ordem por índice importa).
- [ ] Propriedade tem `.AsReadOnly()` aplicado (`_items.AsReadOnly()`), **não cast direto** (`_items`).
- [ ] **Sem `set` público** (`{ get; private set; }` ou expression-bodied `=>`).
- [ ] Mutação só acontece via métodos do Aggregate Root (`AddItem`, `RemoveItem`, `ChangeItemQuantity`).
- [ ] Nada de `List<T>`, `ICollection<T>`, `IList<T>`, `T[]` em propriedades públicas.

### Exemplo completo errado vs certo

❌ **Múltiplas brechas**:
```csharp
public sealed class Bill : AggregateRoot<BillId>
{
    public List<BillItem> Items { get; private set; } = [];        // ❌ List público
    public string[] Tags { get; private set; } = [];                // ❌ array público
    public Dictionary<string, decimal> Discounts { get; }            // ❌ dictionary mutável
        = new();
}

// Uso externo possível:
bill.Items.Add(new BillItem(...));        // ❌ adiciona sem invariante
bill.Items.Clear();                        // ❌ apaga tudo
bill.Tags[0] = "...";                      // ❌ muta array
bill.Discounts["VIP"] = 0.5m;              // ❌ adiciona desconto sem regra
```

✅ **Encapsulado**:
```csharp
public sealed class Bill : AggregateRoot<BillId>
{
    private readonly List<BillItem> _items = [];
    private readonly List<string> _tags = [];
    private readonly Dictionary<string, decimal> _discounts = new();

    public IReadOnlyCollection<BillItem> Items => _items.AsReadOnly();
    public IReadOnlyCollection<string> Tags => _tags.AsReadOnly();
    public IReadOnlyDictionary<string, decimal> Discounts => _discounts;

    public void AddItem(...) { /* valida + _items.Add + recalcula total */ }
    public void AddTag(string tag, DateTime occurredAt) { /* valida + _tags.Add */ }
    public void ApplyDiscount(string code, decimal pct, DateTime occurredAt) { /* valida + _discounts[code] = pct */ }
}
```

## Tratamento de erros

→ Padrão completo em `references/exception-pattern.md`. Resumo:

- Existe **um único tipo** de exception de domínio: `DomainException`.
- Aggregates, Entities e VOs **nunca instanciam `DomainException` diretamente** — sempre via factory `<Aggregate>Errors.<Method>()`.
- IDs no padrão `<BC>.<AGG>##` (Aggregate) ou `<BC>##` (genérico do BC).
- Mensagens em **português**, parâmetros separados, sem dado sensível.

## Equality

- VOs: igualdade definida por `GetEqualityComponents()` — herdado de `ValueObject`.
- Entities (incluindo Aggregate Roots): igualdade por `Id` + tipo — herdado de `Entity`.
- Smart Enums: igualdade por `Id` + tipo — herdado de `Enumeration`.

## Async no domínio

**Default: domínio é síncrono.** Não use `async` em métodos do Aggregate. Operações I/O ficam em Repository/Service da camada de aplicação.

Exceção: se o domínio precisar consultar Domain Service que é async (ex.: verificação externa via ACL), aceite — mas sinalize ao usuário que isso costuma ser sintoma de regra que deveria estar em Application Service.

## Reidratação a partir de persistência

EF Core (ou outro ORM) precisa instanciar o Aggregate com state existente, sem disparar eventos de criação.

Para isso, todos os Aggregates e Entities têm:
- Construtor sem parâmetros `private` (EF instancia via reflexão).
- Propriedades com `private set` (EF popula via reflexão).
- Coleções privadas com `_camelCase` que EF conhece via configuração.

Se o ORM não conseguir popular satisfatoriamente, gere uma factory de reidratação `internal`:

```csharp
internal static Bill Rehydrate(
    BillId id,
    SupplierId supplierId,
    Money totalAmount,
    DueDate dueDate,
    BillStatus status,
    IEnumerable<BillItem> items,
    DateTime createdAt,
    DateTime updatedAt)
{
    var bill = new Bill(id)
    {
        SupplierId = supplierId,
        TotalAmount = totalAmount,
        DueDate = dueDate,
        Status = status,
        CreatedAt = createdAt,
        UpdatedAt = updatedAt
    };
    bill._items.AddRange(items);
    // Does not emit events — this is state reconstruction, not a new fact.
    return bill;
}
```

Use só se EF não conseguir reconstituir via construtor + setters privados.
