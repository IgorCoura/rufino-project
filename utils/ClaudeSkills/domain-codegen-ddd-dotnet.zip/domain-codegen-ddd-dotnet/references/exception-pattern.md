# Padrão de Exceptions de Domínio

> **Toda violação de invariante neste projeto usa este padrão.** Aggregates **nunca** instanciam `DomainException` diretamente — sempre chamam uma factory centralizada. A `DomainException` é uma classe única, padronizada.

## Estrutura

Cada exception de domínio carrega:

| Campo | Tipo | Descrição |
|---|---|---|
| `Id` | `string` | Identificador único — formato `XXX.YYY##` (Aggregate) ou `XXX##` (genérico do BC) |
| `MessageTemplate` | `string` | Template da mensagem com placeholders `{0}`, `{1}`, ... |
| `Parameters` | `IReadOnlyList<object>` | Valores que foram interpolados (capturáveis programaticamente) |
| `SourcePath` | `string` | Origem no código no formato `Arquivo.cs:linha (Método)` |
| `Message` (herdado) | `string` | `MessageTemplate` formatado com `Parameters` |

## Convenção do ID

### Formato

- **Erro de Aggregate**: `<BC>.<AGG><N>` — três letras maiúsculas + ponto + três letras maiúsculas + número.
  - Ex.: `PMD.EMP10` = People Management Domain → Employee → erro 10
  - Ex.: `APD.BIL01` = Accounts Payable Domain → Bill → erro 1

- **Erro genérico do Bounded Context**: `<BC><N>` — três letras maiúsculas + número.
  - Ex.: `PMD10` = People Management Domain → erro genérico 10
  - Use quando o erro **se aplica a vários Aggregates do mesmo BC** (ex.: tenant não autorizado, regra transversal).

- **Erro do SeedWork** (transversal a todo o sistema, lançado por classes-base): `SWK<N>`.
  - Ex.: `SWK01` = SeedWork → erro 1 (ex.: "Id não pode ser Guid.Empty").
  - A sigla `SWK` é **reservada** — não use para outro BC.

### Regex de validação

```
^[A-Z]{3}(\.[A-Z]{3})?\d+$
```

- `[A-Z]{3}` — exatamente 3 letras maiúsculas (sigla do BC ou `SWK`)
- `(\.[A-Z]{3})?` — opcionalmente, ponto + 3 letras maiúsculas (sigla do Aggregate)
- `\d+` — um ou mais dígitos (número crescente)

### Numeração

- Numeração é **crescente por arquivo de errors**. `BillErrors.cs` começa em `01` e vai até `NN`.
- Erros novos vão para o **fim** da numeração. **Nunca renumere** erros existentes — o ID é contrato com clientes/logs.
- Erros descontinuados ficam comentados no arquivo com `// [DESCONTINUADO em yyyy-MM-dd] APD.BIL05 - razão` para não reusar o número.

### Padronização de siglas

A sigla do BC e do Aggregate é definida pelo programador no início do BC. Documente em comentário no topo de cada arquivo de erros:

```csharp
// BC: APD (Accounts Payable Domain)
// Aggregate: BIL (Bill)
```

Sigla **`SWK`** é reservada e **fixa** para erros do SeedWork — não use para outros BCs.

## Mensagens — regras de segurança e estilo

### NUNCA incluir nas mensagens ou parâmetros

- Senhas, tokens, chaves de API, segredos.
- Hashes de credenciais.
- Dados de outros tenants.
- IDs externos sigilosos (números completos de cartão, CPF/CNPJ exceto últimos dígitos quando justificado).
- Stack traces internos.
- Caminhos de arquivos do servidor.
- Endereços de IP, URLs internas.

### Sempre incluir nas mensagens

- O **conceito de negócio** afetado (ex.: "Bill", "Employee").
- O **estado/valor relevante** que causou o erro (ex.: status atual, ID do Aggregate em formato público).
- A **regra violada** em poucas palavras.

### Estilo

- Mensagem em **português** (linguagem do usuário do projeto).
- Curta: 1 frase, sem jargão técnico.
- Sempre termina com ponto final.
- **Não** começa com "Erro:" ou "Falha:" — o ID já comunica que é erro.
- Use `{0}`, `{1}`, `{2}`... para placeholders, na ordem em que `Parameters` é passado.

### Bons vs maus exemplos

✅ Bom:
```
"Transição inválida de status: {0} → {1}."
Parameters: ["DRAFT", "PAID"]
→ "Transição inválida de status: DRAFT → PAID."
```

✅ Bom:
```
"Bill com status {0} não pode ser modificada."
Parameters: ["PAID"]
```

❌ Ruim (vaza interno):
```
"Falha ao executar UPDATE em tb_bill com id 7e3..."
```

❌ Ruim (sem contexto):
```
"Operação inválida."
```

❌ Ruim (vaza dado sensível):
```
"Token {0} expirado."
Parameters: ["eyJhbGciOiJIUzI1..."]
```

## Classe `DomainException`

### Implementação

```csharp
// <BoundedContext>.Domain/SeedWork/DomainException.cs
namespace <BoundedContext>.Domain.SeedWork;

using System.Text.RegularExpressions;

public sealed class DomainException : Exception
{
    private static readonly Regex ID_PATTERN = 
        new(@"^[A-Z]{3}(\.[A-Z]{3})?\d+$", RegexOptions.Compiled);

    public string Id { get; }
    public string MessageTemplate { get; }
    public IReadOnlyList<object> Parameters { get; }
    public string SourcePath { get; }

    public DomainException(
        string id,
        string messageTemplate,
        IReadOnlyList<object> parameters,
        string sourcePath)
        : base(BuildMessage(messageTemplate, parameters))
    {
        if (string.IsNullOrWhiteSpace(id))
            throw new ArgumentException("Id is required.", nameof(id));
        if (!ID_PATTERN.IsMatch(id))
            throw new ArgumentException(
                $"Id '{id}' does not match pattern XXX## or XXX.YYY##.", nameof(id));
        if (string.IsNullOrWhiteSpace(messageTemplate))
            throw new ArgumentException(
                "MessageTemplate is required.", nameof(messageTemplate));
        if (parameters is null)
            throw new ArgumentNullException(nameof(parameters));
        if (parameters.Any(p => p is null))
            throw new ArgumentException(
                "Parameters cannot contain null values.", nameof(parameters));
        if (string.IsNullOrWhiteSpace(sourcePath))
            throw new ArgumentException(
                "SourcePath is required.", nameof(sourcePath));

        Id = id;
        MessageTemplate = messageTemplate;
        Parameters = parameters;
        SourcePath = sourcePath;
    }

    private static string BuildMessage(string template, IReadOnlyList<object> parameters)
    {
        if (string.IsNullOrWhiteSpace(template))
            return template ?? string.Empty;
        if (parameters is null || parameters.Count == 0)
            return template;
        return string.Format(template, parameters.ToArray());
    }

    public override string ToString() =>
        $"[{Id}] {Message} | at {SourcePath}";
}
```

### Notas

- `ArgumentException` (e não `DomainException` recursivamente) para falhas de validação **da própria exception** — são bugs de programação, não regras de domínio.
- `BuildMessage` chamado no `: base(...)` antes da validação porque `Exception` exige `Message` no construtor base. Validação efetiva acontece logo depois; se algo estiver errado, lança `ArgumentException` no momento da criação.
- `ToString()` formata pra log: `[APD.BIL01] Transição inválida... | at Bill.cs:67 (Approve)`.

## Factory de erros — um arquivo por Aggregate

### Localização

Factory de erros de um Aggregate fica **junto com o Aggregate**, dentro do projeto do BC:

```
<BoundedContext>.Domain/
└── <Aggregate>/
    ├── <Aggregate>.cs                ← Aggregate Root
    ├── <Aggregate>Errors.cs          ← Factory de erros
    └── ...
```

Erros transversais ao BC (compartilhados entre vários Aggregates) ficam na **raiz do projeto do BC**:

```
<BoundedContext>.Domain/
└── <BoundedContext>Errors.cs         ← Erros genéricos do BC, na raiz
```

Erros transversais lançados pelas classes do `SeedWork` (`Entity`, `AggregateRoot`, `ValueObject`) ficam dentro de `SeedWork`:

```
<BoundedContext>.Domain/
└── SeedWork/
    └── SeedWorkErrors.cs             ← Erros do SeedWork — sigla SWK
```

A sigla **`SWK`** é reservada para erros do SeedWork. Use o padrão `SWK##` (sem ponto). Estes são erros técnicos de invariante das próprias classes-base — geralmente coisas como "Id não pode ser Guid.Empty", "GetEqualityComponents retornou null", etc.

### Template de factory

```csharp
// AccountsPayable.Domain/Bills/BillErrors.cs
namespace AccountsPayable.Domain.Bills;

using System.IO;
using System.Runtime.CompilerServices;
using AccountsPayable.Domain.SeedWork;

// BC: APD (Accounts Payable Domain)
// Aggregate: BIL (Bill)
internal static class BillErrors
{
    private const string AGGREGATE_PREFIX = "APD.BIL";

    public static DomainException InvalidStatusTransition(
        string currentStatus,
        string targetStatus,
        [CallerFilePath] string filePath = "",
        [CallerMemberName] string memberName = "",
        [CallerLineNumber] int lineNumber = 0)
        => new(
            id: $"{AGGREGATE_PREFIX}01",
            messageTemplate: "Transição inválida de status: {0} → {1}.",
            parameters: new object[] { currentStatus, targetStatus },
            sourcePath: BuildSourcePath(filePath, memberName, lineNumber));

    public static DomainException CannotModifyPaidBill(
        [CallerFilePath] string filePath = "",
        [CallerMemberName] string memberName = "",
        [CallerLineNumber] int lineNumber = 0)
        => new(
            id: $"{AGGREGATE_PREFIX}02",
            messageTemplate: "Bill paga é imutável.",
            parameters: Array.Empty<object>(),
            sourcePath: BuildSourcePath(filePath, memberName, lineNumber));

    public static DomainException EmptyBillCannotBeSubmitted(
        [CallerFilePath] string filePath = "",
        [CallerMemberName] string memberName = "",
        [CallerLineNumber] int lineNumber = 0)
        => new(
            id: $"{AGGREGATE_PREFIX}03",
            messageTemplate: "Bill sem itens não pode ser submetida para aprovação.",
            parameters: Array.Empty<object>(),
            sourcePath: BuildSourcePath(filePath, memberName, lineNumber));

    public static DomainException ItemAmountCannotBeNegative(
        decimal attemptedAmount,
        [CallerFilePath] string filePath = "",
        [CallerMemberName] string memberName = "",
        [CallerLineNumber] int lineNumber = 0)
        => new(
            id: $"{AGGREGATE_PREFIX}04",
            messageTemplate: "Valor de item não pode ser negativo. Valor recebido: {0}.",
            parameters: new object[] { attemptedAmount },
            sourcePath: BuildSourcePath(filePath, memberName, lineNumber));

    private static string BuildSourcePath(string filePath, string memberName, int lineNumber)
        => $"{Path.GetFileName(filePath)}:{lineNumber} ({memberName})";
}
```

### Pontos importantes

- **`internal static class`** — só código do mesmo assembly do domínio acessa. Application/Infrastructure não devem importar factories de erros do domínio.
- **`AGGREGATE_PREFIX`** como `const` no topo da classe — facilita refatorar e evita typos. Constantes seguem o padrão `MAIÚSCULAS_COM_UNDERSCORE` no domínio.
- **`[CallerFilePath]`, `[CallerMemberName]`, `[CallerLineNumber]`** — atributos do C# preenchidos automaticamente pelo compilador no ponto da chamada.
- **Métodos sempre nomeados pela regra violada**, em PascalCase, descritivos: `InvalidStatusTransition`, `CannotModifyPaidBill`, `ItemAmountCannotBeNegative`.
- **Parameters sempre `new object[] { ... }`** ou `Array.Empty<object>()` — nunca `null`.
- **`BuildSourcePath` privado**, repetido em cada arquivo de errors — pequeno custo, mantém isolamento.

### Erros genéricos do BC

```csharp
// AccountsPayable.Domain/AccountsPayableErrors.cs
namespace AccountsPayable.Domain;

using System.IO;
using System.Runtime.CompilerServices;
using <BoundedContext>.Domain.SeedWork;

// BC: APD (Accounts Payable Domain) - erros transversais
internal static class AccountsPayableErrors
{
    private const string BC_PREFIX = "APD";

    public static DomainException TenantMismatch(
        string expectedTenantId,
        string actualTenantId,
        [CallerFilePath] string filePath = "",
        [CallerMemberName] string memberName = "",
        [CallerLineNumber] int lineNumber = 0)
        => new(
            id: $"{BC_PREFIX}01",
            messageTemplate: "Operação não permitida: tenant {0} não pode acessar recurso de {1}.",
            parameters: new object[] { actualTenantId, expectedTenantId },
            sourcePath: BuildSourcePath(filePath, memberName, lineNumber));

    private static string BuildSourcePath(string filePath, string memberName, int lineNumber)
        => $"{Path.GetFileName(filePath)}:{lineNumber} ({memberName})";
}
```

### Erros do SeedWork

Lançados pelas próprias classes-base (`Entity`, `AggregateRoot`, `ValueObject`). A classe é `internal` mas suas factories podem precisar ser `public` para serem chamadas pelas classes-base que são herdadas em outros assemblies.

```csharp
// <BoundedContext>.Domain/SeedWork/SeedWorkErrors.cs
namespace <BoundedContext>.Domain.SeedWork;

using System.IO;
using System.Runtime.CompilerServices;

// SeedWork (SWK) — erros transversais lançados pelas classes-base
public static class SeedWorkErrors
{
    private const string BC_PREFIX = "SWK";

    public static DomainException EmptyId(
        string entityTypeName,
        [CallerFilePath] string filePath = "",
        [CallerMemberName] string memberName = "",
        [CallerLineNumber] int lineNumber = 0)
        => new(
            id: $"{BC_PREFIX}01",
            messageTemplate: "Id de {0} não pode ser Guid.Empty.",
            parameters: new object[] { entityTypeName },
            sourcePath: BuildSourcePath(filePath, memberName, lineNumber));

    private static string BuildSourcePath(string filePath, string memberName, int lineNumber)
        => $"{Path.GetFileName(filePath)}:{lineNumber} ({memberName})";
}
```

A base `Entity<TId>` consome essa factory:

```csharp
protected Entity(TId id)
{
    if (id.Equals(TId.Empty))
        throw SeedWorkErrors.EmptyId(this.GetType().Name);
    _Id = id;
}

public virtual TId Id
{
    get => _Id;
    protected set
    {
        if (value.Equals(TId.Empty))
            throw SeedWorkErrors.EmptyId(this.GetType().Name);
        _Id = value;
    }
}
```

## Uso no Aggregate

```csharp
public sealed class Bill : AggregateRoot<BillId>
{
    // ...

    public void Approve(UserId approver, DateTime occurredAt)
    {
        if (!Status.CanTransitionTo(BillStatus.Approved))
            throw BillErrors.InvalidStatusTransition(Status.Name, "APPROVED");

        Status = BillStatus.Approved;
        AddDomainEvent(new BillApproved(...));
    }

    public void AddItem(string description, Money amount, string categoryCode)
    {
        if (Status.Equals(BillStatus.Paid))
            throw BillErrors.CannotModifyPaidBill();

        if (amount.Amount < 0)
            throw BillErrors.ItemAmountCannotBeNegative(amount.Amount);

        // ...
    }

    public void SubmitForApproval(DateTime occurredAt)
    {
        if (!Status.CanTransitionTo(BillStatus.AwaitingApproval))
            throw BillErrors.InvalidStatusTransition(Status.Name, "AWAITING_APPROVAL");

        if (_items.Count == 0)
            throw BillErrors.EmptyBillCannotBeSubmitted();

        Status = BillStatus.AwaitingApproval;
        AddDomainEvent(new BillSubmittedForApproval(...));
    }
}
```

**Note**: o Aggregate **só consome** as factories. Nenhuma string literal de erro, nenhuma instância direta de `DomainException`.

## Catálogo central (opcional, recomendado)

Para projetos grandes, mantenha um arquivo `docs/error-catalog.md` listando todos os IDs em uso, mensagens, e onde estão definidos. Pode ser gerado por script lendo as factories.

```markdown
# Catálogo de Erros de Domínio

## APD — Accounts Payable Domain

### Genéricos (APD##)
- `APD01` — Operação não permitida: tenant {0} não pode acessar recurso de {1}.
  - Definido em: `AccountsPayableErrors.cs`

### Bill (APD.BIL##)
- `APD.BIL01` — Transição inválida de status: {0} → {1}.
- `APD.BIL02` — Bill paga é imutável.
- `APD.BIL03` — Bill sem itens não pode ser submetida para aprovação.
- `APD.BIL04` — Valor de item não pode ser negativo. Valor recebido: {0}.
  - Definidos em: `BillErrors.cs`
```

A skill **não gera** este catálogo automaticamente, mas pode oferecer-se a atualizá-lo se o usuário tiver um.

## Checklist ao adicionar um novo erro

- [ ] Identificou o BC e o Aggregate?
- [ ] Sigla do BC tem 3 letras maiúsculas? Sigla do Aggregate idem?
- [ ] Número é o próximo crescente no arquivo (não reusou número descontinuado)?
- [ ] Mensagem está em PT, curta, sem jargão técnico?
- [ ] Mensagem **não vaza** dado sensível?
- [ ] Placeholders `{0}, {1}, ...` correspondem à ordem dos parâmetros?
- [ ] Método tem `[CallerFilePath]`, `[CallerMemberName]`, `[CallerLineNumber]`?
- [ ] Aggregate consome a factory (não cria `DomainException` direto)?

## Quando o erro é "técnico" e não de domínio

Se o erro **não é violação de invariante de negócio** mas sim falha técnica (DB indisponível, timeout, deserialização inválida), **não use `DomainException`**. Use `InvalidOperationException`, `ArgumentException`, `IOException`, etc., conforme apropriado. `DomainException` é exclusiva para regras do domínio.

Exemplos:
- "Status inválido para transição" → `DomainException` (regra de domínio).
- "Falha ao serializar evento para outbox" → `InvalidOperationException` (técnico).
- "Tenant não autorizado" → `DomainException` (regra de domínio: isolamento multi-tenant).
- "Conexão com banco perdida" → `IOException` ou específico do driver (técnico).
