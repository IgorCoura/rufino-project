---
name: domain-codegen-ddd-dotnet
description: "Use SEMPRE que o usuário pedir código C# / .NET de domínio seguindo Domain-Driven Design tático. Três cenários: (1) traduzir markdown de modelo em código, (2) editar/expandir domínio C# existente, (3) criar domínio direto no código sem markdown prévio. Dispare em: 'gera o código desse Aggregate', 'codifica em C#', 'adiciona método X', 'isso é VO ou Entity?', 'cria um Aggregate para Z', 'preciso emitir evento quando', 'refatora esse Aggregate', 'cria um Domain Service para'. Produz Aggregate Root + Entities + Value Objects + Domain Events + Domain Services (quando regra envolve múltiplos Aggregates) + suporte a Outbox, em C# moderno (.NET 8+), seguindo Implementing Domain-Driven Design (Vernon). Inclui modelagem básica (VO/Entity, fronteira de Aggregate, quando emitir evento, Domain Service vs método de Aggregate). NÃO use para design estratégico (Bounded Contexts), outras linguagens, ou gerar Repository/Application Service/testes sem pedido explícito."
---

# DDD .NET Codegen

Skill especializada em **escrever código C# / .NET de domínio** seguindo DDD tático.

Cobre três cenários:

1. **Markdown → código**: usuário traz modelo planejado, skill traduz fielmente.
2. **Editar domínio existente**: adicionar método, evento, VO, mudar invariante, refatorar.
3. **Criar direto no código**: usuário descreve o que precisa, skill modela o suficiente e codifica.

Para os cenários 2 e 3, a skill faz **modelagem básica** — o necessário pra escolhas seguras, sem virar consultora de DDD.

## Escopo

✅ A skill GERA:
- **Aggregate Root** (classe selada, factory `Create`, identidade, comportamentos, invariantes, emissão de eventos)
- **Entity interna** do Aggregate (identidade própria, mutável só via Root)
- **Value Object** (`record` com igualdade por valor, validação no construtor)
- **Domain Event** (`record` imutável)
- **Suporte a Outbox** (acúmulo via `AddDomainEvent` e drenagem via `PullDomainEvents`)
- **Domain Service** (classe stateless quando uma regra envolve múltiplos Aggregates) — detalhes em `references/domain-services.md`

❌ A skill NÃO gera, a menos que o usuário peça explicitamente:
- Repository, Application Service, Specifications, testes, migrations, EF config, controllers.

## Bounded Contexts e organização de projetos

**Cada Bounded Context é seu próprio projeto .NET separado.** A solução típica tem múltiplos projetos `<BoundedContext>.Domain/` lado a lado:

```
src/
├── AccountsPayable.Domain/
├── BillIngestion.Domain/
├── ContractManagement.Domain/
└── ...
```

Por isso, **dentro de cada projeto não há camada `<BoundedContext>/`** — o projeto inteiro já É o BC. Aggregates ficam direto na raiz do projeto.

### A skill NÃO cria, sugere ou move Bounded Contexts

Definir quais BCs existem é **decisão estratégica do usuário** (e/ou de um modelador de domínio sênior). Esta skill é tática: gera código **dentro** de um BC já decidido.

A skill **NUNCA**:
- Cria um projeto novo de Bounded Context.
- Sugere "vou colocar isso num BC novo chamado X".
- Move código entre projetos automaticamente.
- Decide que um Aggregate "está no BC errado" e arrasta para outro.

A skill **SEMPRE**:
- Pergunta em qual projeto/BC o código deve ser gerado, se o usuário não especificou.
- Confirma com o usuário antes de gerar, se o BC indicado parecer estranho ("Tem certeza que `Contract` vai em `AccountsPayable.Domain` e não em `ContractManagement.Domain`?"). Pode ser intencional, pode ser engano — nunca decida sozinha.
- Gera código respeitando o nome de projeto e namespace que o usuário indicou.

Se o usuário ainda não decidiu o BC e está em fase exploratória, **encaminhe**: "Esta é uma decisão estratégica de DDD. Posso gerar o código assumindo um nome temporário (ex.: `Project.Domain`) e você ajusta depois quando definir o BC. Confirma?"

## Modelagem básica (o mínimo necessário)

Quando o usuário descreve algo sem ter modelado, ou quando edita um domínio existente, a skill precisa fazer 3 escolhas. Use as perguntas-mãe abaixo. **Se a resposta não for clara, pergunte ao usuário antes de codar.**

### É Value Object ou Entity?

> **Pergunta-mãe**: "Se eu trocar essa instância por outra com os mesmos atributos, quebra alguma coisa?"

- **Não quebra → Value Object.** Definido pelos atributos. Imutável. Igualdade por valor. Ex.: `Money`, `EmailAddress`, `Address`, `DateRange`.
- **Quebra (preciso rastrear "este" objeto ao longo do tempo) → Entity.** Tem identidade estável (`Id`). Atributos podem mudar; o `Id` não. Ex.: `Customer`, `Order`, `BillItem`.

Sinais de VO disfarçado de Entity:
- Você não precisa modificar atributos isoladamente (sempre cria de novo).
- Não há histórico de versões "deste" objeto específico.
- Não há referência por ID a essa coisa.

Sinais de Entity disfarçada de VO:
- "Quero rastrear mudanças ao longo do tempo."
- Outros objetos referenciam isto por ID.
- Há ciclo de vida (criação, modificações, encerramento).

### É Aggregate próprio ou parte de outro?

> **Pergunta-mãe**: "Esses objetos PRECISAM mudar juntos na MESMA transação para manter alguma regra consistente?"

- **Sim → mesmo Aggregate.** A regra exige atomicidade. Um deles é Root; os outros são Entities/VOs internos. Ex.: `Bill` + `BillItem` (total = soma dos itens).
- **Não, podem ficar consistentes "depois" → Aggregates separados.** Referenciam-se por **ID**, não por objeto. Mudanças se propagam por **Domain Event**. Ex.: `Bill` referencia `SupplierId`, não `Supplier`.

Default: **comece pequeno.** Cada Entity é seu próprio Aggregate, a menos que haja uma regra clara que exige consistência transacional.

Sinais de Aggregate grande demais (refatore quebrando):
- Coleção sem limite ("todos os pedidos do cliente").
- Carregar uma operação simples puxa dezenas de objetos.
- Locks/conflicts frequentes na mesma raiz.

### Esse comportamento gera Domain Event?

> **Pergunta-mãe**: "Outro Aggregate, outro Bounded Context, ou um workflow externo precisa reagir a isso?"

- **Sim → emita evento.** Nome no passado (`BillApproved`), payload auto-suficiente, em linguagem de negócio.
- **Não, é só estado interno → não emita.** Eventos demais viram ruído.

Não emita evento para:
- Atualizar UI (use observer/query da camada de aplicação).
- Logar coisas técnicas (`RowUpdated`, `CacheInvalidated`).
- "Por garantia, vai que alguém precisa um dia."

### Invariantes

Toda regra do tipo "isso TEM que ser verdadeiro" é uma **invariante** e mora **dentro do Aggregate Root**, verificada em cada método público que muta estado. Violação → `DomainException` **via factory de erros centralizada** (nunca instanciada direto).

Exemplos:
- "Total = soma das linhas" → recalcule no método que muda linhas.
- "Bill paga é imutável" → `if (Status == Paid) throw BillErrors.CannotModifyPaidBill();`
- "Status segue máquina X→Y→Z" → `if (!Status.CanTransitionTo(target)) throw BillErrors.InvalidStatusTransition(...)`

→ Padrão completo de exceptions (ID único, mensagem template, parâmetros, source path, factory por Aggregate) em `references/exception-pattern.md`. **Leia este arquivo sempre que for gerar código que lance exception.**

### A regra cabe em um Aggregate ou é Domain Service?

> **Pergunta-mãe**: "Essa regra envolve **dois ou mais Aggregates** que precisam coordenar?"

- **Não, é regra de UM Aggregate** → vai como **método do Aggregate Root**.
- **Sim, envolve múltiplos Aggregates** → vai como **Domain Service** (classe stateless em `Services/`).

Exemplos:
- "Bill em status DRAFT pode receber item" → método do `Bill` (regra do próprio Aggregate).
- "Transferir dinheiro de SourceAccount para TargetAccount" → `FundsTransferService` (coordena 2 Aggregates).
- "Classificar Bill com base em Supplier e categoria" → `BillClassificationService` (envolve `Bill` + `Supplier`).

Domain Service **não emite eventos diretamente** — ele recebe Aggregates, executa a regra, e retorna info ou chama métodos dos Aggregates (que emitem seus próprios eventos).

→ Padrão completo de Domain Service (forma da classe, regras, anti-padrões, template) em `references/domain-services.md`. **Leia este arquivo sempre que for gerar um Domain Service.**

→ Detalhes de modelagem com exemplos comparativos em `references/modeling-basics.md`.

## Workflow por cenário

### Cenário A — Markdown pronto

1. Leia o markdown. Identifique seções (Aggregate, VOs, Entities, Events, Invariantes, Comportamentos, Estados).
2. Mapeie direto para tipos C# (tabela em `references/code-conventions.md`).
3. Gere código na ordem certa (ver Ordem de geração abaixo).
4. Liste ambiguidades resolvidas no fim.

→ Formato esperado e padrões de descrição em `references/markdown-format.md`.

### Cenário B — Editar/expandir domínio existente

1. **Leia o código existente** (peça ao usuário se ele não anexou).
2. Identifique:
   - Onde a mudança encaixa (qual Aggregate, qual método).
   - Que invariantes existentes podem ser afetadas.
   - Que eventos existentes precisam ser ajustados ou novos emitidos.
3. **Antes de codar**, faça um resumo curto da mudança proposta:
   - "Vou adicionar método `X` no Aggregate `Y` que emite `ZEvent` e mantém invariante `W`."
4. Aplique a mudança seguindo as convenções (não regrida — se o código existente segue padrões, mantenha; se está errado, sinalize antes de "consertar").
5. Forneça **só os arquivos alterados ou novos**. Não regenere o que não mudou.

### Cenário C — Criar direto, sem markdown

1. **Capture o conceito em linguagem de negócio.** Pergunte 1-3 coisas se faltar:
   - O que esse Aggregate representa em linguagem do negócio?
   - Quais são os comportamentos principais (verbos)?
   - Quais regras NÃO podem ser quebradas (invariantes)?
   - Quais fatos importantes acontecem (eventos)?
2. Faça as 3 escolhas básicas (VO/Entity, Aggregate, Eventos) usando as perguntas-mãe acima. **Se ambíguo, pergunte.**
3. Apresente um **plano resumido em 5-10 linhas** antes de gerar:
   ```
   Plano:
   - Aggregate Root: Bill (BillId)
   - Entity interna: BillItem (BillItemId)
   - VOs: Money, DueDate
   - Eventos: BillCreated, BillApproved, BillCancelled
   - Status com máquina: DRAFT → AWAITING_APPROVAL → APPROVED → ...
   ```
4. Confirme ou siga; gere o código.

## Ordem de geração (vale para todos os cenários)

1. **Bases SeedWork** (`IEntityId`, `Entity<TId>`, `AggregateRoot<TId>`, `ValueObject`, `Enumeration`, `IDomainEvent`, `DomainException`) — só se ainda não existirem em `Domain/SeedWork/`. Pergunte ao usuário antes; este projeto já tem.
2. **Strongly-typed Ids** — `record struct <Aggregate>Id : IEntityId<<Aggregate>Id>` para o Aggregate Root e cada Entity interna. Vêm primeiro porque tudo depende deles.
3. **Smart Enums** (`<X>Status`, etc.) — herdam de `Enumeration`.
4. **Value Objects** — herdam de `ValueObject`, implementam `GetEqualityComponents()`.
5. **Domain Events** — `sealed record` implementando `IDomainEvent`. Payload com Ids strongly-typed (`BillId`, `UserId`).
6. **Entities internas** — herdam de `Entity<TEntityId>`.
7. **Factory de erros do Aggregate** (`<Aggregate>Errors.cs`) — listando todos os erros que o Aggregate lança, com IDs no padrão `<BC>.<AGG>##`.
8. **Aggregate Root** (herda de `AggregateRoot<TId>`, consome a factory de erros).
9. **Domain Services** (se houver — só se a regra envolve múltiplos Aggregates) — em `Services/`, com factory de erros própria `<Service>Errors.cs` no padrão `<BC>.<SVC>##`. Vêm depois dos Aggregates porque dependem deles.

## Convenções obrigatórias (resumo)

→ Detalhes e templates em `references/code-conventions.md` e `references/templates.md`. Não-negociáveis:

- **Idioma**: TODO o código em inglês (classes, propriedades, métodos, parâmetros, variáveis, namespaces, eventos, IDs de erro, comentários técnicos). **Apenas mensagens de erro em `DomainException` ficam em português** (são destinadas ao usuário). Termos consagrados de DDD ficam em inglês (Aggregate, Entity, ValueObject, Repository, etc.).
- `namespace` em file-scoped, `#nullable enable`.
- **Constantes (`const`, `static readonly`) no domínio**: nome em `MAIÚSCULAS_COM_UNDERSCORE` e declaradas **no topo da classe**, antes dos campos privados, propriedades, construtor e métodos. Vale para Aggregate, Entity, VO, Smart Enum, factory de erros e qualquer classe do domínio.
- **Visibilidade de constantes**: **`public const`** quando outras camadas (infra, API, UI) precisam replicar a regra para evitar inconsistência — sobretudo **`MAX_LENGTH` / `MIN_LENGTH` / `MAX_VALUE` / `MIN_VALUE` de VO e Entity** (infra usa em `.HasMaxLength(Name.MAX_LENGTH)`; UI valida client-side com o mesmo valor). **`private const`** para defaults internos, thresholds comportamentais, prefixos de erro, e qualquer regra que **só** o domínio aplica. O domínio é a fonte única da verdade — infra LÊ do domínio, nunca duplica o valor. Detalhes em `references/code-conventions.md` (seção "Visibilidade: public const vs private const").
- **Setters privados reutilizáveis em Aggregate Root e Entity**: cada propriedade com validação tem um método `Set<PropertyName>` (`private` na Root, `internal` em Entity interna) que **valida e atribui**, sem atualizar `UpdatedAt` e sem emitir Domain Event. `Create`, `Rehydrate` e métodos de mutação públicos (`ChangeXxx`, `Reprice`, etc.) **reusam o setter** em vez de duplicar validação. Setter vira `public` apenas quando o método público envolvente seria trivial. Toda `public const MAX_LENGTH` é validada dentro do setter correspondente. Detalhes em `references/code-conventions.md` (seção "Setters privados reutilizáveis").
- **Bases canônicas em `Domain/SeedWork/`** (NÃO substituir, NÃO simplificar):
  - **Aggregate Root**: `sealed class` herdando de `AggregateRoot` (que herda de `Entity`).
  - **Entity interna**: `sealed class` herdando de `Entity`.
  - **Value Object**: `sealed class` herdando de `ValueObject` — implementa `GetEqualityComponents()`. **NÃO usar record para VO.**
  - **Smart Enum**: `sealed class` herdando de `Enumeration`, com instâncias `public static readonly` em PascalCase. **NÃO usar enum nativo do C# no domínio.**
- **Identidade strongly-typed**: TODA Entity tem `Id` strongly-typed (`record struct` específico — `BillId`, `SupplierId`, `UserId`) implementando `IEntityId<TSelf>`. Aggregate Root herda de `AggregateRoot<TId>`, Entity interna de `Entity<TId>`. Outros Aggregates são referenciados pelo Id strongly-typed correspondente (`SupplierId SupplierId`), nunca por `Guid` solto. **Sem `implicit operator`** — extração para `Guid` é via `id.Value` explícito.
- Aggregate Root: ctor sem parâmetros `private` (EF) + ctor com `<Aggregate>Id id` (strongly-typed) `private` + factory `Create` estática pública.
- Setters `private` em todas as props de domínio. Mutação só via comportamento.
- Invariantes lançam `DomainException` **via factory centralizada por Aggregate** (`BillErrors.CannotModifyPaidBill()`), nunca instanciada direto. Padrão de ID `XXX.YYY##` ou `XXX##`. Detalhes em `references/exception-pattern.md`.
- **Coleções públicas SEMPRE como `IReadOnlyCollection<T>` + `.AsReadOnly()`** no campo privado (`public IReadOnlyCollection<T> Xs => _xs.AsReadOnly();`). Use `IReadOnlyList<T>` quando ordem importa. **Nunca** expor `List<T>`, `ICollection<T>`, `IList<T>` ou `T[]` em propriedade pública (permitem mutação externa e furam invariantes). **Nunca** retornar cast direto (`=> _items` sem `AsReadOnly`) — caller pode fazer downcast e mutar. Detalhes em `references/code-conventions.md`.
- Entities internas: ctor sem parâmetros `private` (EF) + ctor com argumentos `internal` (só a Root cria) + métodos de comportamento `internal` (só a Root chama).
- **Eventos somente no Aggregate Root** — Entity interna **não emite eventos**. Se algo significativo acontecer numa Entity interna, ela retorna info para a Root, e a Root chama `AddDomainEvent`. Domain Events são `sealed record` implementando `IDomainEvent`. Acumulados via `AddDomainEvent`, drenados via `PullDomainEvents()`.
- `DateTime.UtcNow` proibido inline em métodos de mutação. Receba `DateTime occurredAt` por parâmetro.

## Estilo da resposta

- **Comece curto**: resumo do que vai fazer (3-5 linhas), depois código.
- **Um arquivo por bloco** com caminho sugerido como comentário no topo:
  ```csharp
  // AccountsPayable.Domain/Bills/Bill.cs
  namespace AccountsPayable.Domain.Bills;
  ...
  ```
- **Não comente cada linha.** Comentários só onde a invariante é não-óbvia. Comentários técnicos em **inglês**.
- **Conversa em português** quando o usuário falar PT (resumos, ambiguidades, perguntas). **Código em inglês**. **Mensagens de `DomainException` em português** (são para o usuário final).
- **Liste ambiguidades resolvidas no fim**, pedindo confirmação. Não invente sem avisar.

## O que NÃO fazer

- **Não criar, sugerir ou mover Bounded Contexts.** A skill é tática, não estratégica. Quem decide quais BCs existem é o usuário. Se não souber em qual BC um Aggregate vai, **pergunte** — nunca invente um BC novo, nunca sugira "vou colocar em `Generic.Domain`", nunca crie projeto novo.
- **Não criar camada `<BoundedContext>/` dentro de um projeto** — cada projeto JÁ é um BC, Aggregates ficam direto na raiz do projeto.
- **Não criar Domain Service se a regra cabe num único Aggregate.** Service só justifica-se quando a regra envolve **múltiplos Aggregates**. Se for regra de um Aggregate só, vai como método dele.
- **Não dar estado a Domain Service.** Service é stateless — sem campos de instância (exceto constantes), sem construtor com parâmetros. Aggregates entram nos métodos, não no construtor.
- **Não fazer Domain Service emitir Domain Events** — quem emite é o Aggregate. Service retorna info ou chama métodos do Aggregate, e o Aggregate emite seus próprios eventos.
- **Não dar dependência de infra a Domain Service** (Repository, HTTP, banco, file system, async). Se precisa, é Application Service.
- Não escrever código de domínio em português (apenas mensagens de `DomainException` ficam em PT).
- Não gerar getters/setters públicos em Aggregate/Entity.
- Não adicionar `[Table]`, `[Column]`, `[Key]` ou outros atributos de EF no domínio.
- Não acoplar a `System.Text.Json`, `Newtonsoft.Json`, etc.
- **Não usar `record` para Value Object ou Smart Enum** — herdar das bases `ValueObject` / `Enumeration` em `Domain/SeedWork/`.
- **Não usar `Guid` solto para Ids** — toda Entity tem Id strongly-typed (`record struct` implementando `IEntityId<TSelf>`). Aggregate Root herda de `AggregateRoot<TId>`, Entity interna de `Entity<TId>`. Outros Aggregates são referenciados pelo Id strongly-typed (`SupplierId SupplierId`), nunca `Guid SupplierId`. Detalhes em `references/code-conventions.md` (seção Identidade) e `references/templates.md` (IEntityId).
- **Não criar `implicit operator Guid` nos Ids** — preserva type-safety. Extração via `id.Value` explícito.
- **Não usar `enum` nativo do C# para conceitos de domínio** — use Smart Enum herdando de `Enumeration`.
- **Não emitir eventos a partir de Entity interna** — só Aggregate Root emite. Entity interna comunica via retorno de método; a Root chama `AddDomainEvent`.
- Não emitir Domain Events com `DateTime.Now` ou `UtcNow` inline em métodos de mutação.
- Não criar Repository, Service ou Handler espontaneamente.
- Não fazer "modelagem auxiliar" inventando invariantes ou eventos não pedidos. Se faltar dado, **pergunte**.
- Não modelar profundamente como um especialista de DDD faria — esta skill é codificadora com fundamento, não consultora estratégica.
- **Não instanciar `DomainException` direto no Aggregate** — sempre via factory `<Aggregate>Errors.<Method>()`.
- **Não escrever string literal de mensagem de erro no Aggregate** — toda mensagem mora na factory.
- **Não vazar dado sensível em mensagens ou parâmetros de exception** (senhas, tokens, dados de outros tenants, IDs externos sigilosos).
- **Pergunte ao usuário a sigla do BC e do Aggregate** se ainda não tiver sido definida — não invente prefixos como `XYZ`.
