# Infrastructure Setup

Templates da infraestrutura de teste de integração: a factory que sobe o container, a base que cada teste herda, e a collection que compartilha o container na suíte.

## Conteúdo
- [WebApplicationFactory](#webapplicationfactory)
- [BaseIntegrationTest](#baseintegrationtest)
- [CollectionDefinition](#collectiondefinition)
- [Pré-requisito no Program.cs](#pré-requisito-no-programcs)
- [Decisões de design](#decisões-de-design)

---

## WebApplicationFactory

Sobe o Postgres em container, aplica migrations, prepara o Respawn e injeta a connection string dinâmica na aplicação. Implementa `IAsyncLifetime` — o xUnit chama `InitializeAsync` uma vez antes da suíte e `DisposeAsync` uma vez no fim.

```csharp
// Infrastructure/IntegrationTestWebAppFactory.cs
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Npgsql;
using Respawn;
using System.Data.Common;
using Testcontainers.PostgreSql;
using Xunit;

namespace Ordering.Api.IntegrationTests.Infrastructure;

public sealed class IntegrationTestWebAppFactory
    : WebApplicationFactory<Program>, IAsyncLifetime
{
    private readonly PostgreSqlContainer _postgres = new PostgreSqlBuilder()
        .WithImage("postgres:17")          // pin: nunca 'latest'
        .WithDatabase("ordering_test")
        .WithUsername("postgres")
        .WithPassword("postgres")
        .Build();

    private DbConnection _dbConnection = null!;
    private Respawner _respawner = null!;

    // Sobrescreve APENAS a connection string. Não remover/re-adicionar serviços do DI.
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseSetting(
            "ConnectionStrings:Database",          // <- nome lido no Program.cs
            _postgres.GetConnectionString());
    }

    public async Task InitializeAsync()
    {
        await _postgres.StartAsync();

        // Aplica o schema via migrations (não EnsureCreated).
        using (var scope = Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<OrderingDbContext>();
            await db.Database.MigrateAsync();
        }

        _dbConnection = new NpgsqlConnection(_postgres.GetConnectionString());
        await _dbConnection.OpenAsync();

        _respawner = await Respawner.CreateAsync(_dbConnection, new RespawnerOptions
        {
            DbAdapter = DbAdapter.Postgres,
            SchemasToInclude = ["public"],
            // __EFMigrationsHistory já é ignorada por padrão.
            // Adicione aqui tabelas de dado de REFERÊNCIA que não devem ser limpas.
            // TablesToIgnore = [new Table("currency_types")]
        });
    }

    public async Task ResetDatabaseAsync() => await _respawner.ResetAsync(_dbConnection);

    // Helpers de acesso ao banco para seed e verificação (scope NOVO sempre).
    public async Task ExecuteDbContextAsync(Func<OrderingDbContext, Task> action)
    {
        using var scope = Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<OrderingDbContext>();
        await action(db);
    }

    public async Task<T> ExecuteDbContextAsync<T>(Func<OrderingDbContext, Task<T>> action)
    {
        using var scope = Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<OrderingDbContext>();
        return await action(db);
    }

    public new async Task DisposeAsync()
    {
        await _dbConnection.DisposeAsync();
        await _postgres.StopAsync();
    }
}
```

---

## BaseIntegrationTest

Cada classe de teste herda desta base. Ela expõe o `HttpClient` e os helpers, e — crucial — chama o reset do Respawn no `DisposeAsync`, que o xUnit executa **depois de cada teste**.

```csharp
// Infrastructure/BaseIntegrationTest.cs
using Xunit;

namespace Ordering.Api.IntegrationTests.Infrastructure;

[Collection(nameof(IntegrationTestCollection))]
public abstract class BaseIntegrationTest : IAsyncLifetime
{
    protected readonly IntegrationTestWebAppFactory Factory;
    protected readonly HttpClient Client;

    protected BaseIntegrationTest(IntegrationTestWebAppFactory factory)
    {
        Factory = factory;
        Client = factory.CreateClient();
    }

    // Seed comum à classe vai aqui (sobrescrito pela classe filha).
    // Roda ANTES de cada teste, com o banco já limpo pelo teste anterior.
    public virtual Task InitializeAsync() => Task.CompletedTask;

    // Roda DEPOIS de cada teste: limpa tudo para o próximo começar do zero.
    public Task DisposeAsync() => Factory.ResetDatabaseAsync();
}
```

---

## CollectionDefinition

Faz o xUnit compartilhar **uma única** instância da factory (logo, um único container) entre todas as classes de teste da coleção. Sem isso, cada classe subiria seu próprio Postgres — lento.

```csharp
// Infrastructure/IntegrationTestCollection.cs
using Xunit;

namespace Ordering.Api.IntegrationTests.Infrastructure;

[CollectionDefinition(nameof(IntegrationTestCollection))]
public sealed class IntegrationTestCollection
    : ICollectionFixture<IntegrationTestWebAppFactory>;
```

---

## Pré-requisito no Program.cs

`WebApplicationFactory<Program>` precisa enxergar a classe `Program`. Com top-level statements (padrão em .NET moderno), ela é gerada como `internal`. Exponha-a adicionando ao final do `Program.cs` da aplicação:

```csharp
public partial class Program { }
```

Alternativa sem tocar no `Program.cs`: criar uma interface marcadora vazia (`public interface IApiMarker {}`) num assembly conhecido da API e usar `WebApplicationFactory<IApiMarker>`. A skill prefere `public partial class Program {}` por ser o caminho mais comum e explícito.

---

## Decisões de design

**Class fixture vs. collection fixture.** A collection (um container para a suíte inteira) é o padrão por ser rápida; o isolamento vem do Respawn limpando entre testes. Use class fixture (um container por classe) só se uma classe específica modifica estado global de forma que o reset não cobre — é mais lento, porém mais isolado.

**Por que `UseSetting` e não variável de ambiente.** `Environment.SetEnvironmentVariable` também funciona, mas é estado global do processo e pode colidir se você roda factories diferentes em paralelo. `UseSetting` é escopado à instância da factory.

**Por que abrir a conexão do Respawn separada.** O Respawn precisa de uma `DbConnection` própria, persistente, para inspecionar metadados e rodar os DELETEs — independente do pool de conexões que a aplicação usa nas requisições.

**Ordem dentro do `InitializeAsync`.** Container primeiro (sem ele não há connection string), migrations depois (precisam do banco no ar), Respawn por último (precisa do schema já criado para mapear as FKs).

**Mensageria.** Se a aplicação usa MassTransit, o padrão é o **in-memory transport** do test harness, configurado em `ConfigureTestServices` — sem container, sem mexer na factory. Só quando for testar contra RabbitMQ real é que entra um `RabbitMqContainer` análogo ao Postgres. Detalhes em `messaging-tests.md`.
