# Seeding Data

Como popular o banco com o estado inicial que um teste precisa. Há três níveis, escolhidos por **abrangência** do dado.

## A decisão de fundo: seed pelo domínio vs. seed cru

**Seed pelo domínio** — instancie o agregado pela factory real e salve via DbContext:

```csharp
await Factory.ExecuteDbContextAsync(async db =>
{
    var customer = Customer.Register(           // a factory de verdade
        CustomerId.From(KnownIds.Customer),
        Email.Create("ana@exemplo.com"),
        "Ana Silva");
    db.Customers.Add(customer);
    await db.SaveChangesAsync();
});
```

Vantagem: os dados são **válidos por construção** — passaram pela mesma porta que o código de produção, respeitando todas as invariantes. Você nunca cria um estado que o domínio jamais permitiria.

**Seed cru** — INSERT direto, pulando as invariantes:

```csharp
await Factory.ExecuteSqlAsync(
    "INSERT INTO orders (id, customer_id, status, total_amount, total_currency) " +
    "VALUES (@id, @cid, @status, @amount, @currency)",
    new { id = orderId, cid = customerId, status = "Shipped", amount = 150m, currency = "BRL" });
```

Vantagem: fabrica qualquer estado, inclusive os "impossíveis" pela porta da frente (registro legado, estado pós-migração). Risco: pode criar um estado que o domínio rejeitaria, validando um cenário irreal — falso positivo perigoso.

**Regra:** prefira semear pelo domínio. Caia para o seed cru só quando montar o estado pela porta da frente for genuinamente impraticável, ciente de que está afirmando "suponha o banco neste estado", não "este estado é alcançável".

---

## Nível 1 — Dado de cenário, específico de UM teste

Como cada teste começa limpo (Respawn no `DisposeAsync`), semeie no próprio Arrange. O seed vive e morre dentro do método — máxima localidade, quem lê o teste vê de que estado ele depende.

```csharp
[Fact]
public async Task PostOrders_WhenCustomerIsBlocked_ShouldReturnConflict()
{
    // Arrange — seed exclusivo DESTE teste
    var customerId = await Factory.ExecuteDbContextAsync(async db =>
    {
        var customer = CustomerMother.Default();
        customer.Block("inadimplência");        // estado que só este teste precisa
        db.Customers.Add(customer);
        await db.SaveChangesAsync();
        return customer.Id.Value;
    });

    var request = new CreateOrderRequest(customerId, [/* ... */]);

    var response = await Client.PostAsJsonAsync("/api/orders", request);

    Assert.Equal(HttpStatusCode.Conflict, response.StatusCode);
}
```

Quando o setup é mais pesado (várias entidades relacionadas), extraia para um helper **bem nomeado**, mas ainda chamado explicitamente pelo teste — não num hook automático. Assim o seed é opt-in: só quem chama recebe o estado.

```csharp
public static class SeedExtensions
{
    public static Task<Guid> SeedShippedOrderAsync(
        this IntegrationTestWebAppFactory factory, decimal total)
    {
        return factory.ExecuteDbContextAsync(async db =>
        {
            var customer = CustomerMother.Default();
            var order = OrderMother.ForCustomer(customer.Id).WithTotal(total).Shipped();
            db.Customers.Add(customer);
            db.Orders.Add(order);
            await db.SaveChangesAsync();
            return order.Id.Value;
        });
    }
}

// no teste:
var orderId = await Factory.SeedShippedOrderAsync(total: 150m);
```

---

## Nível 2 — Dado comum a TODA a classe

Quando todos (ou quase todos) os testes da classe partem do mesmo pré-requisito — ex.: uma classe `RefundOrderTests` em que todo teste precisa de um pedido entregue. Sobe para o `InitializeAsync` da base, que roda antes de cada teste com o banco já limpo.

```csharp
[Collection(nameof(IntegrationTestCollection))]
public class RefundOrderTests : BaseIntegrationTest
{
    private Guid _orderId;

    public RefundOrderTests(IntegrationTestWebAppFactory factory) : base(factory) { }

    public override async Task InitializeAsync()
    {
        _orderId = await Factory.SeedShippedOrderAsync(total: 150m);
    }

    [Fact]
    public async Task PostRefund_WhenOrderIsShipped_ShouldSucceed()
    {
        var response = await Client.PostAsync($"/api/orders/{_orderId}/refund", null);
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }
}
```

**Linha divisória entre nível 1 e 2:** se você se pegar escrevendo `if (testeX)` no `InitializeAsync`, ou semeando um dado que metade dos testes ignora, o seed pertence ao teste (nível 1), não ao hook. Forçar estado peculiar num `InitializeAsync` compartilhado obriga os outros testes a conviver com dado que não lhes diz respeito e abre porta para acoplamento acidental.

---

## Nível 3 — Dado de referência GLOBAL e imutável

Dado que toda a suíte precisa e que nunca muda: tabelas de domínio estáveis (tipos de moeda, países, configurações). Não faz sentido repopular a cada teste. Semeie **uma vez** na factory (depois das migrations) e adicione as tabelas ao `TablesToIgnore` do Respawn, para o reset não as apagar.

```csharp
// dentro do InitializeAsync da factory, após MigrateAsync():
using (var scope = Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<OrderingDbContext>();
    if (!await db.CurrencyTypes.AnyAsync())
    {
        db.CurrencyTypes.AddRange(CurrencyType.GetAll());
        await db.SaveChangesAsync();
    }
}

_respawner = await Respawner.CreateAsync(_dbConnection, new RespawnerOptions
{
    DbAdapter = DbAdapter.Postgres,
    SchemasToInclude = ["public"],
    TablesToIgnore = [new Table("currency_types"), new Table("countries")]
});
```

Isso separa **dado de referência** (semeado uma vez, sobrevive ao reset) de **dado de cenário** (semeado por teste, apagado entre testes).

---

## Armadilha de ordenação (a mais comum)

Há dois `InitializeAsync` diferentes:
- O da **factory** (`IAsyncLifetime` da fixture): roda **uma vez** para a suíte. → migrations + dado de referência (nível 3).
- O da **base de teste**: roda **por teste**. → dado de cenário comum à classe (nível 2).

Misturar é a causa #1 de testes que passam isolados mas falham em suíte: dado de referência semeado por teste é apagado pelo Respawn no meio do caminho; ou dado de cenário semeado na factory vaza entre testes. Cada nível no seu lugar.
