# State Verification

Como confirmar o que foi realmente persistido no banco, **sem** depender de um endpoint GET.

## Por que não usar o GET para verificar escrita

Usar o GET para conferir o resultado de um POST acopla o teste de escrita à corretude do endpoint de leitura. Se o GET tem um bug de mapeamento, o teste de POST falha (ou passa) pelo motivo errado, e você não sabe qual dos dois quebrou. Ler direto do banco isola a responsabilidade: o teste prova que **o POST gravou corretamente**, ponto.

A regra prática:
- **Verifique pelo banco** quando o objetivo é a persistência em si (gravou? mapeou nas colunas certas? o owned type achatou direito?).
- **Verifique pela API** quando o objetivo é o comportamento observável (o cliente consegue criar e depois ler).

Os dois tipos coexistem e cobrem coisas diferentes.

## Forma 1 — via DbContext em scope novo (padrão)

A armadilha central: **use um scope novo**, separado do que a requisição usou. Reusar o contexto da requisição pode devolver a entidade do change tracker (cache de identidade do EF) em vez de ler o banco — e o teste passa mesmo sem ter persistido nada. O `AsNoTracking()` reforça que você quer um snapshot do banco.

```csharp
[Fact]
public async Task PostOrders_WhenRequestIsValid_ShouldPersistOrder()
{
    var request = new CreateOrderRequest(
        CustomerId: KnownIds.Customer,
        Items: [new(ProductId: KnownIds.Product, Quantity: 2)]);

    var response = await Client.PostAsJsonAsync("/api/orders", request);

    Assert.Equal(HttpStatusCode.Created, response.StatusCode);
    var created = await response.Content.ReadFromJsonAsync<OrderResponse>();

    // Lê DIRETO do banco, scope novo, sem cache do change tracker.
    var persisted = await Factory.ExecuteDbContextAsync(db =>
        db.Orders
          .AsNoTracking()
          .Include(o => o.Items)
          .FirstOrDefaultAsync(o => o.Id == created!.Id));

    Assert.NotNull(persisted);
    Assert.Equal(2, persisted!.Items.Count);
    Assert.Equal(request.CustomerId, persisted.CustomerId.Value);
}
```

Sobre agregados DDD: mesmo com setters privados e construtor protegido, o EF materializa a entidade pelo construtor de materialização e backing fields, então você consegue **ler** as propriedades para assertar. O que NÃO se deve fazer aqui é chamar métodos de negócio do agregado dentro do teste de integração — neste nível você só inspeciona estado, não exercita comportamento (isso é papel do teste de domínio).

## Forma 2 — via Dapper / SQL cru (verificar colunas)

Útil quando você quer a verdade absoluta do que está nas colunas, sem o EF no meio: mapeamento de Value Object (owned type achatado em colunas), colunas computadas, defaults do banco, ou quando desconfia que o próprio EF está mascarando o resultado.

```csharp
// Helper na factory (usa a mesma connection string do container):
public async Task<T?> QuerySingleOrDefaultAsync<T>(string sql, object? param = null)
{
    await using var conn = new NpgsqlConnection(_postgres.GetConnectionString());
    await conn.OpenAsync();
    return await conn.QuerySingleOrDefaultAsync<T>(sql, param); // Dapper
}
```

```csharp
// No teste: confirma que o Value Object Money caiu em amount + currency.
var row = await Factory.QuerySingleOrDefaultAsync<(decimal Amount, string Currency)>(
    "SELECT total_amount AS Amount, total_currency AS Currency FROM orders WHERE id = @id",
    new { id = created!.Id });

Assert.Equal(150.00m, row.Amount);
Assert.Equal("BRL", row.Currency);
```

Esta é a forma mais honesta de validar o achatamento de um owned type — é onde o mapeamento esconde mais bugs.

## Armadilha: verificar durante a transação

Com Unit of Work (`SaveChanges` no fim do handler), a escrita só fica visível para outras conexões **após o commit**. No fluxo normal de teste (faz a chamada HTTP → ela completa → verifica), você está seguro: a requisição já retornou, logo a transação commitou. O problema só apareceria se você verificasse de dentro de um middleware ou de uma conexão aberta antes do commit — não é o caso aqui.

## Resumo

| Objetivo | Ferramenta |
|---|---|
| Confirmar que o agregado foi gravado e as relações persistiram | DbContext, scope novo, `AsNoTracking()` + `Include` |
| Confirmar o mapeamento exato de colunas / owned type | Dapper, SQL cru |
| Confirmar comportamento observável fim a fim | endpoint GET via HttpClient |
