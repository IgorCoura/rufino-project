# Test Conventions

Convenções de escrita e um exemplo completo de classe de teste, amarrando seed, ação HTTP, verificação de estado e caminhos de erro.

## Conteúdo
- [Nomenclatura](#nomenclatura)
- [Estrutura AAA](#estrutura-aaa)
- [Duplicação de contratos](#duplicação-de-contratos)
- [Cobertura de caminhos de erro](#cobertura-de-caminhos-de-erro)
- [Ids e datas determinísticos](#ids-e-datas-determinísticos)
- [Exemplo completo](#exemplo-completo)

---

## Nomenclatura

- **Idioma**: todo o código em inglês — classes, métodos, variáveis e nomes de teste. Mensagens de `DomainException` permanecem em PT, mas o teste compara o **status HTTP** e/ou o `Id` do erro, nunca a mensagem traduzida.
- **Método de teste**: `Endpoint_StateUnderTest_ExpectedBehavior`.
  - `PostOrders_WhenRequestIsValid_ShouldReturnCreated`
  - `PostOrders_WhenCustomerIsBlocked_ShouldReturnConflict`
  - `GetOrder_WhenOrderDoesNotExist_ShouldReturnNotFound`
- **Arquivo**: um por caso de uso — `CreateOrderTests.cs`, `RefundOrderTests.cs`.

## Estrutura AAA

Arrange / Act / Assert separados por **linha em branco**, sem comentários `// Arrange` etc. — o espaçamento já delimita. O Act é tipicamente uma única chamada ao `HttpClient`.

## Duplicação de contratos

Os DTOs de request/response usados nos testes são **cópias** dos da aplicação, mantidos em `Contracts/` no projeto de teste. Não reuse os tipos da aplicação.

Motivo: se você reusa o tipo e alguém renomeia uma propriedade do response, o teste continua compilando e passando — mascarando uma quebra de contrato para os clientes reais da API. Com uma cópia independente, a renomeação faz o teste falhar, te forçando a decidir conscientemente: reverter ou versionar a API.

```csharp
// Contracts/OrderContracts.cs — CÓPIAS, evoluem só por decisão consciente
namespace Ordering.Api.IntegrationTests.Contracts;

public sealed record CreateOrderRequest(Guid CustomerId, List<OrderItemDto> Items);
public sealed record OrderItemDto(Guid ProductId, int Quantity);
public sealed record OrderResponse(Guid Id, Guid CustomerId, string Status);
```

## Cobertura de caminhos de erro

Cubra cada código HTTP que o endpoint retorna **explicitamente**. Se o caso de uso "Create Order" retorna 201, 400 e 409, escreva um teste para cada. Não teste 500 se o endpoint não o produz deliberadamente — testar erro não-determinístico gera teste frágil.

Isso protege o contrato: se uma mudança acidental altera o status ou o formato do erro, o teste avisa antes de quebrar os clientes.

## Ids e datas determinísticos

`Guid.NewGuid()`, `DateTime.UtcNow` e `<Type>Id.New()` soltos no arrange geram testes flaky e dificultam asserção de igualdade. Fixe-os:

```csharp
public static class KnownIds
{
    public static readonly Guid Customer = new("11111111-1111-1111-1111-111111111111");
    public static readonly Guid Product  = new("22222222-2222-2222-2222-222222222222");
}

public static readonly DateTime FixedNow =
    new(2024, 1, 15, 10, 30, 0, DateTimeKind.Utc);
```

Ids strongly-typed que precisam de igualdade entre instâncias: `CustomerId.From(KnownIds.Customer)`.

---

## Exemplo completo

Uma classe mostrando os dois estilos de seed (inline e helper), verificação pelo banco, e cobertura de sucesso + dois erros.

```csharp
// Orders/CreateOrderTests.cs
using System.Net;
using System.Net.Http.Json;
using Microsoft.EntityFrameworkCore;
using Ordering.Api.IntegrationTests.Contracts;
using Ordering.Api.IntegrationTests.Infrastructure;
using Ordering.Api.IntegrationTests.Mothers;
using Xunit;

namespace Ordering.Api.IntegrationTests.Orders;

[Collection(nameof(IntegrationTestCollection))]
public class CreateOrderTests : BaseIntegrationTest
{
    public CreateOrderTests(IntegrationTestWebAppFactory factory) : base(factory) { }

    [Fact]
    public async Task PostOrders_WhenRequestIsValid_ShouldReturnCreatedAndPersist()
    {
        await Factory.ExecuteDbContextAsync(async db =>
        {
            db.Customers.Add(CustomerMother.Default());
            await db.SaveChangesAsync();
        });

        var request = new CreateOrderRequest(
            KnownIds.Customer,
            [new OrderItemDto(KnownIds.Product, Quantity: 2)]);

        var response = await Client.PostAsJsonAsync("/api/orders", request);

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var created = await response.Content.ReadFromJsonAsync<OrderResponse>();
        Assert.NotNull(created);

        var persisted = await Factory.ExecuteDbContextAsync(db =>
            db.Orders.AsNoTracking()
              .Include(o => o.Items)
              .FirstOrDefaultAsync(o => o.Id == created!.Id));

        Assert.NotNull(persisted);
        Assert.Equal(KnownIds.Customer, persisted!.CustomerId.Value);
        Assert.Equal(2, persisted.Items.Sum(i => i.Quantity));
    }

    [Fact]
    public async Task PostOrders_WhenCustomerIsBlocked_ShouldReturnConflict()
    {
        await Factory.ExecuteDbContextAsync(async db =>
        {
            var customer = CustomerMother.Default();
            customer.Block("inadimplência");
            db.Customers.Add(customer);
            await db.SaveChangesAsync();
        });

        var request = new CreateOrderRequest(
            KnownIds.Customer,
            [new OrderItemDto(KnownIds.Product, Quantity: 1)]);

        var response = await Client.PostAsJsonAsync("/api/orders", request);

        Assert.Equal(HttpStatusCode.Conflict, response.StatusCode);
    }

    [Fact]
    public async Task PostOrders_WhenCustomerDoesNotExist_ShouldReturnNotFound()
    {
        var request = new CreateOrderRequest(
            CustomerId: Guid.NewGuid(),                 // cliente inexistente: id arbitrário é OK aqui
            [new OrderItemDto(KnownIds.Product, Quantity: 1)]);

        var response = await Client.PostAsJsonAsync("/api/orders", request);

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Theory]
    [InlineData(0)]
    [InlineData(-1)]
    public async Task PostOrders_WhenQuantityIsNotPositive_ShouldReturnBadRequest(int quantity)
    {
        await Factory.ExecuteDbContextAsync(async db =>
        {
            db.Customers.Add(CustomerMother.Default());
            await db.SaveChangesAsync();
        });

        var request = new CreateOrderRequest(
            KnownIds.Customer,
            [new OrderItemDto(KnownIds.Product, quantity)]);

        var response = await Client.PostAsJsonAsync("/api/orders", request);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }
}
```

Observe: o `Guid.NewGuid()` no teste de "cliente inexistente" é intencional e aceitável — o teste justamente não depende de igualdade com nada, só precisa de um id que garantidamente não existe. A proibição de ids aleatórios vale para quando o teste **depende** do valor.
