# Messaging Tests

Como testar publicação e consumo de eventos quando a aplicação usa mensageria. Stack: **MassTransit** com `AddMassTransitTestHarness` sobre o **in-memory transport** do próprio MassTransit (padrão). RabbitMQ real via Testcontainers é opção para quando você precisa validar a integração concreta com o broker.

## O que faz sentido testar aqui

Em testes de integração testamos **uma** aplicação que integra com a mensageria — não o conjunto de serviços conversando entre si (isso seria E2E, fora do escopo). O objetivo é verificar:

- que o evento é **publicado** quando o caso de uso roda;
- que o evento tem o **schema/payload corretos** (o evento é um contrato);
- que um **consumer** da própria aplicação processa o evento como esperado.

## Por que in-memory transport (e o que ele NÃO cobre)

O harness do MassTransit roda sobre um transport **in-memory** que simula o barramento dentro do processo de teste. Vantagens: nenhum container, sem latência de rede, sem porta dinâmica, testes rápidos e determinísticos. É o padrão desta skill.

O trade-off honesto: o in-memory **não** exercita o broker de verdade. Ele valida o roteamento de mensagens da sua aplicação (quem publica, quem consome, com que schema) e a configuração do MassTransit, mas não pega problemas que só aparecem no RabbitMQ real — serialização específica do broker, configuração de exchange/binding, comportamento de retry/dead-letter, credenciais. Para o objetivo comum (publicou? com o payload certo? o consumer processou?), o in-memory cobre. Quando você precisar provar a integração concreta com o RabbitMQ, veja a seção opcional no fim.

## 1. Configurar o test harness in-memory

Configure em `ConfigureTestServices` (roda **depois** do `Program.cs`, então sobrescreve o registro real do barramento). Não precisa de container nem de connection string de broker:

```csharp
protected override void ConfigureWebHost(IWebHostBuilder builder)
{
    builder.UseSetting("ConnectionStrings:Database", _postgres.GetConnectionString());

    builder.ConfigureTestServices(services =>
    {
        services.AddMassTransitTestHarness(x =>
        {
            // registre os consumers que quer exercitar nos testes:
            x.AddConsumer<OrderCreatedConsumer>();
            // sem UsingRabbitMq / UsingInMemory explícito:
            // o test harness usa o transport in-memory por padrão.
        });
    });
}
```

O `AddMassTransitTestHarness` já configura o transport in-memory automaticamente — você não chama `UsingRabbitMq`. Os consumers registrados aqui são conectados ao barramento in-memory.

## 2. Testar publicação e consumo

Pegue o harness do DI, inicie-o **antes** da ação, dispare o caso de uso via HTTP, e verifique:

```csharp
[Fact]
public async Task PostOrders_WhenCreated_ShouldPublishOrderCreatedEvent()
{
    var harness = Factory.Services.GetTestHarness();
    await harness.Start();

    await Factory.ExecuteDbContextAsync(async db =>
    {
        db.Customers.Add(CustomerMother.Default());
        await db.SaveChangesAsync();
    });

    var request = new CreateOrderRequest(KnownIds.Customer, [new(KnownIds.Product, 2)]);

    var response = await Client.PostAsJsonAsync("/api/orders", request);
    Assert.Equal(HttpStatusCode.Created, response.StatusCode);
    var created = await response.Content.ReadFromJsonAsync<OrderResponse>();

    // publicado?
    Assert.True(await harness.Published.Any<OrderCreatedEvent>());

    // consumido com o payload certo?
    var consumerHarness = harness.GetConsumerHarness<OrderCreatedConsumer>();
    Assert.True(await consumerHarness.Consumed.Any<OrderCreatedEvent>(x =>
        x.Context.Message.OrderId == created!.Id &&
        x.Context.Message.CustomerId == KnownIds.Customer));

    await harness.Stop();
}
```

Verifique **cada campo** relevante do payload individualmente (o evento é contrato) — não compare o objeto inteiro por igualdade.

## Armadilha crítica: NÃO teste "não publicou" com o harness

Se você tentar assertar que um evento **não** foi publicado:

```csharp
// ⚠️ NÃO FAÇA ISSO — o teste CONGELA esperando o que nunca chega
Assert.False(await harness.Published.Any<SomeEvent>());
```

`Any<T>()` espera o evento aparecer dentro de um timeout interno; se nunca aparece, fica bloqueado. Para validar ausência de publicação, verifique o **efeito colateral ausente**:

- a linha que o consumer criaria **não** existe no banco (verifique via DbContext);
- ou conte as publicações de um evento que *deveria* ter ocorrido e confirme que o outro não alterou o estado.

Teste a ausência pelo que o sistema **não** fez de observável, não perguntando ao harness "isto não veio?".

## Duplicação de contratos vale para eventos também

Pelo mesmo motivo do princípio #9 (DTOs HTTP), o evento é um contrato com outros serviços. Se a aplicação publica um evento consumido externamente, mudar seu schema sem querer quebra os consumidores. Testar campo a campo o payload protege esse contrato — o teste falha se alguém renomear ou remover um campo do evento.

## Isolamento entre testes

O harness in-memory é criado dentro do escopo da aplicação de teste e iniciado/parado por teste (`harness.Start()`/`harness.Stop()`). Como cada teste roda seu próprio ciclo do harness e o transport é in-memory, não há fila persistente vazando mensagens entre testes — diferente do RabbitMQ real. O Respawn cuida do banco; o harness cuida de si.

## Opcional — RabbitMQ real via Testcontainers

Use quando o in-memory não basta: validar serialização do broker, exchanges/bindings, retry/dead-letter, ou um teste que precisa do RabbitMQ de verdade no caminho. Custa um container e é mais lento.

```csharp
// container na factory, análogo ao Postgres:
private readonly RabbitMqContainer _rabbitMq = new RabbitMqBuilder()
    .WithImage("rabbitmq:3-management")   // pin a versão
    .Build();
// StartAsync no InitializeAsync, StopAsync no DisposeAsync,
// connection string via builder.UseSetting("MessageBroker:Host", _rabbitMq.GetConnectionString());

// e no harness, configure o transport explicitamente:
services.AddMassTransitTestHarness(x =>
{
    x.AddConsumer<OrderCreatedConsumer>();
    x.UsingRabbitMq((context, cfg) =>
    {
        cfg.Host(new Uri(_rabbitMq.GetConnectionString()), h =>
        {
            h.Username("guest");
            h.Password("guest");
        });
        cfg.ConfigureEndpoints(context);
    });
});
```

Com RabbitMQ real, atente para isolamento de filas entre testes (filas efêmeras por execução ou nomes por teste) — algo que o in-memory te dá de graça. A API de verificação (`Published.Any<T>()`, `Consumed.Any<T>()`) é a mesma; só o transport muda.
