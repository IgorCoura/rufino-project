# Cleanup Strategies

Como garantir que cada teste comece de um estado conhecido. **Respawn é o padrão prioritário** por ser rápido e robusto; a transação-por-teste é a alternativa para casos específicos. Avalie teste a teste.

## As três estratégias e seus trade-offs

| Estratégia | Velocidade | Robustez | Quando usar |
|---|---|---|---|
| **Respawn** (padrão) | Rápida | Alta | Padrão geral. Limpa dados mantendo schema, na ordem correta de FKs. |
| **Transação-por-teste** | Mais rápida | Média | Quando o código sob teste **não** gerencia a própria transação e você quer isolamento máximo. |
| Recriar container por teste | Lenta | Altíssima | Praticamente nunca — só se um teste corrompe o schema. |

## Respawn — o padrão

Já coberto em `infrastructure-setup.md`. Reset no `DisposeAsync` da base, depois de cada teste. Funciona com qualquer design, inclusive quando o handler abre e commita a própria transação (Unit of Work) — porque o Respawn limpa **após** o commit, num momento em que não há transação aberta concorrendo.

**Por que é o padrão:** não depende de o teste e o código compartilharem a mesma transação/conexão. Isso é crucial em testes de integração via HTTP, onde a requisição roda no pool de conexões da aplicação, fora do controle do teste.

## Transação-por-teste — a alternativa

A ideia: abrir uma transação no início do teste e dar **rollback** no fim. Nada é commitado, então o banco volta sozinho ao estado anterior — sem precisar deletar nada.

```csharp
[Collection(nameof(IntegrationTestCollection))]
public abstract class TransactionalIntegrationTest : IAsyncLifetime
{
    protected readonly IntegrationTestWebAppFactory Factory;
    protected readonly HttpClient Client;
    private IServiceScope _scope = null!;
    private OrderingDbContext _db = null!;
    private IDbContextTransaction _transaction = null!;

    protected TransactionalIntegrationTest(IntegrationTestWebAppFactory factory)
    {
        Factory = factory;
        Client = factory.CreateClient();
    }

    public async Task InitializeAsync()
    {
        _scope = Factory.Services.CreateScope();
        _db = _scope.ServiceProvider.GetRequiredService<OrderingDbContext>();
        _transaction = await _db.Database.BeginTransactionAsync();
    }

    public async Task DisposeAsync()
    {
        await _transaction.RollbackAsync();   // desfaz tudo, sem DELETE
        await _transaction.DisposeAsync();
        _scope.Dispose();
    }
}
```

### A grande limitação (por que NÃO é o padrão)

A transação só isola se **todos** os acessos ao banco — o seed, o código sob teste e a verificação — compartilham a **mesma conexão**. Num teste via HTTP isso quase nunca acontece: a requisição usa o pool de conexões da aplicação, não a conexão do teste. Resultado: a escrita feita pelo handler é commitada na conexão dela e o rollback do teste não a alcança — o isolamento quebra silenciosamente.

Além disso, se o **próprio handler** abre uma transação (Unit of Work com `BeginTransaction`/`Commit`), você acaba com transações aninhadas ou um commit que escapa do seu rollback. Por isso o critério:

> Use transação-por-teste **apenas** quando o teste exercita o código numa conexão que você controla (ex.: testando um repositório ou um handler diretamente, sem passar pelo HTTP) **e** o código sob teste não gerencia a própria transação.

### Onde a transação-por-teste brilha

No nível **abaixo** do HTTP: testes de integração de repositório ou de handler instanciados diretamente, com o `DbContext` que você mesmo criou e passou. Aí seed, ação e verificação compartilham a conexão, o rollback alcança tudo, e você ganha velocidade (sem DELETEs). Para o teste de ponta a ponta via `HttpClient` que é o foco desta skill, fique com Respawn.

## Critério de decisão (resumo)

```
O teste passa pelo HttpClient (a app abre a própria conexão)?
├── SIM → Respawn (a transação do teste não alcança a conexão da app)
└── NÃO (testa repositório/handler com DbContext que você criou)
    └── O código sob teste gerencia a própria transação?
        ├── SIM → Respawn (evita transação aninhada / commit que escapa)
        └── NÃO → Transação-por-teste é viável e mais rápida
```

Na dúvida, Respawn. Ele nunca dá falso isolamento; a transação-por-teste pode dar, e silenciosamente.
