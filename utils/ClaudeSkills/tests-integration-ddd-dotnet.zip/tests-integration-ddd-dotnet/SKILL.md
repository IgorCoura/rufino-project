---
name: tests-integration-ddd-dotnet
description: "Use SEMPRE que o usuário pedir testes de integração (ou \"ponta a ponta\"/\"end-to-end\") para app .NET Core com DDD + Clean Architecture, testando o fluxo HTTP → Application → Domain → EF Core → PostgreSQL real. Cobre: montar a infra (WebApplicationFactory + Testcontainers + Respawn), testar caso de uso via API real, verificar estado persistido sem endpoint GET, semear dados por teste/classe, e testar mensageria/eventos (MassTransit Test Harness, in-memory). Dispare em: 'cria teste de integração pra esse endpoint', 'testa de ponta a ponta', 'monta a WebApplicationFactory', 'configura Testcontainers com Postgres', 'como limpo o banco entre testes', 'preciso popular o banco antes do teste', 'verifica se gravou no banco', 'testa se o evento foi publicado'. Stack: xUnit + Assert nativo + Testcontainers + Respawn + Mvc.Testing + Object Mother manual + MassTransit Test Harness. NÃO use para testes unitários de domínio puro (use tests-domain-ddd-dotnet), Repository isolado sem HTTP, ou E2E multi-serviço."
---

# DDD .NET Integration Tests

Skill especializada em **escrever testes de integração de ponta a ponta** para aplicações .NET Core com **DDD + Clean Architecture**, exercitando o fluxo completo: requisição HTTP → Controller/Endpoint → Application (Command/Query) → Domain (Aggregate) → EF Core → **PostgreSQL real rodando em container**.

É a skill irmã de nível superior à `tests-domain-ddd-dotnet`: aquela testa o domínio puro sem dependências; esta testa a **borda de infraestrutura e o contrato HTTP** com banco de verdade.

Cobre quatro cenários:

1. **Infra do zero**: montar `WebApplicationFactory` + Testcontainers + Respawn de um projeto que ainda não tem testes de integração.
2. **Teste de caso de uso**: escrever o teste de um Command/Query específico via HTTP.
3. **Verificação de estado**: confirmar o que foi persistido lendo direto do banco (sem depender de endpoint GET).
4. **Seed de dados**: popular o banco com o estado inicial que o teste precisa (inline, por classe, ou dado de referência global).

## Stack obrigatória

- **Framework**: xUnit (não NUnit, não MSTest). Motivo: ciclo de vida por teste (construtor = setup, `IAsyncLifetime.DisposeAsync` = cleanup) torna o isolamento previsível.
- **Assertions**: `Xunit.Assert` nativas (não FluentAssertions, não Shouldly) — alinhado à família de skills DDD do projeto.
- **Host de teste**: `Microsoft.AspNetCore.Mvc.Testing` (`WebApplicationFactory`).
- **Dependências reais**: `Testcontainers.PostgreSql` — Postgres real e descartável. **Nunca** `InMemory` provider (não tem transações, constraints nem comportamento SQL reais) nem banco compartilhado (poluição entre execuções).
- **Limpeza entre testes**: `Respawn` (prioritário) — agnóstico ao ORM, examina os metadados SQL e deleta na ordem correta de FKs. Transação-por-teste é a alternativa para casos específicos (ver `references/cleanup-strategies.md`).
- **Mensageria (quando houver)**: `MassTransit` com `AddMassTransitTestHarness`, sobre o **in-memory transport** (padrão — rápido, sem container). RabbitMQ real via `Testcontainers.RabbitMq` é opção quando é preciso validar a integração concreta com o broker (ver `references/messaging-tests.md`).
- **Geração de dados**: **Object Mother manual** (sem Bogus, sem AutoFixture), reaproveitando os Mothers da skill `tests-domain-ddd-dotnet` quando existirem.

Pacotes do projeto de teste:

```xml
<PackageReference Include="Microsoft.AspNetCore.Mvc.Testing" Version="..." />
<PackageReference Include="Testcontainers.PostgreSql" Version="..." />
<PackageReference Include="Respawn" Version="..." />
<PackageReference Include="Npgsql" Version="..." />
<PackageReference Include="xunit" Version="..." />
<PackageReference Include="xunit.runner.visualstudio" Version="...">
  <PrivateAssets>all</PrivateAssets>
</PackageReference>
<!-- só se a app usa mensageria: -->
<PackageReference Include="MassTransit.TestFramework" Version="..." />
<!-- só se for testar contra RabbitMQ real (opcional; o padrão é in-memory): -->
<PackageReference Include="Testcontainers.RabbitMq" Version="..." />
```

→ Não fixe versões de memória. Se o usuário precisar das versões, consulte o NuGet ou peça para ele rodar `dotnet add package`.

## Princípios não-negociáveis

Estes são os princípios que separam um teste de integração útil de um que dá falsa confiança. Detalhes e código em `references/`.

1. **Sem mocks nas dependências testadas.** O ponto do teste é validar a integração real. Se o handler grava no banco, o teste grava no Postgres de verdade. Mocks pertencem a testes unitários. Um bug clássico que só a integração pega: alterar uma entidade de domínio e esquecer de atualizar o mapeamento EF ou a migration — o teste unitário passa (mocka o banco), a integração falha (como deveria).

2. **Connection string dinâmica, nunca hardcoded.** Testcontainers atribui portas aleatórias. Injete via `builder.UseSetting("ConnectionStrings:<Nome>", _postgres.GetConnectionString())` no `ConfigureWebHost`. **Não** remova/re-adicione `DbContextOptions` do DI — se o `Program.cs` lê a connection via `GetConnectionString`, basta sobrescrever o setting.

3. **Schema via migrations, não `EnsureCreated`.** Use `db.Database.MigrateAsync()` na inicialização. Assim você testa contra o mesmo schema de produção e exercita as próprias migrations. `EnsureCreated` gera o schema do modelo e pode divergir.

4. **Pin da imagem do Postgres.** `postgres:17`, nunca `postgres:latest`. Uma atualização silenciosa de versão quebra a suíte de forma misteriosa.

5. **Verificação lê o banco em scope NOVO.** Para conferir o que foi gravado, abra um `IServiceScope` separado do que a requisição usou e consulte com `AsNoTracking()`. Reusar o contexto da requisição pode devolver a entidade do change tracker (cache de identidade) em vez de ler o banco — e o teste passa mesmo sem ter persistido nada.

6. **Prefira verificar pelo banco, não pelo endpoint GET.** Quando o objetivo é provar persistência ("gravou? mapeou nas colunas certas? o owned type achatou direito?"), leia direto via DbContext (ou Dapper para SQL cru). Usar o GET acopla o teste de escrita à corretude do endpoint de leitura — se um tem bug, você não sabe qual falhou. Verifique via API só quando o objetivo é o comportamento observável (cliente cria e depois lê).

7. **Reset no `DisposeAsync`, seed no `InitializeAsync` (ou inline).** Respawn limpa **depois** de cada teste. Cada teste começa limpo e semeia o seu próprio estado. Isso garante que o seed de um teste nunca vaze para outro. Respawn é o **padrão prioritário** (rápido e agnóstico ao ORM), mas não é o único — alguns testes pedem transação-por-teste. Critério de escolha e implementação em `references/cleanup-strategies.md`.

8. **Seed pela porta do domínio sempre que possível.** Instancie agregados pelas factories reais (`Order.Create(...)`) e salve via DbContext — os dados ficam válidos por construção, respeitando invariantes. Caia para INSERT cru (Dapper) só quando montar o estado pela porta da frente for impraticável (ex.: estado "legado" inalcançável), ciente de que está afirmando "suponha o banco neste estado".

9. **Duplique os modelos de request/response no projeto de teste.** Não reuse os DTOs da aplicação. Se você reusa e renomeia uma propriedade, o teste continua passando e mascara uma quebra de contrato para os clientes da API. Uma cópia independente faz o teste falhar quando o contrato muda — que é o que você quer.

10. **Teste os caminhos de erro, não só o sucesso.** Cubra cada código HTTP que o endpoint retorna explicitamente (200/201, 400, 404, 409...). Não teste 500 se o endpoint não o retorna deliberadamente. Isso protege o contrato: mudou o status/formato de erro sem querer, o teste avisa.

## Workflow por cenário

### Cenário 1 — Infra do zero
1. Leia o `Program.cs` para descobrir **o nome da connection string** (`GetConnectionString("X")`) e o tipo do `DbContext`.
2. Verifique se há `public partial class Program {}` (necessário para `WebApplicationFactory<Program>` com top-level statements). Se não houver e não der para adicionar, use uma interface marcadora (`IApiMarker`) num assembly conhecido.
3. Gere a `IntegrationTestWebAppFactory` (container + migrations + Respawn). Template em `references/infrastructure-setup.md`.
4. Gere a `BaseIntegrationTest` (HttpClient + helpers de DbContext + reset no `DisposeAsync`).
5. Gere a `CollectionDefinition` para compartilhar o container em toda a suíte.

### Cenário 2 — Teste de um caso de uso
1. Identifique o endpoint, o request DTO, o response DTO e os códigos HTTP que ele retorna.
2. **Duplique** os DTOs de request/response no projeto de teste (princípio #9).
3. Escreva o teste de sucesso (Arrange via seed/Mother → Act via HttpClient → Assert no status + corpo + estado persistido).
4. Escreva um teste por caminho de erro (princípio #10).
5. Verifique persistência pelo banco quando o foco é gravação (princípio #6).

### Cenário 3 — Verificação de estado
→ `references/state-verification.md`. Resumo: helper `ExecuteDbContextAsync<T>` em scope novo + `AsNoTracking()`. Para checar colunas cruas (mapeamento de Value Object / owned type), Dapper com SQL direto.

### Cenário 4 — Seed de dados
→ `references/seeding-data.md`. Resumo: dado de **cenário** (por teste) vai inline no Arrange ou em helper explícito chamado pelo teste; dado **comum à classe** vai no `InitializeAsync` da base; dado de **referência global** (imutável) é semeado uma vez na factory e adicionado ao `TablesToIgnore` do Respawn.

### Cenário 5 — Mensageria / eventos
→ `references/messaging-tests.md`. Resumo: configure `AddMassTransitTestHarness` em `ConfigureTestServices` (usa o **in-memory transport** por padrão, sem container) e verifique publicação/consumo via `ITestHarness` (`Published.Any<T>()`, `Consumed.Any<T>()`). Cuidado: **nunca** asserte que um evento *não* foi publicado com o harness — o teste congela. RabbitMQ real só quando precisar validar o broker de verdade.

### Escolha da estratégia de limpeza
→ `references/cleanup-strategies.md`. Respawn é o padrão. Avalie transação-por-teste caso a caso — útil quando o teste precisa de isolamento máximo e o código sob teste **não** gerencia a própria transação.

## Convenções obrigatórias

→ Detalhes em `references/test-conventions.md`. Resumo:

- **Idioma**: código todo em inglês (classes, métodos, variáveis, nomes de teste). Mensagens de `DomainException` permanecem em PT, mas o teste checa o `Id`/status HTTP, não a mensagem.
- **Nome do método de teste**: `Endpoint_StateUnderTest_ExpectedBehavior` (ex.: `PostOrders_WhenCustomerIsBlocked_ShouldReturnConflict`).
- **Estrutura AAA**: Arrange / Act / Assert separados por linha em branco, sem comentários `// Arrange` etc.
- **Object Mother** para montar agregados no seed — nunca instanciar direto no teste. Reuse os Mothers de `tests-domain-ddd-dotnet` se existirem.
- **`DateTime.UtcNow`/`Guid.NewGuid()` proibidos em arrange** — fixe valores ou parametrize via Mother. Tempo/ids aleatórios geram testes flaky e dificultam asserção.
- **`[Fact]`** para caso único; **`[Theory]` + `[InlineData]`** para múltiplos inputs com mesma estrutura (ex.: vários payloads inválidos → mesmo 400).
- **Um arquivo de teste por caso de uso** (`<UseCase>Tests.cs`), dentro de pasta por Aggregate/feature.

## Estrutura de arquivos

Um único projeto de teste de integração por aplicação (host), com sufixo `.IntegrationTests`. A pasta `Infrastructure/` concentra factory, base e collection; as features espelham a organização da Application.

```
<App>.IntegrationTests/
├── Infrastructure/
│   ├── IntegrationTestWebAppFactory.cs     ← container + migrations + Respawn
│   ├── BaseIntegrationTest.cs              ← HttpClient + helpers DbContext + reset
│   └── IntegrationTestCollection.cs        ← ICollectionFixture (1 container p/ suíte)
├── Contracts/                              ← DTOs request/response DUPLICADos (não reusar os da app)
│   └── <UseCase>Contracts.cs
├── Mothers/                                ← Object Mothers de seed (reuse os do domínio quando der)
│   └── <Aggregate>Mother.cs
└── <Aggregate>/
    ├── Create<Aggregate>Tests.cs
    ├── Update<Aggregate>StatusTests.cs
    ├── Get<Aggregate>Tests.cs
    └── <Aggregate>EventsTests.cs           ← publicação/consumo de eventos (se houver mensageria)
```

Exemplo concreto:

```
Ordering.Api.IntegrationTests/
├── Infrastructure/
│   ├── IntegrationTestWebAppFactory.cs
│   ├── BaseIntegrationTest.cs
│   └── IntegrationTestCollection.cs
├── Contracts/
│   └── OrderContracts.cs                   ← CreateOrderRequest, OrderResponse (cópias)
├── Mothers/
│   └── OrderMother.cs
└── Orders/
    ├── CreateOrderTests.cs
    └── RefundOrderTests.cs
```

→ Templates prontos em `references/infrastructure-setup.md` (factory/base/collection), `references/state-verification.md` (verificação), `references/seeding-data.md` (seed), `references/cleanup-strategies.md` (Respawn vs. transação-por-teste), `references/messaging-tests.md` (eventos com MassTransit/RabbitMQ) e `references/test-conventions.md` (convenções + exemplo de teste completo).

## Estilo da resposta

- **Comece curto**: 3-5 linhas dizendo quais arquivos vai gerar.
- **Um arquivo por bloco**, com o caminho como comentário no topo.
- **Infra primeiro** (se for cenário 1), depois os testes que dependem dela.
- **Não comente cada teste** — nomes auto-descritivos bastam.
- **Liste no fim**: pré-requisitos do `Program.cs` (ex.: "adicione `public partial class Program {}`"), nome da connection string assumida, e lacunas que dependem de confirmação.

## O que NÃO fazer

- Não usar `InMemory` provider nem SQLite no lugar do Postgres real — perde-se o ponto do teste.
- Não remover/re-adicionar `DbContextOptions` do DI quando basta sobrescrever a connection string via `UseSetting`.
- Não verificar persistência reusando o DbContext da requisição (cache do change tracker mente) — scope novo + `AsNoTracking()`.
- Não usar o endpoint GET para verificar escrita quando o foco é provar persistência.
- Não reusar os DTOs da aplicação nos testes — duplicar para proteger o contrato.
- Não recriar o container a cada teste (lento) — um container por suíte + Respawn entre testes.
- Não pôr o reset do Respawn no `InitializeAsync` — vai no `DisposeAsync`, para o contrato "cada teste começa limpo e semeia o seu" se manter.
- Não semear via INSERT cru quando dá para semear pela factory do agregado — só caia para SQL cru em estado genuinamente inalcançável.
- Não usar `DateTime.UtcNow`/`Guid.NewGuid()` soltos no arrange.
- Não assertar que um evento **não** foi publicado usando o `ITestHarness` — o teste congela esperando o que nunca chega. Para "não publicou", verifique o efeito colateral ausente (ex.: linha não criada no banco) ou conte as publicações.
- Não confundir o in-memory transport do MassTransit com mock: ele é o transport real do framework rodando em memória, e é o padrão aceitável aqui. Só suba RabbitMQ via Testcontainers quando o objetivo for validar o broker de verdade.
- Não inventar endpoints, DTOs, eventos ou códigos HTTP que não existem no código — se faltar info, **pergunte**.
