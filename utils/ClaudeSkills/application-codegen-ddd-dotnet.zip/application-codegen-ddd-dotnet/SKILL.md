---
name: application-codegen-ddd-dotnet
description: Cria e mantém a camada Application em projetos .NET com Clean Architecture e DDD e mediator próprio (sem MediatR). Use sempre que o usuário pedir para criar Command, Handler, Query, Response, Model, Behavior, ApplicationException, IValidator, ou montar a operação inteira — frases como cria o command de X, monta o handler de Y, expõe a operação Z na Application, preciso de uma query pra listar W, adiciona idempotência aqui, cria validações para Command V disparam a skill mesmo sem citar Application. Cobre Commands com TenantId (Model opcional só quando body diverge), Handlers sealed que orquestram agregado via método rico, Queries com cursor pagination, idempotência via IRequestManager, Application Errors separados de Domain Errors (Application só captura DomainException), validações próprias do .NET (sem FluentValidation, só quando pedido), Behaviors (Logging padrão, Transaction via marker IMultiAggregateCommand). Para API use api-codegen-ddd-dotnet. Para Domain use domain-modeler.
---

# application-codegen-ddd-dotnet

Camada Application em .NET seguindo Clean Architecture e DDD. Corresponde ao círculo de **Use Cases** do livro de Uncle Bob — orquestra Entities (Domain) para realizar a intenção do caller (API).

Equivalência de termos:

| Termo desta skill | Clean Architecture |
|---|---|
| `Command` | Input Data / Request Model |
| `Handler` | Use Case Interactor |
| `Response` | Output Data / Response Model |
| `IRepository<T>` (vive em Domain) | Database Gateway (interface) |
| `Aggregate` (vive em Domain) | Entity (Critical Business Rules) |

A Dependency Rule sempre vale: Application depende de Domain (via interfaces), nunca o contrário. API e Infra dependem de Application.

## Filosofia

1. **Application orquestra, Domain decide.** Handler busca agregado, chama método rico (`bill.Approve(...)`), persiste. `if` de regra de negócio dentro do Handler é sinal de que o método deveria estar no agregado.
2. **CQRS rígido.** Command muta (vai pelo mediator); Query lê (vai por `IXxxQueries` dedicada, sem mediator).
3. **Multi-tenant em primeiro lugar.** `TenantId` é o primeiro parâmetro de todo Command, todo método de Query, e o primeiro filtro de todo `Where`. Sem exceção.
4. **Idempotência sempre.** Todo Command que vem de fora vai embrulhado em `IdentifiedCommand<TCmd, TRes>` checado contra a tabela `ClientRequests`.
5. **Erros separados Application/Domain.** Domain lança `DomainException` via factories `internal` do agregado. Application lança `ApplicationException` via `ApplicationErrors.<Factory>` para falhas de orquestração (não-encontrado, idempotência conflitante, concorrência). Application **nunca** captura `DomainException` para repackaging — deixa subir.
6. **Listas sempre paginadas e ordenadas por cursor.** Sem opt-in. Sem `Skip/Take` por offset.
7. **Convenção rígida sobre criatividade.** Mesma estrutura de pasta, mesma nomenclatura, mesmo template — para que outro dev abra, leia, e saiba.

## Quando o usuário pede algo nesta camada — fluxo

### Cenário A: criar operação nova (Command + Handler + Response)

Mais comum. Ex.: "cria o command de ApproveBill", "monta a operação de criar Employee".

Sequência:

1. **Confirmar agregado e operação.**
   - Qual agregado (Bill, Employee, etc.)? Existe no Domain?
   - Qual operação — Create, Alter (qual método rico?), Delete (hard/soft), ação de domínio (Approve, Submit, ...)?
   - Se a operação não existe no Domain (ex.: método rico ainda não está no agregado), parar e indicar `domain-modeler`.
2. **Decidir se precisa de Model HTTP** — só se `TenantId` vem do path da rota OU o body diverge do Command. Default da skill: cria Model. Ver `references/command-anatomy.md` para a árvore de decisão completa.
3. **Localizar a pasta** — `Application/Commands/<Aggregate>Commands/<Operation>/`. Ver `references/folder-structure.md`.
4. **Gerar Command + Handler + Response + IdentifiedCommandHandler + (opcional) Model.** Ver `references/command-anatomy.md` e `references/handler-anatomy.md`.
5. **Decidir SaveChanges vs Transaction.** Default `UnitOfWork.SaveChangesAsync`; multi-aggregate via marker `IMultiAggregateCommand` aciona `TransactionBehavior`. Ver `references/transactions.md`.
6. **Gerar diagrama de sequência** Mermaid se a operação tem efeito colateral relevante. Ver `references/diagrams.md`.

### Cenário B: criar Query nova

Ex.: "preciso listar Bills paginado", "cria a query GetBillById".

Sequência:

1. Confirmar agregado e o que retornar (List + Detail + Find).
2. Gerar `IXxxQueries` (interface) + `XxxQueries` (impl) + DTOs + `XxxListParams` (params com cursor + sort obrigatórios). Ver `references/query-anatomy.md`.
3. Registrar no DI em `Application/Extension/ApplicationExtensions.cs`. Ver `references/dependency-injection.md`.

### Cenário C: setup inicial da Application

Ex.: "configura a camada Application", "implementa o mediator próprio".

Sequência:

1. Gerar Mediator próprio em `Application/Mediator/` (IRequest, IRequestHandler, IPipelineBehavior, IMediator, Mediator, IdentifiedCommand, IdentifiedCommandHandler, IRequestManager, IDbContextProvider, IMultiAggregateCommand, MediatorRegistration). Ver `references/mediator-implementation.md`.
2. Gerar `Errors/ApplicationException.cs` + `Errors/ApplicationErrors.cs` com factories padrão. Ver `references/error-handling.md`.
3. Gerar `Behaviors/LoggingBehavior.cs` e `Behaviors/TransactionBehavior.cs`.
4. Gerar `Extension/ApplicationExtensions.cs` com `AddApplicationDependencies` (LoggingBehavior ativo; ValidatorBehavior comentado). Ver `references/dependency-injection.md`.
5. Marker assemblies (`CommandAssembly`, `ValidatorAssembly`), GlobalUsings, `SortOrder` global, `Cursor` em `Queries/`.

### Cenário D: adicionar validações de Command

Disparada **somente** quando o usuário pede explicitamente — frase típica: "crie validações de aplicação para o Command X".

Sequência:

1. Confirmar **quais campos** validar (não inventar regras de negócio — essas pertencem ao agregado).
2. Gerar `IValidator<TCommand>` em `Application/Validations/<Aggregate>Commands/<Command>Validator.cs`.
3. Se for o primeiro validator do projeto: descomentar a linha do `ValidatorBehavior` em `ApplicationExtensions.cs` + gerar tipos base (`IValidator`, `ValidationResult`, `ValidationFailure`, `ValidationBuilder`) em `Application/Validations/`. Ver `references/validations.md`.
4. **Sem FluentValidation.** A skill recusa importar a biblioteca.

### Cenário E: mudança pontual (ex.: marcar Command como multi-aggregate)

- "Esse Command toca mais de um agregado" → adicionar `IMultiAggregateCommand` ao Command. Ver `references/transactions.md`.
- "Cachear resposta de idempotência" → mudança no `IdentifiedCommandHandler` + `IRequestManager`. Ver `references/improvements.md` item 2.

## Decisões fundamentais já fixadas

Se o usuário pedir mudança, alertar do impacto antes de gerar.

| Tema | Decisão |
|---|---|
| Mediator | Próprio (sem MediatR). Cache de wrappers via `ConcurrentDictionary`. |
| Validações | Próprias do .NET (DataAnnotations + `IValidator<TCommand>` + `ValidationBuilder`). **Sem FluentValidation**. |
| Pagination de lista | Cursor + sort obrigatório (sem offset). |
| Idempotência | `IdentifiedCommand` + tabela `ClientRequests` (header da camada acima: `Idempotency-Key`). |
| Transaction | `UnitOfWork.SaveChangesAsync` por default; `TransactionBehavior` dispara quando Command implementa `IMultiAggregateCommand`. |
| Erros | Separados: `ApplicationException` na camada Application, `DomainException` no Domain. Application **nunca** captura/repackeia DomainException. |
| Behaviors padrão | `LoggingBehavior` sempre; `TransactionBehavior` registrado mas dispara só para marker; `ValidatorBehavior` ativo quando há validators. |

## O que esta skill NÃO faz

- **Não cria projetos** (.csproj). Assume que `Application/` já existe como class library.
- **Não cria controllers, filtros, middlewares, autenticação** — camada API. Use `api-codegen-ddd-dotnet`.
- **Não cria DbContext, repositórios concretos, migrations** — camada Infra.
- **Não modela agregados, value objects, eventos** — camada Domain. Use `domain-modeler`.
- **Não gera validações de Command automaticamente.** Só quando o usuário pedir (cenário D).
- **Não decide regras de negócio** dentro do Handler. Regra fica no agregado.
- **Não importa as factories internal do Domain.** O modificador `internal` impede — Application só captura `DomainException` subindo.

## Quando perguntar antes de gerar

Pergunte, em vez de inventar, quando:

- Não souber se o agregado existe no Domain.
- Não souber qual método rico do agregado será chamado num `Alter*` ou ação.
- Não souber se Delete é hard ou soft.
- A operação chamar gateway externo (pedir contrato e SLA).
- A operação envolver mais de um agregado — confirmar se é mesmo `IMultiAggregateCommand` ou se é caso de Domain Event + Saga.

## Verbos de Command (resumo rápido)

- `Create<Aggregate>` — gera novo agregado.
- `Alter<Algo><Aggregate>` — muta um campo/aspecto específico. Sempre nominal: `AlterBillItems`, `AlterEmployeeAddress`. Não use `Update<Aggregate>` (é genérico — a pasta deve dizer **o que** muda).
- `Delete<Aggregate>` — remove (hard ou soft, confirme com o usuário).
- Verbo de domínio: `Approve`, `Submit`, `Cancel`, `Reconcile`, `Pay`. Vem do ubiquitous language do bounded context.

## Referências

Leia antes de começar o cenário correspondente:

- `references/folder-structure.md` — estrutura completa de pastas, marker assemblies, GlobalUsings, convenções de nomenclatura, IMultiAggregateCommand, IDbContextProvider. **Leia no cenário A, B ou C.**
- `references/mediator-implementation.md` — código completo do mediator próprio. **Leia no cenário C.**
- `references/command-anatomy.md` — Command, Model (quando criar), Response, padrões por tipo de operação (Create, Alter, Delete, upload, ação). **Leia no cenário A.**
- `references/handler-anatomy.md` — Handler sealed, IdentifiedCommandHandler par, multi-tenancy, mutação via método rico. **Leia no cenário A.**
- `references/query-anatomy.md` — IXxxQueries, cursor pagination, sort obrigatório, params, projeção. **Leia no cenário B.**
- `references/error-handling.md` — ApplicationException, ApplicationErrors, separação estrita de DomainException. **Leia no cenário A ou C.**
- `references/validations.md` — metodologia própria, ValidationBuilder, ValidatorBehavior. **Leia no cenário D.**
- `references/transactions.md` — UnitOfWork.SaveChanges vs TransactionBehavior, IMultiAggregateCommand, ExecutionStrategy. **Leia no cenário A (decisão de SaveChanges) ou E.**
- `references/multi-tenancy.md` — jornada do TenantId, regras anti-IDOR. **Consulte em qualquer cenário.**
- `references/idempotency.md` — IRequestManager, IdentifiedCommandHandler, ClientRequests. **Leia no cenário A (default) ou E.**
- `references/dependency-injection.md` — AddApplicationDependencies, AddCustomMediator, política de behaviors. **Leia no cenário C.**
- `references/improvements.md` — recomendações opcionais (Result\T, idempotência cacheada, Outbox, strongly-typed Ids, métricas). **Leia antes de iniciar um projeto do zero** — várias mudam a forma de gerar código.
- `references/diagrams.md` — biblioteca Mermaid (sequência Command/Query, fluxograma idempotência, ER, classes, estados, bounded context, arquitetura). **Consulte ao gerar diagrama.**
