---
name: application-codegen-ddd-dotnet
description: Cria e mantém a camada Application em projetos .NET com Clean Architecture e DDD e mediator próprio (sem MediatR). Use sempre que o usuário pedir para criar Command, Handler, Query, Response, Model, Behavior, IValidator, ou montar a operação inteira — frases como cria o command de X, monta o handler de Y, expõe a operação Z na Application, preciso de uma query pra listar W, adiciona idempotência aqui, cria validações para Command V disparam a skill mesmo sem citar Application. Cobre Commands com TenantId, Handlers sealed que orquestram agregado via método rico (Change Tracking sem repo.Update, validação obrigatória de IDs via ExistsAsync), Queries com cursor pagination, idempotência via IRequestManager, erros centralizados no Domain (Application só dispara DomainException, sem ApplicationErrors), validações próprias do .NET, Behaviors (Logging, Transaction via marker IMultiAggregateCommand). Para API use api-codegen-ddd-dotnet. Para Domain use domain-modeler.
---

# application-codegen-ddd-dotnet

Camada Application em .NET seguindo Clean Architecture e DDD. Corresponde ao círculo de **Use Cases** do livro de Uncle Bob — orquestra Entities (Domain) para realizar a intenção do caller (API).

Equivalência de termos:

| Termo desta skill | Clean Architecture |
|---|---|
| `Command` | Input Data / Request Model |
| `Handler` | Use Case Interactor |
| `Response` | Output Data / Response Model |
| `IRepository<T>` (vive em Domain) | Database Gateway (interface) |
| `Aggregate` (vive em Domain) | Entity (Critical Business Rules) |

A Dependency Rule sempre vale: Application depende de Domain (via interfaces), nunca o contrário. API e Infra dependem de Application.

## Filosofia

1. **Application orquestra, Domain decide.** Handler busca agregado, chama método rico (`bill.Approve(...)`), persiste. Todo `if` que compara propriedade de domínio (`Status`, `Direction`, `Period`, `Amount`) é vazamento — pertence ao agregado. Toda decisão sobre "quais entidades internas mexer" é do agregado (cascata interna), nunca um `foreach` no Handler chamando comando por comando.
2. **Um agregado modificado por transação.** Handler pode **ler** outros agregados pra alimentar o método rico, mas **modificar** mais de um agregado na mesma transação é violação direta da regra do Vernon. A saída é **eventual consistency via Domain Event** (Outbox + handler que escuta). Marker `IMultiAggregateCommand` existe como exceção controlada — não como atalho.
3. **Change Tracking, nunca `Update()`.** O Repository expõe métodos de busca **tracked** (sem `AsNoTracking`); o EF detecta mutações automaticamente; `SaveChangesAsync` persiste. **Nunca** chame `repo.Update(aggregate)` antes do save — é redundante e mascara o padrão. `repo.Update` só existe para entidades detached (fora do escopo da Application).
4. **CQRS rígido.** Command muta (vai pelo mediator); Query lê (vai por `IXxxQueries` dedicada com `AsNoTracking`, sem mediator).
5. **Multi-tenant em primeiro lugar.** `TenantId` é o primeiro parâmetro de todo Command, todo método de Query, e o primeiro filtro de todo `Where`. Sem exceção.
6. **Idempotência sempre.** Todo Command que vem de fora vai embrulhado em `IdentifiedCommand<TCmd, TRes>` checado contra a tabela `ClientRequests`.
7. **Erros são do Domain. Application apenas dispara.** Não existe `ApplicationException`, não existe `ApplicationErrors`, não existe pasta `Application/Errors/`. Cada agregado define seu `<Aggregate>Errors.cs` (`internal static class`) no Domain, com factory `NotFound(id)` obrigatória e outras para invariantes/conflitos. O Handler chama `throw <Aggregate>Errors.<Factory>(...)` quando uma verificação de orquestração falha. `DomainException` sobe direto pro filtro da API. Mecanismos técnicos da plataforma (validação de input, idempotência) são exceções simples (`CommandValidationException`, `IdempotencyConflictException`), não catálogo. Ver `references/error-handling.md`.
8. **Validação de IDs recebidos é mandatória.** Todo `Guid` em Command que represente referência a outro agregado (ou ao agregado-raiz da ação) **deve** ser validado antes da mutação: agregado-raiz via `FirstOrDefaultAsync(... TenantId, ct) ?? throw <Agg>Errors.NotFound(id)`; referências externas via `ExistsAsync(id, tenantId, ct)` + `throw <RefAgg>Errors.NotFound(id)`. IDs de entidades internas do agregado-raiz (ex.: `CommitmentId` dentro de `Contract`) **não** são validados no Handler — quem valida é o método rico. Ver `references/handler-anatomy.md` → "Validação de IDs recebidos é obrigatória".
9. **Listas sempre paginadas e ordenadas por cursor.** Sem opt-in. Sem `Skip/Take` por offset.
10. **Convenção rígida sobre criatividade.** Mesma estrutura de pasta, mesma nomenclatura, mesmo template — para que outro dev abra, leia, e saiba.

## O Handler é uma das peças mais fáceis de errar — leia esta seção

O Handler tem **uma única forma legítima**:

```csharp
public async Task<XxxResponse> Handle(XxxCommand request, CancellationToken ct)
{
    // 1) Resolver dependências externas que o método rico precisa (consulta a outros repos, gateways)
    // 2) Carregar o agregado-raiz via busca tracked + filtro de TenantId
    // 3) Chamar UM método rico passando os dados resolvidos
    // 4) await repo.UnitOfWork.SaveChangesAsync(ct)
    // 5) return new XxxResponse(aggregate.Id);
}
```

Qualquer coisa fora disso é sinal de problema. Sintomas comuns que a skill **recusa gerar**:

| Sintoma no Handler | O que isto significa | Solução |
|---|---|---|
| `if (aggregate.Status != X) throw ...` | Validação de transição vazou do método rico | Mover o `if` para dentro do método rico do agregado |
| `if (aggregate.Items.Any(i => ...)) throw ...` | Decisão sobre invariante interna vazou | Encapsular no método rico |
| `aggregate.Items.Where(...).ToList(); foreach (var x in ...) aggregate.Cancel(x);` | Handler decidindo "o que" mexer dentro do agregado | Passar parâmetro pro método rico que faz a cascata interna |
| Dois `aggregate.Save` em agregados diferentes na mesma transação | Violação da regra de um-agregado-por-transação | Emitir Domain Event → handler async (Outbox) |
| `var x = new Money(...); var y = new Period(...); var event = Event.Create(x, y, ...)` no Handler | Composição de Value Objects de domínio fora do Domain | Factory method estático no agregado (`Event.RegisterFor(contract, commitment, ...)`) |
| `repo.Update(aggregate)` antes do save | Padrão de entidade detached usado em entidade tracked | Remover. Busca tracked + `SaveChangesAsync` basta |
| `request.ResourceId` (ou qualquer `Guid`) passa direto para `request.ToAggregate()` ou para método rico sem `ExistsAsync` | ID de referência externa não validado | Antes da mutação: `if (!await refRepo.ExistsAsync(id, tenantId, ct)) throw <RefAgg>Errors.NotFound(id)` |
| `throw ApplicationErrors.<X>(...)` ou `throw new ApplicationException(...)` | Application inventando catálogo de erros — proibido | Substituir por factory do Domain: `throw <Aggregate>Errors.<X>(...)` |

Quando o usuário pedir um Handler que cairia em qualquer um desses sintomas, **a skill pergunta primeiro** se o método rico no agregado existe (ou precisa ser criado via `domain-modeler`), e nunca gera com a regra exposta no Handler.

## Quando o usuário pede algo nesta camada — fluxo

### Cenário A: criar operação nova (Command + Handler + Response)

Mais comum. Ex.: "cria o command de ApproveBill", "monta a operação de criar Employee".

Sequência:

1. **Confirmar agregado e operação.**
   - Qual agregado (Bill, Employee, etc.)? Existe no Domain?
   - Qual operação — Create, Alter (qual método rico?), Delete (hard/soft), ação de domínio (Approve, Submit, ...)?
   - Se a operação não existe no Domain (ex.: método rico ainda não está no agregado), parar e indicar `domain-modeler`.
2. **Decidir se precisa de Model HTTP** — só se `TenantId` vem do path da rota OU o body diverge do Command. Default da skill: cria Model. Ver `references/command-anatomy.md` para a árvore de decisão completa.
3. **Localizar a pasta** — `Application/Commands/<Aggregate>Commands/<Operation>/`. Ver `references/folder-structure.md`.
4. **Gerar Command + Handler + Response + IdentifiedCommandHandler + (opcional) Model.** Ver `references/command-anatomy.md` e `references/handler-anatomy.md`.
5. **Decidir SaveChanges vs Transaction.** Default `UnitOfWork.SaveChangesAsync`; multi-aggregate via marker `IMultiAggregateCommand` aciona `TransactionBehavior`. Ver `references/transactions.md`.
6. **Gerar diagrama de sequência** Mermaid se a operação tem efeito colateral relevante. Ver `references/diagrams.md`.

### Cenário B: criar Query nova

Ex.: "preciso listar Bills paginado", "cria a query GetBillById".

Sequência:

1. Confirmar agregado e o que retornar (List + Detail + Find).
2. Gerar `IXxxQueries` (interface) + `XxxQueries` (impl) + DTOs + `XxxListParams` (params com cursor + sort obrigatórios). Ver `references/query-anatomy.md`.
3. Registrar no DI em `Application/Extension/ApplicationExtensions.cs`. Ver `references/dependency-injection.md`.

### Cenário C: setup inicial da Application

Ex.: "configura a camada Application", "implementa o mediator próprio".

Sequência:

1. Gerar Mediator próprio em `Application/Mediator/` (IRequest, IRequestHandler, IPipelineBehavior, IMediator, Mediator, IdentifiedCommand, IdentifiedCommandHandler, IRequestManager, IDbContextProvider, IMultiAggregateCommand, MediatorRegistration, **IdempotencyConflictException**). Ver `references/mediator-implementation.md`.
2. Gerar `Behaviors/LoggingBehavior.cs`, `Behaviors/TransactionBehavior.cs` e a exception técnica **`Behaviors/CommandValidationException.cs`** (lançada pelo `ValidatorBehavior` quando ativo). **Nenhum** `ApplicationException` nem `ApplicationErrors` — erros de regra/negócio vêm do Domain via `<Aggregate>Errors`. Ver `references/error-handling.md`.
3. Gerar `Extension/ApplicationExtensions.cs` com `AddApplicationDependencies` (LoggingBehavior ativo; ValidatorBehavior comentado). Ver `references/dependency-injection.md`.
4. Marker assemblies (`CommandAssembly`, `ValidatorAssembly`), GlobalUsings, `SortOrder` global, `Cursor` em `Queries/`.

### Cenário D: adicionar validações de Command

Disparada **somente** quando o usuário pede explicitamente — frase típica: "crie validações de aplicação para o Command X".

Sequência:

1. Confirmar **quais campos** validar (não inventar regras de negócio — essas pertencem ao agregado).
2. Gerar `IValidator<TCommand>` em `Application/Validations/<Aggregate>Commands/<Command>Validator.cs`.
3. Se for o primeiro validator do projeto: descomentar a linha do `ValidatorBehavior` em `ApplicationExtensions.cs` + gerar tipos base (`IValidator`, `ValidationResult`, `ValidationFailure`, `ValidationBuilder`) em `Application/Validations/`. Ver `references/validations.md`.
4. **Sem FluentValidation.** A skill recusa importar a biblioteca.

### Cenário E: mudança pontual (ex.: marcar Command como multi-aggregate)

- "Esse Command toca mais de um agregado" → adicionar `IMultiAggregateCommand` ao Command. Ver `references/transactions.md`.
- "Cachear resposta de idempotência" → mudança no `IdentifiedCommandHandler` + `IRequestManager`. Ver `references/improvements.md` item 2.

## Decisões fundamentais já fixadas

Se o usuário pedir mudança, alertar do impacto antes de gerar.

| Tema | Decisão |
|---|---|
| Mediator | Próprio (sem MediatR). Cache de wrappers via `ConcurrentDictionary`. |
| Validações | Próprias do .NET (DataAnnotations + `IValidator<TCommand>` + `ValidationBuilder`). **Sem FluentValidation**. |
| Pagination de lista | Cursor + sort obrigatório (sem offset). |
| Idempotência | `IdentifiedCommand` + tabela `ClientRequests` (header da camada acima: `Idempotency-Key`). |
| Persistência de mutação | **Change Tracking via busca tracked** (Repository devolve entidade tracked pelo EF — sem `AsNoTracking`). Handler **nunca** chama `repo.Update(...)`. `SaveChangesAsync` detecta mudanças automaticamente. |
| Transaction | `UnitOfWork.SaveChangesAsync` por default; `TransactionBehavior` dispara quando Command implementa `IMultiAggregateCommand`. |
| Multi-agregado | **Default**: emitir Domain Event no agregado-raiz, handler async reage via Outbox (eventual consistency). **Exceção controlada** via `IMultiAggregateCommand`, com justificativa documentada. |
| Validação de IDs | **Mandatória** em todo Handler. Agregado-raiz via `FirstOrDefaultAsync(..., TenantId, ct) ?? throw <Agg>Errors.NotFound(id)`. Referências externas via `<Ref>Repository.ExistsAsync(id, TenantId, ct)` + `throw <RefAgg>Errors.NotFound(id)`. Entidades internas validam pelo método rico do agregado. |
| Erros | **Todos** os erros de regra/negócio são `DomainException` fabricados por factories `internal` no Domain (`<Aggregate>Errors`). Application **não tem** `ApplicationException`, `ApplicationErrors` nem pasta `Application/Errors/`. Mecanismos técnicos (validação, idempotência) usam exceptions simples (`CommandValidationException`, `IdempotencyConflictException`) — não catálogo. |
| Behaviors padrão | `LoggingBehavior` sempre; `TransactionBehavior` registrado mas dispara só para marker; `ValidatorBehavior` ativo quando há validators. |

## O que esta skill NÃO faz

- **Não cria projetos** (.csproj). Assume que `Application/` já existe como class library.
- **Não cria controllers, filtros, middlewares, autenticação** — camada API. Use `api-codegen-ddd-dotnet`.
- **Não cria DbContext, repositórios concretos, migrations** — camada Infra.
- **Não modela agregados, value objects, eventos** — camada Domain. Use `domain-modeler`.
- **Não gera validações de Command automaticamente.** Só quando o usuário pedir (cenário D).
- **Não decide regras de negócio** dentro do Handler. Regra fica no agregado.
- **Não importa as factories internal do Domain.** O modificador `internal` impede — Application só captura `DomainException` subindo.

## Quando perguntar antes de gerar

Pergunte, em vez de inventar, quando:

- Não souber se o agregado existe no Domain.
- Não souber qual método rico do agregado será chamado num `Alter*` ou ação.
- Não souber se Delete é hard ou soft.
- A operação chamar gateway externo (pedir contrato e SLA).
- A operação envolver mais de um agregado — **default é Domain Event + handler async**; confirme explicitamente se é caso raro de `IMultiAggregateCommand` (todas as 4 exceções do Vernon precisam ser justificadas).
- A descrição do usuário pedir Handler com várias condições do tipo "se o status for X então...". Pare. Pergunte: esse `if` está dentro do método rico do agregado? Se não, ofereça mover.
- A operação iterar sobre coleções internas do agregado e chamar comando por entidade (`foreach (var x in agg.Items) agg.CancelItem(x)`). Isso é cascata — deve estar num único método rico do agregado, não orquestrado no Handler.
- O Command receber `Guid`s de referência para outros agregados, mas o Domain ainda **não tem** a factory `<RefAggregate>Errors.NotFound(id)`. A factory precisa existir antes — peça pra criar via `domain-codegen-ddd-dotnet` (ou direto) antes de gerar o Handler.
- O Repository do agregado referenciado **não tem** método `ExistsAsync(id, tenantId, ct)`. É contrato obrigatório nesta arquitetura — peça pra acrescentar antes.

## Verbos de Command (resumo rápido)

- `Create<Aggregate>` — gera novo agregado.
- `Alter<Algo><Aggregate>` — muta um campo/aspecto específico. Sempre nominal: `AlterBillItems`, `AlterEmployeeAddress`. Não use `Update<Aggregate>` (é genérico — a pasta deve dizer **o que** muda).
- `Delete<Aggregate>` — remove (hard ou soft, confirme com o usuário).
- Verbo de domínio: `Approve`, `Submit`, `Cancel`, `Reconcile`, `Pay`. Vem do ubiquitous language do bounded context.

## Referências

Leia antes de começar o cenário correspondente:

- `references/folder-structure.md` — estrutura completa de pastas, marker assemblies, GlobalUsings, convenções de nomenclatura, IMultiAggregateCommand, IDbContextProvider. **Leia no cenário A, B ou C.**
- `references/mediator-implementation.md` — código completo do mediator próprio. **Leia no cenário C.**
- `references/command-anatomy.md` — Command, Model (quando criar), Response, padrões por tipo de operação (Create, Alter, Delete, upload, ação). **Leia no cenário A.**
- `references/handler-anatomy.md` — Handler sealed, IdentifiedCommandHandler par, multi-tenancy, mutação via método rico. **Leia no cenário A.**
- `references/query-anatomy.md` — IXxxQueries, cursor pagination, sort obrigatório, params, projeção. **Leia no cenário B.**
- `references/error-handling.md` — doutrina: erros de regra/negócio são `DomainException` via factories `<Aggregate>Errors` no Domain; Application não tem catálogo de erros; exceptions técnicas de plataforma (`CommandValidationException`, `IdempotencyConflictException`). **Leia no cenário A ou C.**
- `references/validations.md` — metodologia própria, ValidationBuilder, ValidatorBehavior. **Leia no cenário D.**
- `references/transactions.md` — UnitOfWork.SaveChanges vs TransactionBehavior, IMultiAggregateCommand, ExecutionStrategy. **Leia no cenário A (decisão de SaveChanges) ou E.**
- `references/multi-tenancy.md` — jornada do TenantId, regras anti-IDOR. **Consulte em qualquer cenário.**
- `references/idempotency.md` — IRequestManager, IdentifiedCommandHandler, ClientRequests. **Leia no cenário A (default) ou E.**
- `references/dependency-injection.md` — AddApplicationDependencies, AddCustomMediator, política de behaviors. **Leia no cenário C.**
- `references/improvements.md` — recomendações opcionais (Result\T, idempotência cacheada, Outbox, strongly-typed Ids, métricas). **Leia antes de iniciar um projeto do zero** — várias mudam a forma de gerar código.
- `references/diagrams.md` — biblioteca Mermaid (sequência Command/Query, fluxograma idempotência, ER, classes, estados, bounded context, arquitetura). **Consulte ao gerar diagrama.**
