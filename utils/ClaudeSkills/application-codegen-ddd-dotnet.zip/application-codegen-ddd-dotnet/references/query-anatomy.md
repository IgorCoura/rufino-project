# Anatomia de Queries

Queries são o lado de leitura do CQRS. **Não usam mediator.** Vão direto: camada API (controller) → `IXxxQueries` → `IDbContextFactory<T>` → DTO. Mais simples, menos pipeline, mais performático para reads. Esta skill cobre a interface e a implementação que vivem na Application — quem chama (controller) é da camada acima.

---

## Estrutura de pastas

```
Application/Queries/Employee/
├── IEmployeeQueries.cs   ← interface
├── EmployeeQueries.cs    ← implementação
└── EmployeeDtos.cs       ← DTOs (Get, ListItem, Params, etc.)
```

Um aggregate, três arquivos. **Não cria pasta por query** — todas as queries do mesmo aggregate ficam no mesmo trio.

---

## Por que `IDbContextFactory<T>` em vez de `DbContext`?

- **Reads não compartilham transação com writes.** Cada query abre seu próprio `DbContext`, executa, fecha. Sem state compartilhado, sem risco de "tracking" interferir.
- **Concorrência.** Várias queries paralelas? Cada uma com seu DbContext, sem fila no mesmo contexto.
- **Simplicidade do dispose.** `using var context = factory.CreateDbContext();` — fim de método, dispose automático.

A Infrastructure registra o factory no DI:
```csharp
services.AddDbContextFactory<MeuSaaSContext>(opts => opts.UseSqlServer(...));
```

E o `EmployeeQueries` recebe `IDbContextFactory<MeuSaaSContext>`.

---

## `IEmployeeQueries.cs` — interface

```csharp
namespace MeuSaaS.Application.Queries.Employee;

public interface IEmployeeQueries
{
    Task<EmployeeDto> GetByIdAsync(Guid tenantId, Guid employeeId, CancellationToken ct = default);
    Task<EmployeeDto?> FindByIdAsync(Guid tenantId, Guid employeeId, CancellationToken ct = default);
    Task<PagedResult<EmployeeListItemDto>> ListAsync(Guid tenantId, EmployeeListParams parameters, CancellationToken ct = default);
    Task<bool> ExistsByCpfAsync(Guid tenantId, string cpf, CancellationToken ct = default);
}
```

Convenções:
- **`GetByIdAsync` lança exceção** se não encontrar (`ApplicationException` via `ApplicationErrors.AggregateNotFound`).
- **`FindByIdAsync` retorna `null`** se não encontrar. Use quando o caller pode tratar ausência sem erro.
- **`ListAsync` retorna `PagedResult<T>`** sempre — paginação por cursor + sort é default.
- **`ExistsBy<X>` retorna `bool`** — útil para validações de unicidade chamadas pelo Handler quando vale a pena pré-validar.

Toda assinatura recebe `tenantId` como **primeiro parâmetro**. Sem exceção.

---

## `EmployeeQueries.cs` — implementação

```csharp
using Microsoft.EntityFrameworkCore;

namespace MeuSaaS.Application.Queries.Employee;

public sealed class EmployeeQueries(IDbContextFactory<MeuSaaSContext> factory) : IEmployeeQueries
{
    public async Task<EmployeeDto> GetByIdAsync(Guid tenantId, Guid employeeId)
    {
        await using var context = factory.CreateDbContext();

        return await context.Employees
            .Where(e => e.Id == employeeId && e.TenantId == tenantId)
            .Select(e => new EmployeeDto(
                e.Id,
                e.Name,
                e.Cpf,
                e.BirthDate,
                e.Email,
                e.PhoneNumber,
                e.Status.Name,
                e.HiredAt,
                e.AddressId == null ? AddressDto.Empty : new AddressDto(
                    e.Address!.Street,
                    e.Address.Number,
                    e.Address.City,
                    e.Address.State,
                    e.Address.ZipCode)))
            .FirstOrDefaultAsync()
            ?? throw ApplicationErrors.AggregateNotFound(nameof(Employee), employeeId.ToString());
    }

    public async Task<EmployeeDto?> FindByIdAsync(Guid tenantId, Guid employeeId)
    {
        await using var context = factory.CreateDbContext();

        return await context.Employees
            .Where(e => e.Id == employeeId && e.TenantId == tenantId)
            .Select(e => new EmployeeDto(
                e.Id, e.Name, e.Cpf, e.BirthDate, e.Email, e.PhoneNumber,
                e.Status.Name, e.HiredAt, AddressDto.Empty))
            .FirstOrDefaultAsync();
    }

    public async Task<PagedResult<EmployeeListItemDto>> ListAsync(
        Guid tenantId, EmployeeListParams parameters, CancellationToken ct = default)
    {
        await using var context = factory.CreateDbContext();

        IQueryable<Employee> query = context.Employees
            .Where(e => e.TenantId == tenantId);

        if (!string.IsNullOrWhiteSpace(parameters.NameLike))
            query = query.Where(e => EF.Functions.Like(e.Name, $"%{parameters.NameLike}%"));

        if (parameters.Status is not null)
            query = query.Where(e => e.Status.Name == parameters.Status);

        // Ordenação OBRIGATÓRIA — define a "ordem do cursor".
        // Sempre desempata por Id pra cursor ser determinístico.
        query = (parameters.SortBy, parameters.SortOrder) switch
        {
            (EmployeeSortBy.Name,    SortOrder.Asc)  => query.OrderBy(e => e.Name).ThenBy(e => e.Id),
            (EmployeeSortBy.Name,    SortOrder.Desc) => query.OrderByDescending(e => e.Name).ThenByDescending(e => e.Id),
            (EmployeeSortBy.HiredAt, SortOrder.Asc)  => query.OrderBy(e => e.HiredAt).ThenBy(e => e.Id),
            (EmployeeSortBy.HiredAt, SortOrder.Desc) => query.OrderByDescending(e => e.HiredAt).ThenByDescending(e => e.Id),
            _                                        => query.OrderBy(e => e.Id) // fallback
        };

        // Aplica cursor (se houver). O cursor codifica os campos de sort + Id do último item.
        if (Cursor.TryDecode(parameters.Cursor, out var cursor))
            query = ApplyCursor(query, parameters.SortBy, parameters.SortOrder, cursor);

        // Pega PageSize + 1 pra saber se há próxima página sem precisar de COUNT.
        var rawItems = await query
            .Take(parameters.PageSize + 1)
            .Select(e => new
            {
                e.Id, e.Name, e.Cpf, StatusName = e.Status.Name, e.HiredAt
            })
            .ToListAsync(ct);

        var hasMore = rawItems.Count > parameters.PageSize;
        var pageItems = rawItems.Take(parameters.PageSize).ToList();

        var dtos = pageItems
            .Select(e => new EmployeeListItemDto(e.Id, e.Name, e.Cpf, e.StatusName))
            .ToList();

        string? nextCursor = null;
        if (hasMore && pageItems.Count > 0)
        {
            var last = pageItems[^1];
            nextCursor = Cursor.Encode(parameters.SortBy switch
            {
                EmployeeSortBy.Name    => new CursorState(last.Id, last.Name),
                EmployeeSortBy.HiredAt => new CursorState(last.Id, last.HiredAt),
                _                      => new CursorState(last.Id, null)
            });
        }

        return new PagedResult<EmployeeListItemDto>(dtos, nextCursor);
    }

    // Aplica o WHERE adequado pra "depois do cursor" (estável com sort + Id de desempate).
    private static IQueryable<Employee> ApplyCursor(
        IQueryable<Employee> query,
        EmployeeSortBy sortBy,
        SortOrder order,
        CursorState cursor) => (sortBy, order) switch
    {
        (EmployeeSortBy.Name, SortOrder.Asc) => query.Where(e =>
            string.Compare(e.Name, (string)cursor.Anchor!) > 0 ||
            (e.Name == (string)cursor.Anchor! && e.Id.CompareTo(cursor.Id) > 0)),
        (EmployeeSortBy.Name, SortOrder.Desc) => query.Where(e =>
            string.Compare(e.Name, (string)cursor.Anchor!) < 0 ||
            (e.Name == (string)cursor.Anchor! && e.Id.CompareTo(cursor.Id) < 0)),
        (EmployeeSortBy.HiredAt, SortOrder.Asc) => query.Where(e =>
            e.HiredAt > (DateTime)cursor.Anchor! ||
            (e.HiredAt == (DateTime)cursor.Anchor! && e.Id.CompareTo(cursor.Id) > 0)),
        (EmployeeSortBy.HiredAt, SortOrder.Desc) => query.Where(e =>
            e.HiredAt < (DateTime)cursor.Anchor! ||
            (e.HiredAt == (DateTime)cursor.Anchor! && e.Id.CompareTo(cursor.Id) < 0)),
        _ => query.Where(e => e.Id.CompareTo(cursor.Id) > 0)
    };

    public async Task<bool> ExistsByCpfAsync(Guid tenantId, string cpf, CancellationToken ct = default)
    {
        await using var context = factory.CreateDbContext();
        return await context.Employees
            .AnyAsync(e => e.TenantId == tenantId && e.Cpf == cpf, ct);
    }
}
```

**Pontos invioláveis:**

- `await using var context = factory.CreateDbContext();` em toda função.
- **Filtro por `TenantId` em primeiro lugar.** Antes de qualquer outro `Where`.
- **`Select` projetando direto para DTO dentro da query.** Nunca carregue o aggregate inteiro pra mapear depois — vira `SELECT *` desnecessário.
- **`?? throw ApplicationErrors.AggregateNotFound(...)` para "não encontrado" em `GetByIdAsync`**. Não em `FindByIdAsync`.
- **`Status.Name`** quando o aggregate usa Smart Enum — projeta a string, não o objeto inteiro.
- **`EF.Functions.Like` para LIKE/contains** — performático e SQL-friendly.
- **Lista paginada por cursor + sort sempre.** `Skip/Take` está banido para listagens (ver "Por que cursor" abaixo).
- **`Take(PageSize + 1)`** pra detectar próxima página sem `Count()`.
- **Sort sempre desempata por `Id`** — cursor precisa ser determinístico.

---

## Por que cursor pagination, não offset (`Skip`/`Take` simples)

`Skip(N).Take(M)` (offset) é simples mas degrada em tabelas grandes:

- `OFFSET 100000` faz o banco **ler e descartar** 100k linhas. O5 desempenho cai linearmente com a posição da página.
- Se a tabela muda durante a navegação, itens podem "pular" de página (registro inserido entre paginas adjacentes desloca tudo).

Cursor pagination (`WHERE sort_field > last_value AND id > last_id`) é:

- **O(log n)** — usa índice direto.
- **Estável** — pular itens é raro; rebobinar não pula.
- **Desvantagem**: não dá `TotalCount` sem query adicional (e cara). Cliente que precisa de total faz query separada cacheada.

Para um SaaS multi-tenant onde tabelas chegam fácil em centenas de milhares de linhas, cursor é a escolha certa.

---

## `EmployeeDtos.cs` — DTOs

```csharp
namespace MeuSaaS.Application.Queries.Employee;

public record EmployeeDto(
    Guid Id,
    string Name,
    string Cpf,
    DateOnly BirthDate,
    string Email,
    string? PhoneNumber,
    string Status,
    DateTime HiredAt,
    AddressDto Address)
{
    public static EmployeeDto Empty
        => new(Guid.Empty, string.Empty, string.Empty, default, string.Empty, null,
               string.Empty, default, AddressDto.Empty);
}

public record EmployeeListItemDto(Guid Id, string Name, string Cpf, string Status);

public record AddressDto(string Street, string Number, string City, string State, string ZipCode)
{
    public static AddressDto Empty => new(string.Empty, string.Empty, string.Empty, string.Empty, string.Empty);
}

// ----- Params para list/filtro -----

public record EmployeeListParams(
    int PageSize = 50,
    string? Cursor = null,
    string? NameLike = null,
    string? Status = null,
    EmployeeSortBy SortBy = EmployeeSortBy.Name,
    SortOrder SortOrder = SortOrder.Asc);

public enum EmployeeSortBy { Name, HiredAt, Cpf }
```

**Pontos:**
- `record` sempre.
- **`Empty` estático** para DTOs que podem aparecer como "ausente" (ex.: `AddressDto.Empty` quando funcionário sem endereço).
- **Defaults sensatos**: `PageSize = 50` (ajustar caso a caso), `SortBy` campo natural do agregado.
- **`SortBy` enum por aggregate** — nunca string mágica.
- **`SortOrder` é global** (`Application/Queries/SortOrder.cs`).
- **NÃO existe `PageNumber` nem `SizeSkip`.** Cursor é o único mecanismo de paginação.

---

## `BaseDtos.cs` — DTOs reaproveitados

```csharp
namespace MeuSaaS.Application.DTO;

public record PagedResult<T>(IReadOnlyList<T> Items, string? NextCursor)
{
    public bool HasMore => NextCursor is not null;
}

public record EnumerationDto(int Id, string Name)
{
    public static implicit operator EnumerationDto(SmartEnum<int> e) => new(e.Value, e.Name);
}
```

`SortOrder` em `Application/Queries/SortOrder.cs`:

```csharp
namespace MeuSaaS.Application.Queries;

public enum SortOrder { Asc, Desc }
```

---

## `Cursor` — codificação do cursor

```csharp
namespace MeuSaaS.Application.Queries;

using System.Text;
using System.Text.Json;

/// <summary>
/// Estado interno do cursor: Id de desempate + valor do campo de sort (anchor).
/// </summary>
public sealed record CursorState(Guid Id, object? Anchor);

public static class Cursor
{
    public static string Encode(CursorState state)
    {
        var json = JsonSerializer.Serialize(state, JsonOpts.Default);
        return Convert.ToBase64String(Encoding.UTF8.GetBytes(json));
    }

    public static bool TryDecode(string? raw, out CursorState state)
    {
        state = null!;
        if (string.IsNullOrWhiteSpace(raw)) return false;
        try
        {
            var json = Encoding.UTF8.GetString(Convert.FromBase64String(raw));
            state = JsonSerializer.Deserialize<CursorState>(json, JsonOpts.Default)!;
            return state is not null;
        }
        catch
        {
            return false;
        }
    }

    private static class JsonOpts
    {
        public static readonly JsonSerializerOptions Default = new()
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        };
    }
}
```

Cursor é **opaco** para o cliente — ele só passa de volta sem inspecionar. Codificação base64 ajuda a evitar caracteres problemáticos em URLs.

---

## Padrão para Query com filtros opcionais

Todos os filtros são `string?` ou `T?`. Aplica condicionalmente no LINQ:

```csharp
var query = context.Bills.Where(b => b.TenantId == tenantId);

if (!string.IsNullOrWhiteSpace(parameters.SupplierLike))
    query = query.Where(b => EF.Functions.Like(b.SupplierName, $"%{parameters.SupplierLike}%"));

if (parameters.MinAmount is not null)
    query = query.Where(b => b.Amount >= parameters.MinAmount);

if (parameters.MaxAmount is not null)
    query = query.Where(b => b.Amount <= parameters.MaxAmount);

if (parameters.DueDateFrom is not null)
    query = query.Where(b => b.DueDate >= parameters.DueDateFrom);

if (parameters.DueDateTo is not null)
    query = query.Where(b => b.DueDate <= parameters.DueDateTo);
```

Cada `if` é um filtro independente. Composição linear. Fácil ler.

---

## Padrão para Query com agregação

Quando precisa contar/somar coisas (KPIs, dashboards), faz a agregação no `GroupBy` e projeta para DTO:

```csharp
public async Task<IReadOnlyList<MonthlyExpenseDto>> GetMonthlyExpensesAsync(
    Guid tenantId, int year)
{
    await using var context = factory.CreateDbContext();

    return await context.Bills
        .Where(b => b.TenantId == tenantId && b.PaidAt != null && b.PaidAt.Value.Year == year)
        .GroupBy(b => b.PaidAt!.Value.Month)
        .Select(g => new MonthlyExpenseDto(g.Key, g.Sum(x => x.Amount), g.Count()))
        .OrderBy(d => d.Month)
        .ToListAsync();
}
```

Se o agregado fica complexo demais para LINQ, **caia para SQL puro com `FromSqlRaw` ou Dapper**. Não force LINQ a fazer SQL ruim.

---

## Anti-padrões (não faça)

- ❌ **Carregar o aggregate e mapear no .NET.**
  ```csharp
  // ❌
  var employee = await context.Employees.FindAsync(id);
  return new EmployeeDto(employee.Id, employee.Name, ...);

  // ✅
  return await context.Employees.Where(...).Select(e => new EmployeeDto(...)).FirstOrDefaultAsync();
  ```
- ❌ **Esquecer `TenantId`.** Todo `Where` começa com `e.TenantId == tenantId`.
- ❌ **Reusar `DbContext` entre métodos.** Cada método cria o seu via factory.
- ❌ **`AsNoTracking()` espalhado.** Usando `Select` para DTO o EF já não tracka. Não precisa de `AsNoTracking()` explícito.
- ❌ **Retornar `IEnumerable<T>`.** Sempre `IReadOnlyList<T>` ou `PagedResult<T>`. Caller não deve ter como mutar.
- ❌ **Lista sem paginação por cursor.** `Skip/Take` por offset está banido. Toda lista usa cursor + sort + Id de desempate.
- ❌ **Lista sem `SortBy`/`SortOrder` no params.** Mesmo se houver default, precisa estar explícito no record.
- ❌ **`PageNumber`/`SizeSkip` no params.** Não existe mais. `PageSize` + `Cursor` apenas.
- ❌ **`Count()` numa listagem grande pra montar `TotalCount`.** Cursor não tem total. Se cliente precisa, query separada cacheada.
- ❌ **Lógica de negócio na query.** Query lê. Decisão fica no Handler/Domain. Se a query precisa decidir "se for X então retorna Y senão Z", isso é regra que vai pra cima.

---

## Checklist da Query

- [ ] Interface em `Queries/<Aggregate>Queries/I<Aggregate>Queries.cs`.
- [ ] Implementação em `Queries/<Aggregate>Queries/<Aggregate>Queries.cs`.
- [ ] DTOs em `Queries/<Aggregate>Queries/<Aggregate>Dtos.cs`.
- [ ] Params em `Queries/<Aggregate>Queries/Params/<Aggregate>ListParams.cs`.
- [ ] Recebe `IDbContextFactory<T>` no construtor.
- [ ] `await using var context = factory.CreateDbContext()` em cada método.
- [ ] Filtro por `TenantId` em primeiro lugar.
- [ ] `Select` projeta direto para DTO.
- [ ] `GetByIdAsync` lança `ApplicationErrors.AggregateNotFound`; `FindByIdAsync` retorna `null`.
- [ ] `ListAsync` retorna `PagedResult<T>` com `NextCursor`.
- [ ] **Lista usa cursor pagination + sort sempre.** Sem exceção.
- [ ] **Sort sempre desempata por `Id`.**
- [ ] **`Take(PageSize + 1)`** pra detectar próxima página.
- [ ] DTOs são `record` com `Empty` estático quando aplicável.
- [ ] Registrada no DI em `ApplicationExtensions.cs`.
