# Multi-tenancy — dentro da Application

`TenantId` é o tenant. Uma empresa nunca pode enxergar/alterar dado de outra. Esta skill garante a **fatia de Application** dessa defesa: como `Command`, `Handler` e `Query` lidam com `TenantId`. As outras camadas (rota com `{tenantId}` na API, autorização do JWT, `HasQueryFilter` global no `DbContext`) ficam fora deste escopo — mas valem ser conhecidas.

## Defesa em profundidade — onde a Application entra

```mermaid
flowchart LR
    Route[Rota api/v1/{tenantId}/...] --> Ctrl[Controller<br/>CAMADA API]
    Ctrl -->|Model.ToCommand(tenantId)| Cmd[Command<br/>traz TenantId]
    Cmd --> Hdl[Handler<br/>filtra por TenantId]
    Hdl --> Repo[Repository]
    Repo --> Db[(DB com QueryFilter<br/>opcional global)]

    Ctrl -.->|para Query| Q[Query<br/>filtra por TenantId]
    Q --> Db

    style Cmd fill:#cfe
    style Hdl fill:#cfe
    style Q fill:#cfe
```

As caixas em verde são responsabilidade desta skill. A skill **garante** que essas três camadas sempre filtram. As outras camadas (rota, controller, query filter global) são camadas redundantes que somam.

## Regra 1 — `Command` carrega `TenantId` em primeiro

```csharp
public record CreateEmployeeCommand(
    Guid TenantId,       // ← sempre primeiro
    string Name,
    string Cpf
) : IRequest<EmployeeCreatedResponse>;
```

Vale para **todo** Command (Create, Alter, Delete, qualquer ação de domínio).

`Model` (DTO de input HTTP) **NÃO** tem `TenantId`:

```csharp
public record CreateEmployeeModel(string Name, string Cpf)
{
    public CreateEmployeeCommand ToCommand(Guid tenantId)
        => new(tenantId, Name, Cpf);
}
```

A camada API recebe o `tenantId` da rota e chama `model.ToCommand(tenantId)`. O `Model` nunca aceita `TenantId` no body — isso seria vetor de IDOR direto (cliente enviaria tenant de outro).

## Regra 2 — `Handler` filtra por `TenantId` antes de qualquer outro `Where`

```csharp
public sealed class AlterEmployeeNameCommandHandler(IEmployeeRepository repo)
    : IRequestHandler<AlterEmployeeNameCommand, EmployeeUpdatedResponse>
{
    public async Task<EmployeeUpdatedResponse> Handle(
        AlterEmployeeNameCommand request, CancellationToken ct)
    {
        // ✅ Multi-tenant: TenantId em primeiro lugar
        var employee = await repo.FirstOrDefaultAsync(
            x => x.TenantId == request.TenantId
              && x.Id == request.EmployeeId);

        if (employee is null)
            throw ApplicationErrors.AggregateNotFound(nameof(Employee), request.EmployeeId.ToString());

        employee.AlterName(request.Name);
        await repo.UnitOfWork.SaveChangesAsync(ct);
        return employee.Id;
    }
}
```

Atenção ao `ObjectNotFound` quando o registro existe **em outro tenant**: a mensagem é a mesma de "não existe". **Nunca** vaze a informação "esse id existe mas não é seu" — é leak de existência.

## Regra 3 — `Query` filtra por `TenantId` em primeiro lugar

```csharp
public async Task<EmployeeDto> GetByIdAsync(Guid tenantId, Guid id)
{
    await using var context = _factory.CreateDbContext();

    return await context.Employees
        .Where(x => x.TenantId == tenantId && x.Id == id)   // ✅ tenantId em primeiro
        .Select(x => new EmployeeDto(x.Id, x.Name, x.Cpf))
        .FirstOrDefaultAsync()
        ?? throw ApplicationErrors.AggregateNotFound(nameof(Employee), id.ToString());
}
```

`tenantId` é **sempre o primeiro parâmetro** dos métodos da `IXxxQueries` — convenção que ajuda a auditar visualmente.

## Anti-padrões que a skill recusa

```csharp
// ❌ Command sem TenantId
public record CreateEmployeeCommand(string Name, string Cpf) : IRequest<...>;

// ❌ Handler buscando sem filtrar tenant
var emp = await repo.FirstOrDefaultAsync(x => x.Id == request.EmployeeId);

// ❌ Model HTTP aceitando TenantId do cliente
public record CreateEmployeeModel(Guid TenantId, string Name, ...);

// ❌ Query sem tenantId
public async Task<EmployeeDto> GetByIdAsync(Guid id) { ... }
```

Se o usuário pedir explicitamente um Command sem `TenantId` (ex.: para uma operação **cross-tenant** legítima como "superadmin migra empresa"), a skill **pergunta** e exige que o usuário declare o caso. Default é **com** `TenantId`.

## Casos especiais

### Listagem das empresas que o usuário pertence

Não tem `{tenantId}` na rota porque o conceito é "minhas empresas". A camada API expõe algo como `/api/v1/me/companies`. O Query correspondente recebe `Guid userId` em vez de `Guid tenantId`.

```csharp
public interface IUserCompaniesQueries
{
    Task<IReadOnlyList<CompanyDto>> ListUserCompaniesAsync(Guid userId);
}
```

A Application aceita esse caso porque é **lookup de membership do usuário**, não dado de tenant. `userId` vem do JWT.

### Operação de admin cross-tenant

Modele em **bounded context separado** (`Admin/`). Convenção da rota muda (não tem `{tenantId}` na rota), Command **não** tem `TenantId`, e a autorização precisa ser muito mais estrita (policy `SuperAdminOnly`). A skill, se for chamada para isso, exige que o usuário diga explicitamente "isso é admin cross-tenant" — caso contrário, default seguro é com `TenantId`.

### Background worker / job

Worker **não tem `HttpContext`** — então não dá pra confiar em `HasQueryFilter` global que dependa de tenant atual. Worker que processa um agregado precisa receber `tenantId` explicitamente (pela mensagem da fila / parâmetro do job) e passar adiante. A skill segue a mesma regra: Command tem `TenantId`, Query recebe `tenantId` como parâmetro.

## Camadas redundantes (não responsabilidade desta skill, mas vale citar)

- **Rota** com `{tenantId}` no path — camada API.
- **Filtro de autorização** que valida se o usuário pertence ao `{tenantId}` da rota — camada API (idealmente um `IAsyncActionFilter` global).
- **Global Query Filter** no `DbContext` que filtra por `TenantId` automaticamente — camada Infra.

A presença dessas camadas **não dispensa** o filtro no Handler/Query. Defesa em profundidade significa que se uma falhar, a outra pega.

## Checklist (Application)

- [ ] Command tem `TenantId` como **primeiro parâmetro**.
- [ ] Model **NÃO** tem `TenantId`.
- [ ] Model tem `ToCommand(Guid tenantId)`.
- [ ] Handler filtra por `TenantId` **antes** de qualquer outro `Where`.
- [ ] Query tem `Guid tenantId` como **primeiro parâmetro** dos métodos.
- [ ] Query filtra por `TenantId` **antes** de qualquer outro `Where`.
- [ ] Quando não acha registro **mesmo existindo em outro tenant**, retorna o mesmo `ObjectNotFound` (sem leak).
