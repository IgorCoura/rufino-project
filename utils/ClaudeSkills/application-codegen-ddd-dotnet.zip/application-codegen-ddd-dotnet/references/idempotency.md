# Idempotência via `Idempotency-Key`

Toda operação de escrita passa por `IdentifiedCommand`. Se o mesmo `requestId` chegar duas vezes (por retry do cliente, por timeout que recuperou, por replay), o handler **não processa de novo** — devolve resposta neutra.

---

## Por que isso importa

Cenário: usuário aperta "Pagar conta", request vai, mas a resposta nunca volta (timeout de rede). UI mostra erro. Usuário aperta de novo. Sem idempotência: paga duas vezes. Com idempotência: a segunda passada vê que aquele `requestId` já foi processado, não faz nada, devolve sucesso vazio.

Princípio:
- Cliente é responsável por gerar um `Guid` único **por intenção do usuário**.
- Servidor é responsável por reconhecer o `Guid` e não reprocessar.

---

## Fluxo completo

```mermaid
flowchart TD
    A[Cliente gera Guid Idempotency-Key<br/>e envia POST/PUT] --> B[Controller]
    B --> C{Mediator.Send IdentifiedCommand}
    C --> D[IdentifiedCommandHandler]
    D --> E{IRequestManager.ExistAsync requestId?}
    E -->|sim| F[CreateResultForDuplicateRequest<br/>retorna Response neutra]
    E -->|não| G[CreateRequestForCommandAsync<br/>persiste o Id]
    G --> H[Mediator.Send Command real]
    H --> I[Handler real executa]
    I --> J[Response real]
    F --> K[Devolve para o cliente 200]
    J --> K
```

---

## `IRequestManager` — interface

```csharp
namespace MeuSaaS.Application.Mediator;

public interface IRequestManager
{
    Task<bool> ExistAsync(Guid id);
    Task CreateRequestForCommandAsync<T>(Guid id);
}
```

Implementação típica (na Infrastructure):

```csharp
namespace MeuSaaS.Infrastructure.Idempotency;

public class RequestManager(MeuSaaSContext context) : IRequestManager
{
    public Task<bool> ExistAsync(Guid id)
        => context.ClientRequests.AnyAsync(r => r.Id == id);

    public async Task CreateRequestForCommandAsync<T>(Guid id)
    {
        context.ClientRequests.Add(new ClientRequest
        {
            Id = id,
            Name = typeof(T).Name,
            Time = DateTimeOffset.UtcNow
        });
        await context.SaveChangesAsync();
    }
}
```

A tabela `ClientRequests` (na Infra):
```csharp
public class ClientRequest
{
    public Guid Id { get; set; }              // PK
    public string Name { get; set; } = "";
    public DateTimeOffset Time { get; set; }
}
```

PK é o `Id`. Isso garante que se duas threads concorrentes tentarem inserir o mesmo, o banco rejeita uma — `DbUpdateException(UniqueConstraint)` que o filtro da API mapeia para resposta HTTP.

---

## Como o cliente gera o `requestId`

Algumas estratégias:

### A — UUID novo a cada clique de submit

Mais simples. O front intercepta o submit do form, gera um `crypto.randomUUID()`, manda. Se o usuário clica de novo (por impaciência), gera **outro** UUID e manda — virando 2 cobranças se o backend processou as duas. Não resolve o problema real.

**Não use sozinho.**

### B — UUID estável por intenção (recomendado)

O front gera o UUID **uma vez** quando o formulário abre. Mantém na state do componente. Se o usuário submeter, e a resposta demorar/falhar, o front re-submete com **o mesmo** UUID. O backend reconhece e não duplica.

```javascript
// pseudo-Flutter
class PayBillForm {
  final String requestId = Uuid().v4();   // gerado uma vez por instância

  Future<void> submit() async {
    try {
      await api.post('/bills/pay', { 'amount': 100 },
        headers: { 'Idempotency-Key': requestId });
    } catch (e) {
      // pode tentar de novo com o MESMO requestId
    }
  }
}
```

### C — UUID derivado do conteúdo (idempotência por payload)

`requestId = sha256(payload)`. Se o mesmo payload for mandado, o `requestId` é o mesmo. Bom para ações verdadeiramente idempotentes (ex.: criar registro com chave natural). Ruim quando o mesmo conteúdo deve gerar duas operações distintas (ex.: duas transferências de R$100 entre as mesmas contas).

**Use só onde fizer sentido semântico.**

---

## `CreateResultForDuplicateRequest` — o que retornar?

```csharp
public class AlterEmployeeNameIdentifiedCommandHandler(...)
    : IdentifiedCommandHandler<AlterEmployeeNameCommand, AlterEmployeeNameResponse>(...)
{
    protected override AlterEmployeeNameResponse CreateResultForDuplicateRequest()
        => new(Guid.Empty);
}
```

Princípios:

- **Resposta semanticamente "ok, mas não te conto detalhes"**. `Guid.Empty` no Id, listas vazias, strings vazias.
- Cliente **não consegue distinguir** "processou agora" vs "já tinha processado". Isso é deliberado — para o cliente, ambos são "deu certo".
- Se o cliente realmente precisa do `Id` real do recurso (ex.: criou um Employee e quer o `Id`), ele consulta via GET depois. **Não confie em response de duplicação para dados.**

Anti-padrão: tentar buscar o resultado original e devolvê-lo. Por dois motivos:
- O resultado original pode não estar mais disponível (foi deletado, alterado).
- A complexidade de "guardar o resultado de cada request" é grande pra benefício pequeno. KISS.

---

## E se o handler real falhar depois de `CreateRequestForCommandAsync`?

```csharp
public async Task<R> Handle(IdentifiedCommand<T, R> request, CancellationToken ct)
{
    if (await requestManager.ExistAsync(request.Id))
        return CreateResultForDuplicateRequest();

    await requestManager.CreateRequestForCommandAsync<T>(request.Id);
    // <-- requestId já gravado

    return await mediator.Send(request.Command, ct);
    // <-- se aqui der throw, o requestId está no banco mas não houve efeito
}
```

Cenário: o `CreateRequestForCommandAsync` fez commit (gravou na tabela `ClientRequests`). Em seguida, o `mediator.Send` chama o handler real, que faz suas operações **no mesmo contexto de transação ou em outro**, e falha.

Resultado:
- Se o handler real usa o **mesmo `DbContext`** (mesma transação implícita), o rollback rola tudo, **incluindo a inserção em `ClientRequests`**. ✅ — quando o cliente repetir, vai entrar de novo, processar, sucesso.
- Se usa **DbContext separado** (ex.: chamada externa, contexto de outra database), aí sim — `ClientRequests` ficou gravado, handler real falhou. Cliente repete com o mesmo `requestId`, recebe `CreateResultForDuplicateRequest()` = sucesso vazio. **Mas o efeito não aconteceu.** Falsa idempotência.

Mitigação:

1. **Padrão simples (recomendado):** `RequestManager` usa o **mesmo `DbContext` Scoped** que o resto do handler. Como ambos compartilham o `DbContext`, o `SaveChangesAsync` final dispara junto. Se algo falhar antes, `ClientRequests` não foi commitado.

   Atenção ao detalhe: a versão da `RequestManager` apresentada acima chama `await context.SaveChangesAsync()` **dentro** do `CreateRequestForCommandAsync`. Isso commita imediatamente — não é o que queremos.

   Versão correta (mantém transação compartilhada):
   ```csharp
   public Task CreateRequestForCommandAsync<T>(Guid id)
   {
       context.ClientRequests.Add(new ClientRequest { Id = id, Name = typeof(T).Name, Time = DateTimeOffset.UtcNow });
       return Task.CompletedTask;   // SaveChanges fica para o handler real fazer junto
   }
   ```

   Então o `IdentifiedCommandHandler` precisa garantir que o `mediator.Send` rode **antes** de qualquer commit. O `Repository.UnitOfWork.SaveChangesAsync()` no fim do handler real commita os dois (a inserção em `ClientRequests` E a mutação do aggregate).

2. **Padrão multi-aggregate:** quando o Command toca mais de um agregado e está marcado com `IMultiAggregateCommand`, o `TransactionBehavior` abre `BeginTransactionAsync` automaticamente ao redor do Handler. A inserção em `ClientRequests` (sem `SaveChangesAsync` interno) e os múltiplos `SaveChangesAsync` dos repositórios entram todos na mesma transação. Ver `references/transactions.md`.

> **Recomendação:** começar com (1) — o caso default (Command que toca um agregado). Quando aparecer Command que toca mais de um, marcar com `IMultiAggregateCommand` e usar (2) automaticamente.

---

## Limpeza da tabela `ClientRequests`

A tabela cresce indefinidamente. Recomendações:

- **Job de limpeza** (por exemplo, semanal): apagar registros com `Time < UtcNow - 30 dias`. Trade-off: requests legitimamente duplicados após 30 dias seriam reprocessados. Aceitável na maioria dos casos (cliente não vai retentar 30 dias depois).
- **Particionamento** se a base for monstruosa (raramente necessário).
- **Não indexar campo `Name`** se você não consulta por ele. Só PK + `Time` para o job de limpeza.

---

## Anti-padrões (não faça)

- ❌ **Endpoint de escrita sem `[FromHeader] Idempotency-Key`.** Idempotência é universal. _(Responsabilidade da camada API — esta skill garante que o `IdentifiedCommand` sempre exista; quem expõe o HTTP precisa receber o header e popular o wrapper.)_
- ❌ **Cliente que não envia o header.** Tem dois caminhos:
  - Servidor rejeita com 400 ("requestId obrigatório") — preferido para forçar bom comportamento.
  - Servidor gera `Guid.NewGuid()` se ausente — não resolve nada (cada request vira um id novo). Use como "modo permissivo" só durante migração.
- ❌ **Mesmo `requestId` reutilizado para operações diferentes.** Frontend gera novo UUID por intenção/tela.
- ❌ **Confiar em retorno de operação duplicada para preencher UI.** Cliente sempre faz GET separado para confirmar estado.
- ❌ **`CreateResultForDuplicateRequest` lançando exceção.** É falso erro — cliente está reformatando algo legítimo.

---

## Checklist de idempotência

- [ ] `IdentifiedCommand<T, R>` definido em `Application/Mediator/`.
- [ ] `IdentifiedCommandHandler<T, R>` abstrato definido com `CreateResultForDuplicateRequest`.
- [ ] `IRequestManager` interface em `Application/Mediator/`, implementação na Infra.
- [ ] Tabela `ClientRequests` (PK = Id) na base.
- [ ] Todo Command tem `XxxIdentifiedCommandHandler` no mesmo arquivo do `XxxCommandHandler`.
- [ ] Todo controller de escrita tem `[FromHeader(Name = "Idempotency-Key")] Guid requestId` _(camada API — checklist incluído aqui só para referência cruzada)_.
- [ ] `CreateResultForDuplicateRequest` retorna valor neutro (Guid.Empty etc.).
- [ ] (Recomendado) `RequestManager.CreateRequestForCommandAsync` **não** chama `SaveChangesAsync` — fica para o handler real fazer junto.
- [ ] Job/script de limpeza periódica de registros antigos.
