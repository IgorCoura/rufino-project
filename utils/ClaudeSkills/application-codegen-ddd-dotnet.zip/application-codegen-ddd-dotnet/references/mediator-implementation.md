# Mediator próprio — substituto do MediatR

Esta é a implementação à mão do mediator. Mesma superfície que o MediatR (`IRequest<T>`, `IRequestHandler<,>`, `IPipelineBehavior<,>`, `IMediator.Send`), zero dependência externa. Toda a infraestrutura mora em `Application/Mediator/`.

---

## Por que mediator próprio?

- **Controle total.** Sabemos exatamente o que acontece em cada `Send`. Quando algo der errado, dá pra ler 200 linhas de código nosso, não escavar source de terceiro.
- **Zero risco de licenciamento.** MediatR mudou modelo de licença em 2024 — nada nos obriga a depender de uma escolha comercial alheia.
- **Mínimo essencial.** Implementamos só o que usamos: `Send` para um único response. Não temos `Publish` (events), nem `Stream`, nem reflection elaborada de notification handlers. Mantemos enxuto.

Trade-off honesto: perdemos o ecossistema (behaviors prontos da comunidade, exemplos abundantes, plugins). Aceitamos porque o código é simples e o time controla.

---

## Arquivos — código completo

### `IRequest.cs`

```csharp
namespace MeuSaaS.Application.Mediator;

/// <summary>
/// Marker interface para requests que retornam <typeparamref name="TResponse"/>.
/// Todo Command e Query implementa essa interface (mas Queries no nosso padrão
/// não usam mediator — vão direto pelas IXxxQueries).
/// </summary>
public interface IRequest<out TResponse> { }
```

### `IRequestHandler.cs`

```csharp
namespace MeuSaaS.Application.Mediator;

public interface IRequestHandler<in TRequest, TResponse>
    where TRequest : IRequest<TResponse>
{
    Task<TResponse> Handle(TRequest request, CancellationToken cancellationToken);
}
```

### `RequestHandlerDelegate.cs`

```csharp
namespace MeuSaaS.Application.Mediator;

/// <summary>
/// Delegate usado pelos pipeline behaviors para chamar "o próximo na cadeia".
/// Cada behavior recebe um <see cref="RequestHandlerDelegate{TResponse}"/>
/// que, quando invocado, executa o próximo behavior — ou o handler final.
/// </summary>
public delegate Task<TResponse> RequestHandlerDelegate<TResponse>();
```

### `IPipelineBehavior.cs`

```csharp
namespace MeuSaaS.Application.Mediator;

/// <summary>
/// Behavior que envolve a execução de um handler. Ordem de execução é definida
/// pela ordem de registro no DI: o primeiro registrado é o mais externo.
/// Use para cross-cutting concerns: logging, validação, transações, métricas.
/// </summary>
public interface IPipelineBehavior<in TRequest, TResponse>
    where TRequest : IRequest<TResponse>
{
    Task<TResponse> Handle(
        TRequest request,
        RequestHandlerDelegate<TResponse> next,
        CancellationToken cancellationToken);
}
```

### `IMediator.cs`

```csharp
namespace MeuSaaS.Application.Mediator;

public interface IMediator
{
    Task<TResponse> Send<TResponse>(
        IRequest<TResponse> request,
        CancellationToken cancellationToken = default);
}
```

### `Mediator.cs`

```csharp
using System.Collections.Concurrent;
using System.Reflection;
using Microsoft.Extensions.DependencyInjection;

namespace MeuSaaS.Application.Mediator;

public sealed class Mediator(IServiceProvider serviceProvider) : IMediator
{
    // Cache de wrappers por tipo de request — evita reflection a cada Send.
    private static readonly ConcurrentDictionary<Type, RequestHandlerWrapperBase> _handlerCache = new();

    public Task<TResponse> Send<TResponse>(
        IRequest<TResponse> request,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        var requestType = request.GetType();

        var wrapper = (RequestHandlerWrapper<TResponse>)_handlerCache.GetOrAdd(
            requestType,
            static t =>
            {
                var wrapperType = typeof(RequestHandlerWrapperImpl<,>)
                    .MakeGenericType(t, t.GetInterfaces()
                        .First(i => i.IsGenericType && i.GetGenericTypeDefinition() == typeof(IRequest<>))
                        .GetGenericArguments()[0]);
                return (RequestHandlerWrapperBase)Activator.CreateInstance(wrapperType)!;
            });

        return wrapper.Handle(request, serviceProvider, cancellationToken);
    }

    // ----- internals -----

    private abstract class RequestHandlerWrapperBase { }

    private abstract class RequestHandlerWrapper<TResponse> : RequestHandlerWrapperBase
    {
        public abstract Task<TResponse> Handle(
            IRequest<TResponse> request,
            IServiceProvider provider,
            CancellationToken ct);
    }

    private sealed class RequestHandlerWrapperImpl<TRequest, TResponse> : RequestHandlerWrapper<TResponse>
        where TRequest : IRequest<TResponse>
    {
        public override Task<TResponse> Handle(
            IRequest<TResponse> request,
            IServiceProvider provider,
            CancellationToken ct)
        {
            var handler = provider.GetService<IRequestHandler<TRequest, TResponse>>()
                ?? throw new InvalidOperationException(
                    $"Handler para {typeof(TRequest).Name} não foi registrado.");

            // Resolve behaviors. Reverte a ordem para que o primeiro registrado seja o mais externo.
            var behaviors = provider.GetServices<IPipelineBehavior<TRequest, TResponse>>().Reverse().ToList();

            // Monta a cadeia: começa do handler, embrulha em cada behavior.
            RequestHandlerDelegate<TResponse> handlerDelegate = () => handler.Handle((TRequest)request, ct);

            foreach (var behavior in behaviors)
            {
                var next = handlerDelegate;
                handlerDelegate = () => behavior.Handle((TRequest)request, next, ct);
            }

            return handlerDelegate();
        }
    }
}
```

**Pontos importantes:**

- **Cache de wrapper por tipo de request.** A primeira chamada paga reflection; as subsequentes são O(1).
- **Resolução por DI**, não por reflection a cada Send. Os handlers e behaviors são instanciados pelo `IServiceProvider`.
- **Behaviors compostos via delegate chaining.** Mesmo modelo do MediatR. Primeiro registrado = mais externo (executa primeiro no caminho de ida, último no de volta).
- **Nenhum tratamento de exceção aqui.** Exceções fluem; o `ApplicationExceptionFilter` na API as captura.

### `IRequestManager.cs`

```csharp
namespace MeuSaaS.Application.Mediator;

/// <summary>
/// Persiste IDs de requests já processadas para garantir idempotência.
/// Implementação fica na Infrastructure (tabela ClientRequests com PK = Id).
/// </summary>
public interface IRequestManager
{
    Task<bool> ExistAsync(Guid id);
    Task CreateRequestForCommandAsync<T>(Guid id);
}
```

### `IdentifiedCommand.cs`

```csharp
namespace MeuSaaS.Application.Mediator;

/// <summary>
/// Embrulha um <typeparamref name="T"/> com um <see cref="Id"/> de request.
/// Se o mesmo Id chegar duas vezes, o handler decide retornar o resultado neutro
/// em vez de processar de novo — garantindo idempotência.
/// </summary>
public record IdentifiedCommand<T, R>(T Command, Guid Id) : IRequest<R>
    where T : IRequest<R>;
```

### `IdentifiedCommandHandler.cs`

```csharp
namespace MeuSaaS.Application.Mediator;

/// <summary>
/// Handler base que verifica se o requestId já foi processado antes de delegar
/// para o handler real. Cada Command tem uma subclasse concreta no mesmo arquivo
/// do CommandHandler, sobrescrevendo CreateResultForDuplicateRequest().
/// </summary>
public abstract class IdentifiedCommandHandler<T, R>(
    IMediator mediator,
    ILogger<IdentifiedCommandHandler<T, R>> logger,
    IRequestManager requestManager)
    : IRequestHandler<IdentifiedCommand<T, R>, R>
    where T : IRequest<R>
{
    /// <summary>
    /// Resultado retornado quando o request já foi processado. Tipicamente um
    /// "vazio" semanticamente seguro (Guid.Empty, ou um DTO vazio).
    /// </summary>
    protected abstract R CreateResultForDuplicateRequest();

    public async Task<R> Handle(IdentifiedCommand<T, R> request, CancellationToken cancellationToken)
    {
        var alreadyExists = await requestManager.ExistAsync(request.Id);
        if (alreadyExists)
        {
            logger.LogInformation(
                "----- Request idempotente ignorada: {RequestId} para {CommandType} -----",
                request.Id, typeof(T).Name);
            return CreateResultForDuplicateRequest();
        }

        await requestManager.CreateRequestForCommandAsync<T>(request.Id);

        logger.LogInformation(
            "----- Sending command {CommandType} (RequestId: {RequestId}) -----",
            typeof(T).Name, request.Id);

        var result = await mediator.Send(request.Command, cancellationToken);

        logger.LogInformation(
            "----- Command {CommandType} processed (RequestId: {RequestId}) -----",
            typeof(T).Name, request.Id);

        return result;
    }
}
```

**Observação importante sobre transação:** o `CreateRequestForCommandAsync` grava no banco *antes* de o handler real rodar. Se o handler falhar, a request fica registrada como "processada" mesmo sem efeito. Tem dois jeitos de resolver:

1. **Transação que envolve registro + handler.** O `IRequestManager` registra dentro da mesma transação do `UnitOfWork`. Mais correto, mais complexo.
2. **Aceitar:** se o handler falhou, o cliente pode reenviar — mas com **outro** requestId, porque o anterior já está marcado. A maioria dos clientes gera requestId novo a cada tentativa, então isso é OK.

Recomendação: aceitar o (2) por padrão. Documentar para o time. Se aparecer caso onde (1) é necessário (ex.: cobranças financeiras), customizar.

### `MediatorRegistration.cs`

```csharp
using System.Reflection;
using Microsoft.Extensions.DependencyInjection;

namespace MeuSaaS.Application.Mediator;

public static class MediatorRegistration
{
    /// <summary>
    /// Registra o IMediator e escaneia os assemblies fornecidos por IRequestHandler<,> e IPipelineBehavior<,>.
    /// Use AddCustomMediator(typeof(CommandAssembly).Assembly) no Program.cs.
    /// </summary>
    public static IServiceCollection AddCustomMediator(
        this IServiceCollection services,
        params Assembly[] assemblies)
    {
        services.AddScoped<IMediator, Mediator>();

        foreach (var assembly in assemblies)
        {
            RegisterHandlers(services, assembly, typeof(IRequestHandler<,>));
            RegisterHandlers(services, assembly, typeof(IPipelineBehavior<,>));
        }

        return services;
    }

    private static void RegisterHandlers(IServiceCollection services, Assembly assembly, Type openGeneric)
    {
        var implementations = assembly.GetTypes()
            .Where(t => t is { IsClass: true, IsAbstract: false })
            .SelectMany(t => t.GetInterfaces()
                .Where(i => i.IsGenericType && i.GetGenericTypeDefinition() == openGeneric)
                .Select(i => new { Service = i, Implementation = t }))
            .ToList();

        foreach (var pair in implementations)
        {
            // Scoped por padrão — handlers são leves, sem estado entre requests.
            services.AddScoped(pair.Service, pair.Implementation);
        }
    }
}
```

**Por que `Scoped`?** Handlers usam Repositories, que usam DbContext, que é Scoped. Misturar lifetimes (Singleton handler com Scoped DbContext) é receita pra captive dependency.

---

## Como registrar pipeline behaviors

No `ApplicationInjectionConfig.cs`:

```csharp
public static IServiceCollection AddApplicationDependencies(
    this IServiceCollection services, IConfiguration configuration)
{
    // Mediator + handlers (scan por convenção)
    services.AddCustomMediator(typeof(CommandAssembly).Assembly);

    // Queries — registradas manualmente (não passam pelo mediator).
    services.AddScoped<IBillQueries, BillQueries>();

    // Behaviors:
    //   LoggingBehavior      → ATIVO sempre (loga toda execução de Handler).
    //   ValidatorBehavior    → INATIVO até primeira validação ser pedida pelo usuário.
    //   TransactionBehavior  → REGISTRADO sempre, dispara só p/ IMultiAggregateCommand.
    services.AddScoped(typeof(IPipelineBehavior<,>), typeof(LoggingBehavior<,>));
    // services.AddScoped(typeof(IPipelineBehavior<,>), typeof(ValidatorBehavior<,>));
    services.AddScoped(typeof(IPipelineBehavior<,>), typeof(TransactionBehavior<,>));

    return services;
}
```

A ordem de registro define a ordem de execução (do primeiro registrado para o mais interno). Logging fica sempre como o mais externo — loga tudo, inclusive falhas de validação ou rollback de transação.

---

## Diagrama — fluxo de uma request via mediator

```mermaid
sequenceDiagram
    autonumber
    participant C as Controller
    participant M as IMediator
    participant ICH as IdentifiedCommandHandler
    participant RM as IRequestManager
    participant H as Handler real
    participant R as Repository
    participant DB as Banco

    C->>M: Send(IdentifiedCommand<X, R>)
    M->>ICH: Handle(IdentifiedCommand)
    ICH->>RM: ExistAsync(requestId)
    RM->>DB: SELECT ClientRequests
    DB-->>RM: false
    RM-->>ICH: false
    ICH->>RM: CreateRequestForCommandAsync(requestId)
    RM->>DB: INSERT ClientRequests
    ICH->>M: Send(X) (Command real)
    M->>H: Handle(X)
    H->>R: FirstOrDefaultAsync(...)
    R->>DB: SELECT
    DB-->>R: aggregate
    R-->>H: aggregate
    H->>H: aggregate.AlterName(...)
    H->>R: UnitOfWork.SaveChangesAsync()
    R->>DB: UPDATE
    H-->>M: Response
    M-->>ICH: Response
    ICH-->>M: Response
    M-->>C: Response
```

E o caso de duplicação (mesmo requestId chegando 2x):

```mermaid
sequenceDiagram
    autonumber
    participant C as Controller
    participant M as IMediator
    participant ICH as IdentifiedCommandHandler
    participant RM as IRequestManager

    C->>M: Send(IdentifiedCommand<X, R>) [requestId já visto]
    M->>ICH: Handle(IdentifiedCommand)
    ICH->>RM: ExistAsync(requestId)
    RM-->>ICH: true
    Note over ICH: log "Request idempotente ignorada"
    ICH-->>M: CreateResultForDuplicateRequest()
    M-->>C: Response neutro (Guid.Empty)
```

---

## Diagrama de classes — núcleo do mediator

```mermaid
classDiagram
    class IRequest~TResponse~ {
        <<interface>>
    }

    class IRequestHandler~TRequest_TResponse~ {
        <<interface>>
        +Handle(TRequest, CancellationToken) Task~TResponse~
    }

    class IPipelineBehavior~TRequest_TResponse~ {
        <<interface>>
        +Handle(TRequest, RequestHandlerDelegate, CancellationToken) Task~TResponse~
    }

    class IMediator {
        <<interface>>
        +Send~TResponse~(IRequest, CancellationToken) Task~TResponse~
    }

    class Mediator {
        -IServiceProvider _serviceProvider
        +Send~TResponse~(IRequest, CancellationToken) Task~TResponse~
    }

    class IdentifiedCommand~T_R~ {
        +T Command
        +Guid Id
    }

    class IdentifiedCommandHandler~T_R~ {
        <<abstract>>
        #CreateResultForDuplicateRequest() R
        +Handle(IdentifiedCommand, CancellationToken) Task~R~
    }

    class IRequestManager {
        <<interface>>
        +ExistAsync(Guid) Task~bool~
        +CreateRequestForCommandAsync~T~(Guid) Task
    }

    IMediator <|.. Mediator
    IRequest <|-- IdentifiedCommand
    IRequestHandler <|.. IdentifiedCommandHandler
    IdentifiedCommandHandler --> IMediator : delega
    IdentifiedCommandHandler --> IRequestManager : verifica
    Mediator --> IRequestHandler : resolve via DI
    Mediator --> IPipelineBehavior : compõe pipeline
```

---

## Checklist de qualidade do mediator

Quando entregar a infra do mediator, garanta:

- [ ] `Mediator.cs` tem cache de wrapper por tipo (`ConcurrentDictionary`).
- [ ] `Send` rejeita `request == null` com `ArgumentNullException`.
- [ ] Handler ausente lança `InvalidOperationException` com mensagem clara.
- [ ] Behaviors são compostos na ordem correta (primeiro registrado = mais externo).
- [ ] `MediatorRegistration` escaneia todos os assemblies passados.
- [ ] Lifetime `Scoped` para handlers e behaviors.
- [ ] `IdentifiedCommandHandler` é `abstract` e tem `CreateResultForDuplicateRequest` abstrato.
- [ ] `IRequestManager` está como interface (implementação fica na Infra).
- [ ] Logs de idempotência saem com template Serilog-style.
