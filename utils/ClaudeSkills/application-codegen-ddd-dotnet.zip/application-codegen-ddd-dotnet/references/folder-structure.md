# Estrutura de pastas — Application

Esta skill **assume que o projeto `Application` já existe** como class library .NET. Se não existir, **pare e peça ao usuário para criar** — esta skill nunca cria `.csproj`.

## Layout completo

```
Application/
├── Commands/
│   ├── CommandAssembly.cs                ← marker (assembly de Commands)
│   └── BillCommands/
│       ├── ApproveBill/
│       │   ├── ApproveBillCommand.cs
│       │   ├── ApproveBillModel.cs                ← OPCIONAL — só se body ≠ Command
│       │   ├── ApproveBillCommandHandler.cs
│       │   ├── ApproveBillIdentifiedCommandHandler.cs
│       │   └── ApproveBillResponse.cs
│       ├── CreateBill/
│       │   ├── CreateBillCommand.cs
│       │   ├── CreateBillModel.cs                 ← OPCIONAL
│       │   ├── CreateBillCommandHandler.cs
│       │   ├── CreateBillIdentifiedCommandHandler.cs
│       │   └── CreateBillResponse.cs
│       └── ...
│
├── Queries/
│   ├── SortOrder.cs                       ← enum global Asc/Desc
│   ├── Cursor.cs                          ← codificação base64 para cursor pagination
│   └── BillQueries/
│       ├── IBillQueries.cs
│       ├── BillQueries.cs
│       ├── BillDtos.cs
│       └── Params/
│           ├── BillListParams.cs
│           └── BillSortBy.cs
│
├── Mediator/
│   ├── IRequest.cs
│   ├── IRequestHandler.cs
│   ├── IPipelineBehavior.cs
│   ├── IMediator.cs
│   ├── Mediator.cs
│   ├── IdentifiedCommand.cs
│   ├── IdentifiedCommandHandler.cs
│   ├── IRequestManager.cs
│   ├── IMultiAggregateCommand.cs          ← marker — TransactionBehavior dispara para isto
│   ├── IDbContextProvider.cs              ← interface para acesso ao DbContext ambient
│   └── MediatorRegistration.cs
│
├── Behaviors/
│   ├── LoggingBehavior.cs                 ← ATIVO por padrão
│   ├── ValidatorBehavior.cs               ← INATIVO até primeira validação ser pedida
│   └── TransactionBehavior.cs             ← REGISTRADO sempre, dispara só p/ IMultiAggregateCommand
│
├── Validations/                           ← ganha conteúdo só quando pedido pelo usuário
│   ├── ValidatorAssembly.cs               ← marker
│   ├── IValidator.cs                      ← interface base (própria, sem FluentValidation)
│   ├── ValidationResult.cs
│   ├── ValidationFailure.cs
│   ├── ValidationBuilder.cs               ← helper opcional
│   └── BillCommands/
│       └── CreateBillCommandValidator.cs  ← um validator por Command, quando pedido
│
├── DTO/
│   ├── BaseDTO.cs
│   ├── PagedResult.cs                     ← cursor-based: {Items, NextCursor}
│   ├── EnumerationDto.cs
│   └── Responses/
│       ├── BillCreatedResponse.cs
│       └── BillApprovedResponse.cs
│
├── Extension/
│   └── ApplicationExtensions.cs           ← AddApplicationDependencies
│
├── Util/                                  ← helpers genéricos da camada
│   └── ... (vazio por padrão; Result<T> pode entrar aqui — ver improvements.md)
│
└── GlobalUsings.cs
```

> **Sobre erros:** A camada Application **não possui** pasta `Errors/`, nem `ApplicationException`, nem `ApplicationErrors`. Todos os erros de regra/negócio são `DomainException`s fabricadas por factories `internal` no Domain (`<Aggregate>Errors.cs`, ao lado do agregado), e o Handler apenas chama essas factories quando uma verificação de orquestração falha (ex.: `?? throw BillErrors.NotFound(id)`). Mecanismos técnicos de transporte (validação de input, idempotência) usam exceptions simples sem catálogo — `CommandValidationException` em `Behaviors/`, `IdempotencyConflictException` em `Mediator/`. Detalhes em `references/error-handling.md`.

## Regras

### Uma pasta por operação

`Application/Commands/<Aggregate>Commands/<Operation>/` tem **3 a 5 arquivos**:

1. `<Operation><Aggregate>Command.cs` — **sempre**.
2. `<Operation><Aggregate>CommandHandler.cs` — **sempre**.
3. `<Operation><Aggregate>IdentifiedCommandHandler.cs` — **sempre** (pareado para idempotência).
4. `<Operation><Aggregate>Response.cs` — **sempre** (pode estar inline em `DTO/Responses/` se preferir; **escolha um e fixe**).
5. `<Operation><Aggregate>Model.cs` — **OPCIONAL**. Só quando o body recebido pela API for diferente do Command (ver `references/command-anatomy.md` — caso default no projeto: `TenantId` no path, body restante → cria Model).

### Marker assemblies e marker interfaces

#### Marker assemblies

Ficheiro vazio (ou quase) cujo único propósito é dar `typeof(CommandAssembly).Assembly` para escaneadores saberem qual assembly varrer:

```csharp
// Application/Commands/CommandAssembly.cs
namespace MeuSaaS.Application.Commands;
public class CommandAssembly { }
```

```csharp
// Application/Validations/ValidatorAssembly.cs
namespace MeuSaaS.Application.Validations;
public class ValidatorAssembly { }
```

#### Marker interfaces

Sinalizadoras vazias para o pipeline de behaviors:

```csharp
// Application/Mediator/IMultiAggregateCommand.cs
namespace MeuSaaS.Application.Mediator;

/// <summary>
/// Quando um Command implementa esta interface, o TransactionBehavior
/// abre uma transação explícita ao redor do Handler.
/// Use quando a operação toca mais de um agregado.
/// </summary>
public interface IMultiAggregateCommand { }
```

```csharp
// Application/Mediator/IDbContextProvider.cs
namespace MeuSaaS.Application.Mediator;

/// <summary>
/// Application define a interface; Infra implementa apontando para o DbContext escopado.
/// Usado pelo TransactionBehavior para abrir BeginTransaction sem depender do tipo concreto.
/// </summary>
public interface IDbContextProvider
{
    Microsoft.EntityFrameworkCore.DbContext Current { get; }
}
```

### GlobalUsings

`Application/GlobalUsings.cs` evita repetir `using` em todo arquivo:

```csharp
global using MeuSaaS.Application.Mediator;
global using MeuSaaS.Application.DTO;
global using MeuSaaS.Domain;                      // raízes de agregado e factories XxxErrors
global using MeuSaaS.Domain.Repositories;
global using MeuSaaS.Domain.SeedWork;             // DomainException (Handlers chamam factories que retornam isso)
global using System.Collections.Generic;
global using System.Threading;
global using System.Threading.Tasks;
```

> **Cuidado com o GlobalUsing de `MeuSaaS.Domain.SeedWork`:** ele dá acesso ao **tipo** `DomainException` (necessário para `catch (DomainException)` em `LoggingBehavior`/`MetricsBehavior`), mas **não** dá acesso às factories `internal` de erros do Domain — essas continuam encapsuladas no assembly de Domain por design. Application só captura, nunca constrói.

### Onde mora cada interface

| Interface | Pasta | Quem implementa |
|---|---|---|
| `IRequest<T>` | `Application/Mediator/` | Commands |
| `IRequestHandler<TReq, TRes>` | `Application/Mediator/` | Handlers da operação |
| `IPipelineBehavior<TReq, TRes>` | `Application/Mediator/` | Behaviors em `Application/Behaviors/` |
| `IMediator` | `Application/Mediator/` | `Mediator` (mesma pasta) |
| `IRequestManager` | `Application/Mediator/` | Implementação na **Infra** (Application só declara) |
| `IDbContextProvider` | `Application/Mediator/` | Implementação na **Infra** |
| `IMultiAggregateCommand` | `Application/Mediator/` | Commands que tocam >1 agregado |
| `IValidator<TCommand>` | `Application/Validations/` | Validator concreto na mesma área |
| `IXxxQueries` | `Application/Queries/<Aggregate>Queries/` | `XxxQueries` na mesma pasta |
| `IXxxRepository` | **Domain** (não Application) | Implementação na **Infra** |

### Convenções de nomenclatura

| Tipo | Padrão | Exemplo |
|---|---|---|
| Command | `<Verb><Aggregate>Command` | `ApproveBillCommand` |
| Model HTTP (opcional) | `<Verb><Aggregate>Model` | `ApproveBillModel` |
| Handler real | `<Verb><Aggregate>CommandHandler` | `ApproveBillCommandHandler` |
| Handler idempotente | `<Verb><Aggregate>IdentifiedCommandHandler` | `ApproveBillIdentifiedCommandHandler` |
| Response | `<Verb><Aggregate>Response` ou `<Aggregate><PastVerb>Response` | `ApproveBillResponse` / `BillCreatedResponse` |
| Query interface | `I<Aggregate>Queries` | `IBillQueries` |
| Query impl | `<Aggregate>Queries` | `BillQueries` |
| List Params | `<Aggregate>ListParams` | `BillListParams` |
| List DTO | `<Aggregate>ListItemDto` | `BillListItemDto` |
| Detail DTO | `<Aggregate>Dto` | `BillDto` |
| Sort enum | `<Aggregate>SortBy` | `BillSortBy` |
| Validator | `<Verb><Aggregate>CommandValidator` | `ApproveBillCommandValidator` |
| Marker multi-aggregate | `IMultiAggregateCommand` | (interface vazia) |

`SortOrder` é **global** (`Application/Queries/SortOrder.cs`) com valores `Asc`/`Desc`.

### Verbos de Command

- `Create` — gera novo agregado.
- `Alter<Algo>` — muta um campo/aspecto. Sempre nominal: `AlterBillItems`, `AlterEmployeeAddress`. **Não use `Update`** porque "atualizar" é genérico — a pasta deve dizer **o que** muda.
- `Delete` — remove (hard ou soft).
- `<VerbDeAcaoEspecifica>` — ações de domínio: `ApproveBill`, `SubmitOrder`, `CancelContract`. Verbo do ubiquitous language.

## Quando o usuário pede algo que foge da estrutura

- "Quero colocar o Handler em outra pasta." → Pergunte o porquê. Se for organização legítima (ex.: handlers gigantes precisando de helpers próprios), aceite. Se for "porque acho mais bonito", recuse — convenção rígida vence.
- "Quero múltiplos commands no mesmo arquivo." → Não. Um arquivo por arquivo. Discoverability importa mais que economizar arquivos.
- "Posso fazer um Command que muta dois agregados?" → **Default é não.** Redesenhe via Domain Event: o Command altera o agregado-raiz, o agregado emite evento, um handler async (lendo do Outbox) modifica o segundo agregado em outra transação. Só marque com `IMultiAggregateCommand` se a operação cair em uma das 4 exceções do Vernon (UI batch, ausência de infra de eventual consistency, transação global obrigada, user-aggregate affinity) — ver `references/transactions.md`.

## O que NÃO mora em Application

| Coisa | Onde mora |
|---|---|
| Controllers, filtros HTTP, middleware | API |
| `BaseController`, `OkResponse` helpers | API |
| `DomainExceptionFilter`, `CommandValidationExceptionFilter`, `IdempotencyConflictExceptionFilter` (mapeiam para HTTP) | API |
| Configuração Serilog, OpenAPI, autenticação | API |
| `DbContext`, `DbContextFactory`, repositórios concretos | Infra |
| Implementação de `IDbContextProvider`, `IRequestManager` | Infra |
| Migrations EF | Infra |
| `IBlobService` implementação, `HttpClient` configurado | Infra |
| Aggregates, Value Objects, Domain Events, Domain Services | Domain |
| Interfaces de repositório (`IBillRepository`) | Domain |
| `DomainException`, `<Aggregate>Errors` factories `internal` | Domain |

Esta skill **só** toca em `Application/`. Quando o handler precisa de algo que não está em Application (ex.: chamar gateway externo), ele recebe a interface (definida em Domain ou Application) e a Infra resolve via DI.
