# Anatomia de Handler + IdentifiedCommandHandler

Cada `<Operation>CommandHandler.cs` contém **dois** tipos no mesmo arquivo:

1. O Handler real (que faz o trabalho).
2. O `IdentifiedCommandHandler` correspondente (que controla idempotência).

Manter os dois juntos é deliberado: alterar a assinatura do Command quase sempre afeta os dois. Estarem lado a lado evita esquecer de atualizar um.

---

## Template completo

```csharp
namespace MeuSaaS.Application.Commands.EmployeeCommands.AlterEmployeeName;

public sealed class AlterEmployeeNameCommandHandler(IEmployeeRepository repo)
    : IRequestHandler<AlterEmployeeNameCommand, AlterEmployeeNameResponse>
{
    public async Task<AlterEmployeeNameResponse> Handle(
        AlterEmployeeNameCommand request,
        CancellationToken cancellationToken)
    {
        var employee = await repo.FirstOrDefaultAsync(
            e => e.Id == request.EmployeeId && e.TenantId == request.TenantId)
            ?? throw ApplicationErrors.AggregateNotFound(nameof(Employee), request.EmployeeId.ToString()));

        employee.AlterName(request.NewName);

        await repo.UnitOfWork.SaveChangesAsync(cancellationToken);
        return employee.Id;
    }
}

public class AlterEmployeeNameIdentifiedCommandHandler(
    IMediator mediator,
    ILogger<IdentifiedCommandHandler<AlterEmployeeNameCommand, AlterEmployeeNameResponse>> logger,
    IRequestManager requestManager)
    : IdentifiedCommandHandler<AlterEmployeeNameCommand, AlterEmployeeNameResponse>(mediator, logger, requestManager)
{
    protected override AlterEmployeeNameResponse CreateResultForDuplicateRequest()
        => new(Guid.Empty);
}
```

---

## Regras invioláveis do Handler real

### 1. Sempre `sealed class`

```csharp
public sealed class AlterEmployeeNameCommandHandler(...) : IRequestHandler<...>
```

Por quê: handlers não devem ser herdados. Se você está pensando em compartilhar lógica entre handlers, use composição (um `Service` injetado), não herança.

### 2. Construtor primário (C# 12+)

```csharp
public sealed class AlterEmployeeNameCommandHandler(IEmployeeRepository repo)
    : IRequestHandler<...>
```

Não escreva construtor explícito com campo `_repo`. Use o parâmetro do construtor primário direto no método. Mais enxuto, mais idiomático.

### 3. Uma dependência principal: o Repository do aggregate-raiz

```csharp
public sealed class AlterEmployeeNameCommandHandler(IEmployeeRepository repo)
```

Se o Handler precisa de mais coisa (`IBlobService`, `IPaymentGateway`), tudo bem injetar — mas pense duas vezes:

- Múltiplos repos? Provavelmente está modificando mais de um aggregate na mesma transação. Pare. Modela um `DomainService` ou usa eventos de domínio.
- Gateway externo? OK, mas pense em failure mode. Se o gateway está fora, o que acontece com o aggregate? Resiliência via Polly fica no registro do `HttpClient` (ver `dependency-injection.md`).

### 4. Filtro por `TenantId` é obrigatório

```csharp
var employee = await repo.FirstOrDefaultAsync(
    e => e.Id == request.EmployeeId && e.TenantId == request.TenantId)
```

**Nunca** `repo.FirstOrDefaultAsync(e => e.Id == request.EmployeeId)` sem o `TenantId`. Sem isso, qualquer empresa que adivinhe um Id de outra empresa enxerga/altera o dado.

A defesa em profundidade dessa skill é: filtro no Handler **e** na query **e** (idealmente) um `QueryFilter` global no `DbContext`. Camadas redundantes — se uma falhar, a outra pega.

### 5. Aggregate não encontrado → `ApplicationException`

```csharp
?? throw ApplicationErrors.AggregateNotFound(nameof(Employee), request.EmployeeId.ToString());
```

- Use `?? throw` em uma linha (operador `??` para `null`).
- Sempre `nameof(Aggregate)` — não string mágica.
- O `this` no construtor da `DomainException` é o handler que disparou. Útil para logging.

### 6. Mutação via método rico — não setter

```csharp
employee.AlterName(request.NewName);            // ✅
employee.Name = request.NewName;                // ❌
```

Setters em propriedades de aggregate só são tolerados em propriedades navegacionais simples (relacionamentos 1:1). Para tudo que afeta invariante, método rico no aggregate.

### 7. `SaveChangesAsync` no repository

```csharp
await repo.UnitOfWork.SaveChangesAsync(cancellationToken);
```

O Unit of Work mora no Repository (`repo.UnitOfWork`). Não injete `IUnitOfWork` separado — duplica responsabilidade.

`cancellationToken` **sempre** é passado adiante. Não engula.

### 8. Retorne o `Id` (com conversão implícita)

```csharp
return employee.Id;
```

O `Response` define `public static implicit operator XxxResponse(Guid id) => new(id);`. Por isso o handler pode retornar `Guid` direto. Nunca devolva o aggregate inteiro — vaza a entidade de domínio.

---

## Regras do `IdentifiedCommandHandler`

### 1. Mesma classe, mesmo arquivo

Se o arquivo tem `AlterEmployeeNameCommandHandler`, ele também tem `AlterEmployeeNameIdentifiedCommandHandler`. **Sem exceção.** Se você criou um Command, criou os dois handlers.

### 2. Construtor primário, herda do `IdentifiedCommandHandler<T, R>`

```csharp
public class AlterEmployeeNameIdentifiedCommandHandler(
    IMediator mediator,
    ILogger<IdentifiedCommandHandler<AlterEmployeeNameCommand, AlterEmployeeNameResponse>> logger,
    IRequestManager requestManager)
    : IdentifiedCommandHandler<AlterEmployeeNameCommand, AlterEmployeeNameResponse>(mediator, logger, requestManager)
```

Note: a classe **não é `sealed`**, mas também não vai ser herdada — só não usamos `sealed` aqui por convenção (a classe base é `abstract` e o ciclo de herança termina aqui).

### 3. Implementa só `CreateResultForDuplicateRequest()`

```csharp
protected override AlterEmployeeNameResponse CreateResultForDuplicateRequest()
    => new(Guid.Empty);
```

O que retornar quando o request for duplicado? Algo semanticamente seguro. Padrão: `Guid.Empty` no construtor do Response. Se o Response for mais complexo, retorne valores neutros (string vazia, lista vazia, etc.).

**Nunca** lance exceção aqui. O cliente pode ter mandado de novo por timeout legítimo — ele recebe a resposta neutra e segue.

---

## Padrão para Handler de Create

```csharp
public sealed class CreateEmployeeCommandHandler(IEmployeeRepository repo)
    : IRequestHandler<CreateEmployeeCommand, CreateEmployeeResponse>
{
    public async Task<CreateEmployeeResponse> Handle(
        CreateEmployeeCommand request, CancellationToken cancellationToken)
    {
        var employee = request.ToAggregate();
        await repo.AddAsync(employee);
        await repo.UnitOfWork.SaveChangesAsync(cancellationToken);
        return employee.Id;
    }
}
```

Atalho: `request.ToAggregate()` faz o mapeamento. O Handler virou trivial.

Validação de unicidade (ex.: CPF não pode repetir na mesma empresa) é responsabilidade do Domain (via `DomainService`) ou da própria base via constraint — quando a base reclamar, o filtro de exceção da camada API converte `DbUpdateException(UniqueConstraint)` em `DomainException` (ver `error-handling.md` para detalhes do mapeamento).

---

## Padrão para Handler de Delete (soft)

```csharp
public sealed class DeactivateEmployeeCommandHandler(IEmployeeRepository repo)
    : IRequestHandler<DeactivateEmployeeCommand, DeactivateEmployeeResponse>
{
    public async Task<DeactivateEmployeeResponse> Handle(
        DeactivateEmployeeCommand request, CancellationToken ct)
    {
        var employee = await repo.FirstOrDefaultAsync(
            e => e.Id == request.EmployeeId && e.TenantId == request.TenantId)
            ?? throw ApplicationErrors.AggregateNotFound(nameof(Employee), request.EmployeeId.ToString()));

        employee.Deactivate();   // método rico — pode disparar evento de domínio
        await repo.UnitOfWork.SaveChangesAsync(ct);
        return employee.Id;
    }
}
```

---

## Padrão para Handler com gateway externo

```csharp
public sealed class ProcessPaymentCommandHandler(
    IBillRepository repo,
    IPaymentGateway gateway,
    ILogger<ProcessPaymentCommandHandler> logger)
    : IRequestHandler<ProcessPaymentCommand, ProcessPaymentResponse>
{
    public async Task<ProcessPaymentResponse> Handle(
        ProcessPaymentCommand request, CancellationToken ct)
    {
        var bill = await repo.FirstOrDefaultAsync(
            b => b.Id == request.BillId && b.TenantId == request.TenantId)
            ?? throw ApplicationErrors.AggregateNotFound(nameof(Bill), request.BillId.ToString()));

        bill.MarkAsPaymentInProgress();        // estado intermediário
        await repo.UnitOfWork.SaveChangesAsync(ct);

        try
        {
            var receipt = await gateway.ChargeAsync(bill.Amount, bill.PaymentMethod, ct);
            bill.MarkAsPaid(receipt.TransactionId, receipt.PaidAt);
        }
        catch (PaymentGatewayException ex)
        {
            logger.LogWarning(ex, "Pagamento falhou para BillId {BillId}", bill.Id);
            bill.MarkAsPaymentFailed(ex.Reason);
        }

        await repo.UnitOfWork.SaveChangesAsync(ct);
        return bill.Id;
    }
}
```

**Por que dois `SaveChanges`?** Porque o estado intermediário (`PaymentInProgress`) precisa estar persistido **antes** da chamada externa. Se o processo cair durante o `ChargeAsync`, na volta dá pra reconciliar.

A política de retry/timeout/circuit-breaker do gateway fica no `AddHttpClient` da Infra (`HttpPolicyFactory`). Aqui no Handler só tratamos a exceção tipada.

---

## Anti-padrões (não faça)

- ❌ **`try/catch` engolindo exceção e retornando `null` ou Response vazio.** Deixe a exceção subir — o filtro pega.
- ❌ **`Console.WriteLine` ou `Debug.WriteLine` para diagnóstico.** Use `ILogger` injetado.
- ❌ **Acesso direto a `DbContext` no Handler.** Handler fala com Repository. Period.
- ❌ **Lógica de negócio no Handler.** Se está fazendo `if`s comparando estado pra decidir o que fazer, isso vai pro Domain.
- ❌ **Múltiplos `SaveChangesAsync` sem necessidade.** Faça uma vez no fim, exceto quando o cenário exige (ex.: estado intermediário antes de chamada externa).
- ❌ **Esquecer o `cancellationToken`.** Sempre passa adiante.

---

## Checklist do Handler

Quando entregar um Handler, garanta:

- [ ] Classe é `sealed`.
- [ ] Construtor primário com Repository do aggregate.
- [ ] Filtro por `TenantId` em qualquer busca.
- [ ] `?? throw ApplicationErrors.AggregateNotFound(...)` em buscas que devem encontrar.
- [ ] Mutação via método rico do aggregate (não setter).
- [ ] `await repo.UnitOfWork.SaveChangesAsync(cancellationToken)` no fim.
- [ ] Retorno conta com a conversão implícita (`return employee.Id`).
- [ ] `IdentifiedCommandHandler` correspondente no mesmo arquivo, com `CreateResultForDuplicateRequest` definido.
