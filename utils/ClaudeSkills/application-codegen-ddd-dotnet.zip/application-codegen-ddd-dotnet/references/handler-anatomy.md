# Anatomia de Handler + IdentifiedCommandHandler

Cada `<Operation>CommandHandler.cs` contém **dois** tipos no mesmo arquivo:

1. O Handler real (que faz o trabalho).
2. O `IdentifiedCommandHandler` correspondente (que controla idempotência).

Manter os dois juntos é deliberado: alterar a assinatura do Command quase sempre afeta os dois. Estarem lado a lado evita esquecer de atualizar um.

---

## A forma legítima do Handler — uma única

```csharp
public async Task<XxxResponse> Handle(XxxCommand request, CancellationToken ct)
{
    // 1) (opcional) consultas que alimentam o método rico
    // 2) Carrega o agregado-raiz via busca tracked + filtro de TenantId
    // 3) Chama UM método rico (pode passar dados resolvidos no passo 1)
    // 4) await repo.UnitOfWork.SaveChangesAsync(ct)
    // 5) return aggregate.Id
}
```

Tudo que sai disso é sintoma. As próximas seções desdobram cada passo e mostram o que **não** fazer.

---

## Template completo

```csharp
namespace MeuSaaS.Application.Commands.EmployeeCommands.AlterEmployeeName;

public sealed class AlterEmployeeNameCommandHandler(IEmployeeRepository repo)
    : IRequestHandler<AlterEmployeeNameCommand, AlterEmployeeNameResponse>
{
    public async Task<AlterEmployeeNameResponse> Handle(
        AlterEmployeeNameCommand request,
        CancellationToken cancellationToken)
    {
        // Busca tracked — sem AsNoTracking. EF passa a observar a entidade.
        var employee = await repo.FirstOrDefaultAsync(
            e => e.Id == request.EmployeeId && e.TenantId == request.TenantId,
            cancellationToken)
            ?? throw EmployeeErrors.NotFound(request.EmployeeId);

        // Mutação via método rico — método decide se é válido, atualiza estado, emite eventos.
        employee.AlterName(request.NewName);

        // SaveChanges detecta a mutação automaticamente. SEM repo.Update().
        await repo.UnitOfWork.SaveChangesAsync(cancellationToken);
        return new AlterEmployeeNameResponse(employee.Id);
    }
}

public class AlterEmployeeNameIdentifiedCommandHandler(
    IMediator mediator,
    ILogger<IdentifiedCommandHandler<AlterEmployeeNameCommand, AlterEmployeeNameResponse>> logger,
    IRequestManager requestManager)
    : IdentifiedCommandHandler<AlterEmployeeNameCommand, AlterEmployeeNameResponse>(mediator, logger, requestManager)
{
    protected override AlterEmployeeNameResponse CreateResultForDuplicateRequest()
        => new(Guid.Empty);
}
```

---

## Regras invioláveis do Handler real

### 1. Sempre `sealed class`

```csharp
public sealed class AlterEmployeeNameCommandHandler(...) : IRequestHandler<...>
```

Handlers não devem ser herdados. Compartilhamento de lógica vai por composição (um `Service` injetado), não herança.

### 2. Construtor primário (C# 12+)

```csharp
public sealed class AlterEmployeeNameCommandHandler(IEmployeeRepository repo)
    : IRequestHandler<...>
```

Não escreva construtor explícito com campo `_repo`. Use o parâmetro do construtor primário direto no método.

### 3. Uma dependência principal + repositórios auxiliares para validação de IDs

```csharp
public sealed class AlterEmployeeNameCommandHandler(IEmployeeRepository repo)
```

Múltiplos repositórios de **escrita** é sinal vermelho — você provavelmente está modificando mais de um agregado. Pare. Use Domain Event. Repositórios extras para **ler** ou **verificar existência** de outro agregado são aceitáveis e, mais que isso, **obrigatórios** quando o Command traz IDs de referência (ver seção "Validação de IDs recebidos é obrigatória" e "Multi-agregado: regra de ouro").


Gateways externos (`IPaymentGateway`, `IBlobService`): OK injetar — mas pense em failure mode. Resiliência (Polly) fica no registro do `HttpClient` na Infra.

### 4. Busca tracked + filtro por `TenantId` é obrigatório

```csharp
var employee = await repo.FirstOrDefaultAsync(
    e => e.Id == request.EmployeeId && e.TenantId == request.TenantId,
    cancellationToken);
```

**Duas coisas críticas nessa chamada:**

- **Tracking**: o Repository devolve a entidade *tracked* pelo `ChangeTracker` do EF (nada de `AsNoTracking`). É isso que permite chamar `SaveChangesAsync` sem precisar de `Update()`.
- **TenantId**: **nunca** `repo.FirstOrDefaultAsync(e => e.Id == request.EmployeeId)` sem o filtro de tenant. Qualquer empresa que adivinhe um Id de outra enxergaria/alteraria o dado.

A defesa em profundidade desta skill é: filtro no Handler **e** na query do repositório **e** (idealmente) um `QueryFilter` global no `DbContext`. Camadas redundantes — se uma falhar, a outra pega.

> **Nota sobre o contrato do Repository**: nesta arquitetura, `IXxxRepository.FirstOrDefaultAsync(...)` **devolve entidade tracked por padrão**. Quem quer leitura sem tracking usa o lado `IXxxQueries` (CQRS — query side, com `AsNoTracking()`). Misturar os dois é o erro mais comum: queries leem com `AsNoTracking`, repos de comando leem tracked.

### 5. Aggregate não encontrado → `DomainException` via factory do agregado

```csharp
?? throw EmployeeErrors.NotFound(request.EmployeeId);
```

- Use `?? throw` em uma linha.
- A factory é **do Domain do agregado correspondente** (`<Aggregate>Errors.NotFound(id)`), não da Application. A Application não define erros próprios — ver `references/error-handling.md`.
- Se a factory `<Aggregate>Errors.NotFound(id)` ainda não existe no Domain, ela precisa ser criada antes (responsabilidade da skill `domain-codegen-ddd-dotnet`). **Não invente um `ApplicationErrors.NotFound` para suprir a falta** — peça a factory no Domain.

### 6. Mutação via método rico — sem setter, sem decisões no Handler

```csharp
employee.AlterName(request.NewName);            // ✅
employee.Name = request.NewName;                // ❌ — fura encapsulamento
```

Mas há um erro mais sutil e muito comum: **o Handler tomar a decisão e só pedir pro agregado executar**. Isso também é vazamento. Ver seção "Decisão de domínio nunca no Handler" abaixo.

### 7. `SaveChangesAsync` no Unit of Work do Repository — sem `Update()`

```csharp
await repo.UnitOfWork.SaveChangesAsync(cancellationToken);
```

**Nunca** chame `repo.Update(employee)` antes:

```csharp
// ❌ ERRADO — Update é supérfluo e mascara o padrão de tracking.
repo.Update(employee);
await repo.UnitOfWork.SaveChangesAsync(cancellationToken);

// ✅ CERTO — a entidade já está tracked pela busca, SaveChanges detecta a mudança.
await repo.UnitOfWork.SaveChangesAsync(cancellationToken);
```

Por que `Update()` é errado aqui:

- A entidade veio de uma busca tracked. O `ChangeTracker` já a observa.
- Chamar `Update(employee)` marca **todas as propriedades como modificadas** (mesmo as que não mudaram), produzindo um `UPDATE` com colunas desnecessárias.
- Mascara qualquer bug de "entidade detached" — quando isso realmente acontece, a chamada esconde o problema.
- Mistura mental: leitor do código fica em dúvida se essa entidade é tracked ou não.

A única situação legítima para `repo.Update(entity)` é quando você recebe a entidade **detached** (vinda de cache externo, de outro contexto, deserializada). Isso não acontece em handler de Application: o Handler **sempre** carrega o agregado via repositório nesta arquitetura.

`cancellationToken` **sempre** é passado adiante. Não engula.

### 8. Retorne `new XxxResponse(...)` construído explicitamente

```csharp
return new AlterEmployeeNameResponse(employee.Id);
```

Sempre construa o Response **explicitamente**. Sem `implicit operator`. A construção explícita uniformiza Response mínimo (só `Id`) e Response rico (com campos extras) sob a mesma forma, e deixa óbvio em revisão de código o que está saindo da camada. Nunca devolva o aggregate inteiro — vaza a entidade de domínio.

Para decidir **o que** colocar dentro do `XxxResponse` (mínimo só com `Id` ou rico com campos adicionais), ver `references/command-anatomy.md` → "Anatomia do Response: o que devolver".

---

## Validação de IDs recebidos é obrigatória

Esta regra é **inviolável**: se o Command traz um `Guid` que representa **referência a outro agregado**, o Handler **deve** verificar que esse ID existe (e pertence ao tenant) **antes** de qualquer mutação. Se não verificar, a saída cai em uma de três falhas:

1. Foreign-key explode no banco com mensagem opaca, e o cliente recebe 500.
2. O agregado é criado/mutado com referência a algo inexistente, e quebra mais tarde.
3. Um tenant adivinha o ID de outro e referencia recurso alheio.

A justificativa teórica completa (Evans, Vernon IDDD §10, Geerts & McCarthy axioms, ISO/IEC 15944-4 §7.1, Hruby §5.1) está em `references/error-handling.md`. Resumo: existência cross-aggregate é "structural rule" — não é invariante do agregado dono, é checagem de orquestração. Logo, **mora no Application Handler**, com erro fabricado no Domain.

### Taxonomia dos IDs que aparecem em Commands

| Tipo de ID no Command | Exemplo | Quem valida | Como |
|---|---|---|---|
| **`TenantId`** | `Guid TenantId` | (não valida existência — autenticação já garantiu) | usado só como filtro |
| **ID do agregado-raiz da ação** | `Guid BillId` em `ApproveBillCommand` | Handler | `FirstOrDefaultAsync(..., TenantId, ct) ?? throw <Agg>Errors.NotFound(id)` |
| **ID de referência a outro agregado** | `Guid ResourceId`, `Guid CounterpartyId`, `Guid ApproverId` | Handler | `if (!await otherRepo.ExistsAsync(id, tenantId, ct)) throw <OtherAgg>Errors.NotFound(id)` |
| **ID de entidade interna do agregado-raiz** | `Guid CommitmentId` (commitment vive dentro de `Contract`) | **Método rico do agregado** (não o Handler) | dentro de `contract.Approve(commitmentId, ...)` — agregado lança `<Agg>Errors.<Inner>NotFound(...)` |
| **ID gerado pelo próprio Command** | `Guid NewBillId = Guid.NewGuid()` (criação) | (nada — não tem o que verificar) | passa adiante |

### Padrão obrigatório: `ExistsAsync` no Repository

Todo `IXxxRepository` desta arquitetura **deve** expor:

```csharp
public interface IBillRepository : IRepository<Bill>
{
    Task<Bill?> FirstOrDefaultAsync(Expression<Func<Bill, bool>> predicate, CancellationToken ct);

    /// <summary>
    /// Verifica existência sem trazer dados. Implementa como SELECT 1 ... LIMIT 1.
    /// Sempre inclui filtro de TenantId — defesa em profundidade contra vazamento cross-tenant.
    /// </summary>
    Task<bool> ExistsAsync(Guid id, Guid tenantId, CancellationToken ct);

    Task AddAsync(Bill bill);
    Task RemoveAsync(Bill bill);
    IUnitOfWork UnitOfWork { get; }
}
```

Por que `ExistsAsync` e não `GetByIdAsync`:

- `EXISTS` no Postgres compila pra `SELECT 1 ... LIMIT 1` — barato.
- Não materializa o agregado — não infla `ChangeTracker`, não custa hidratação de Value Objects.
- Vernon (IDDD §10): "verify the reference without loading the entire aggregate".
- O parâmetro `tenantId` é **obrigatório na assinatura** — não confiar em `Where(x => x.Id == id)` esquecendo do tenant.

### Padrão completo de Handler de Create com IDs externos

```csharp
public sealed class CreateEconomicContractCommandHandler(
    IEconomicContractRepository contractRepo,
    IEconomicResourceRepository resourceRepo,     // só pra validar referência
    IEconomicAgentRepository agentRepo)            // só pra validar referência
    : IRequestHandler<CreateEconomicContractCommand, CreateEconomicContractResponse>
{
    public async Task<CreateEconomicContractResponse> Handle(
        CreateEconomicContractCommand request,
        CancellationToken ct)
    {
        // 1) VALIDAÇÃO DE IDs EXTERNOS — antes de qualquer composição de agregado.
        //    Cada falha lança DomainException da factory do agregado correspondente.
        if (!await resourceRepo.ExistsAsync(request.ResourceId, request.TenantId, ct))
            throw EconomicResourceErrors.NotFound(request.ResourceId);

        if (!await agentRepo.ExistsAsync(request.CounterpartyId, request.TenantId, ct))
            throw EconomicAgentErrors.NotFound(request.CounterpartyId);

        // 2) Composição do agregado via factory (depois que IDs estão garantidos).
        var contract = request.ToAggregate();

        // 3) Persistência (Change Tracking — sem repo.Update).
        await contractRepo.AddAsync(contract);
        await contractRepo.UnitOfWork.SaveChangesAsync(ct);

        return new CreateEconomicContractResponse(contract.Id);
    }
}
```

### Padrão de Handler de Update com IDs externos

```csharp
public sealed class ReassignBillApproverCommandHandler(
    IBillRepository billRepo,
    IEmployeeRepository employeeRepo)              // só pra validar o ApproverId
    : IRequestHandler<ReassignBillApproverCommand, ReassignBillApproverResponse>
{
    public async Task<ReassignBillApproverResponse> Handle(
        ReassignBillApproverCommand request,
        CancellationToken ct)
    {
        // 1) Valida o ID de referência (Approver é um Employee).
        if (!await employeeRepo.ExistsAsync(request.NewApproverId, request.TenantId, ct))
            throw EmployeeErrors.NotFound(request.NewApproverId);

        // 2) Carrega o agregado-raiz (busca tracked). O ?? throw cobre o BillId.
        var bill = await billRepo.FirstOrDefaultAsync(
            b => b.Id == request.BillId && b.TenantId == request.TenantId, ct)
            ?? throw BillErrors.NotFound(request.BillId);

        // 3) Mutação via método rico (regras do Bill, incluindo "pode reassignar nesse status?")
        bill.ReassignApprover(request.NewApproverId);

        await billRepo.UnitOfWork.SaveChangesAsync(ct);
        return new ReassignBillApproverResponse(bill.Id);
    }
}
```

### Por que validar antes da composição/mutação?

Falha rápida com mensagem clara. Se você compõe o agregado primeiro e deixa pro DB rejeitar via foreign key:

- O cliente recebe `500 Internal Server Error` em vez de `404 EconomicResource não encontrado`.
- O log mostra `DbUpdateException: insert or update on table "economic_contracts" violates foreign key constraint`, que diz nada pro produto.
- A validação fica acoplada ao esquema do banco — se amanhã for documento (sem FK), explode silenciosamente.

### O que **não** se valida (cuidado para não exagerar)

**Não valide IDs de entidades internas do próprio agregado-raiz no Handler.** Se `Contract` tem `Commitments` e o Command traz `CommitmentId`, é o método rico do `Contract` que vai chamar `contract.FindCommitment(commitmentId)` e lançar `EconomicContractErrors.CommitmentNotFound(commitmentId)` internamente. O Handler **não** olha a coleção `contract.Commitments` pra checar antes — isso é decisão interna do agregado.

```csharp
// ❌ ERRADO — Handler espiando coleção interna do agregado
var contract = await repo.FirstOrDefaultAsync(...) ?? throw ContractErrors.NotFound(...);

if (!contract.Commitments.Any(c => c.Id == request.CommitmentId))
    throw ContractErrors.CommitmentNotFound(request.CommitmentId);   // Handler decidindo

contract.Approve(request.CommitmentId, ...);

// ✅ CERTO — agregado decide internamente
var contract = await repo.FirstOrDefaultAsync(...) ?? throw ContractErrors.NotFound(...);
contract.Approve(request.CommitmentId, ...);   // método rico chama FindCommitment, lança se não achar
```

### Tabela final de decisão

Antes de gerar um Handler, percorra cada parâmetro `Guid` do Command e responda:

| Pergunta | Sim → faz isso |
|---|---|
| É `TenantId`? | usa como filtro em todo `Where` / `ExistsAsync` |
| É o ID do agregado-raiz que vou mutar/carregar? | `FirstOrDefaultAsync(..., TenantId, ct) ?? throw <Agg>Errors.NotFound(id)` |
| É referência a **outro** agregado? | `if (!await <other>Repo.ExistsAsync(id, TenantId, ct)) throw <OtherAgg>Errors.NotFound(id)` antes da mutação |
| É entidade interna do agregado-raiz? | não valida — passa pro método rico e deixa ele lançar |
| É um Id novo que o próprio Command está criando? | não valida |

Se algum `Guid` do Command sair dessa tabela sem destino, **algo está errado**: pergunte ao usuário antes de gerar.

---

## Decisão de domínio nunca no Handler

Esta é a regra mais violada na prática. O Handler **não decide**. Ele orquestra.

### Sintoma 1: validação de transição no Handler

```csharp
// ❌ ERRADO — três regras de domínio vazaram pro Handler.
public async Task<...> Handle(ApproveBillCommand request, CancellationToken ct)
{
    var bill = await repo.FirstOrDefaultAsync(b => b.Id == request.BillId && b.TenantId == request.TenantId, ct)
        ?? throw BillErrors.NotFound(request.BillId);

    if (bill.Status != BillStatus.Draft)
        throw BillErrors.CannotApproveInStatus(bill.Status.Name);   // ← regra de domínio no Handler

    if (bill.DueDate < DateTime.UtcNow)
        throw BillErrors.CannotApproveOverdue();                    // ← regra de domínio no Handler

    if (bill.Amount.IsZero)
        throw BillErrors.CannotApproveZeroAmount();                 // ← regra de domínio no Handler

    bill.Approve(request.ApproverId, DateTime.UtcNow);
    await repo.UnitOfWork.SaveChangesAsync(ct);
    return new ApproveBillResponse(bill.Id);
}
```

```csharp
// ✅ CERTO — validações encapsuladas dentro de Approve().
public async Task<...> Handle(ApproveBillCommand request, CancellationToken ct)
{
    var bill = await repo.FirstOrDefaultAsync(b => b.Id == request.BillId && b.TenantId == request.TenantId, ct)
        ?? throw BillErrors.NotFound(request.BillId);

    bill.Approve(request.ApproverId, DateTime.UtcNow);  // método valida tudo internamente, lança DomainException se inválido
    await repo.UnitOfWork.SaveChangesAsync(ct);
    return new ApproveBillResponse(bill.Id);
}
```

Heurística: se você está prestes a escrever `if (aggregate.SomeProperty ...)` no Handler, **pare**. Esse `if` quer estar dentro do método rico.

### Sintoma 2: cascata interna no Handler (Tell, Don't Ask violado)

Caso clássico: "ao terminar contrato, cancele em cascata todos os commitments pendentes com período após a data de término".

```csharp
// ❌ ERRADO — Handler lendo coleção interna, decidindo o que cancelar, chamando comando por comando.
public async Task<...> Handle(TerminateContractCommand request, CancellationToken ct)
{
    var contract = await repo.FirstOrDefaultAsync(...)
        ?? throw ContractErrors.NotFound(request.ContractId);

    var commitmentsToCancel = contract.Commitments
        .Where(c => (c.Status == CommitmentStatus.Promised || c.Status == CommitmentStatus.Reserved)
                 && c.Period.FirstDay() > request.TerminationDate)
        .Select(c => c.Id)
        .ToList();

    foreach (var commitmentId in commitmentsToCancel)
        contract.CancelCommitment(commitmentId, occurredAt);

    contract.Terminate(occurredAt);

    await repo.UnitOfWork.SaveChangesAsync(ct);
    return new TerminateContractResponse(contract.Id);
}
```

A regra "ao terminar, cancele commitments futuros pendentes" é **regra de negócio do Contract**. Ela pertence ao método `Terminate()`.

```csharp
// ✅ CERTO — Handler delega ao método rico; cascata acontece dentro do agregado.
public async Task<...> Handle(TerminateContractCommand request, CancellationToken ct)
{
    // Consulta auxiliar (I/O) — isto é orquestração legítima
    var lastInflowPeriod = await eventRepo.GetLastInflowPeriodAsync(
        contractId: request.ContractId, tenantId: request.TenantId, ct);

    var contract = await repo.FirstOrDefaultAsync(
        c => c.Id == request.ContractId && c.TenantId == request.TenantId, ct)
        ?? throw ContractErrors.NotFound(request.ContractId);

    // O método rico recebe os dados resolvidos, valida invariantes, faz cascata interna, emite eventos.
    contract.Terminate(request.TerminationDate, lastInflowPeriod, timeProvider.GetUtcNow().UtcDateTime);

    await repo.UnitOfWork.SaveChangesAsync(ct);
    return new TerminateContractResponse(contract.Id);
}
```

### Sintoma 3: composição de Value Objects no Handler

```csharp
// ❌ ERRADO — montagem de domain types fora do Domain.
var participations = new List<Participation>
{
    new(contract.CounterpartyId, ParticipationRole.Provider),
    new(EconomicAgentId.From(tenantId.Value), ParticipationRole.Recipient),
};
var eventAmount = new Money(commitment.ExpectedAmount.Amount, commitment.ExpectedAmount.Currency);
var period = new CompetencePeriod(commitment.Period.Year, commitment.Period.Month);

var economicEvent = EconomicEvent.RegisterCovered(
    EconomicEventId.New(), tenantId, FlowDirection.Inflow, ...,
    eventAmount, participations, period, ...);
```

```csharp
// ✅ CERTO — factory do agregado conhece a composição.
var economicEvent = EconomicEvent.RegisterInflowCoverageFor(
    contract: contract,
    commitment: commitment,
    occurredAt: request.OccurredAt,
    registeredBy: createdBy);
```

`RegisterInflowCoverageFor` é um factory method estático em `EconomicEvent` que sabe extrair Money, Period, Participations a partir de Contract+Commitment. Composição é domínio, não orquestração.

---

## Multi-agregado: regra de ouro

> **Um agregado modificado por transação.** (Vernon)

O default desta skill: quando o usuário descreve operação que "muda Contract **e** cria Event", a saída é **Domain Event + handler async**, não dois `SaveChanges` na mesma transação, nem `IMultiAggregateCommand` por preguiça.

### Padrão correto (default)

```csharp
// Handler 1 — modifica APENAS o agregado-raiz que dispara a ação.
public sealed class RegisterEconomicEventCommandHandler(
    IEconomicEventRepository eventRepo,
    IEconomicContractRepository contractRepo)   // leitura, não escrita
    : IRequestHandler<RegisterEconomicEventCommand, RegisterEconomicEventResponse>
{
    public async Task<...> Handle(RegisterEconomicEventCommand request, CancellationToken ct)
    {
        // Lê contract (só pra alimentar o factory). Não modifica.
        var contract = await contractRepo.FirstOrDefaultAsync(
            c => c.Id == request.ContractId && c.TenantId == request.TenantId, ct)
            ?? throw EconomicContractErrors.NotFound(request.ContractId);

        var commitment = contract.FindCommitment(request.CommitmentId);

        // Cria UM agregado. O factory emite EconomicEventRegistered.
        var economicEvent = EconomicEvent.RegisterInflowCoverageFor(contract, commitment, request.OccurredAt, request.UserId);
        await eventRepo.AddAsync(economicEvent);
        await eventRepo.UnitOfWork.SaveChangesAsync(ct);  // Outbox inscreve o evento

        return new RegisterEconomicEventResponse(economicEvent.Id);
    }
}

// Handler 2 — reage ao Domain Event, modifica outro agregado em OUTRA transação.
public sealed class MarkCommitmentFulfilledOnEventRegisteredHandler(
    IEconomicContractRepository contractRepo)
    : IRequestHandler<EconomicEventRegisteredIntegrationEvent, Unit>
{
    public async Task<Unit> Handle(EconomicEventRegisteredIntegrationEvent evt, CancellationToken ct)
    {
        var contract = await contractRepo.FirstOrDefaultAsync(
            c => c.Id == evt.ContractId && c.TenantId == evt.TenantId, ct)
            ?? throw EconomicContractErrors.NotFound(evt.ContractId);

        contract.MarkFulfilled(evt.CommitmentId, evt.EconomicEventId, evt.OccurredAt);  // idempotente
        await contractRepo.UnitOfWork.SaveChangesAsync(ct);  // ← transação separada

        return Unit.Value;
    }
}
```

Pontos:

- Cada handler modifica **um** agregado.
- A consistência entre Contract e Event é **eventual** — mas com Outbox + retry, é confiável.
- Idempotência no handler 2 (`MarkFulfilled` deve ser no-op se já foi marcado) — agregado decide.
- Sem `IMultiAggregateCommand`. Sem `BeginTransactionAsync`.

### Quando `IMultiAggregateCommand` é aceitável

As 4 exceções do Vernon, traduzidas:

1. **UI batch** — criar N agregados independentes a partir de um clique (não há invariante atravessando, é só conveniência).
2. **Sem infraestrutura de eventual consistency** — projeto sem Outbox, sem worker, sem nada. Aí marca e justifica.
3. **Transação global legada** — quando regulação ou stack obriga 2PC.
4. **User-aggregate affinity** — o mesmo usuário é dono dos dois agregados, contenção concorrente é desprezível.

Fora dessas, a skill **recusa** marcar Command com `IMultiAggregateCommand` e oferece o caminho de Domain Event.

---

## Padrão para Handler de Create

Caso simples — Command sem IDs externos além do `TenantId`:

```csharp
public sealed class CreateEmployeeCommandHandler(IEmployeeRepository repo)
    : IRequestHandler<CreateEmployeeCommand, CreateEmployeeResponse>
{
    public async Task<CreateEmployeeResponse> Handle(
        CreateEmployeeCommand request, CancellationToken ct)
    {
        var employee = request.ToAggregate();           // factory do agregado faz a composição
        await repo.AddAsync(employee);                  // marca como Added no ChangeTracker
        await repo.UnitOfWork.SaveChangesAsync(ct);
        return new CreateEmployeeResponse(employee.Id);
    }
}
```

Caso com IDs externos — o template em "Padrão completo de Handler de Create com IDs externos" (acima) é o de referência. Valide **antes** de `request.ToAggregate()`.

Em Create, `repo.AddAsync(employee)` é necessário — a entidade é nova, não veio de busca tracked. Aqui não é o caso do `Update()` redundante: `Add` informa ao EF que a entidade existe e deve ser inserida.

Unicidade de chave natural (ex.: CPF não pode repetir na mesma empresa): valide **no Handler** via método dedicado do Repository (`IsTaxIdInUseAsync(taxId, tenantId, ct)`) lançando `<Aggregate>Errors.TaxIdAlreadyInUse(taxId)` — factory do **Domain**. A constraint única no DB serve como rede de segurança contra race: quando reclamar, o filtro de exceção da API mapeia `DbUpdateException(UniqueConstraint)` diretamente para 409, sem tradução pela Application.

---

## Padrão para Handler de Delete (soft)

```csharp
public sealed class DeactivateEmployeeCommandHandler(IEmployeeRepository repo)
    : IRequestHandler<DeactivateEmployeeCommand, DeactivateEmployeeResponse>
{
    public async Task<DeactivateEmployeeResponse> Handle(
        DeactivateEmployeeCommand request, CancellationToken ct)
    {
        var employee = await repo.FirstOrDefaultAsync(
            e => e.Id == request.EmployeeId && e.TenantId == request.TenantId, ct)
            ?? throw EmployeeErrors.NotFound(request.EmployeeId);

        employee.Deactivate();   // método rico — pode disparar evento de domínio
        await repo.UnitOfWork.SaveChangesAsync(ct);
        return new DeactivateEmployeeResponse(employee.Id);
    }
}
```

Hard delete usa `repo.Remove(employee)` — também marca no ChangeTracker, idem `Add`. **Sem `Update()` em nenhum dos dois casos.**

---

## Padrão para Handler com gateway externo

```csharp
public sealed class ProcessPaymentCommandHandler(
    IBillRepository repo,
    IPaymentGateway gateway,
    ILogger<ProcessPaymentCommandHandler> logger)
    : IRequestHandler<ProcessPaymentCommand, ProcessPaymentResponse>
{
    public async Task<ProcessPaymentResponse> Handle(
        ProcessPaymentCommand request, CancellationToken ct)
    {
        var bill = await repo.FirstOrDefaultAsync(
            b => b.Id == request.BillId && b.TenantId == request.TenantId, ct)
            ?? throw BillErrors.NotFound(request.BillId);

        bill.MarkAsPaymentInProgress();        // estado intermediário
        await repo.UnitOfWork.SaveChangesAsync(ct);

        try
        {
            var receipt = await gateway.ChargeAsync(bill.Amount, bill.PaymentMethod, ct);
            bill.MarkAsPaid(receipt.TransactionId, receipt.PaidAt);
        }
        catch (PaymentGatewayException ex)
        {
            logger.LogWarning(ex, "Pagamento falhou para BillId {BillId}", bill.Id);
            bill.MarkAsPaymentFailed(ex.Reason);
        }

        await repo.UnitOfWork.SaveChangesAsync(ct);
        return new ProcessPaymentResponse(bill.Id);
    }
}
```

Dois `SaveChanges` aqui são intencionais: o estado intermediário precisa estar persistido **antes** da chamada externa, para reconciliação caso o processo caia. Mesma entidade tracked ao longo de tudo — **nenhum `Update()`** em parte alguma.

---

## Regras do `IdentifiedCommandHandler`

### 1. Mesma classe, mesmo arquivo

Se o arquivo tem `AlterEmployeeNameCommandHandler`, ele também tem `AlterEmployeeNameIdentifiedCommandHandler`. **Sem exceção.**

### 2. Construtor primário, herda do `IdentifiedCommandHandler<T, R>`

```csharp
public class AlterEmployeeNameIdentifiedCommandHandler(
    IMediator mediator,
    ILogger<IdentifiedCommandHandler<AlterEmployeeNameCommand, AlterEmployeeNameResponse>> logger,
    IRequestManager requestManager)
    : IdentifiedCommandHandler<AlterEmployeeNameCommand, AlterEmployeeNameResponse>(mediator, logger, requestManager)
```

A classe **não é `sealed`**, mas também não vai ser herdada — só não usamos `sealed` aqui por convenção (a classe base é `abstract` e o ciclo de herança termina aqui).

### 3. Implementa só `CreateResultForDuplicateRequest()`

```csharp
protected override AlterEmployeeNameResponse CreateResultForDuplicateRequest()
    => new(Guid.Empty);
```

Padrão: `Guid.Empty` no construtor do Response. Para responses complexos, valores neutros (string vazia, lista vazia).

**Nunca** lance exceção aqui. O cliente pode ter mandado de novo por timeout legítimo — ele recebe a resposta neutra e segue.

---

## Anti-padrões (não faça)

- ❌ **`repo.Update(aggregate)` antes do save.** A entidade veio tracked. SaveChanges detecta. Update marca tudo como modificado e mascara intenção.
- ❌ **`AsNoTracking` em busca de Command.** Reservado pro lado Query (CQRS). Comando precisa de tracking pra mutar.
- ❌ **`ApplicationErrors.XXX(...)` ou `throw new ApplicationException(...)` em qualquer lugar.** Application não define erros. Use `<Aggregate>Errors.<Factory>(...)` do Domain.
- ❌ **`Application/Errors/` no projeto.** Pasta morreu na nova doutrina — remova se existir.
- ❌ **Receber `Guid` no Command e seguir sem verificar existência.** Ver "Validação de IDs recebidos é obrigatória".
- ❌ **`if (aggregate.Status...)` no Handler.** Vai pro método rico do agregado.
- ❌ **`foreach (var x in aggregate.Items) aggregate.DoSomething(x)`.** Cascata interna é responsabilidade do agregado.
- ❌ **Modificar dois agregados na mesma transação (sem justificativa Vernon).** Use Domain Event + handler async.
- ❌ **Composição de Value Objects no Handler.** Factory do agregado.
- ❌ **`try/catch` engolindo exceção e retornando `null` ou Response vazio.** Deixe subir.
- ❌ **Capturar `DomainException` para reembrulhar.** Sobe direto pro filtro da API.
- ❌ **`Console.WriteLine` ou `Debug.WriteLine`.** Use `ILogger` injetado.
- ❌ **Acesso direto a `DbContext` no Handler.** Handler fala com Repository.
- ❌ **Múltiplos `SaveChangesAsync` sem motivo.** Faça uma vez no fim, exceto quando o cenário exige (estado intermediário antes de chamada externa).
- ❌ **Esquecer o `cancellationToken`.** Sempre passa adiante.

---

## Checklist do Handler

Quando entregar um Handler, garanta:

- [ ] Classe é `sealed`.
- [ ] Construtor primário com Repository do aggregate-raiz.
- [ ] **Cada ID recebido no Command (exceto `TenantId` e IDs de entidades internas) foi validado antes da mutação** — agregado-raiz via `FirstOrDefaultAsync ?? throw <Aggregate>Errors.NotFound`, referências externas via `ExistsAsync` + `throw <RefAggregate>Errors.NotFound`. Ver "Validação de IDs recebidos é obrigatória".
- [ ] Filtro por `TenantId` em qualquer busca (incluindo `ExistsAsync`).
- [ ] Busca tracked (sem `AsNoTracking`) — repositório retorna entidade observada pelo `ChangeTracker`.
- [ ] `?? throw <Aggregate>Errors.NotFound(...)` em buscas que devem encontrar. **Nunca** `ApplicationErrors.AggregateNotFound`.
- [ ] Mutação via método rico do aggregate (não setter, não decisão no Handler).
- [ ] **Zero ocorrências de `repo.Update(...)`.** SaveChanges + Change Tracking faz o trabalho.
- [ ] **Zero ocorrências de `ApplicationErrors`** ou `ApplicationException` em qualquer parte do Handler.
- [ ] **Zero `if` que olha propriedade do agregado pra decidir lançar.** Regra vai pro método rico.
- [ ] **Zero loops que chamam comando do agregado por entidade interna.** Cascata interna no agregado.
- [ ] No máximo UM agregado modificado. Outros agregados afetados → Domain Event + handler async.
- [ ] `await repo.UnitOfWork.SaveChangesAsync(cancellationToken)` no fim.
- [ ] Retorno é `new XxxResponse(...)` construído **explicitamente** — nunca o agregado inteiro, nunca via `implicit operator`.
- [ ] `IdentifiedCommandHandler` correspondente no mesmo arquivo, com `CreateResultForDuplicateRequest` definido.
