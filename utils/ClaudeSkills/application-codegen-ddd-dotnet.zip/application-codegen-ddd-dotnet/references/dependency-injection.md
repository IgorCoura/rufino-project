# Dependency Injection — só Application

Esta skill **não** gera o `Program.cs` (responsabilidade da camada API). Ela gera **duas extensions** que vivem em `Application/Extension/` e são chamadas pela API.

## `AddApplicationDependencies`

Registra tudo que **vive em Application**: queries, behaviors (Logging e Transaction sempre ativos; Validator opcional), validators (via scan), handlers de domain event (se houver).

```csharp
namespace MeuSaaS.Application.Extension;

using System.Reflection;
using MeuSaaS.Application.Behaviors;
using MeuSaaS.Application.Mediator;
using MeuSaaS.Application.Validations;
// ... usings das queries concretas

public static class ApplicationExtensions
{
    public static IServiceCollection AddApplicationDependencies(this IServiceCollection services)
    {
        // ---------- QUERIES ----------
        services.AddScoped<IEmployeeQueries, EmployeeQueries>();
        services.AddScoped<IBillQueries, BillQueries>();
        // ... outras queries

        // ---------- BEHAVIORS ----------
        // ORDEM IMPORTA: Logging primeiro (envolve tudo), depois Validator, depois Transaction.
        services.AddScoped(typeof(IPipelineBehavior<,>), typeof(LoggingBehavior<,>));      // sempre ativo
        // services.AddScoped(typeof(IPipelineBehavior<,>), typeof(ValidatorBehavior<,>));  // descomenta na primeira validação
        services.AddScoped(typeof(IPipelineBehavior<,>), typeof(TransactionBehavior<,>));  // sempre registrado, dispara só p/ IMultiAggregateCommand

        // ---------- VALIDATORS (scan automático) ----------
        // Inativo até ValidatorBehavior ser registrado, mas o scan já fica configurado.
        var validatorAssembly = typeof(ValidatorAssembly).Assembly;
        foreach (var t in validatorAssembly.GetTypes())
        {
            if (t.IsAbstract || t.IsInterface) continue;
            var iface = t.GetInterfaces().FirstOrDefault(i =>
                i.IsGenericType && i.GetGenericTypeDefinition() == typeof(IValidator<>));
            if (iface is not null)
                services.AddScoped(iface, t);
        }

        // ---------- DOMAIN EVENT HANDLERS ----------
        // (se houver INotificationHandler<T> ou equivalente custom)

        return services;
    }
}
```

### Lifetime das Queries

`Scoped`. Mesmo que o `IDbContextFactory<T>` seja `Singleton` (porque ele cria contextos sob demanda), a Query em si é Scoped — uma instância por request HTTP.

### Política de Behaviors

| Behavior | Estado default | Quando ativar/desativar |
|---|---|---|
| `LoggingBehavior` | **Ativo sempre.** | Mantém. Útil em todas as operações para timing + correlation. |
| `ValidatorBehavior` | **Inativo (linha comentada).** | Descomentar quando o usuário pedir a primeira validação. Skill descomenta automaticamente nesse caso. |
| `TransactionBehavior` | **Registrado mas só dispara para `IMultiAggregateCommand`.** | Mantém sempre registrado — o behavior tem early-return quando o request não é multi-aggregate, então custo é desprezível. |

### Ordem dos behaviors (importa)

A ordem em que `services.AddScoped(typeof(IPipelineBehavior<,>), ...)` é chamada **determina a ordem de execução** (do primeiro registrado para o último). Recomendado:

1. **Logging** (envolve tudo — log inclui falha de validação e rollback de transação).
2. **Validator** (descarta input ruim antes da transação ser aberta).
3. **Transaction** (envolve o Handler real).
4. (futuro) **Metrics** (mais perto do Handler, mede só o "trabalho útil").

### Por que `IValidator<T>` é scaneado mesmo sem ValidatorBehavior ativo

O scan custa nada em runtime depois do startup. Manter o scan configurado significa que, no momento em que o usuário pedir a primeira validação, a única mudança é descomentar a linha do `ValidatorBehavior` — os validators já estão registrados.

## `AddCustomMediator`

Registra o mediator próprio e escaneia o assembly de Commands para descobrir todos `IRequestHandler<TReq, TRes>`. Implementação completa do método em `references/mediator-implementation.md`.

Assinatura esperada:

```csharp
public static IServiceCollection AddCustomMediator(
    this IServiceCollection services,
    params Assembly[] assemblies)
{
    services.AddSingleton<IMediator, Mediator>();

    foreach (var assembly in assemblies)
    {
        var handlerTypes = assembly.GetTypes()
            .Where(t => !t.IsAbstract && !t.IsInterface)
            .SelectMany(t => t.GetInterfaces()
                .Where(i => i.IsGenericType
                         && i.GetGenericTypeDefinition() == typeof(IRequestHandler<,>))
                .Select(i => new { Implementation = t, Service = i }));

        foreach (var h in handlerTypes)
            services.AddScoped(h.Service, h.Implementation);
    }

    return services;
}
```

Uso (vai no `Program.cs` da camada API):

```csharp
builder.Services.AddCustomMediator(typeof(CommandAssembly).Assembly);
```

### Por que registrar via marker assembly

`typeof(CommandAssembly).Assembly` é estável. Se um dia o nome do projeto mudar, o marker continua apontando pro lugar certo. Evita string mágica e evita `Assembly.GetExecutingAssembly()` em código não-óbvio.

### Mediator é Singleton, Handler é Scoped

O `Mediator` é Singleton porque é stateless e tem cache de wrappers de tipo (`ConcurrentDictionary`). Os Handlers são Scoped porque dependem de repositórios e DbContext (que são Scoped). O `Mediator` resolve handlers via `IServiceProvider` injetado — então cada `Send` vai pegar uma instância nova do escopo atual. Nada quebra.

## Como a API consome (referência — fora do escopo desta skill)

Só pra fechar o ciclo, mostrando como a API liga as duas:

```csharp
// Program.cs (CAMADA API — esta skill NÃO gera)
builder.Services.AddInfraDependencies(builder.Configuration);   // Infra
builder.Services.AddApplicationDependencies();                  // ← desta skill
builder.Services.AddCustomMediator(typeof(CommandAssembly).Assembly); // ← desta skill
builder.Services.AddServicesDependencies();                     // Domain services / event handlers

builder.Services.AddControllers(...);
// resto da API: auth, swagger, filters, etc.
```

## O que NÃO entra no `AddApplicationDependencies`

| Coisa | Onde vai |
|---|---|
| `DbContext`, `DbContextFactory` | `AddInfraDependencies` (Infra) |
| Repositórios concretos (`EmployeeRepository`) | `AddInfraDependencies` (Infra) |
| `IRequestManager` implementação | `AddInfraDependencies` (Infra) |
| `IBlobService`, `HttpClient`s | `AddInfraDependencies` (Infra) |
| Domain Services, Domain Event Handlers | extension separada `AddServicesDependencies` (vive na Application **ou** Domain, dependendo do projeto) |
| Filtros HTTP, autenticação, autorização | `Program.cs` da API |
| Logging (Serilog), OpenAPI | `Program.cs` da API |

## Domain Event Handlers — onde registrar

Se o projeto usa Domain Events (recomendado quando agregados precisam comunicar), os handlers podem viver na Application (mais comum) ou na Infra (se forem dispatch para fila/email).

Quando vivem na Application, registre numa terceira extension `AddServicesDependencies`:

```csharp
public static IServiceCollection AddServicesDependencies(this IServiceCollection services)
{
    services.AddScoped<INotificationHandler<EmployeeCreatedEvent>, EmployeeCreatedEventHandler>();
    services.AddScoped<IEmployeeDomainService, EmployeeDomainService>();
    return services;
}
```

Esta skill **gera essa extension separada** se o usuário pedir handlers de evento — não junta com `AddApplicationDependencies` para deixar claro o que é cross-cutting de domínio versus o que é infra de Application.

## Checklist

- [ ] `Application/Extension/ApplicationExtensions.cs` com `AddApplicationDependencies`.
- [ ] Todas as Queries do projeto registradas (Scoped, interface → impl).
- [ ] Behaviors comentados (não registrar até existir validator/logger/transaction real).
- [ ] `AddCustomMediator` definido em `Application/Mediator/MediatorRegistration.cs`.
- [ ] Marker assembly `CommandAssembly` em `Application/Commands/`.
- [ ] (Se houver) `AddServicesDependencies` separado para domain event handlers / domain services.
