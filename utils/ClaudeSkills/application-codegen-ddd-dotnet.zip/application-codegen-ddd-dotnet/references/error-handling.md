# Tratamento de erros — todos os erros de negócio vivem no Domain

Esta skill segue uma regra estrita: **a Application não define erros próprios.** Todos os erros que comunicam problemas de regra/negócio — incluindo "não encontrado", "conflito", "já existe", "estado inválido" — são `DomainException`s fabricadas por factories que **vivem no Domain**, junto do agregado a que se referem.

O Handler da Application apenas **dispara** esses erros quando uma verificação no nível de orquestração detecta o problema (ex.: `ExistsAsync` retornou `false`, `FirstOrDefaultAsync` retornou `null`).

> Justificativa teórica completa em `references/why-domain-owns-errors.md` (citando Evans, Vernon IDDD, Geerts & McCarthy, ISO/IEC 15944-4). Resumo: existência cross-aggregate é "structural rule" no sentido da ISO 15944 — pertence ao mesmo nível conceitual de uma invariante do agregado referenciado. Quem fabrica é o Domain.

## Doutrina em uma frase

> **Application orquestra, Domain decide, Domain define a forma do erro.** Application só lança o que o Domain define.

## A regra prática

| Situação | Quem **decide** que houve erro | Quem **fabrica** o erro | Tipo |
|---|---|---|---|
| ID de agregado referenciado não existe | Handler (via `ExistsAsync`) | `<Aggregate>Errors.NotFound(id)` no **Domain** | `DomainException` |
| Agregado-raiz da ação não existe pro tenant | Handler (via `FirstOrDefaultAsync`) | `<Aggregate>Errors.NotFound(id)` no **Domain** | `DomainException` |
| Duplicação de regra de negócio (overlap, already-fulfilled) | Handler (via query especializada) ou Aggregate (no método rico) | `<Aggregate>Errors.Xxx(...)` no **Domain** | `DomainException` |
| Unicidade de chave natural (CPF já existe) | Handler (via `IsTaxIdInUseAsync`) ou DB (constraint) | `<Aggregate>Errors.TaxIdAlreadyInUse(taxId)` no **Domain** | `DomainException` |
| Invariante do agregado violada (transição de status, range, soma) | Método rico do agregado | `<Aggregate>Errors.Xxx(...)` no **Domain** | `DomainException` |
| Falha técnica: validação de Command (formato/range/obrigatório) | `ValidatorBehavior` | (nenhuma factory — exception simples de plataforma) | `CommandValidationException` |
| Falha técnica: idempotência (mesma key, payload diferente) | `IdentifiedCommandHandler` | (nenhuma factory — exception simples de plataforma) | `IdempotencyConflictException` |
| Falha técnica: concorrência otimista do EF | EF Core / driver | (nenhuma — sobe direto) | `DbUpdateConcurrencyException` |
| Falha técnica: DB indisponível, deserialização, etc. | EF Core / driver | (nenhuma — sobe direto) | `IOException`, etc. |

A coluna "Quem fabrica" é o ponto: **toda exceção de regra/negócio é fabricada no Domain.** A Application só chama.

## O que isto remove da Application

A Application **não tem mais**:

- ❌ `Application/Errors/ApplicationException.cs`
- ❌ `Application/Errors/ApplicationErrors.cs`
- ❌ `ApplicationErrors.AggregateNotFound(...)` — agora `<Aggregate>Errors.NotFound(...)` no Domain.
- ❌ `ApplicationErrors.UnauthorizedTenantAccess(...)` — eliminado por design (o filtro `TenantId` na query já bloqueia; se mesmo assim cair, o caminho natural é `NotFound`).
- ❌ `ApplicationErrors.ConcurrencyConflict(...)` — `DbUpdateConcurrencyException` sobe direta para o filtro da API.
- ❌ `ApplicationErrors.ValidationFailed(...)` — `CommandValidationException` simples (ver abaixo).
- ❌ `ApplicationErrors.IdempotencyKeyConflict(...)` — `IdempotencyConflictException` simples (ver abaixo).

Não existe mais a pasta `Application/Errors/`. Se ela existe no seu projeto, **deve ser removida**.

## O que cada agregado precisa ter no Domain

Cada `<Aggregate>Errors.cs` (no Domain, `internal static class` ao lado do agregado) **deve** ter, no mínimo:

```csharp
namespace MeuSaaS.Domain.Aggregates.BillAggregate;

using System.Runtime.CompilerServices;
using System.IO;
using MeuSaaS.Domain.SeedWork;

internal static class BillErrors
{
    // Obrigatório em todo agregado: factory de NotFound para uso por Handlers.
    public static DomainException NotFound(
        Guid billId,
        [CallerFilePath] string filePath = "",
        [CallerMemberName] string memberName = "",
        [CallerLineNumber] int lineNumber = 0)
        => new(
            id: "APD.BIL00",  // padrão "##00" reservado para NotFound do agregado
            messageTemplate: "Bill com identificador '{0}' não encontrado.",
            parameters: new object[] { billId },
            sourcePath: $"{Path.GetFileName(filePath)}:{lineNumber} ({memberName})");

    // ... demais factories de invariantes específicas do Bill
    public static DomainException CannotApproveInStatus(string currentStatus, ...) => ...;
    public static DomainException InvalidStatusTransition(string from, string to, ...) => ...;
}
```

> **Geração**: a factory `NotFound` é responsabilidade da skill `domain-codegen-ddd-dotnet` (ou do desenvolvedor que escreve o Domain). Esta skill (Application) **consome** essa factory; ela não a cria. Se um Handler precisa de `<Aggregate>Errors.NotFound(...)` e a factory não existe no Domain, a saída é pedir pra criar antes de prosseguir — não inventar um `ApplicationErrors.NotFound`.

A regra de ID `##00` para NotFound não é arbitrária: deixa explícito no catálogo de erros do Bounded Context que aquele código é "o agregado não foi encontrado" — útil para o filtro da API mapear todos os `##00` para HTTP 404 sem precisar checar o agregado específico.

### Como o Domain pode marcar a categoria HTTP do erro

Recomendado (e provavelmente já existe no seu Domain): o `DomainException` tem uma propriedade `Category` que ajuda o filtro da API:

```csharp
public sealed class DomainException : Exception
{
    public string Id { get; }
    public string MessageTemplate { get; }
    public IReadOnlyList<object> Parameters { get; }
    public string SourcePath { get; }
    public DomainErrorCategory Category { get; }   // ← NotFound, Conflict, Invalid
    // ...
}

public enum DomainErrorCategory
{
    Invalid,    // 400 / 422 — invariante violada, transição inválida
    NotFound,   // 404 — referência não existe
    Conflict    // 409 — duplicação, already-fulfilled, race condition de regra
}
```

A factory `NotFound` retorna com `Category = DomainErrorCategory.NotFound`; `TaxIdAlreadyInUse` com `Category = Conflict`; e invariantes de transição com `Category = Invalid`. O filtro da API mapeia direto:

```csharp
return ex.Category switch
{
    DomainErrorCategory.NotFound => Results.NotFound(...),
    DomainErrorCategory.Conflict => Results.Conflict(...),
    DomainErrorCategory.Invalid  => Results.UnprocessableEntity(...),
    _ => Results.BadRequest(...),
};
```

Se o seu projeto ainda não tem `Category`, a alternativa é o filtro mapear por **convenção do ID**: `##00` → 404, faixa `##90–99` → 409, demais → 422. Mas `Category` é mais explícito.

## O que a Application FAZ

### 1. Lança `DomainException` chamando factories do Domain

```csharp
var bill = await repo.FirstOrDefaultAsync(
    b => b.Id == request.BillId && b.TenantId == request.TenantId, ct)
    ?? throw BillErrors.NotFound(request.BillId);   // ← DomainException, do Domain
```

```csharp
if (!await resourceRepo.ExistsAsync(request.ResourceId, request.TenantId, ct))
    throw EconomicResourceErrors.NotFound(request.ResourceId);
```

### 2. Deixa `DomainException` subir quando vem de método rico

```csharp
bill.Approve(request.ApproverId, DateTime.UtcNow);  // pode lançar — sobe direto
```

Captura para **logar** é aceitável (ex.: `LoggingBehavior`):

```csharp
try { return await next(); }
catch (DomainException ex)
{
    logger.LogWarning(ex, "Domain error in {Command}: {ErrorId}", typeof(TRequest).Name, ex.Id);
    throw;   // throw sem nome — preserva stack
}
```

Captura para **transformar** é proibida — Application não reembrulha DomainException em outra coisa.

### 3. Trata exceptions técnicas (de plataforma) sem fabricá-las como DomainException

Concorrência do EF, falhas de DB, IO — sobem direto pro filtro da API. **Nenhuma tradução intermediária pela Application.**

## Exceptions técnicas da plataforma da Application

Há **dois** tipos de exception que vivem dentro da Application mas **não** são erros de negócio nem de domínio — são mecanismos técnicos de transporte. Esses são exceptions simples (sem catálogo, sem factory, sem template) que o filtro da API conhece e mapeia diretamente.

### `CommandValidationException` — falhas do `ValidatorBehavior`

```csharp
namespace MeuSaaS.Application.Behaviors;

public sealed class CommandValidationException : Exception
{
    public IReadOnlyList<string> Failures { get; }

    public CommandValidationException(IReadOnlyList<string> failures)
        : base("O Command falhou em uma ou mais validações.")
    {
        Failures = failures ?? Array.Empty<string>();
    }
}
```

Lançada pelo `ValidatorBehavior` quando o `IValidator<TCommand>` retorna falhas. Não tem ID, código nem template — só uma lista de mensagens. O filtro da API mapeia → 400 Bad Request com o array de mensagens.

**Por que isto não viola a regra "Domain define erros"?** Porque `CommandValidationException` não comunica um erro de negócio — comunica que o input não chegou em condições de ser interpretado como negócio. É equivalente ao parsing falhar no ModelBinder. Não há entidade ou regra de domínio envolvida.

### `IdempotencyConflictException` — `IdentifiedCommand` com payload diferente

```csharp
namespace MeuSaaS.Application.Mediator;

public sealed class IdempotencyConflictException : Exception
{
    public Guid RequestId { get; }
    public string CommandName { get; }

    public IdempotencyConflictException(Guid requestId, string commandName)
        : base($"Idempotency-Key '{requestId}' já foi usada para outro comando.")
    {
        RequestId = requestId;
        CommandName = commandName;
    }
}
```

Lançada pelo `IdentifiedCommandHandler` quando o `IRequestManager` detecta que a mesma `Idempotency-Key` já foi usada para um Command **diferente**. Filtro da API → 409 Conflict.

**Por que não é DomainException?** Idempotência é proteção de transporte (HTTP), não conceito do domínio. O agregado `Bill` não sabe que existe HTTP, nem `Idempotency-Key`. Modelar como erro do Bill seria forçar.

> Essas duas exceptions são as **únicas** exceções "de plataforma" que a Application define. Tudo mais que parece erro é DomainException via factory do Domain.

## Anti-padrões

```csharp
// ❌ Application criando catálogo de erros próprio
throw new ApplicationException("NOT_FOUND", "Bill ...", ...);
// Não. NotFound é DomainException do Bill: throw BillErrors.NotFound(id);

// ❌ Application capturando DomainException pra "padronizar"
try { agg.Approve(); }
catch (DomainException ex) { throw new ApplicationException(...); }
// Não. DomainException sobe.

// ❌ Application traduzindo DbUpdateException em erro de domínio
catch (DbUpdateException ex) when (IsUniqueConstraint(ex))
{
    throw EmployeeErrors.TaxIdAlreadyInUse(employee.TaxId);
}
// Caso BORDERLINE. Aceitável APENAS se a unicidade não foi pré-checada via ExistsAsync.
// Padrão preferido: checar via repo.IsTaxIdInUseAsync ANTES de tentar inserir; constraint
// vira rede de segurança contra race, e o filtro da API mapeia DbUpdateException(unique)
// para 409 sem precisar de tradução pela Application.

// ❌ Handler que recebe um ID e segue sem validar
public async Task<...> Handle(CreateContractCommand request, CancellationToken ct)
{
    var contract = request.ToAggregate();  // request.ResourceId nunca foi validado!
    await repo.AddAsync(contract);
    ...
}
// Quase certo que vai estourar foreign key no DB com mensagem opaca, ou cria contrato com
// referência para Resource inexistente que vai dar problema depois.

// ❌ Application engolindo exceção
try { agg.DoStuff(); } catch { return Guid.Empty; }
// Esconde bug. Sobe.

// ❌ Re-throw embrulhando em outra exception
try { ... } catch (Exception ex) { _log.Error(ex); throw new Exception("erro", ex); }
// Quebra stack. Use throw; sem nome.

// ❌ Manter Application/Errors/ no projeto
// Se existe, remove. ApplicationException e ApplicationErrors não fazem mais parte desta arquitetura.
```

## Checklist

### Domain (não é desta skill gerar, mas a Application depende)
- [ ] Cada agregado tem `<Aggregate>Errors.cs` `internal static class` no Domain.
- [ ] Cada `<Aggregate>Errors` tem ao menos uma factory `NotFound(<id>)` retornando `DomainException` com `Category = NotFound`.
- [ ] Demais factories cobrem invariantes e conflitos (`Category = Invalid`/`Conflict`).
- [ ] IDs seguem `^[A-Z]{3}(\.[A-Z]{3})?\d+$`. Convenção: `##00` reservado para NotFound.

### Application (esta skill)
- [ ] **Não existe** pasta `Application/Errors/`. Se existir no projeto, é dívida — remover.
- [ ] **Não existe** `ApplicationException` nem `ApplicationErrors` no código gerado.
- [ ] Handler que carrega agregado-raiz usa `?? throw <Aggregate>Errors.NotFound(id)`.
- [ ] Handler que aceita IDs de referência valida via `ExistsAsync` e lança `<RefAggregate>Errors.NotFound(id)`. Ver `handler-anatomy.md` → "Validação de IDs recebidos é obrigatória".
- [ ] Handler **nunca** captura `DomainException` para repackaging.
- [ ] `ValidatorBehavior` lança `CommandValidationException` (em `Application/Behaviors/`).
- [ ] `IdentifiedCommandHandler` lança `IdempotencyConflictException` (em `Application/Mediator/`).
- [ ] Nenhum outro tipo de exception é fabricado pela Application.

## Sobre `Result<T>` (alternativa)

`Result<T>` em vez de exceptions para fluxo esperado continua sendo uma opção descrita em `improvements.md`. Combina particularmente bem com a doutrina atual: todos os "erros previsíveis" são `DomainException` via factory do Domain, então `Result<T, DomainException>` é trivial.
