# Tratamento de erros — Application + Domain estritamente separados

Esta skill segue **Clean Architecture estrito**: **Domain** tem seus erros (regras de negócio violadas — invariantes do agregado); **Application** tem os seus (orquestração da camada — idempotência, concorrência, input do Command que cruzou validação por algum caminho). **A Application NUNCA importa erros do Domain** — só os captura subindo via `DomainException`.

## Por quê separar

| Tipo de erro | Camada | Exemplos |
|---|---|---|
| Invariante de domínio violada | **Domain** | "Bill paga é imutável", "Transição inválida de status", "CPF já existente" |
| Invariante das classes-base do `SeedWork` | **Domain (SeedWork)** | "Id não pode ser `Guid.Empty`" |
| Falha de orquestração da camada | **Application** | "Aggregate não encontrado", "Concorrência otimista", "Idempotência conflitante" |
| Validação de input do Command (ainda na Application) | **Application** | "Campo X obrigatório", "Tamanho excedido" |
| Falha técnica (DB indisponível, deserialização) | **nenhuma das duas** — `InvalidOperationException`, `IOException` etc. |

A regra que deixa isso simples: **Domain não conhece "input HTTP" nem "idempotência" nem "transação"** — esses conceitos não existem para o agregado. Logo, erros sobre eles **não pertencem ao Domain**.

A camada API (fora desta skill) tem **dois mappers** distintos para HTTP:
- `DomainExceptionFilter` mapeia `DomainException` → 400/422/409 conforme o catálogo.
- `ApplicationExceptionFilter` mapeia `ApplicationException` → 400/404/409 conforme o tipo.

## Domain — `DomainException` (resumo)

> O padrão completo está documentado em `Domain/SeedWork/DomainException.cs` do projeto. **Esta skill não gera nem altera factories de erro do Domain** — Application é cliente, não dono.

Resumo do contrato:

```csharp
namespace MeuSaaS.Domain.SeedWork;

public sealed class DomainException : Exception
{
    public string Id { get; }                          // ex.: "APD.BIL01"
    public string MessageTemplate { get; }             // ex.: "Transição inválida: {0} → {1}."
    public IReadOnlyList<object> Parameters { get; }   // ex.: ["DRAFT", "PAID"]
    public string SourcePath { get; }                  // ex.: "Bill.cs:67 (Approve)"
    // Message herdado = MessageTemplate formatado
}
```

Aggregate lança via factory `internal` (ex.: `BillErrors.InvalidStatusTransition(...)`). Application **vê** a exceção subindo, **não** a constrói.

### O que a Application FAZ com `DomainException`

**Nada** — deixa subir. O filtro da camada API converte em HTTP. A única coisa que a Application precisa garantir é não capturar e engolir.

```csharp
// ❌ NUNCA
try
{
    aggregate.DoSomething();
}
catch (DomainException ex)
{
    // ... transformar em outro erro? logar? engolir?
}

// ✅ SEMPRE
aggregate.DoSomething();   // se lançar DomainException, sobe
```

Exceção rara: behavior do mediator que precisa **logar** a exceção antes de subir (ex.: `LoggingBehavior`). Aí use `try { ... } catch { logar; throw; }` — `throw` sem nome de variável preserva stack trace.

### O que a Application NÃO FAZ

- Não importa as factories `internal` (`BillErrors`, `EmployeeErrors`, etc.). Compilador impede.
- Não conhece os IDs (`APD.BIL01`). Eles aparecem como string opaca no log.
- Não traduz mensagens. A camada API/cliente final faz tradução por ID se necessário.

## Application — `ApplicationException` e `ApplicationErrors`

Esta skill **gera e mantém** os arquivos da Application.

### Estrutura

```
Application/
├── Errors/
│   ├── ApplicationException.cs
│   └── ApplicationErrors.cs
```

### `ApplicationException`

Espelha a forma do `DomainException` para ter um filtro HTTP simétrico, mas com um `Code` (string) em vez do ID `XXX.YYY##` do Domain. Aqui não temos catálogo numerado — os erros da Application são **menos numerosos e mais genéricos**.

```csharp
// Application/Errors/ApplicationException.cs
namespace MeuSaaS.Application.Errors;

using System.Runtime.CompilerServices;

public sealed class ApplicationException : Exception
{
    public string Code { get; }
    public string MessageTemplate { get; }
    public IReadOnlyList<object> Parameters { get; }
    public string SourcePath { get; }

    public ApplicationException(
        string code,
        string messageTemplate,
        IReadOnlyList<object> parameters,
        string sourcePath)
        : base(BuildMessage(messageTemplate, parameters))
    {
        if (string.IsNullOrWhiteSpace(code))
            throw new ArgumentException("Code is required.", nameof(code));
        if (string.IsNullOrWhiteSpace(messageTemplate))
            throw new ArgumentException("MessageTemplate is required.", nameof(messageTemplate));
        if (parameters is null)
            throw new ArgumentNullException(nameof(parameters));
        if (parameters.Any(p => p is null))
            throw new ArgumentException("Parameters cannot contain null values.", nameof(parameters));
        if (string.IsNullOrWhiteSpace(sourcePath))
            throw new ArgumentException("SourcePath is required.", nameof(sourcePath));

        Code = code;
        MessageTemplate = messageTemplate;
        Parameters = parameters;
        SourcePath = sourcePath;
    }

    private static string BuildMessage(string template, IReadOnlyList<object> parameters)
        => parameters is null || parameters.Count == 0
            ? template
            : string.Format(template, parameters.ToArray());

    public override string ToString() => $"[{Code}] {Message} | at {SourcePath}";
}
```

> **Por que `Code` e não `Id`?** Os erros da Application não seguem o padrão `XXX.YYY##` do Domain (que pertence ao bounded context). São erros de orquestração — `NOT_FOUND`, `CONCURRENCY`, `IDEMPOTENCY_CONFLICT`, `VALIDATION_FAILED`. Strings semânticas, sem numeração.

### `ApplicationErrors` — catálogo de factories

Public static class (ao contrário do Domain, que é `internal` por bounded context). A Application é **uma só** dentro do projeto, e seus erros são consumidos por todos os Handlers/Queries da camada.

```csharp
// Application/Errors/ApplicationErrors.cs
namespace MeuSaaS.Application.Errors;

using System.Runtime.CompilerServices;
using System.IO;

public static class ApplicationErrors
{
    public static ApplicationException AggregateNotFound(
        string aggregateName,
        string identifier,
        [CallerFilePath] string filePath = "",
        [CallerMemberName] string memberName = "",
        [CallerLineNumber] int lineNumber = 0)
        => new(
            code: "NOT_FOUND",
            messageTemplate: "{0} com identificador '{1}' não encontrado.",
            parameters: new object[] { aggregateName, identifier },
            sourcePath: BuildSourcePath(filePath, memberName, lineNumber));

    public static ApplicationException ConcurrencyConflict(
        string aggregateName,
        string identifier,
        [CallerFilePath] string filePath = "",
        [CallerMemberName] string memberName = "",
        [CallerLineNumber] int lineNumber = 0)
        => new(
            code: "CONCURRENCY_CONFLICT",
            messageTemplate: "{0} '{1}' foi modificado por outra operação. Recarregue e tente novamente.",
            parameters: new object[] { aggregateName, identifier },
            sourcePath: BuildSourcePath(filePath, memberName, lineNumber));

    public static ApplicationException IdempotencyKeyConflict(
        Guid requestId,
        string commandName,
        [CallerFilePath] string filePath = "",
        [CallerMemberName] string memberName = "",
        [CallerLineNumber] int lineNumber = 0)
        => new(
            code: "IDEMPOTENCY_CONFLICT",
            messageTemplate: "Idempotency-Key '{0}' já foi usada para outro comando ({1}).",
            parameters: new object[] { requestId, commandName },
            sourcePath: BuildSourcePath(filePath, memberName, lineNumber));

    public static ApplicationException ValidationFailed(
        string commandName,
        IReadOnlyList<string> failures,
        [CallerFilePath] string filePath = "",
        [CallerMemberName] string memberName = "",
        [CallerLineNumber] int lineNumber = 0)
        => new(
            code: "VALIDATION_FAILED",
            messageTemplate: "Validação falhou em {0}: {1}",
            parameters: new object[] { commandName, string.Join("; ", failures) },
            sourcePath: BuildSourcePath(filePath, memberName, lineNumber));

    public static ApplicationException UnauthorizedTenantAccess(
        Guid expectedTenantId,
        Guid actualTenantId,
        [CallerFilePath] string filePath = "",
        [CallerMemberName] string memberName = "",
        [CallerLineNumber] int lineNumber = 0)
        => new(
            code: "UNAUTHORIZED_TENANT_ACCESS",
            messageTemplate: "Tenant '{0}' não pode acessar recurso de '{1}'.",
            parameters: new object[] { actualTenantId, expectedTenantId },
            sourcePath: BuildSourcePath(filePath, memberName, lineNumber));

    private static string BuildSourcePath(string filePath, string memberName, int lineNumber)
        => $"{Path.GetFileName(filePath)}:{lineNumber} ({memberName})";
}
```

> **Atenção sobre `UnauthorizedTenantAccess`**: existe um caso similar no Domain (`AccountsPayableErrors.TenantMismatch`). A diferença é onde o erro é detectado:
> - Detectado **dentro do agregado** (ex.: agregado recebe operação de outro tenant via método interno) → `DomainException` do Domain.
> - Detectado **na Application** (ex.: Handler busca aggregate por ID e recebe um de tenant diferente porque alguém burlou o filtro) → `ApplicationException`.
>
> Na prática, o filtro de tenant no Handler/Query é tão estrito que esse erro raramente sobe — funciona como guarda extra.

### Convenções

- Factories sempre têm `[CallerFilePath]`, `[CallerMemberName]`, `[CallerLineNumber]`.
- Mensagens em PT, curtas, sem jargão técnico (mesma regra do Domain).
- `Parameters` nunca `null`. Use `Array.Empty<object>()`.
- Códigos em UPPER_SNAKE_CASE: `NOT_FOUND`, `CONCURRENCY_CONFLICT`, `IDEMPOTENCY_CONFLICT`, `VALIDATION_FAILED`.
- Quando aparecer caso novo: **adicione factory antes** de usar. Não construa `ApplicationException` direto fora do catálogo.

## Quando usar cada uma — matriz prática

| Situação | Quem lança | Tipo |
|---|---|---|
| `aggregate.Approve()` em status inválido | Aggregate (`BillErrors`) | `DomainException` |
| `repo.FindAsync(id)` retornou null | Handler | `ApplicationException` (`NOT_FOUND`) |
| Validação de Command via `IValidator<T>` | `ValidatorBehavior` | `ApplicationException` (`VALIDATION_FAILED`) |
| `SaveChangesAsync` lançou `DbUpdateConcurrencyException` | (interceptor da Infra) → re-lançar como | `ApplicationException` (`CONCURRENCY_CONFLICT`) |
| `IRequestManager.ExistAsync` confirma duplicata com payload diferente | `IdentifiedCommandHandler` | `ApplicationException` (`IDEMPOTENCY_CONFLICT`) |
| Handler buscou agregado com filtro `TenantId` certo mas linha trouxe outro tenant (bug ou bypass) | Handler | `ApplicationException` (`UNAUTHORIZED_TENANT_ACCESS`) |
| `Bill.AddItem(amount)` com amount negativo | Aggregate (`BillErrors`) | `DomainException` |
| DB caiu | EF / driver | `IOException` ou específico |
| Falha ao serializar evento para outbox | (Infra) | `InvalidOperationException` |

## Anti-padrões

```csharp
// ❌ Application criando DomainException
throw new DomainException("APP01", "...", ...);
// Não. DomainException é só do Domain, lançada por factories internal lá.

// ❌ Application capturando DomainException pra "padronizar"
try { agg.Approve(); }
catch (DomainException ex) { throw new ApplicationException("...", ...); }
// Não. Domain e Application são erros distintos. Filter da API trata cada um.

// ❌ Application lançando string literal
throw new ApplicationException("CODE", "msg", new object[]{}, "...");
// Não. Sempre via ApplicationErrors.<Factory>.

// ❌ Ignorar exceção
try { agg.DoStuff(); } catch { return Guid.Empty; }
// Esconde bug. Deixa subir.

// ❌ Logar e re-lançar embrulhando em outra exceção
try { ... } catch (Exception ex) { _log.Error(ex); throw new Exception("erro", ex); }
// Quebra stack trace. Use throw; sem nome.
```

## Checklist

### Domain (não responsabilidade desta skill, mas validar)
- [ ] `DomainException` em `Domain/SeedWork/DomainException.cs`.
- [ ] Cada Aggregate tem seu `<Aggregate>Errors.cs` `internal static class` ao lado.
- [ ] IDs seguem `^[A-Z]{3}(\.[A-Z]{3})?\d+$`.
- [ ] Factories usam `[CallerFilePath]`, `[CallerMemberName]`, `[CallerLineNumber]`.

### Application (responsabilidade desta skill)
- [ ] `Application/Errors/ApplicationException.cs` criado.
- [ ] `Application/Errors/ApplicationErrors.cs` com pelo menos `AggregateNotFound`, `ConcurrencyConflict`, `IdempotencyKeyConflict`, `ValidationFailed`, `UnauthorizedTenantAccess`.
- [ ] Handler **nunca** captura `DomainException` para repackaging.
- [ ] Handler **nunca** constrói `ApplicationException` direto — sempre via `ApplicationErrors.<Factory>`.
- [ ] Quando precisar de código novo, adicionar em `ApplicationErrors` antes de usar.

## Sobre Result\<T\> (alternativa)

`Result<T>` (em vez de exceções para fluxo esperado) continua sendo uma evolução opcional documentada em `improvements.md`. Combina especialmente bem com erros separados Application/Domain — a Application retorna `Result<TResponse, ApplicationError>` e exceções ficam apenas para `DomainException` e técnicas. Veja `improvements.md` se interessar.
