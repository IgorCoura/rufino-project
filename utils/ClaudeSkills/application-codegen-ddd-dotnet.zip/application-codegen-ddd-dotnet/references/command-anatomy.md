# Anatomia de Command (e Model quando necessário)

Toda operação de escrita tem **no mínimo** o Command, o Handler e a Response numa pasta dedicada:

```
Commands/EmployeeCommands/AlterEmployeeName/
├── AlterEmployeeNameCommand.cs           ← este arquivo (sempre)
├── AlterEmployeeNameCommandHandler.cs
├── AlterEmployeeNameResponse.cs
└── AlterEmployeeNameModel.cs             ← OPCIONAL — só quando body ≠ Command
```

Este documento cobre o `Command.cs`, o `Model.cs` (quando existir) e o `Response.cs`. Para Handler ver `handler-anatomy.md`.

---

## Princípio fundamental: Command primeiro, Model só quando preciso

A skill **gera o Command direto** e o usa como input do Handler. **Model é opcional** — só existe quando o **body recebido pela API é diferente do Command**.

### Quando NÃO precisa de Model (caso default)

Se todos os campos do Command vêm do body (ou de uma combinação de body + cabeçalhos que a camada API resolve com binding nativo), o Controller pode receber o **Command direto via `[FromBody]`** e despachar.

```csharp
// Application — só o Command, sem Model
public record CreateNoteCommand(
    Guid TenantId,
    string Title,
    string Content
) : IRequest<CreateNoteResponse>;

// (camada API — fora do escopo desta skill, mostrado só para fechar o ciclo)
[HttpPost]
public Task<...> Create([FromBody] CreateNoteCommand command, CancellationToken ct)
    => mediator.Send(command, ct);
```

### Quando PRECISA de Model

Quando há divergência entre o que o cliente envia no body e o que o Command exige. Cenário mais comum (e padrão do projeto):

> **`TenantId` vem do path (`/api/v1/{tenantId}/notes`), o restante vem do body.**

Aí o Model representa **só o body**, e o `ToCommand(tenantId, ...)` injeta o que falta:

```csharp
// Application
public record CreateNoteCommand(
    Guid TenantId,
    string Title,
    string Content
) : IRequest<CreateNoteResponse>;

public record CreateNoteModel(
    string Title,
    string Content
)
{
    public CreateNoteCommand ToCommand(Guid tenantId) =>
        new(tenantId, Title, Content);
}

// (camada API)
[HttpPost("api/v1/{tenantId}/notes")]
public Task<...> Create(
    [FromRoute] Guid tenantId,
    [FromBody]  CreateNoteModel model,
    CancellationToken ct)
    => mediator.Send(model.ToCommand(tenantId), ct);
```

Outros casos legítimos para criar Model:

| Cenário | Por quê |
|---|---|
| `TenantId` no path, restante no body | mais comum no projeto — default da skill |
| Vários campos no path (ex.: `/{tenantId}/employees/{employeeId}/photos`) | path + body precisam compor o Command |
| Upload de arquivo (`IFormFile` no body) | Command usa `Stream` (não pode depender de `IFormFile`); Model carrega o `IFormFile` e converte |
| Algum campo vem de header (correlation-id, idempotency-key, etc.) que precisa ir pro Command | binding por header → Model converte |
| Há transformação de tipo entre HTTP e Domínio (string → enum, string ISO → `DateOnly`) | Model carrega o tipo HTTP-friendly, conversão acontece no `ToCommand` |

### Fluxo de geração da skill

```mermaid
flowchart TD
    A[Usuário pede operação] --> B[Skill gera Command + Handler + Response]
    B --> C{TenantId vem do path<br/>OU body diverge do Command?}
    C -- Sim --> D[Skill cria Model + ToCommand]
    C -- Não --> E[Skill avisa: 'sem Model — Controller<br/>recebe Command direto via FromBody']
```

**Default da skill**: sempre gera Model **quando o Command tem `TenantId`** (porque esse é o caso esperado no projeto: TenantId vem da rota). Para Commands sem `TenantId` (raro — admin cross-tenant, jobs de seed), gera só o Command.

Se o usuário disser explicitamente "não precisa de Model" ou "todos os campos vêm no body", a skill respeita e gera só o Command.

---

## Estrutura mínima — Command

```csharp
namespace MeuSaaS.Application.Commands.EmployeeCommands.AlterEmployeeName;

public record AlterEmployeeNameCommand(
    Guid TenantId,
    Guid EmployeeId,
    string NewName
) : IRequest<AlterEmployeeNameResponse>;
```

Pontos invioláveis:

- **Command é `record`**. Imutável, value-equality, suporte a `with`. Nunca `class`.
- **Command implementa `IRequest<TResponse>`.** Sem isso, não passa pelo mediator.
- **Command tem `TenantId` como primeiro parâmetro** (quando aplicável). Sempre.
- Namespace segue a hierarquia de pastas: `MeuSaaS.Application.Commands.<Aggregate>Commands.<Operation>`.

## Estrutura do Model (quando criado)

```csharp
public record AlterEmployeeNameModel(
    Guid EmployeeId,
    string NewName
)
{
    public AlterEmployeeNameCommand ToCommand(Guid tenantId) =>
        new(tenantId, EmployeeId, NewName);
}
```

Pontos invioláveis:

- **Model é `record`**, mesmo padrão do Command.
- **Model NÃO tem `TenantId`** quando o `TenantId` vem do path. Se o usuário insistir em colocar, recuse — é vetor de IDOR direto (cliente enviaria tenant de outro).
- **`ToCommand(tenantId)` é o único mapeamento Model → Command.** Sem AutoMapper. Mapeamento à mão, simples e explícito.
- Quando o Model existe **apenas** porque o body diverge do Command, ele recebe **só os campos que vêm do body**.

---

## Anatomia do Response: o que devolver

Toda operação devolve um `Response`. Por default ele contém **apenas o `Id` do aggregate afetado** — esse é o piso, nunca menos. A regra-mestre acima desse piso:

> **Só inclua um campo no Response se ele evitar um round-trip imediato e previsível do cliente.**

Cada campo adicional é um contrato extra que se quebra silenciosamente quando o agregado evoluir. Resista a empilhar "por garantia".

### Estrutura mínima

```csharp
namespace MeuSaaS.Application.Commands.EmployeeCommands.AlterEmployeeName;

public sealed record AlterEmployeeNameResponse(Guid Id);
```

- **`sealed record`** — imutável, sem herança, mesmo padrão de Command e Model.
- Nome `<Operation>Response`.
- Vive na **mesma pasta do Command + Handler** (não em `DTO/Responses/`).
- **Sem `implicit operator`**. O Handler chama `return new AlterEmployeeNameResponse(employee.Id);` — construção explícita, sempre.

### Quando ficar no mínimo (default)

Mantenha só o `Id` quando o cliente da operação **vai chamar uma Query em seguida** pra ver o resultado, ou simplesmente **não precisa de feedback** além de "deu certo". A maioria dos casos cai aqui:

- Criar, alterar, deletar, ativar, desativar — sem cascata visível para o usuário.
- Operações onde o cliente já tem o estado em memória (foi ele quem mandou o input).
- Operações disparadas por workflow/sistema que só precisa saber se foi.
- Operações cujo cliente é UI e o próximo passo já é redirect para tela de detalhe (que faz GET).

### Quando o Response cresce — quatro padrões legítimos

| Padrão | Quando aplica | Exemplo |
|---|---|---|
| **Estado pós-operação** | A operação muda o estado do agregado e o cliente quer confirmação imediata sem GET | `TerminateContractResponse(Guid Id, string Status)` — cliente sabe na hora que ficou `"Terminated"` |
| **Métrica de efeito cascata** | A operação dispara cascata interna no agregado e o usuário quer feedback do tamanho do efeito | `TerminateContractResponse(Guid Id, string Status, int CanceledCommitmentsCount)` — "cancelei 7 commitments" |
| **Entidades internas recém-criadas** | A operação cria entidades dentro do agregado-raiz que o cliente precisa referenciar logo depois | `ActivateContractResponse(Guid Id, string Status, IReadOnlyList<CommitmentDto> Commitments)` — UI precisa dos IDs dos commitments criados pra montar a tela |
| **Denormalização útil de Value Object** | Devolver `.Name` de Enumeration ou texto formatado quando o cliente precisa exibir e a busca seria desperdiçada | `RegisterEventResponse(Guid Id, string Direction, string ResourceKind)` — em vez de devolver enums opacos |

Cada um desses tem em comum: o campo evita uma chamada imediata óbvia do cliente. Se o cliente **não** faria essa chamada de qualquer forma, o campo não cabe.

### Quando NÃO crescer (anti-padrões)

- ❌ **Devolver o aggregate inteiro.** Vaza a entidade de domínio através da fronteira. Sempre serialize campos selecionados em `record` próprio.
- ❌ **Devolver dados que o cliente já tem na mão.** Se ele mandou `name: "Maria"` no Command, não tem por que receber `name: "Maria"` no Response.
- ❌ **Devolver dados que precisam de outra query pra montar.** Response não justifica ir buscar coisas que a operação não tocou. Isso é trabalho de Query.
- ❌ **Empilhar campos "por garantia".** Cada campo é contrato. Quanto mais campos, mais quebra silenciosa quando o agregado evoluir.
- ❌ **Devolver `List<XxxDto>` não paginada** quando a lista pode crescer indefinidamente. Se a operação criou 50 commitments, devolva os IDs e um count. Listas grandes vão pra Query paginada via cursor.

### Conviver com `CreateResultForDuplicateRequest` (idempotência)

O `IdentifiedCommandHandler` exige uma resposta neutra para retentativas idempotentes. Para Response mínimo:

```csharp
protected override AlterEmployeeNameResponse CreateResultForDuplicateRequest()
    => new(Guid.Empty);
```

Para Response com campos extras, escolha **valores neutros que não dão a impressão de "operação real"**:

```csharp
protected override TerminateContractResponse CreateResultForDuplicateRequest()
    => new(Id: Guid.Empty, Status: string.Empty, CanceledCommitmentsCount: 0);

protected override ActivateContractResponse CreateResultForDuplicateRequest()
    => new(Id: Guid.Empty, Status: string.Empty, Commitments: Array.Empty<CommitmentDto>());
```

O cliente, ao receber `Id == Guid.Empty`, sabe que aquilo foi uma resposta "já processado anteriormente". Se precisar do estado atual, dispara uma Query.

### Checklist do Response

- [ ] É `sealed record` com nome `<Operation>Response`.
- [ ] Tem **pelo menos** o `Guid Id` do agregado afetado.
- [ ] Não usa `implicit operator` — o Handler constrói explicitamente.
- [ ] Cada campo extra (além do `Id`) cabe em um dos 4 padrões legítimos acima.
- [ ] Não devolve o agregate; não devolve campo que o cliente já tem; não devolve lista não paginada.
- [ ] `CreateResultForDuplicateRequest` retorna instância com valores neutros que sinalizam "já processado".

---

## Padrão para Create

Quando a operação cria um aggregate novo, o Command tem método `ToAggregate()` que devolve a instância pronta para o Handler salvar:

```csharp
namespace MeuSaaS.Application.Commands.EmployeeCommands.CreateEmployee;

public record CreateEmployeeCommand(
    Guid TenantId,
    string Name,
    string Cpf,
    DateOnly BirthDate,
    string Email
) : IRequest<CreateEmployeeResponse>
{
    public Employee ToAggregate()
        => Employee.Create(
            tenantId: TenantId,
            name: Name,
            cpf: Cpf,
            birthDate: BirthDate,
            email: Email);
}

public record CreateEmployeeModel(
    string Name,
    string Cpf,
    DateOnly BirthDate,
    string Email
)
{
    public CreateEmployeeCommand ToCommand(Guid tenantId)
        => new(tenantId, Name, Cpf, BirthDate, Email);
}
```

O Handler vira praticamente uma linha:

```csharp
public async Task<CreateEmployeeResponse> Handle(CreateEmployeeCommand request, CancellationToken ct)
{
    var employee = request.ToAggregate();          // mapeamento Command → Aggregate
    await repo.AddAsync(employee);                  // ou repo.Add(employee), depende do repo
    await repo.UnitOfWork.SaveChangesAsync(ct);
    return new CreateEmployeeResponse(employee.Id);
}
```

`Employee.Create(...)` é o **factory method estático no aggregate** (definido na camada Domain). Ele encapsula a criação válida — valida invariantes, gera o `Id`, levanta o `EmployeeCreatedDomainEvent`. Se o usuário ainda não tem o factory, alerte e siga para o `domain-modeler`.

---

## Padrão para Update / Alter / mutações específicas

Update **não** tem `ToAggregate()`. O Handler carrega o aggregate existente (busca **tracked**) e chama um método rico:

```csharp
public record AlterEmployeeNameCommand(
    Guid TenantId,
    Guid EmployeeId,
    string NewName
) : IRequest<AlterEmployeeNameResponse>;
```

Handler:

```csharp
var employee = await repo.FirstOrDefaultAsync(
    e => e.Id == request.EmployeeId && e.TenantId == request.TenantId, ct)
    ?? throw EmployeeErrors.NotFound(request.EmployeeId);

employee.AlterName(request.NewName);                // método rico no aggregate
await repo.UnitOfWork.SaveChangesAsync(ct);         // Change Tracking detecta a mutação. SEM repo.Update().
return new AlterEmployeeNameResponse(employee.Id);
```

**Três erros comuns que a skill recusa gerar:**

1. **Setter direto** — `employee.Name = request.NewName`. Fura encapsulamento, impede o agregado de validar invariantes / disparar eventos.
2. **`repo.Update(employee)` antes do save** — a entidade já está tracked pela busca; chamar `Update()` é supérfluo, marca todas as propriedades como modificadas e mascara intenção. Ver `references/handler-anatomy.md` para o detalhe.
3. **Validações de domínio antes do método rico** — `if (employee.Status != X) throw ...` no Handler. A regra pertence ao método rico.

Se o aggregate ainda não tem o método rico, é sinal de domínio anêmico — alerte o usuário antes de gerar o Handler.

---

## Padrão para Delete

```csharp
public record DeleteEmployeeCommand(Guid TenantId, Guid EmployeeId)
    : IRequest<DeleteEmployeeResponse>;

public record DeleteEmployeeModel(Guid EmployeeId)
{
    public DeleteEmployeeCommand ToCommand(Guid tenantId)
        => new(tenantId, EmployeeId);
}
```

Pergunta importante: é hard delete ou soft delete?

- **Hard delete:** `repo.Remove(employee)` no Handler. Use só quando faz sentido apagar de verdade (rascunho descartado, registro órfão).
- **Soft delete:** `employee.Deactivate()` (ou `Archive()`, `MarkAsDeleted()`). Aggregate marca um flag, evento de domínio dispara. **Padrão recomendado**, principalmente em domínios financeiros e multi-tenant onde auditoria importa.

Se o usuário não disse, **pergunte**. Não invente.

---

## Padrão para upload de arquivo

Quando o Command recebe arquivo, o tipo do campo é `Stream` (não `IFormFile` — esse é HTTP, fica fora do Application):

```csharp
public record UploadEmployeePhotoCommand(
    Guid TenantId,
    Guid EmployeeId,
    string FileName,
    string ContentType,
    Stream Content
) : IRequest<UploadEmployeePhotoResponse>;

public record UploadEmployeePhotoModel(Guid EmployeeId, IFormFile File)
{
    public UploadEmployeePhotoCommand ToCommand(Guid tenantId)
        => new(tenantId, EmployeeId, File.FileName, File.ContentType, File.OpenReadStream());
}
```

O Handler usa o `Stream` direto e passa para o `IBlobService`:

```csharp
var url = await blobService.UploadAsync(
    container: $"companies/{request.TenantId}/employees/{request.EmployeeId}",
    fileName: request.FileName,
    contentType: request.ContentType,
    content: request.Content,
    cancellationToken: ct);

employee.AlterPhotoUrl(url);
await repo.UnitOfWork.SaveChangesAsync(ct);
```

No controller (camada API), o endpoint declara `[RequestSizeLimit(...)]` — isso é responsabilidade de quem expõe o HTTP, não da Application.

---

## Padrão para Command que recebe lista

Listas no Command são `IReadOnlyList<T>`, não `List<T>`:

```csharp
public record AddDependentsCommand(
    Guid TenantId,
    Guid EmployeeId,
    IReadOnlyList<DependentItem> Dependents
) : IRequest<AddDependentsResponse>;

public record DependentItem(string Name, DateOnly BirthDate, string Cpf);
```

Por quê: imutabilidade. Quem recebe não tem direito de fazer `.Add(...)`.

Se o item da lista precisa virar entidade no aggregate, o mapeamento fica num método do Command:

```csharp
public IReadOnlyList<Dependent> ToDomainDependents()
    => Dependents.Select(d => Dependent.Create(d.Name, d.BirthDate, d.Cpf)).ToList();
```

---

## Padrão para Command com dado opcional

Use tipos nullable explícitos (`string?`, `DateOnly?`):

```csharp
public record UpdateEmployeeContactCommand(
    Guid TenantId,
    Guid EmployeeId,
    string? Email,        // null = não alterar
    string? Phone         // null = não alterar
) : IRequest<UpdateEmployeeContactResponse>;
```

No Handler:

```csharp
if (request.Email is not null)
    employee.AlterEmail(request.Email);
if (request.Phone is not null)
    employee.AlterPhone(request.Phone);
```

Cuidado: "string vazia" e "null" significam coisas diferentes. Se quiser permitir "limpar o campo", use `Optional<T>` ou um marcador explícito. A maioria dos casos, null = não tocar funciona.

---

## Anti-padrões (não faça)

- ❌ **Lógica no `ToCommand` ou `ToAggregate`.** Esses métodos só mapeiam. Validação é da Application (Validator) ou do Domain (factory).
- ❌ **Command que retorna void (`IRequest`).** Sempre retorne algo — pelo menos o `Id` do aggregate afetado. Útil para idempotência e logs.
- ❌ **Command com referência para o aggregate em si** (`Employee Employee`). Command leva *dados*, não objetos de domínio.
- ❌ **Usar `class` em vez de `record`.** Imutabilidade não é negociável.
- ❌ **`TenantId` no Model.** Vem da rota, não do body. Sempre.
- ❌ **Múltiplos commands no mesmo arquivo.** Cada operação tem sua pasta e seu trio de arquivos.
- ❌ **Handler com `if (aggregate.Status...) throw ...` antes do método rico.** Regra é do agregado. Ver `references/handler-anatomy.md`.
- ❌ **Handler chamando `repo.Update(aggregate)` antes de `SaveChangesAsync`.** A entidade está tracked pela busca. Change Tracking detecta mutações automaticamente.
- ❌ **Command que aparenta mexer em mais de um agregado sem passar pelo redesenho com Domain Event.** Ver `references/transactions.md`.
