# Biblioteca de diagramas Mermaid

Sempre que gerar uma feature nova na Application, acompanhe com **pelo menos um diagrama** do tipo apropriado. Esta é a biblioteca de templates — copie, ajuste nomes, entregue.

Vários diagramas mostram o **fluxo completo** (Cliente → API → Application → Infra → DB) mesmo que esta skill toque só na Application. Isso é proposital: ajuda quem está escrevendo o Handler a entender em qual posição do trajeto ele está.

Tipos cobertos:
1. Sequência de Command (fluxo HTTP completo — fronteira entre API e Application destacada)
2. Sequência de Query
3. Fluxograma de IdentifiedCommand (idempotência — vive na Application)
4. ER do Aggregate (referência do Domain — útil para escrever Handler)
5. Classes da camada Application (Command/Handler/Response)
6. Estados de uma entidade (state machine) — geralmente Domain, mas Application referencia
7. Bounded Context Map (visão arquitetural)
8. Casos de uso
9. Arquitetura geral (Clean Architecture — onde a Application se encaixa)

---

## 1. Sequência de Command — fluxo HTTP completo

Use para **cada Command novo** quando o fluxo tem efeito colateral relevante (não é CRUD raso).

```mermaid
sequenceDiagram
    autonumber
    actor Cliente
    participant API as Controller
    participant ID as IdentifiedCommandHandler
    participant Med as Mediator
    participant H as CreateBillHandler
    participant Repo as IBillRepository
    participant DB as Database

    Cliente->>API: POST /api/v1/{tenantId}/bill<br/>Idempotency-Key: <guid>
    API->>API: model.ToCommand(tenantId)
    API->>ID: mediator.Send(IdentifiedCommand)
    ID->>Repo: requestManager.ExistAsync(requestId)
    Repo-->>ID: false
    ID->>Repo: requestManager.CreateRequestForCommandAsync
    ID->>Med: mediator.Send(command interno)
    Med->>H: Handle(CreateBillCommand)
    H->>H: command.ToAggregate()
    H->>Repo: Add(bill)
    H->>Repo: UnitOfWork.SaveChangesAsync()
    Repo->>DB: INSERT bill + ClientRequest
    DB-->>Repo: ok
    Repo-->>H: 1
    H-->>Med: BillCreatedResponse(bill.Id)
    Med-->>ID: response
    ID-->>API: response
    API-->>Cliente: 200 OK + body
```

**Adapte para sua feature**: troque `CreateBill` pelo nome real, ajuste passos de mutação se houver gateway externo, fila, etc.

---

## 2. Sequência de Query

Queries não passam pelo mediator. Diagrama é mais curto.

```mermaid
sequenceDiagram
    autonumber
    actor Cliente
    participant API as BillController
    participant Q as IBillQueries
    participant Ctx as DbContext
    participant DB as Database

    Cliente->>API: GET /api/v1/{tenantId}/bill?pageSize=50
    API->>Q: ListAsync(tenantId, params)
    Q->>Ctx: factory.CreateDbContext()
    Q->>Ctx: Where(TenantId).Select(dto).Skip().Take()
    Ctx->>DB: SELECT ... LIMIT 50
    DB-->>Ctx: rows
    Ctx-->>Q: List<BillListItemDto>
    Q-->>API: PagedResult<BillListItemDto>
    API-->>Cliente: 200 OK + body
```

---

## 3. Fluxograma de IdentifiedCommand (idempotência)

Mostra o que acontece quando o mesmo `Idempotency-Key` chega de novo.

```mermaid
flowchart TD
    A[Recebe IdentifiedCommand] --> B{requestId já existe<br/>em ClientRequests?}
    B -- Sim --> C[Retorna<br/>CreateResultForDuplicateRequest]
    B -- Não --> D[Insere ClientRequest<br/>na mesma transação]
    D --> E[Despacha command<br/>via mediator]
    E --> F[Handler real executa]
    F --> G{SaveChanges<br/>com sucesso?}
    G -- Sim --> H[Retorna response real]
    G -- Não --> I[Lança exceção<br/>ClientRequest também sofre rollback]
```

---

## 4. ER do Aggregate

Use quando criar agregado novo. Mostra entidades, value objects, relacionamentos.

```mermaid
erDiagram
    Bill {
        Guid Id PK
        Guid TenantId FK
        string SupplierName
        string DocumentCode UK
        decimal Amount
        DateTime DueDate
        string Status
        DateTime CreatedAt
        DateTime UpdatedAt
    }
    BillItem {
        Guid Id PK
        Guid BillId FK
        string Description
        decimal Amount
        string CategoryCode
    }
    Attachment {
        Guid Id PK
        Guid BillId FK
        string Type
        string Url
    }
    Tenant {
        Guid Id PK
        string Name
    }

    Tenant ||--o{ Bill : "has many"
    Bill ||--o{ BillItem : "has many (owned)"
    Bill ||--o{ Attachment : "has many"
```

**Convenção**: PK = primary key, FK = foreign key, UK = unique key. Value Objects entram como entidade no diagrama mas anote `(owned)` no relacionamento.

---

## 5. Classes da camada Application

Use no início do projeto e quando alguém da equipe pergunta "como tudo se encaixa".

```mermaid
classDiagram
    class IRequest~TResponse~ {
        <<interface>>
    }
    class IRequestHandler~TRequest, TResponse~ {
        <<interface>>
        +Handle(TRequest, CancellationToken) Task~TResponse~
    }
    class IMediator {
        <<interface>>
        +Send~TResponse~(IRequest~TResponse~) Task~TResponse~
    }
    class CreateBillCommand {
        +Guid TenantId
        +string SupplierName
        +string DocumentCode
        +decimal Amount
        +DateTime DueDate
        +ToAggregate() Bill
    }
    class CreateBillModel {
        +string SupplierName
        +string DocumentCode
        +decimal Amount
        +DateTime DueDate
        +ToCommand(Guid) CreateBillCommand
    }
    class CreateBillCommandHandler {
        -IBillRepository _repo
        +Handle(CreateBillCommand) Task~BillCreatedResponse~
    }
    class CreateBillIdentifiedCommandHandler {
        +CreateResultForDuplicateRequest() BillCreatedResponse
    }
    class IdentifiedCommandHandler~TCmd, TRes~ {
        <<abstract>>
        +Handle(IdentifiedCommand) Task~TRes~
        #CreateResultForDuplicateRequest()* TRes
    }
    class BillCreatedResponse {
        +Guid Id
    }
    class BaseDTO {
        +Guid Id
    }

    IRequest~TResponse~ <|.. CreateBillCommand
    IRequestHandler~TRequest, TResponse~ <|.. CreateBillCommandHandler
    IdentifiedCommandHandler~TCmd, TRes~ <|-- CreateBillIdentifiedCommandHandler
    BaseDTO <|-- BillCreatedResponse
    CreateBillModel ..> CreateBillCommand : creates
    CreateBillCommandHandler ..> BillCreatedResponse : returns
```

---

## 6. State machine de uma entidade

Use para entidades com ciclo de vida (Pedido, Pagamento, Contrato, etc.).

```mermaid
stateDiagram-v2
    [*] --> Draft: Create
    Draft --> Submitted: Submit
    Draft --> Cancelled: Cancel
    Submitted --> Approved: Approve
    Submitted --> Rejected: Reject
    Submitted --> Cancelled: Cancel
    Approved --> Paid: Pay
    Approved --> Cancelled: Cancel
    Paid --> Reconciled: Reconcile
    Rejected --> [*]
    Cancelled --> [*]
    Reconciled --> [*]

    note right of Approved: Permite alteração<br/>de pagador
    note right of Paid: Imutável após<br/>conciliação
```

Cada transição vira (em geral) **um Command no Application**. O agregado tem método rico (`pedido.Submit()`, `pedido.Approve(...)`) que valida se a transição é válida.

---

## 7. Bounded Context Map

Use no nível arquitetural — qual contexto fala com qual e como.

```mermaid
flowchart LR
    subgraph FIN[Contexto: Financeiro]
        FIN_AP[Contas a Pagar]
        FIN_AR[Contas a Receber]
        FIN_DRE[DRE]
    end

    subgraph PEOPLE[Contexto: Pessoas]
        PE[Employee]
        PE_ROLE[Role]
    end

    subgraph CUST[Contexto: Clientes]
        CL[Customer]
        CL_CONTRACT[Contract]
    end

    subgraph IDP[Identity Provider]
        KC[Keycloak]
    end

    FIN_AP -- "usa Customer/Contract<br/>(ACL)" --> CUST
    FIN_AR -- "usa Customer/Contract<br/>(ACL)" --> CUST
    FIN_DRE -- "consume Domain Events<br/>de AP e AR" --> FIN_AP
    FIN_DRE -- "consume Domain Events" --> FIN_AR
    PEOPLE -- "auth via" --> IDP
    FIN -- "auth via" --> IDP
    CUST -- "auth via" --> IDP
```

**ACL** = Anti-Corruption Layer (tradução entre modelos de contextos diferentes). Documente sempre que dois contextos compartilham conceito mas com semântica diferente.

---

## 8. Casos de uso

Use no início de uma feature ou módulo para alinhar o **escopo do que será implementado**.

```mermaid
flowchart LR
    subgraph CO[Contexto: Contas a Pagar]
        UC1[(Capturar conta<br/>via email)]
        UC2[(Capturar conta<br/>via upload)]
        UC3[(Classificar conta)]
        UC4[(Aprovar conta)]
        UC5[(Agendar pagamento)]
        UC6[(Executar pagamento<br/>via API)]
        UC7[(Conciliar pagamento)]
        UC8[(Visualizar dashboard)]
    end

    Sistema((Sistema<br/>de IA))
    Aprovador((Aprovador<br/>humano))
    Banco((Banco<br/>via API))
    Email((Servidor<br/>email))

    Email --> UC1
    Aprovador --> UC2
    Sistema --> UC3
    Aprovador --> UC4
    Sistema --> UC5
    Banco --> UC6
    Banco --> UC7
    Aprovador --> UC8

    UC1 -.->|extends| UC3
    UC2 -.->|extends| UC3
    UC4 -.->|includes| UC5
    UC5 -.->|includes| UC6
```

---

## 9. Arquitetura geral (Clean Architecture)

Use **uma vez** por sistema, no readme do repo ou na documentação de onboarding.

```mermaid
flowchart TB
    subgraph EXT[Adapters externos]
        WEB[Web Browser<br/>Flutter]
        MOB[Mobile<br/>Flutter]
        EMAIL[Email worker]
        BANK[Bank API]
    end

    subgraph API[MeuSaaS.API]
        CTRL[Controllers]
        FILT[Filters / Auth]
        DI_API[DI Extensions]
    end

    subgraph APP[MeuSaaS.Application]
        CMD[Commands + Handlers]
        QRY[Queries cursor-paginated]
        MED[Mediator próprio]
        BHV[Behaviors:<br/>Logging, Validator, Transaction]
        ERR[ApplicationErrors]
        VAL[Validations próprias]
    end

    subgraph DOM[MeuSaaS.Domain]
        AGG[Aggregates + métodos ricos]
        VO[Value Objects]
        EVT[Domain Events]
        DERR[DomainException +<br/>internal Errors factories]
        REPO_I[Repository Interfaces]
    end

    subgraph INFRA[MeuSaaS.Infra]
        EFCTX[DbContext]
        REPO[Repositories]
        BLOB[Blob Service]
        HTTP[HttpClients + Polly]
    end

    WEB --> CTRL
    MOB --> CTRL
    EMAIL --> CTRL
    CTRL --> MED
    MED --> BHV
    BHV --> CMD
    CTRL --> QRY
    CMD --> AGG
    CMD --> REPO_I
    CMD --> ERR
    AGG --> DERR
    AGG --> EVT
    QRY --> EFCTX
    REPO_I -.implements.-> REPO
    REPO --> EFCTX
    REPO --> BLOB
    EFCTX --> BANK
    HTTP --> BANK
    DI_API -.wires.-> APP
    DI_API -.wires.-> INFRA

    classDef app fill:#cfe;
    classDef dom fill:#fed;
    class CMD,QRY,MED,BHV,ERR,VAL app;
    class AGG,VO,EVT,DERR,REPO_I dom;
```

**Regra de leitura**: setas de cima pra baixo (e de fora pra dentro) são permitidas; setas de baixo pra cima precisam passar por interface (linha tracejada).

---

## Convenções para os diagramas

1. **Use IDs descritivos** (`UC1` no flowchart é ok, mas em ER use o nome real `Bill`).
2. **Limite a ~15 nós por diagrama**. Se passar disso, divida em diagramas menores.
3. **Anote escolhas não óbvias** com `note` (Mermaid suporta em sequência e estado).
4. **Não tente fazer um diagrama que mostra tudo** — escolha um aspecto.
5. **Sempre teste o Mermaid** rodando localmente (mermaid.live) antes de commitar — sintaxe quebra fácil.
