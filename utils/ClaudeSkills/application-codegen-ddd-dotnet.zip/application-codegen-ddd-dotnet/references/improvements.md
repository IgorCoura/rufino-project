# Recomendações de melhoria — escopo Application

Leitura **antes do scaffolding inicial**. As recomendações abaixo afetam a forma de gerar código nesta camada. Algumas são opt-in (você decide se vale agora), outras são quase imperdíveis.

Cada recomendação tem: **o que**, **por quê**, **como**, **veredito** (adotar agora / depois / opcional).

> Itens que pertencem à camada API (CorrelationId middleware, TenantAuthorizationFilter, ProblemDetails, HealthChecks, versionamento de API, OpenAPI) ou à Infra (Global Query Filter de soft delete, configuração OTel exporters) ficam fora deste documento.
>
> Itens que **já viraram default da skill** (cursor pagination, LoggingBehavior, TransactionBehavior, separação Application/Domain de erros, validações via metodologia própria) também não aparecem mais aqui — passaram para os references principais.

---

## 1. `Result<T>` em vez de exceptions para fluxo esperado

**O que.** Em vez de `throw <Aggregate>Errors.NotFound(...)` quando o agregado não existe, retornar `Result<T, DomainException>` que carrega sucesso ou erro. Excepcionais reais (banco caiu, falha de serialização) continuam exceções.

**Por quê.** Exceções são caras (stack walk, instanciação) e — mais importante — borram a fronteira entre **fluxo esperado** (cliente mandou ID que não existe) e **fluxo excepcional** (banco caiu). O esperado deve ser tipado.

Combina muito bem com a doutrina atual de erros: o Domain define **todos** os erros previsíveis via factories `<Aggregate>Errors.*` retornando `DomainException`. Então o tipo de erro em `Result<T, DomainException>` é uniforme e já existe — você só troca o `throw` por `return`.

**Como.**

```csharp
namespace MeuSaaS.Application.Util;

using MeuSaaS.Domain.SeedWork;

public readonly record struct Result<T>
{
    public T? Value { get; }
    public DomainException? Error { get; }
    public bool IsSuccess => Error is null;

    private Result(T value) { Value = value; Error = null; }
    private Result(DomainException error) { Value = default; Error = error; }

    public static Result<T> Success(T value) => new(value);
    public static Result<T> Failure(DomainException error) => new(error);

    public static implicit operator Result<T>(T value) => Success(value);
    public static implicit operator Result<T>(DomainException error) => Failure(error);
}
```

As factories `<Aggregate>Errors.NotFound(...)` (e todas as outras) **já retornam `DomainException`** — funcionam sem alteração tanto via `throw` quanto via `return`.

Handler:

```csharp
public async Task<Result<ApproveBillResponse>> Handle(
    ApproveBillCommand request, CancellationToken ct)
{
    var bill = await repo.FirstOrDefaultAsync(
        b => b.Id == request.BillId && b.TenantId == request.TenantId, ct);
    if (bill is null)
        return BillErrors.NotFound(request.BillId);   // implícito → Result<...>.Failure

    bill.Approve(request.ApproverId, DateTime.UtcNow);   // se invariante violada: DomainException sobe
    // alternativa: capturar e converter pra Result, se quiser uniformidade total.

    await repo.UnitOfWork.SaveChangesAsync(ct);
    return new ApproveBillResponse(bill.Id);
}
```

O filtro da API precisa entender duas saídas:
- Handler retornou `Result<T>.IsSuccess == true` → 200 com `Value`.
- Handler retornou `Result<T>.IsSuccess == false` → mapeia `Error.Category` (Invalid/NotFound/Conflict) para HTTP (422/404/409).

**Trade-off.** Toda assinatura de Handler vira `Result<T>` (verbosidade). Você ganha: zero exceções para fluxo esperado, performance, código mais explícito. As exceptions técnicas de plataforma (`CommandValidationException`, `IdempotencyConflictException`) continuam como exceptions — não fazem parte do `Result<T>` porque acontecem **antes** do Handler ser invocado (são lançadas em behaviors).

**Veredito.** **Adotar para casos novos**. Migrar gradualmente. Em handlers triviais (CRUD puro) o ganho é pequeno; em handlers complexos com várias validações, é enorme. Se adotar, o `IRequest<TResponse>` passa a esperar `Result<TResponse>` quando fizer sentido.

---

## 2. Idempotência com resultado real cacheado

**O que.** Hoje, `IdentifiedCommandHandler.CreateResultForDuplicateRequest()` retorna `new Response(Guid.Empty)` — um valor neutro. Cliente que retransmite recebe **resposta diferente** da primeira vez, mesmo que o efeito (a operação já feita) seja o mesmo.

**Por quê.** Cliente espera idempotência **completa**: mesma request, mesma resposta. Retornar `Empty` força o cliente a "buscar de novo" depois — pior UX e abre janela de race condition.

**Como.** Salvar o **resultado** junto com o request_id na tabela `ClientRequests`:

```csharp
public class ClientRequest
{
    public Guid Id { get; set; }
    public string CommandName { get; set; } = "";
    public string? ResponseJson { get; set; }
    public DateTime CreatedAt { get; set; }
}
```

`IRequestManager` ganha:

```csharp
Task<string?> GetCachedResponseAsync(Guid id, CancellationToken ct);
Task SaveResponseAsync(Guid id, string commandName, object response, CancellationToken ct);
```

`IdentifiedCommandHandler`:

```csharp
public override async Task<TResponse> Handle(
    IdentifiedCommand<TCommand, TResponse> req, CancellationToken ct)
{
    var cached = await _requestManager.GetCachedResponseAsync(req.Id, ct);
    if (cached is not null)
        return JsonSerializer.Deserialize<TResponse>(cached)!;

    var result = await _mediator.Send(req.Command, ct);
    await _requestManager.SaveResponseAsync(req.Id, typeof(TCommand).Name, result!, ct);
    return result;
}
```

**Cuidado.** Resposta cacheada precisa estar **na mesma transação** do efeito colateral. Use o mesmo `DbContext` e mesma chamada de `SaveChangesAsync` (ou mesmo `BeginTransaction` se for `IMultiAggregateCommand`).

**Veredito.** **Adotar agora se UX importa** (formulário que o usuário pode reenviar, mobile com retry automático). Para integração interna (worker → API), `Empty` resolve.

---

## 3. Outbox pattern para Domain Events

**O que.** Quando agregado dispara `DomainEvent` que precisa virar **side effect externo** (mandar email, publicar em fila, chamar webhook), não fazer dispatch síncrono dentro do `SaveChanges`. Persistir o evento numa tabela `Outbox` na mesma transação, e ter um worker que lê e despacha.

**Por quê.** Sem outbox, ou (a) você dispara o side effect **antes** de salvar e arrisca disparar evento de operação que falhou no commit, ou (b) você dispara **depois** e arrisca o processo morrer entre commit e dispatch — efeito perdido. Outbox elimina os dois cenários.

**Como.**

1. `SaveChangesInterceptor` no DbContext (Infra): antes de salvar, varre `ChangeTracker` por `IAggregateRoot` com eventos pendentes; serializa cada evento e insere em `Outbox` na mesma transação.
2. `OutboxProcessor` (BackgroundService) lê linhas de `Outbox` em batch, despacha cada uma via `IMediator.Publish` (notification handler) ou broker externo, marca como processada.
3. Polling com `FOR UPDATE SKIP LOCKED` (Postgres) para múltiplas instâncias do worker.

**Onde a Application entra.** Definição da interface do despachador (`IIntegrationEventDispatcher` ou equivalente), e os notification handlers que vão consumir os eventos despachados pelo worker. O interceptor e o processor moram em Infra.

**Trade-off.** Latência de side effect (eventual consistency — segundos, não milissegundos). Mais infra (tabela, worker). Pago pelo enorme ganho de confiabilidade.

**Veredito.** **Adotar quando aparecer o primeiro side effect externo** (email, webhook, fila). Antes disso, dispatch síncrono via `SaveChanges` está ok. Para um SaaS de gestão financeira com integrações bancárias, vai aparecer cedo.

---

## 4. Strongly-typed Ids

**O que.** `Guid TenantId, Guid BillId` é fácil de trocar acidentalmente (compilador não pega). `record TenantId(Guid Value)` força type-safety.

**Por quê.** Bug clássico: `command.BillId` no lugar de `command.TenantId`. Compila, roda, vaza dado.

**Como.** Domain define:

```csharp
public readonly record struct BillId(Guid Value)
{
    public static BillId New() => new(Guid.NewGuid());
    public static implicit operator Guid(BillId id) => id.Value;
}

public readonly record struct TenantId(Guid Value)
{
    public static implicit operator Guid(TenantId id) => id.Value;
}
```

Application usa:

```csharp
public record ApproveBillCommand(
    TenantId TenantId,
    BillId BillId,
    Guid ApproverId
) : IRequest<ApproveBillResponse>;
```

EF precisa de `ValueConverter<BillId, Guid>` (Infra). JSON precisa de `JsonConverter` (API). Dá trabalho.

**Veredito.** **Opcional, alto retorno em projeto grande**. Para SaaS com 50+ agregados, o ganho é gigante. Para projeto pequeno, é overengineering. Decida cedo — migrar é doloroso.

---

## 5. Métricas via Behavior (OpenTelemetry)

**O que.** Behavior que mede latência e contagem de cada Handler. Exporta para Prometheus/OTLP via OpenTelemetry.

**Por quê.** Logs são detalhe pontual; métricas mostram tendência. Quanto demora handler X em p95? Quantos comandos por minuto? Quantas duplicatas? Sem métricas, você só sabe pelo cliente reclamando.

**Como — só a parte da Application:**

```csharp
namespace MeuSaaS.Application.Behaviors;

using System.Diagnostics.Metrics;

public sealed class MetricsBehavior<TRequest, TResponse>(IMeterFactory factory)
    : IPipelineBehavior<TRequest, TResponse>
    where TRequest : IRequest<TResponse>
{
    private static readonly Meter _meter = new("Application.Mediator");
    private static readonly Histogram<double> _latency =
        _meter.CreateHistogram<double>("mediator.handler.duration", "ms");
    private static readonly Counter<long> _count =
        _meter.CreateCounter<long>("mediator.handler.count");

    public async Task<TResponse> Handle(
        TRequest request, RequestHandlerDelegate<TResponse> next, CancellationToken ct)
    {
        var name = typeof(TRequest).Name;
        var sw = Stopwatch.StartNew();
        var status = "success";
        try
        {
            return await next();
        }
        catch (DomainException) { status = "domain_failure"; throw; }
        catch (CommandValidationException) { status = "validation_failure"; throw; }
        catch (IdempotencyConflictException) { status = "idempotency_conflict"; throw; }
        catch { status = "failure"; throw; }
        finally
        {
            _latency.Record(sw.Elapsed.TotalMilliseconds,
                new("handler", name),
                new("status", status));
            _count.Add(1, new("handler", name), new("status", status));
        }
    }
}
```

A configuração do OpenTelemetry (exporters, `AddOpenTelemetry` no `Program.cs`) é da camada API.

**Veredito.** **Adotar quando começar a ter usuários reais**. Antes disso, não tem o que medir.

---

## 6. Testes — convenção de pasta espelhada

**O que.** Para cada `Application/Commands/BillCommands/ApproveBill/ApproveBillCommandHandler.cs`, ter `tests/Application.Tests/Commands/BillCommands/ApproveBill/ApproveBillCommandHandlerTests.cs`. Mesma estrutura de pasta, sufixo `Tests`.

**Por quê.** Encontrar o teste de um handler em segundos. Refactor de pasta = refactor do teste.

**Como.** `dotnet new xunit -n MeuSaaS.Application.Tests` no `tests/`. `NSubstitute` para repos, `Bogus` para fakes, `FluentAssertions` para asserções legíveis.

```csharp
public class ApproveBillCommandHandlerTests
{
    private readonly IBillRepository _repo = Substitute.For<IBillRepository>();
    private readonly ApproveBillCommandHandler _sut;

    public ApproveBillCommandHandlerTests()
    {
        _sut = new ApproveBillCommandHandler(_repo);
    }

    [Fact]
    public async Task Handle_should_throw_BillNotFound_when_bill_missing()
    {
        var cmd = new ApproveBillCommand(Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid());
        _repo.FirstOrDefaultAsync(Arg.Any<...>()).Returns((Bill?)null);

        var act = () => _sut.Handle(cmd, CancellationToken.None);

        var ex = await act.Should().ThrowAsync<DomainException>();
        ex.Which.Category.Should().Be(DomainErrorCategory.NotFound);
        // ou, com convenção de Id: ex.Which.Id.Should().Be("APD.BIL00");
    }

    [Fact]
    public async Task Handle_should_let_DomainException_bubble()
    {
        // bill em status que não permite Approve → BillErrors.InvalidStatusTransition
        // teste garante que Handler NÃO captura nem repackeia
    }

    [Fact]
    public async Task Handle_should_filter_by_tenant_in_alter_scenarios()
    {
        // teste explícito de multi-tenancy: não acha bill se tenant não bate
    }
}
```

**Para integração**, `WebApplicationFactory<Program>` + Testcontainers (Postgres real em Docker durante teste).

**Veredito.** **Adotar agora**. Se a skill gera código sem teste, dívida cresce até virar muralha.

---

## 7. `EnumerationDto` compartilhado é facade — cuidado

**Recomendação contrária.** A spec original usa `EnumerationDto` em `BaseDtos.cs` para todo Smart Enum. Isso vira facade que mascara campos diferentes (Status tem `Color`, Role tem `IsSystem`, etc.). Quando bate o primeiro caso "preciso desse campo só nesse enum", o time tende a inflar `EnumerationDto` com tudo, ou cria DTO específico em outro canto e o `EnumerationDto` fica fantasma.

**Recomendação.** DTOs específicos por enum quando há campo extra. `EnumerationDto` só para o caso trivial (Id + Name). Não force reuso.

**Veredito.** **Adotar disciplina desde o início**.

---

## 8. Soft delete — o handler ainda filtra explicitamente

**O que.** Embora o filtro global de soft delete (`HasQueryFilter` no DbContext) seja recomendado na Infra, o handler **continua** filtrando explicitamente:

```csharp
var bill = await repo.FirstOrDefaultAsync(
    x => x.TenantId == request.TenantId
      && x.Id == request.BillId
      && !x.Deleted);
```

**Por quê.** Defesa em profundidade. `IgnoreQueryFilters()` é fácil de chamar acidentalmente. Background workers podem não ter o filtro ativo. O handler que **escreve** sobre dados nunca pode prosseguir com soft-deleted.

**Veredito.** **Adotar como hábito**. O custo de digitar `&& !x.Deleted` é zero.

---

## Ordem sugerida de adoção

**Antes do primeiro deploy de produção:**
- 6 (Testes), 7 (disciplina `EnumerationDto`), 8 (filtro explícito de soft delete).

**Antes do primeiro side effect externo:**
- 3 (Outbox).

**Quando time crescer ou aparecer bug grave de fluxo esperado:**
- 1 (`Result<T>`), 4 (Strongly-typed Ids).

**Sempre que aparecer:**
- 2 (Idempotência cacheada — se UX importa), 5 (Métricas — quando começar a ter usuários reais).
