# Transações — quando usar `UnitOfWork.SaveChangesAsync` vs `BeginTransactionAsync`

A camada Application coordena escrita em duas formas:

1. **`SaveChangesAsync` único do Unit of Work** — default, simples, atômico já no nível do EF.
2. **Transação explícita** (`BeginTransactionAsync` + `CommitAsync`) — quando o efeito atravessa múltiplos `SaveChangesAsync` ou múltiplos contextos.

A skill **detecta** automaticamente o caso 2 via interface marcadora `IMultiAggregateCommand`. Para o caso 1, não faz nada além do que o Handler já faz.

## Quando usar `UnitOfWork.SaveChangesAsync` (caso default)

Vale para a **maioria dos Commands**. Características:

- Toca **um único agregado** (cria, altera ou deleta).
- Idempotência via `IRequestManager` que **participa do mesmo `SaveChangesAsync`** (gravação de `ClientRequest` + agregado na mesma transação implícita do EF).
- Domain Events do agregado são despachados antes ou depois do `SaveChanges` conforme a estratégia (Outbox via interceptor é o recomendado — ver `improvements.md`).

Exemplo:

```csharp
public sealed class ApproveBillCommandHandler(IBillRepository repo)
    : IRequestHandler<ApproveBillCommand, ApproveBillResponse>
{
    public async Task<ApproveBillResponse> Handle(
        ApproveBillCommand request, CancellationToken ct)
    {
        var bill = await repo.FirstOrDefaultAsync(
            x => x.TenantId == request.TenantId && x.Id == request.BillId)
            ?? throw ApplicationErrors.AggregateNotFound(
                nameof(Bill), request.BillId.ToString());

        bill.Approve(request.ApproverId, DateTime.UtcNow);

        await repo.UnitOfWork.SaveChangesAsync(ct); // ← atômico no nível do EF
        return bill.Id;
    }
}
```

Por que isso é seguro:

- O EF abre uma transação implícita ao redor de `SaveChangesAsync`. Se algo falhar (constraint, concorrência), faz rollback automático.
- O `ClientRequest` (idempotência) é inserido no mesmo `DbContext`. Vai junto.
- Se você tiver `SaveChangesInterceptor` para Outbox (recomendado), os Domain Events também entram na mesma transação implícita.

## Quando usar `TransactionBehavior` (caso explícito)

Use quando:

1. **Command toca mais de um agregado** (precisa de `SaveChangesAsync` em mais de um repositório, ou de operações que o EF não junta automaticamente).
2. **Coordenação entre múltiplos `DbContext`** (raro — geralmente é sinal de bounded context errado).
3. **Operação inclui chamada externa** que precisa rolar back se algo posterior falhar (mas nesse caso o ideal é Outbox + Saga, não transação distribuída).

Você sinaliza pelo Command:

```csharp
public record TransferFundsCommand(
    Guid TenantId,
    Guid SourceAccountId,
    Guid DestinationAccountId,
    decimal Amount
) : IRequest<TransferFundsResponse>, IMultiAggregateCommand; // ← marker
```

`IMultiAggregateCommand` é uma **interface vazia** em `Application/Mediator/`:

```csharp
namespace MeuSaaS.Application.Mediator;

/// <summary>
/// Marker interface. Quando um Command implementa esta interface, o
/// TransactionBehavior abre uma transação explícita ao redor do Handler.
/// Use quando a operação toca mais de um agregado e o SaveChangesAsync
/// único do UoW não basta para garantir atomicidade.
/// </summary>
public interface IMultiAggregateCommand { }
```

### `TransactionBehavior` — implementação

```csharp
namespace MeuSaaS.Application.Behaviors;

public sealed class TransactionBehavior<TRequest, TResponse>(
    IDbContextProvider dbContextProvider,
    ILogger<TransactionBehavior<TRequest, TResponse>> logger)
    : IPipelineBehavior<TRequest, TResponse>
    where TRequest : IRequest<TResponse>
{
    public async Task<TResponse> Handle(
        TRequest request,
        RequestHandlerDelegate<TResponse> next,
        CancellationToken ct)
    {
        // Só dispara para Commands marcados explicitamente.
        if (request is not IMultiAggregateCommand)
            return await next();

        var context = dbContextProvider.Current;
        if (context.Database.CurrentTransaction is not null)
        {
            // Já há uma transação ambient (raro — vem de cima). Não abre outra.
            return await next();
        }

        var executionStrategy = context.Database.CreateExecutionStrategy();
        return await executionStrategy.ExecuteAsync(async () =>
        {
            await using var tx = await context.Database.BeginTransactionAsync(ct);
            try
            {
                logger.LogInformation(
                    "----- Begin transaction for {Command} -----",
                    typeof(TRequest).Name);

                var response = await next();

                await tx.CommitAsync(ct);
                logger.LogInformation(
                    "----- Commit transaction for {Command} -----",
                    typeof(TRequest).Name);

                return response;
            }
            catch
            {
                await tx.RollbackAsync(ct);
                logger.LogWarning(
                    "----- Rollback transaction for {Command} -----",
                    typeof(TRequest).Name);
                throw;
            }
        });
    }
}
```

### `IDbContextProvider` — quem dá acesso ao `DbContext` ambient

A Application **não** depende do `DbContext` concreto. Define a interface:

```csharp
namespace MeuSaaS.Application.Mediator;

public interface IDbContextProvider
{
    /// <summary>
    /// Retorna o DbContext escopado da request atual. Implementação na Infra
    /// usa o DbContext registrado como Scoped (compartilhado entre os repositórios).
    /// </summary>
    DbContext Current { get; }
}
```

Implementação na **Infra** (não desta skill):

```csharp
public sealed class DbContextProvider(MeuSaaSDbContext context) : IDbContextProvider
{
    public DbContext Current => context;
}
```

### `ExecutionStrategy` — por que é importante

`SqlServer` e `PostgreSQL` (Npgsql) suportam retry-on-failure (`EnableRetryOnFailure`). Com retry ativo, **transações explícitas falham** se você não passar pela `ExecutionStrategy`. O wrapper `executionStrategy.ExecuteAsync(...)` re-tenta toda a transação se a falha for transiente.

Sem isso, o EF lança:

> `InvalidOperationException: The configured execution strategy 'SqlServerRetryingExecutionStrategy' does not support user-initiated transactions. Use the execution strategy returned by 'DbContext.Database.CreateExecutionStrategy()' to execute all the operations in the transaction as a retriable unit.`

## Idempotência dentro da transação

Em **ambos os casos** (single-aggregate e multi-aggregate), a gravação em `ClientRequests` precisa estar **na mesma transação** do efeito. Caso contrário, você arrisca:

- Salvar `ClientRequest` mas o efeito principal sofrer rollback → a próxima retentativa do cliente vê "já processado" e não processa, mas o efeito **nunca** aconteceu.
- Salvar o efeito mas falhar ao gravar `ClientRequest` → `ClientRequests` está incompleto, próxima retentativa **reprocessa** quando não devia.

Por isso o `IRequestManager.CreateRequestForCommandAsync(...)` **NÃO chama `SaveChangesAsync`** internamente. Ele apenas adiciona o `ClientRequest` ao `DbContext`. Quem chama `SaveChangesAsync` é:

- **Single-aggregate**: o Handler real (uma chamada só, no fim).
- **Multi-aggregate**: cada repositório que precisa salvar (mais de uma chamada), e o `TransactionBehavior` abraça tudo num `BeginTransaction/Commit`.

Ver `references/idempotency.md` para o fluxo completo.

## Domain Events — onde entram na transação

Default recomendado: **Outbox via `SaveChangesInterceptor`** (Infra). O interceptor:

1. Antes do `SaveChanges`, varre `ChangeTracker` por agregados com Domain Events pendentes.
2. Serializa cada evento e adiciona registros em `Outbox` no mesmo `DbContext`.
3. Deixa o `SaveChanges` proceder — `Outbox` entra na mesma transação implícita.

Worker separado lê `Outbox` e dispara handlers/integrations.

Esse é o padrão recomendado em `improvements.md`. Sem Outbox, você tem dois cenários ruins:

- **Dispatch antes de `SaveChanges`**: handler vê o evento, age, e o `SaveChanges` falha → efeito sem causa.
- **Dispatch depois de `SaveChanges`**: processo morre entre commit e dispatch → causa sem efeito.

## Quando NÃO usar transação explícita

- **Toda operação possível**. O EF é eficiente com transações implícitas. Abrir transação explícita para single-aggregate é desperdício.
- **Para "ter certeza"**. Não se ganha nada — `SaveChanges` já é atômico.
- **Para envolver chamadas externas**. Transação distribuída entre DB e API externa não funciona. Use Outbox + Saga.

## Anti-padrões

```csharp
// ❌ Handler abrindo transação manualmente
public async Task<...> Handle(...)
{
    using var tx = await _context.Database.BeginTransactionAsync(ct);
    try { ... await tx.CommitAsync(ct); }
    catch { await tx.RollbackAsync(ct); throw; }
}
// O behavior cuida disso. Handler fica focado na lógica.

// ❌ Salvar duas vezes em SaveChanges separados sem transação explícita
await repoA.UnitOfWork.SaveChangesAsync(ct);
// ... algo pode falhar aqui ...
await repoB.UnitOfWork.SaveChangesAsync(ct);
// Se for atômico necessário, marca o Command com IMultiAggregateCommand.

// ❌ Engolir exceção dentro da transação
try { ... } catch { /* engole */ }
// Behavior nunca sabe que precisa fazer rollback. Operação fica em estado zumbi.

// ❌ TransactionScope (do System.Transactions)
using var scope = new TransactionScope();
// EF Core 6+ tem suporte limitado e cria conexões duplicadas. Use BeginTransactionAsync.
```

## Checklist

- [ ] Default: `await repo.UnitOfWork.SaveChangesAsync(ct)` no fim do Handler.
- [ ] `IRequestManager.CreateRequestForCommandAsync(...)` **não** chama `SaveChangesAsync`.
- [ ] Para Command que toca >1 agregado: implementar `IMultiAggregateCommand`.
- [ ] `TransactionBehavior` registrado no DI (sempre — só dispara para o marker).
- [ ] `IDbContextProvider` definido em `Application/Mediator/`, implementado em Infra.
- [ ] Behavior usa `CreateExecutionStrategy().ExecuteAsync(...)` — necessário com retry-on-failure.
- [ ] Outbox para Domain Events (Infra) — ver `improvements.md`.
- [ ] **Nunca** abrir transação manualmente no Handler.
