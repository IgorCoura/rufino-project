# Persistência — Change Tracking, `UnitOfWork.SaveChangesAsync` e Transações

A camada Application coordena escrita confiando em **três mecanismos do EF** que devem ser entendidos antes de tudo:

1. **Change Tracking** — o `ChangeTracker` do EF observa as entidades carregadas via busca tracked e detecta mutações automaticamente.
2. **`SaveChangesAsync` único do Unit of Work** — default para qualquer operação que toca **um** agregado. Atômico no nível do EF (transação implícita).
3. **Transação explícita** (`BeginTransactionAsync` + `CommitAsync`) — exceção controlada, automatizada via `TransactionBehavior` quando o Command implementa `IMultiAggregateCommand`.

> **Princípio que orienta tudo aqui**: a Application *prefere* `SaveChangesAsync` único; multi-agregado tenta resolver por **Domain Event + Outbox** antes de cogitar `IMultiAggregateCommand`.

---

## Change Tracking — por que isto importa

O Repository desta arquitetura devolve entidades **tracked** (sem `AsNoTracking`). Isso significa que o `ChangeTracker` do `DbContext` passa a observar cada propriedade do agregado, incluindo as entidades internas e Value Objects mapeados.

Quando o Handler chama o método rico do agregado:

```csharp
contract.Terminate(request.TerminationDate, lastInflowPeriod, occurredAt);
```

…o método interno do agregado pode alterar várias propriedades, cancelar entidades filhas, mudar status, etc. **O `ChangeTracker` registra cada uma dessas mutações.** Quando o Handler chama `SaveChangesAsync`, o EF gera o `UPDATE` apropriado, alterando **só** as colunas que mudaram.

### O que isto remove do Handler

**Você não precisa, e não deve, chamar `repo.Update(aggregate)`:**

```csharp
// ❌ ANTIPADRÃO
contract.Terminate(...);
repo.Update(contract);                                  // ← supérfluo, danoso
await repo.UnitOfWork.SaveChangesAsync(ct);

// ✅ CORRETO
contract.Terminate(...);
await repo.UnitOfWork.SaveChangesAsync(ct);             // Change Tracking faz o trabalho
```

Por que `Update()` é danoso aqui:

1. **Marca todas as propriedades como modificadas**, mesmo as que não mudaram. O `UPDATE` gerado escreve colunas desnecessárias.
2. **Conflita com `[ConcurrencyCheck]` / `RowVersion`** — sobrescreve campos que você pretendia controlar otimisticamente.
3. **Mascara entidades detached.** Se a entidade veio detached por bug (ex.: cache mal usado), `Update()` "resolve" silenciosamente — esconde o defeito.
4. **Confunde leitor**. Quem revisa o código fica em dúvida sobre o estado da entidade.

A única situação legítima de `repo.Update(entity)` é trabalhar com entidade detached (vinda de cache externo, request anterior, deserialização). Em Handler de Application **isso nunca acontece**: o Handler busca via repositório, na request atual, no `DbContext` escopado da request.

### Tracking vs No-Tracking — separação CQRS

| Lado | Quem usa | Tracking? |
|---|---|---|
| Command | `IXxxRepository` chamado pelo Handler | **Tracked** (`FirstOrDefaultAsync` sem `.AsNoTracking()`) |
| Query | `IXxxQueries` chamado fora do mediator (pela API) | **NoTracking** (`AsNoTracking()` explícito) |

A skill **recusa** gerar Handler que chame Queries pra alimentar mutação, e recusa repositório que devolva `AsNoTracking()` por default. Repositório é lado de escrita.

---

## Default: `SaveChangesAsync` único do Unit of Work

Vale para **a esmagadora maioria dos Commands**. Características:

- Toca **um único agregado** (cria, altera ou deleta).
- Idempotência via `IRequestManager` que **participa do mesmo `SaveChangesAsync`** (gravação de `ClientRequest` + agregado na mesma transação implícita do EF).
- Domain Events do agregado entram no Outbox no mesmo `SaveChanges` via interceptor (ver `improvements.md`).

Exemplo canônico:

```csharp
public sealed class ApproveBillCommandHandler(IBillRepository repo)
    : IRequestHandler<ApproveBillCommand, ApproveBillResponse>
{
    public async Task<ApproveBillResponse> Handle(
        ApproveBillCommand request, CancellationToken ct)
    {
        var bill = await repo.FirstOrDefaultAsync(
            x => x.TenantId == request.TenantId && x.Id == request.BillId, ct)
            ?? throw BillErrors.NotFound(request.BillId);

        bill.Approve(request.ApproverId, DateTime.UtcNow);   // método rico decide tudo

        await repo.UnitOfWork.SaveChangesAsync(ct);          // atômico no nível do EF
        return new ApproveBillResponse(bill.Id);
    }
}
```

Por que isso é seguro:

- O EF abre uma transação implícita ao redor de `SaveChangesAsync`. Falha (constraint, concorrência) → rollback automático.
- O `ClientRequest` (idempotência) é inserido no mesmo `DbContext`. Vai junto.
- Com `SaveChangesInterceptor` para Outbox, os Domain Events também entram na mesma transação implícita.

---

## Multi-agregado — caminho default é Domain Event, não `IMultiAggregateCommand`

Quando a operação descrita pelo usuário aparenta mexer em mais de um agregado, a primeira pergunta da skill é:

> "Os dois agregados precisam estar consistentes **imediatamente** (mesma transação), ou é aceitável que a propagação aconteça em segundos/minutos?"

Em 95% dos casos, **eventual consistency é aceitável** — e Vernon argumenta com cuidado que mesmo quando soa "imediato", quase sempre não é necessário. O caminho correto:

### Padrão Outbox + Domain Event (default)

```csharp
// 1) Handler do Command — modifica APENAS o agregado-raiz.
public sealed class RegisterEconomicEventCommandHandler(
    IEconomicEventRepository eventRepo,
    IEconomicContractRepository contractRepo)
    : IRequestHandler<RegisterEconomicEventCommand, RegisterEconomicEventResponse>
{
    public async Task<...> Handle(RegisterEconomicEventCommand request, CancellationToken ct)
    {
        // contractRepo aqui é só pra LER — alimentar o factory. Não modifica.
        var contract = await contractRepo.FirstOrDefaultAsync(
            c => c.Id == request.ContractId && c.TenantId == request.TenantId, ct)
            ?? throw EconomicContractErrors.NotFound(request.ContractId);

        var commitment = contract.FindCommitment(request.CommitmentId);

        var economicEvent = EconomicEvent.RegisterInflowCoverageFor(contract, commitment, request.OccurredAt, request.UserId);
        await eventRepo.AddAsync(economicEvent);
        await eventRepo.UnitOfWork.SaveChangesAsync(ct);   // Outbox inscreve EconomicEventRegistered

        return new RegisterEconomicEventResponse(economicEvent.Id);
    }
}

// 2) Handler de Integration Event (consome do Outbox) — modifica o segundo agregado em OUTRA transação.
public sealed class MarkCommitmentFulfilledHandler(IEconomicContractRepository contractRepo)
    : IRequestHandler<EconomicEventRegisteredIntegrationEvent, Unit>
{
    public async Task<Unit> Handle(EconomicEventRegisteredIntegrationEvent evt, CancellationToken ct)
    {
        var contract = await contractRepo.FirstOrDefaultAsync(
            c => c.Id == evt.ContractId && c.TenantId == evt.TenantId, ct)
            ?? throw EconomicContractErrors.NotFound(evt.ContractId);

        contract.MarkFulfilled(evt.CommitmentId, evt.EconomicEventId, evt.OccurredAt);  // idempotente por design
        await contractRepo.UnitOfWork.SaveChangesAsync(ct);

        return Unit.Value;
    }
}
```

Pontos:

- Cada Handler modifica **um único agregado**.
- Idempotência no segundo handler: `MarkFulfilled` deve ser **no-op** se o commitment já está fulfilled. Agregado decide.
- Outbox + retry garantem que a propagação acontece, mesmo se o segundo handler falhar transitivamente.
- `IMultiAggregateCommand` **não é usado** aqui — não é necessário.

### Exceção controlada: `IMultiAggregateCommand`

Use **só** quando a operação se enquadra em uma das 4 exceções do Vernon, traduzidas pro nosso vocabulário:

1. **UI batch.** Criar N agregados independentes a partir de um clique (sem invariante atravessando — só conveniência).
2. **Sem infraestrutura de eventual consistency.** Projeto que ainda não tem Outbox/worker — caminho temporário. Documente a dívida.
3. **Transação global obrigada por regulação ou stack legado.** Raro.
4. **User-aggregate affinity garantida.** Mesmo usuário é dono dos dois agregados, contenção concorrente desprezível.

Fora dessas, a skill **recusa** o atalho e oferece o padrão Outbox.

Quando legítimo, sinaliza pelo Command:

```csharp
public record TransferFundsCommand(
    Guid TenantId,
    Guid SourceAccountId,
    Guid DestinationAccountId,
    decimal Amount
) : IRequest<TransferFundsResponse>, IMultiAggregateCommand;
```

`IMultiAggregateCommand` é uma **interface vazia** em `Application/Mediator/`:

```csharp
namespace MeuSaaS.Application.Mediator;

/// <summary>
/// Marker interface. Quando um Command implementa esta interface, o
/// TransactionBehavior abre uma transação explícita ao redor do Handler.
/// Use apenas para os casos onde Domain Event + Outbox não é viável.
/// Justifique no XML doc do Command qual das 4 exceções do Vernon se aplica.
/// </summary>
public interface IMultiAggregateCommand { }
```

### `TransactionBehavior` — implementação

```csharp
namespace MeuSaaS.Application.Behaviors;

public sealed class TransactionBehavior<TRequest, TResponse>(
    IDbContextProvider dbContextProvider,
    ILogger<TransactionBehavior<TRequest, TResponse>> logger)
    : IPipelineBehavior<TRequest, TResponse>
    where TRequest : IRequest<TResponse>
{
    public async Task<TResponse> Handle(
        TRequest request,
        RequestHandlerDelegate<TResponse> next,
        CancellationToken ct)
    {
        // Só dispara para Commands marcados explicitamente.
        if (request is not IMultiAggregateCommand)
            return await next();

        var context = dbContextProvider.Current;
        if (context.Database.CurrentTransaction is not null)
        {
            // Já há uma transação ambient (raro — vem de cima). Não abre outra.
            return await next();
        }

        var executionStrategy = context.Database.CreateExecutionStrategy();
        return await executionStrategy.ExecuteAsync(async () =>
        {
            await using var tx = await context.Database.BeginTransactionAsync(ct);
            try
            {
                logger.LogInformation(
                    "----- Begin transaction for {Command} -----",
                    typeof(TRequest).Name);

                var response = await next();

                await tx.CommitAsync(ct);
                logger.LogInformation(
                    "----- Commit transaction for {Command} -----",
                    typeof(TRequest).Name);

                return response;
            }
            catch
            {
                await tx.RollbackAsync(ct);
                logger.LogWarning(
                    "----- Rollback transaction for {Command} -----",
                    typeof(TRequest).Name);
                throw;
            }
        });
    }
}
```

Mesmo dentro de um Command marcado com `IMultiAggregateCommand`, a regra de **não chamar `repo.Update(...)`** continua valendo. As entidades carregadas via repositório dentro do Handler estão tracked — o `SaveChangesAsync` de cada repositório (ou um único no fim) detecta as mudanças. A transação só serve pra agrupar atomicamente.

### `IDbContextProvider` — quem dá acesso ao `DbContext` ambient

A Application **não** depende do `DbContext` concreto. Define a interface:

```csharp
namespace MeuSaaS.Application.Mediator;

public interface IDbContextProvider
{
    /// <summary>
    /// Retorna o DbContext escopado da request atual. Implementação na Infra
    /// usa o DbContext registrado como Scoped (compartilhado entre os repositórios).
    /// </summary>
    DbContext Current { get; }
}
```

Implementação na **Infra** (não desta skill):

```csharp
public sealed class DbContextProvider(MeuSaaSDbContext context) : IDbContextProvider
{
    public DbContext Current => context;
}
```

### `ExecutionStrategy` — por que é importante

`SqlServer` e `PostgreSQL` (Npgsql) suportam retry-on-failure (`EnableRetryOnFailure`). Com retry ativo, **transações explícitas falham** se você não passar pela `ExecutionStrategy`. O wrapper `executionStrategy.ExecuteAsync(...)` re-tenta toda a transação se a falha for transiente.

Sem isso, o EF lança:

> `InvalidOperationException: The configured execution strategy 'SqlServerRetryingExecutionStrategy' does not support user-initiated transactions. Use the execution strategy returned by 'DbContext.Database.CreateExecutionStrategy()' to execute all the operations in the transaction as a retriable unit.`

---

## Idempotência dentro da transação

Em **ambos os casos** (single-aggregate e multi-aggregate), a gravação em `ClientRequests` precisa estar **na mesma transação** do efeito. Caso contrário, você arrisca:

- Salvar `ClientRequest` mas o efeito principal sofrer rollback → próxima retentativa vê "já processado", mas o efeito **nunca** aconteceu.
- Salvar o efeito mas falhar ao gravar `ClientRequest` → `ClientRequests` incompleto, próxima retentativa **reprocessa**.

Por isso o `IRequestManager.CreateRequestForCommandAsync(...)` **NÃO chama `SaveChangesAsync`** internamente. Ele apenas adiciona o `ClientRequest` ao `DbContext`. Quem chama `SaveChangesAsync` é:

- **Single-aggregate**: o Handler real (uma chamada só, no fim).
- **Multi-aggregate**: cada repositório que precisa salvar (mais de uma chamada), e o `TransactionBehavior` abraça tudo num `BeginTransaction/Commit`.

Ver `references/idempotency.md` para o fluxo completo.

---

## Domain Events — onde entram na transação

Default recomendado: **Outbox via `SaveChangesInterceptor`** (Infra). O interceptor:

1. Antes do `SaveChanges`, varre `ChangeTracker` por agregados com Domain Events pendentes.
2. Serializa cada evento e adiciona registros em `Outbox` no mesmo `DbContext`.
3. Deixa o `SaveChanges` proceder — `Outbox` entra na mesma transação implícita.

Worker separado lê `Outbox` e dispara handlers/integrations em **outra transação**, com retry. É isso que viabiliza o padrão de eventual consistency descrito acima.

Sem Outbox, você tem dois cenários ruins:

- **Dispatch antes de `SaveChanges`**: handler vê o evento, age, e o `SaveChanges` falha → efeito sem causa.
- **Dispatch depois de `SaveChanges`**: processo morre entre commit e dispatch → causa sem efeito.

---

## Anti-padrões

```csharp
// ❌ Update() antes de SaveChanges (entidade já tracked)
contract.Terminate(...);
_contractRepo.Update(contract);
await _contractRepo.UnitOfWork.SaveChangesAsync(ct);
// Remove o Update. SaveChanges detecta sozinho.

// ❌ Handler abrindo transação manualmente
public async Task<...> Handle(...)
{
    using var tx = await _context.Database.BeginTransactionAsync(ct);
    try { ... await tx.CommitAsync(ct); }
    catch { await tx.RollbackAsync(ct); throw; }
}
// TransactionBehavior cuida disso. Handler fica focado na lógica.

// ❌ Modificar dois agregados sem marker, sem Domain Event
await _agregadoA_repo.UnitOfWork.SaveChangesAsync(ct);  // salvou agregado A
// ... algo pode falhar aqui ...
await _agregadoB_repo.UnitOfWork.SaveChangesAsync(ct);  // perdeu atomicidade
// Se realmente precisa atomicidade, marca com IMultiAggregateCommand.
// Senão, transformar uma das modificações em Domain Event + handler async.

// ❌ Engolir exceção dentro da transação
try { ... } catch { /* engole */ }
// Behavior nunca sabe que precisa fazer rollback. Operação fica em estado zumbi.

// ❌ TransactionScope (do System.Transactions)
using var scope = new TransactionScope();
// EF Core 6+ tem suporte limitado e cria conexões duplicadas. Use BeginTransactionAsync.

// ❌ AsNoTracking em repositório de Command
public Task<Contract?> FirstOrDefaultAsync(...) =>
    _db.Contracts.AsNoTracking().FirstOrDefaultAsync(...);
// Remove o AsNoTracking. Repositório de Command devolve tracked.
```

---

## Checklist

- [ ] Default: `await repo.UnitOfWork.SaveChangesAsync(ct)` no fim do Handler.
- [ ] **Zero `repo.Update(...)` no código gerado.** Change Tracking faz o trabalho.
- [ ] **Repositório de Command devolve entidade tracked** (sem `AsNoTracking`).
- [ ] `IRequestManager.CreateRequestForCommandAsync(...)` **não** chama `SaveChangesAsync`.
- [ ] **Operação que parece tocar >1 agregado**: primeira tentativa é redesenhar com Domain Event + handler async.
- [ ] Só usar `IMultiAggregateCommand` se cair em uma das 4 exceções (documentar qual no XML doc).
- [ ] `TransactionBehavior` registrado no DI (sempre — só dispara para o marker).
- [ ] `IDbContextProvider` definido em `Application/Mediator/`, implementado em Infra.
- [ ] Behavior usa `CreateExecutionStrategy().ExecuteAsync(...)` — necessário com retry-on-failure.
- [ ] Outbox para Domain Events (Infra) — ver `improvements.md`.
- [ ] **Nunca** abrir transação manualmente no Handler.
