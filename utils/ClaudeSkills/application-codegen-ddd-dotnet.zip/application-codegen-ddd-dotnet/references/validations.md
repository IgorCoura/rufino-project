# Validações de Application — metodologia própria

Esta camada **só ganha validações quando o usuário pedir explicitamente** com frase parecida a:

> "Crie validações de aplicação para o Command `CreateBill`."

Ou:

> "Adicione validação para `<campo>` no Command `<X>`."

**A skill nunca cria validações automaticamente** ao gerar Command/Handler. Pode (deve) **alertar** que o Command parece se beneficiar de validação, mas não cria.

## Princípios

1. **Sem FluentValidation, sem MediatR.Validation, sem nenhum pacote externo de validação.** Só recursos do .NET (DataAnnotations) + interfaces customizadas + lógica imperativa quando preciso.
2. **Validação é da Application, não do Domain.** Trata input do Command (formato, presença, faixa, formato regex). Regras de negócio (CPF é válido como entidade fiscal? esse approver pode aprovar?) ficam **no agregado** e lançam `DomainException`.
3. **Falha de validação = `CommandValidationException`** (exception técnica simples em `Application/Behaviors/`, com lista de mensagens — sem catálogo, sem código). Filtro da API mapeia → 400. Ver `references/error-handling.md`.
4. **Behavior automático.** Validações rodam no `ValidatorBehavior` do mediator — Handler não chama validador manualmente.
5. **Um validator por Command.** Mesmo namespace, arquivo separado.

## Onde mora

```
Application/
└── Validations/
    ├── ValidatorAssembly.cs                    ← marker assembly
    ├── IValidator.cs                           ← interface base
    ├── ValidationResult.cs                     ← resultado
    ├── ValidationFailure.cs                    ← cada falha
    └── BillCommands/
        ├── CreateBillCommandValidator.cs       ← gerado quando pedido
        └── ApproveBillCommandValidator.cs      ← gerado quando pedido
```

## Tipos base

### `IValidator<TCommand>`

```csharp
namespace MeuSaaS.Application.Validations;

public interface IValidator<in TCommand>
{
    ValueTask<ValidationResult> ValidateAsync(TCommand command, CancellationToken ct = default);
}
```

`ValueTask` para o caso comum (validação síncrona — sem alocação). Async fica disponível quando o validator precisa consultar algo (ex.: verificar se um valor já existe no banco — embora geralmente isso é responsabilidade do Domain).

### `ValidationResult` e `ValidationFailure`

```csharp
namespace MeuSaaS.Application.Validations;

public sealed record ValidationFailure(string Field, string Message);

public sealed record ValidationResult(IReadOnlyList<ValidationFailure> Failures)
{
    public bool IsValid => Failures.Count == 0;

    public static ValidationResult Success { get; } = new(Array.Empty<ValidationFailure>());

    public static ValidationResult Fail(params ValidationFailure[] failures) => new(failures);

    public static ValidationResult Fail(string field, string message) =>
        new(new[] { new ValidationFailure(field, message) });
}
```

### Builder leve (opcional, para reduzir boilerplate)

```csharp
namespace MeuSaaS.Application.Validations;

public sealed class ValidationBuilder
{
    private readonly List<ValidationFailure> _failures = new();

    public ValidationBuilder Require(bool condition, string field, string message)
    {
        if (!condition) _failures.Add(new(field, message));
        return this;
    }

    public ValidationBuilder RequireNotEmpty(string? value, string field) =>
        Require(!string.IsNullOrWhiteSpace(value), field, $"{field} é obrigatório.");

    public ValidationBuilder RequireMaxLength(string? value, int max, string field) =>
        Require(value is null || value.Length <= max, field, $"{field} excede o tamanho máximo de {max}.");

    public ValidationBuilder RequireRange<T>(T value, T min, T max, string field) where T : IComparable<T> =>
        Require(value.CompareTo(min) >= 0 && value.CompareTo(max) <= 0, field, $"{field} deve estar entre {min} e {max}.");

    public ValidationBuilder RequireRegex(string? value, string pattern, string field, string message) =>
        Require(value is not null && System.Text.RegularExpressions.Regex.IsMatch(value, pattern), field, message);

    public ValidationBuilder RequireNotEmpty(Guid value, string field) =>
        Require(value != Guid.Empty, field, $"{field} é obrigatório.");

    public ValidationResult Build() =>
        _failures.Count == 0 ? ValidationResult.Success : new(_failures);
}
```

## Validator concreto — exemplo

Quando o usuário pede *"crie validações para `CreateBillCommand`"*, a skill gera:

```csharp
namespace MeuSaaS.Application.Validations.BillCommands;

using MeuSaaS.Application.Commands.BillCommands.CreateBill;

public sealed class CreateBillCommandValidator : IValidator<CreateBillCommand>
{
    public ValueTask<ValidationResult> ValidateAsync(
        CreateBillCommand command, CancellationToken ct = default)
    {
        var result = new ValidationBuilder()
            .RequireNotEmpty(command.TenantId, nameof(command.TenantId))
            .RequireNotEmpty(command.Description, nameof(command.Description))
            .RequireMaxLength(command.Description, 200, nameof(command.Description))
            .RequireRange(command.Amount, 0.01m, 1_000_000m, nameof(command.Amount))
            .RequireRegex(command.DocumentCode, @"^[A-Z]{3}-\d{6}$",
                nameof(command.DocumentCode),
                "DocumentCode deve seguir o formato AAA-000000.")
            .Build();

        return ValueTask.FromResult(result);
    }
}
```

Pontos:

- `sealed class`. Sempre.
- Construtor primário se houver dependências (ex.: validação que precisa de query — raro).
- Quase sempre síncrono → `ValueTask.FromResult(...)`.
- **Não chama o banco**. Se a validação precisa consultar dado, ou (a) é regra de domínio (vai pro agregado/domain service), ou (b) é validação de "não duplicar" via constraint do banco (deixa subir como `DbUpdateException` e o filter da API mapeia).

## Alternativa: DataAnnotations

Para casos triviais, dá pra usar DataAnnotations direto no Command/Model — sem precisar de validator próprio:

```csharp
public record CreateBillModel(
    [Required, StringLength(200)]
    string Description,

    [Range(0.01, 1_000_000)]
    decimal Amount,

    [Required, RegularExpression(@"^[A-Z]{3}-\d{6}$")]
    string DocumentCode);
```

A camada **API** (não desta skill) tem `[ApiController]` que dispara DataAnnotations automaticamente no model binding e devolve 400 sem chegar ao mediator. **Bom para validação rasa**.

Quando usar DataAnnotations vs `IValidator<TCommand>`:

| Situação | Use |
|---|---|
| Validação rasa de campo (formato, tamanho, presença) que cabe num atributo | DataAnnotations no Model (não no Command) |
| Validação que combina campos (`StartDate < EndDate`) | `IValidator<TCommand>` |
| Validação que precisa de contexto async | `IValidator<TCommand>` |
| Validação que não tem Model HTTP (Command vem direto via [FromBody]) | `IValidator<TCommand>` |

A skill **prefere `IValidator<TCommand>`** quando vai gerar — vale para **qualquer** caso, é uniforme, e não depende do `[ApiController]` ter sido configurado certo na API.

## `ValidatorBehavior`

Roda antes do Handler. Resolve `IValidator<TCommand>` registrados, executa, agrega falhas, lança `CommandValidationException`:

```csharp
namespace MeuSaaS.Application.Behaviors;

using MeuSaaS.Application.Validations;

public sealed class ValidatorBehavior<TRequest, TResponse>(
    IEnumerable<IValidator<TRequest>> validators)
    : IPipelineBehavior<TRequest, TResponse>
    where TRequest : IRequest<TResponse>
{
    public async Task<TResponse> Handle(
        TRequest request,
        RequestHandlerDelegate<TResponse> next,
        CancellationToken ct)
    {
        if (!validators.Any())
            return await next();

        var failures = new List<ValidationFailure>();
        foreach (var v in validators)
        {
            var result = await v.ValidateAsync(request, ct);
            if (!result.IsValid)
                failures.AddRange(result.Failures);
        }

        if (failures.Count == 0)
            return await next();

        var messages = failures
            .Select(f => $"{f.Field}: {f.Message}")
            .ToList();

        throw new CommandValidationException(messages);
    }
}
```

`CommandValidationException` é uma exception técnica simples (sem catálogo, sem template, sem código), definida em `Application/Behaviors/`:

```csharp
namespace MeuSaaS.Application.Behaviors;

public sealed class CommandValidationException : Exception
{
    public IReadOnlyList<string> Failures { get; }

    public CommandValidationException(IReadOnlyList<string> failures)
        : base("O Command falhou em uma ou mais validações.")
    {
        Failures = failures ?? Array.Empty<string>();
    }
}
```

Por que não é `DomainException`? Porque o que `CommandValidationException` comunica é "o input não chegou em condição de ser interpretado como negócio" — é equivalente ao parsing falhar no ModelBinder, não um erro de regra. Não há entidade ou regra de domínio envolvida. O filtro da API mapeia → 400 com o array `Failures`. Ver `references/error-handling.md`.

Note:

- Suporta múltiplos validators para o mesmo Command (raramente útil, mas o framework não impede).
- Falhas agregadas em uma única `CommandValidationException`.
- Se nenhum validator está registrado, behavior se torna no-op — nada acontece.

## Registro no DI

A skill **descomenta** as duas linhas em `Application/Extension/ApplicationExtensions.cs` quando o usuário pede a primeira validação:

```csharp
// services.AddScoped(typeof(IPipelineBehavior<,>), typeof(ValidatorBehavior<,>));
//                                  ↑
//                          vira ativo aqui
```

E registra cada `IValidator<TCommand>` concreto via scan:

```csharp
public static IServiceCollection AddApplicationDependencies(this IServiceCollection services)
{
    // ... (queries, outras coisas)

    services.AddScoped(typeof(IPipelineBehavior<,>), typeof(LoggingBehavior<,>));
    services.AddScoped(typeof(IPipelineBehavior<,>), typeof(ValidatorBehavior<,>));   // ativo
    services.AddScoped(typeof(IPipelineBehavior<,>), typeof(TransactionBehavior<,>));

    // Scan automático de validators no assembly de Validations
    foreach (var t in typeof(ValidatorAssembly).Assembly.GetTypes())
    {
        var iface = t.GetInterfaces().FirstOrDefault(i =>
            i.IsGenericType &&
            i.GetGenericTypeDefinition() == typeof(IValidator<>));
        if (iface is not null && !t.IsAbstract && !t.IsInterface)
            services.AddScoped(iface, t);
    }

    return services;
}
```

## Onde NÃO usar validações de Application

- **Validar regra de negócio do agregado.** Ex.: "Bill paga não pode ser modificada" — isso é responsabilidade do agregado, lança `DomainException` via `BillErrors.CannotModifyPaidBill()`.
- **Validar que dado existe no banco.** Ex.: "ResourceId existe?" — se é referência a outro agregado, valida no Handler via `<Other>Repository.ExistsAsync(id, tenantId, ct)` + `throw <OtherAgg>Errors.NotFound(id)`. Se a operação assume existência do agregado-raiz, busca com `?? throw <Agg>Errors.NotFound(id)`. Em ambos os casos, **factory de erro vive no Domain**, não na Application. Ver `references/handler-anatomy.md` → "Validação de IDs recebidos é obrigatória".
- **Autorizar.** Autorização é do Identity Provider (Keycloak) + filtros da API. O filtro de `TenantId` na query torna acesso cross-tenant inviável (vira `NotFound`). Não é validação de input.

## Anti-padrões

```csharp
// ❌ Validator com CPF/regra de negócio
public sealed class CreateEmployeeCommandValidator : IValidator<CreateEmployeeCommand>
{
    public ValueTask<ValidationResult> ValidateAsync(...)
    {
        // CPF validação digita por dígito (regra de domínio fiscal)
        // → MOVE PARA O VALUE OBJECT Cpf no Domain.
    }
}

// ❌ Lógica de validação dentro do Handler
public async Task<...> Handle(CreateBillCommand request, ...)
{
    if (string.IsNullOrEmpty(request.Description))
        throw new CommandValidationException(new[] { "Description é obrigatório" });
    // Move pro Validator. Handler é orquestração.
}

// ❌ Importar FluentValidation
using FluentValidation;       // proibido neste projeto
public class V : AbstractValidator<...> { ... }
```

## Checklist ao adicionar validação

- [ ] Confirmar com o usuário **quais campos** validar (não inventar regras).
- [ ] Validador em `Application/Validations/<Aggregate>Commands/<Command>Validator.cs`.
- [ ] `sealed class` implementando `IValidator<TCommand>`.
- [ ] Assinatura `ValueTask<ValidationResult>` retornando `ValueTask.FromResult(...)` quando síncrono.
- [ ] Construído com `ValidationBuilder` ou lógica imperativa direta — sem libs externas.
- [ ] Não consulta o banco (a menos que o usuário tenha pedido caso específico — alertar).
- [ ] `ValidatorBehavior` ativado no `ApplicationExtensions.cs` (descomentar a linha se for o primeiro).
- [ ] Não duplicar regras que já estão no agregado (separação clara: input vs invariante).
